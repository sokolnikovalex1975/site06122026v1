<!doctype html>
<html lang="ru">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>Разработка программы производственного контроля (ППК) и ППК по ХАССП в Москве — ПЕСТКОНТРОЛЬ Центр</title>
<meta name="description" content="Разработка ППК под ваш объект: от 5 900 ₽ за 1 рабочий день, ППК по ХАССП для общепита и пищевых производств — от 19 900 ₽ за 3 рабочих дня. Нормы 2026 года, план-график исследований, приказ и журналы.">
<link rel="canonical" href="https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/razrabotka-ppk/">
<meta name="theme-color" content="#000000">
<meta property="og:type" content="website">
<meta property="og:locale" content="ru_RU">
<meta property="og:site_name" content="ПЕСТКОНТРОЛЬ Центр">
<meta property="og:url" content="https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/razrabotka-ppk/">
<meta property="og:title" content="Разработка ППК и ППК по ХАССП — программа производственного контроля под ваш объект">
<meta property="og:description" content="Разработка ППК под ваш объект: от 5 900 ₽ за 1 рабочий день, ППК по ХАССП для общепита и пищевых производств — от 19 900 ₽ за 3 рабочих дня. Нормы 2026 года, план-график исследований, приказ и журналы.">
<meta property="og:image" content="https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/img/rppk-og.jpg">
<meta property="og:image:type" content="image/jpeg">
<meta property="og:image:width" content="1200">
<meta property="og:image:height" content="630">
<meta property="og:image:alt" content="Специалист и владелец пекарни изучают распечатанную программу производственного контроля">
<meta name="twitter:card" content="summary_large_image">
<link rel="icon" href="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 32 32'%3E%3Ccircle cx='16' cy='16' r='15' fill='%2309090b' stroke='%237c86ff' stroke-width='2'/%3E%3Cpath d='M16 7l7 3v5c0 5-3 8.5-7 10-4-1.5-7-5-7-10v-5z' fill='none' stroke='%23fff' stroke-width='2'/%3E%3C/svg%3E">
<link rel="preload" href="../fonts/inter-ru-wght-normal.woff2" as="font" type="font/woff2" crossorigin>
<link rel="preload" as="image" media="(min-width:761px)" imagesrcset="../img/rppk-hero-1440.webp 1440w, ../img/rppk-hero.webp 1920w" imagesizes="100vw" fetchpriority="high">
<link rel="preload" as="image" media="(max-width:760px)" imagesrcset="../img/rppk-hero-mob-760.webp 760w, ../img/rppk-hero-mob.webp 1024w" imagesizes="100vw" fetchpriority="high">
<script>
  /* начальные состояния анимаций — только при работающем JS; страховка — через 4 с всё показывается.
     Заставка — один раз за посещение: при переходе по ссылке с якорем и между страницами сайта её нет */
  (function (d) {
    d.classList.add('js');
    try { if (location.hash || sessionStorage.getItem('pc-intro')) d.classList.add('no-intro'); else sessionStorage.setItem('pc-intro', '1'); }
    catch (e) { if (location.hash) d.classList.add('no-intro'); }
    setTimeout(function () { if (!d.classList.contains('anim-ready')) d.classList.add('anim-fail'); }, 4000);
  })(document.documentElement);
</script>
<link rel="stylesheet" href="../style.css?v=20261106s2">
<style>.d-page .s{padding:clamp(64px,7vw,128px) 0;border-top:1px solid var(--line)}.d-crumbs{padding-top:calc(clamp(68px,6vw,115px) + 20px);font-size:14px;color:var(--t3);display:flex;flex-wrap:wrap;gap:8px}.d-crumbs a{color:var(--t2)}.d-crumbs a:hover{color:var(--t1)}.d-hero{padding:clamp(28px,3vw,56px) 0 clamp(64px,7vw,128px)}.d-hero .wrap{display:grid;grid-template-columns:minmax(0,1.15fr) minmax(0,.85fr);gap:clamp(28px,4vw,80px);align-items:center}.d-hero h1{font-size:clamp(34px,4.2vw,80px);line-height:1.05;letter-spacing:-.045em;font-weight:300;margin:18px 0 0}.d-ticks{list-style:none;padding:0;margin:28px 0 34px;display:grid;gap:12px}.d-ticks li{position:relative;padding-left:30px;line-height:1.5}.d-ticks li::before{content:"";position:absolute;left:2px;top:.42em;width:13px;height:7px;border-left:2px solid var(--acc);border-bottom:2px solid var(--acc);transform:rotate(-45deg)}.d-btns{display:flex;flex-wrap:wrap;gap:12px}.ph-img{aspect-ratio:4/3;border:1.5px dashed var(--line2);border-radius:var(--r);display:flex;align-items:center;justify-content:center;text-align:center;padding:28px;color:var(--t3);font-size:14px;line-height:1.5;background:rgba(255,255,255,.02)}.ph-doc{aspect-ratio:3/4;max-width:340px}.d-cards{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:16px}.d-card{background:var(--card);border:1px solid var(--line2);border-radius:var(--r);padding:clamp(22px,2vw,34px)}.d-card h3{font-size:clamp(20px,1.5vw,26px);font-weight:400;letter-spacing:-.02em;margin:0 0 12px}.d-card p{color:var(--t2);line-height:1.6;margin:0}.d-note{color:var(--t2);margin:24px 0 0;line-height:1.6}.d-strong{color:var(--t1);font-size:clamp(18px,1.3vw,22px)}.d-split{display:grid;grid-template-columns:minmax(0,1fr) minmax(0,340px);gap:clamp(28px,4vw,80px);align-items:start}.d-two{display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1fr);gap:clamp(28px,4vw,80px);align-items:start}.d-two .head{margin-bottom:0}.d-two .d-ticks{margin:0}.d-terms{list-style:none;counter-reset:t;padding:0;margin:0;border-top:1px solid var(--line2)}.d-terms li{display:grid;grid-template-columns:44px minmax(0,.42fr) minmax(0,1fr);gap:16px;padding:18px 0;border-bottom:1px solid var(--line2);line-height:1.55}.d-terms li::before{counter-increment:t;content:counter(t,decimal-leading-zero);color:var(--t3)}.d-terms b{font-weight:500}.d-terms span{color:var(--t2)}.d-doc{display:grid;gap:16px;justify-items:start}.d-small{font-size:14px;color:var(--t3);margin:0}.d-steps{list-style:none;counter-reset:st;padding:0;margin:0;display:grid;grid-template-columns:repeat(5,minmax(0,1fr));gap:18px}.d-steps li{border-top:2px solid var(--line2);padding-top:18px;line-height:1.55}.d-steps li::before{counter-increment:st;content:"0" counter(st);display:block;color:var(--acc);font-size:14px;margin-bottom:12px}.d-steps b{display:block;font-weight:500;margin-bottom:8px}.d-steps span{color:var(--t2)}.d-table{width:100%;border-collapse:collapse;line-height:1.5}.d-table th,.d-table td{text-align:left;vertical-align:top;padding:16px 20px 16px 0;border-bottom:1px solid var(--line2)}.d-table th{color:var(--t3);font-weight:400;font-size:14px}.d-table td{color:var(--t2)}.d-table td:first-child{color:var(--t1)}.d-vs td:first-child{color:var(--t2)}.d-vs th:last-child,.d-vs td:last-child{color:var(--t1);background:rgba(124,134,255,.07);padding-left:20px}.d-cols2{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:16px;margin-top:28px}.d-chips{list-style:none;padding:0;margin:0;display:flex;flex-wrap:wrap;gap:10px}.d-chips a{display:inline-block;padding:12px 18px;border:1px solid var(--line2);border-radius:999px;color:var(--t1);transition:border-color .2s}.d-chips a:hover{border-color:var(--acc)}.tbd{background:rgba(255,209,102,.14);color:#ffd166;border-radius:4px;padding:0 .2em}.d-page .cta .sub{margin-bottom:30px}@media (max-width:1100px){.d-steps{grid-template-columns:repeat(2,minmax(0,1fr))}}@media (max-width:860px){.d-hero .wrap,.d-split,.d-two,.d-cols2,.d-cards{grid-template-columns:minmax(0,1fr)}.d-terms li{grid-template-columns:36px minmax(0,1fr);gap:6px 12px}.d-terms span{grid-column:2}.ph-doc{display:none}}@media (max-width:600px){.d-steps{grid-template-columns:minmax(0,1fr)}.d-table thead{display:none}.d-table,.d-table tbody,.d-table tr,.d-table td{display:block;width:100%}.d-table tr{border:1px solid var(--line2);border-radius:var(--r);padding:6px 16px;margin-bottom:12px}.d-table td{border:0;padding:10px 0}.d-table td+td{border-top:1px solid var(--line)}.d-table td::before{content:attr(data-l);display:block;font-size:13px;color:var(--t3);margin-bottom:4px}.d-vs td:last-child{background:none;padding-left:0}.d-page .form .btn-lg{padding:0 16px}}.hdr .nav a{white-space:nowrap}.f-lazy:not(.bg-in){background-image:none!important}
.f-hero .hero-media{overflow:hidden}.f-hero .hero-media::after{content:"";position:absolute;inset:0 0 auto;height:200px;background:linear-gradient(180deg,rgba(9,9,11,.72),rgba(9,9,11,0));pointer-events:none}.f-hero .f-hero-img{position:absolute;inset:0;width:100%;height:100%;object-fit:cover;object-position:64% 50%;filter:saturate(.95)}.f-hero::before{background:linear-gradient(90deg,rgba(9,9,11,.92) 0%,rgba(9,9,11,.84) 40%,rgba(9,9,11,.32) 58%,rgba(9,9,11,0) 74%)}.f-hero::after{height:22%}.f-hero p.lead{max-width:600px}.f-crumbs{display:flex;flex-wrap:wrap;gap:8px;font-size:14px;color:var(--t3);margin:0 0 26px}.f-crumbs a{color:var(--t2)}.f-crumbs a:hover{color:var(--t1)}.f-urgent{margin:22px 0 0;color:var(--t2);font-size:15px}.f-urgent::before{content:"";display:inline-block;width:8px;height:8px;border-radius:50%;background:var(--grn);margin-right:10px;vertical-align:middle}
.f-checks{position:relative;padding:clamp(28px,3vw,56px) 0 clamp(56px,6vw,110px)}.f-check.panel{max-width:none}.f-check-in{position:relative;z-index:1;display:grid;grid-template-columns:minmax(0,.9fr) minmax(0,1.1fr);gap:clamp(24px,4vw,80px);padding:clamp(24px,3vw,52px)}.f-check-t{font-size:clamp(28px,2.6vw,48px);line-height:1.08;letter-spacing:-.04em;font-weight:300;margin:0}.f-check-res{margin:22px 0 10px;color:var(--t2);font-size:15px}.f-check-res b{font-size:clamp(40px,3.4vw,64px);font-weight:300;letter-spacing:-.04em;color:var(--acc);margin-right:6px;line-height:1;transition:color .3s}.f-check-res.full b{color:var(--grn)}.f-check-note{color:var(--t2);line-height:1.6;margin:0 0 28px;max-width:440px}.f-check-list{list-style:none;margin:0;padding:0;display:grid;align-content:center;border-top:1px solid var(--line)}.f-check-list li{border-bottom:1px solid var(--line)}.f-check-list label{display:flex;gap:18px;align-items:center;padding:18px 4px;cursor:pointer;font-size:clamp(16px,1.15vw,20px);line-height:1.4;color:var(--t2);transition:color .25s}.f-check-list label:hover{color:var(--t1)}.f-check-list input{appearance:none;-webkit-appearance:none;flex:none;width:26px;height:26px;margin:0;border-radius:8px;border:1.4px solid var(--line2);background:rgba(255,255,255,.03) center/14px no-repeat;cursor:pointer;transition:background-color .25s,border-color .25s}.f-check-list input:checked{background-color:var(--acc2);border-color:var(--acc);background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 14 14'%3E%3Cpath d='M2.5 7.5l3 3 6-7' fill='none' stroke='%23fff' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'/%3E%3C/svg%3E")}.f-check-list input:focus-visible{outline:2px solid var(--acc);outline-offset:3px}.f-check-list input:checked+span{color:var(--t1)}
.d-card .f-num{font-size:clamp(28px,2.4vw,44px);line-height:1.05;letter-spacing:-.035em;font-weight:300;color:var(--acc);margin:0 0 16px}.f-req .d-card{border-top:2px solid rgba(124,134,255,.45)}
.f-zmap{display:grid;grid-template-columns:minmax(0,1.4fr) minmax(0,1fr);gap:clamp(20px,2.4vw,44px);align-items:start}.f-plan{margin:0;padding:clamp(14px,1.4vw,26px)}.f-plan svg{display:block;width:100%;height:auto}.f-plan svg *{pointer-events:none}.f-plan .zf,.f-plan .bdg{pointer-events:all}.f-plan .zf{fill:transparent;transition:fill .3s,stroke .3s}.f-plan .z.on .zf{fill:rgba(124,134,255,.14)}.f-plan .z6.on .zf{fill:rgba(124,134,255,.05);stroke:#7c86ff}.f-plan .bdg circle{fill:#09090b;stroke:#7c86ff;stroke-width:2;transition:fill .3s}.f-plan .bdg text{fill:#7c86ff;font:500 22px Inter,system-ui,sans-serif;text-anchor:middle;dominant-baseline:central;transition:fill .3s}.f-plan .bdg.on circle{fill:#7c86ff}.f-plan .bdg.on text{fill:#fff}.f-plan .lbl text{fill:#84848e;font:400 15px Inter,system-ui,sans-serif}.f-legend{display:flex;flex-wrap:wrap;gap:10px 22px;margin:16px 4px 2px;font-size:13px;color:var(--t3)}.f-legend span{display:inline-flex;align-items:center;gap:9px}.f-legend i{flex:none;display:inline-block}.lg-st{width:11px;height:11px;border-radius:2px;background:var(--yel)}.lg-tr{width:11px;height:11px;border-radius:50%;background:var(--acc)}.lg-uv{width:20px;height:7px;border-radius:4px;background:#c4b5fd;box-shadow:0 0 8px rgba(167,139,250,.9)}.lg-fl{width:24px;border-top:2px dashed var(--acc)}.f-zlist{list-style:none;padding:0;margin:0;display:grid;gap:10px;counter-reset:zl}.f-zlist li{display:grid;grid-template-columns:40px minmax(0,1fr);gap:2px 14px;align-items:start;padding:15px 18px;border:1.4px solid var(--line);border-radius:var(--r);background:var(--card);transition:border-color .3s,background .3s;outline:none;cursor:default}.f-zlist li::before{counter-increment:zl;content:counter(zl);grid-row:1/span 2;width:34px;height:34px;border-radius:50%;border:1.4px solid var(--acc);color:var(--acc);display:flex;align-items:center;justify-content:center;font-size:15px;transition:background .3s,color .3s}.f-zlist b{font-weight:500;font-size:clamp(16px,1.05vw,19px);line-height:1.3}.f-zlist span{color:var(--t2);font-size:clamp(14px,.9vw,16px);line-height:1.5}.f-zlist li.on,.f-zlist li:hover,.f-zlist li:focus-visible{border-color:rgba(124,134,255,.6);background:rgba(124,134,255,.08)}.f-zlist li.on::before{background:var(--acc);color:#fff}
.f-steps4{grid-template-columns:repeat(4,minmax(0,1fr))}.d-steps li.f-alert{border-top-color:var(--yel)}.d-steps li.f-alert::before{color:var(--yel)}
.inds.f-inds{grid-template-columns:repeat(6,minmax(0,1fr))}.inds.f-inds>*{grid-column:span 2}.inds.f-inds>:nth-child(n+4){grid-column:span 3}.inds.f-inds>:nth-child(n+4) .ind-img{aspect-ratio:834/275}
.f-lbl{display:block;font-size:12px;letter-spacing:.08em;text-transform:uppercase;color:var(--acc);margin:4px 0 8px}.f-mb{margin:0 0 4px}.f-pricecard .f-price{margin:22px 0 26px;color:var(--t2);line-height:1.6}.f-pricecard .f-price b{display:block;color:var(--t1);font-weight:400;font-size:clamp(20px,1.6vw,28px);letter-spacing:-.02em;line-height:1.25;margin-bottom:6px}.d-card .btn{max-width:100%;white-space:normal;text-align:center;line-height:1.25}
@media (max-width:1100px){.f-steps4{grid-template-columns:repeat(2,minmax(0,1fr))}.f-zmap,.f-check-in{grid-template-columns:minmax(0,1fr)}.inds.f-inds{grid-template-columns:repeat(2,minmax(0,1fr))}.inds.f-inds>*,.inds.f-inds>:nth-child(n+4){grid-column:auto}.inds.f-inds>:nth-child(n+4) .ind-img{aspect-ratio:556/275}.inds.f-inds>:last-child{grid-column:1/-1}.inds.f-inds>:last-child .ind-img{aspect-ratio:834/275}}
@media (max-width:900px){.hdr{background:rgba(0,0,0,.72);backdrop-filter:blur(18px);-webkit-backdrop-filter:blur(18px);border-color:var(--line)}.f-hero{display:block;min-height:0;padding:68px 0 clamp(44px,8vw,72px)}.f-hero::before,.f-hero::after{display:none}.f-hero .hero-media{position:relative;inset:auto;width:100%;aspect-ratio:16/9}.f-hero .hero-media::after{height:100%;background:linear-gradient(180deg,rgba(0,0,0,0) 62%,#000 100%)}.f-hero .f-hero-img{object-position:70% 50%;filter:none}.f-hero .wrap{margin-top:-24px}.f-hero p.lead{max-width:760px}}@media (max-width:760px){.f-hero .hero-media{aspect-ratio:4/3}.f-hero .f-hero-img{object-position:50% 50%}.f-crumbs{font-size:13px;margin-bottom:18px}.inds.f-inds{grid-template-columns:minmax(0,1fr)}.inds.f-inds>:last-child{grid-column:auto}.inds.f-inds>:last-child .ind-img{aspect-ratio:556/275}}
@media (max-width:600px){.f-steps4{grid-template-columns:minmax(0,1fr)}.d-btns .btn,.d-card .btn,.f-check .btn{width:100%;white-space:normal;text-align:center;line-height:1.25}.d-page .btn-lg{padding:0 16px}.f-plan .lbl{display:none}.f-check-in{padding:24px 20px}.f-check-list label{padding:15px 2px;gap:14px}.f-zlist li{padding:14px}}
@media (max-width:400px){.hdr .wrap{gap:10px}.hdr-right{gap:8px}.logo{gap:8px}.logo-mark{width:34px;height:34px}.logo-name{font-size:15px}.phone i,.burger{width:40px;height:40px}}@media (max-width:340px){.logo-sub{display:none}}
/* ===== Страница «Разработка ППК» (/razrabotka-ppk/): дополнения к стилям отраслевой страницы ===== */
.rp-page .f-hero .f-hero-img{object-position:62% 50%}
/* заголовок длиннее, чем на других страницах (53 знака): чуть меньше кегль, чтобы «производственного контроля» шло одной строкой и кнопки были на первом экране */
@media (min-width:761px){.rp-page .hero h1{font-size:clamp(38px,3.5vw,68px)}}
.rp-hero-list{list-style:none;padding:0;margin:26px 0 0;display:grid;gap:10px;max-width:640px}
.rp-hero-list li{position:relative;padding-left:28px;color:#c4c4cc;line-height:1.5;font-size:clamp(15px,.95vw,18px)}
.rp-hero-list li::before{content:"";position:absolute;left:2px;top:.45em;width:12px;height:6px;border-left:2px solid var(--acc);border-bottom:2px solid var(--acc);transform:rotate(-45deg)}
.rp-trust{display:grid;gap:4px;margin:28px 0 0;font-size:14px;line-height:1.5;color:#a1a1aa;max-width:700px}
.rp-trust a,.rp-upd a,.rp-principles a,.rp-short a,.rp-when a,#laboratoriya .d-note a,#vybor .d-note a{color:var(--t2);border-bottom:1px solid var(--line2);transition:color .25s,border-color .25s}
.rp-trust a{color:#c4c4cc;white-space:nowrap}
.rp-principles a{white-space:nowrap}
.rp-trust a:hover,.rp-upd a:hover,.rp-principles a:hover,.rp-short a:hover,.rp-when a:hover,#laboratoriya .d-note a:hover,#vybor .d-note a:hover{color:var(--t1);border-color:var(--acc)}

/* определение и «коротко» */
.rp-def{margin:0 0 clamp(28px,3vw,44px);padding:clamp(18px,1.6vw,26px) clamp(20px,2vw,30px);border:1px solid var(--line2);border-left:2px solid var(--acc);border-radius:var(--r);background:var(--card);color:var(--t2);line-height:1.65;max-width:1100px;font-size:clamp(16px,1.05vw,19px)}
.rp-def b{color:var(--t1);font-weight:500}
.d-table.rp-short{max-width:1100px}
.rp-short th{width:240px;color:var(--t3);font-size:15px}
.d-table.rp-short td,.d-table.rp-short td:first-child{color:#c4c4cc}
.rp-upd{margin:20px 0 0;font-size:14px;line-height:1.6;color:var(--t3)}

/* ППК или ППК по ХАССП — сравнение */
.d-table.rp-cmp{max-width:1200px}
@media (min-width:901px){.rp-cmp thead th:nth-child(1){width:20%}.rp-cmp thead th:nth-child(2),.rp-cmp thead th:nth-child(3){width:40%}}
.rp-cmp thead th{font-size:clamp(17px,1.2vw,21px);color:var(--t1);font-weight:500;letter-spacing:-.01em}
.rp-cmp thead th:nth-child(3){color:var(--acc)}
.rp-cmp tbody th{font-size:15px}
.d-table.rp-cmp td{color:#c4c4cc}
.rp-cmp td b{color:var(--t1);font-weight:400;font-size:clamp(20px,1.6vw,28px);letter-spacing:-.02em;white-space:nowrap}

/* когда разрабатывать и когда менять */
@media (min-width:901px){.rp-when th:nth-child(1){width:38%}.rp-when th:nth-child(3){width:26%}}
.d-table.rp-when td:nth-child(2){color:#c4c4cc}
.rp-when td:nth-child(3){font-size:15px;color:var(--t3)}

/* 9 пунктов раздела 3 */
.rp-pt{display:inline-block;min-width:44px;padding:2px 10px;border-radius:999px;border:1px solid rgba(124,134,255,.45);background:rgba(124,134,255,.08);color:var(--acc);font-size:14px;line-height:1.5;text-align:center;white-space:nowrap}
@media (min-width:901px){.rp-items th:nth-child(1){width:92px}.rp-items th:nth-child(2){width:40%}}
.rp-items thead th:nth-child(3){color:var(--acc)}
.d-table.rp-items td:nth-child(2){color:var(--t1)}
.d-table.rp-items td:nth-child(3){color:#c4c4cc}

/* что добавляется в ППК по ХАССП (ТР ТС 021/2011, ст. 11, ч. 3) */
.rp-haccp{margin-top:clamp(28px,3vw,48px);padding:clamp(22px,2.4vw,36px);background:var(--card);border:1px solid var(--line2);border-top:2px solid var(--acc);border-radius:var(--r)}
.rp-haccp h3{font-size:clamp(20px,1.6vw,28px);font-weight:400;letter-spacing:-.02em;line-height:1.25;margin:0 0 12px;color:var(--t1)}
.rp-haccp>p{margin:0 0 clamp(20px,2vw,28px);color:var(--t2);line-height:1.65;max-width:1040px}
.rp-hlist{list-style:none;counter-reset:rh;padding:0;margin:0;display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:20px clamp(20px,2.4vw,36px)}
.rp-hlist li{padding-top:16px;border-top:1px solid var(--line2);line-height:1.5}
.rp-hlist li::before{counter-increment:rh;content:"0" counter(rh);display:block;color:var(--acc);font-size:13px;margin-bottom:10px}
.rp-hlist b{display:block;color:var(--t1);font-weight:500;margin-bottom:6px;font-size:clamp(16px,1.05vw,18px)}
.rp-hlist li>span{color:var(--t2);font-size:15px;line-height:1.55}

/* что вы получите */
.rp-docs{list-style:none;counter-reset:rd;padding:0;margin:0;display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:14px}
.rp-docs li{background:var(--card);border:1px solid var(--line2);border-top:2px solid rgba(124,134,255,.45);border-radius:var(--r);padding:clamp(20px,1.8vw,28px);line-height:1.5}
.rp-docs li::before{counter-increment:rd;content:"0" counter(rd);display:block;color:var(--acc);font-size:14px;margin-bottom:14px}
.rp-docs b{display:block;font-weight:500;line-height:1.3;margin-bottom:8px;font-size:clamp(17px,1.15vw,20px)}
.rp-docs li>span{color:var(--t2);font-size:15px;line-height:1.55}

/* образец (компонент .p-obr из «Программы пест-контроля») */
.p-obr{display:grid;grid-template-columns:minmax(0,1.05fr) minmax(0,.95fr);gap:clamp(24px,3.4vw,56px);align-items:start}
.p-obr-pages{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:14px}
.p-obr-page{display:block;color:var(--t2);font-size:13px;line-height:1.4}
.p-obr-page>span{display:block;border-radius:10px;overflow:hidden;border:1px solid var(--line2);background:#fff;box-shadow:0 14px 36px rgba(0,0,0,.45);transition:border-color .2s,transform .2s;margin-bottom:10px}
.p-obr-page img{display:block;width:100%;height:auto;aspect-ratio:720/1018}
.p-obr-page:hover>span{border-color:var(--acc);transform:translateY(-2px)}
.p-obr-page b{display:block;color:var(--t1);font-weight:500}
.p-obr-info{background:var(--card);border:1px solid var(--line2);border-top:2px solid var(--acc);border-radius:var(--r);padding:clamp(22px,2.4vw,34px)}
.p-obr-info h3{font-size:clamp(19px,1.4vw,24px);font-weight:400;letter-spacing:-.02em;margin:0 0 14px;color:var(--t1)}
.p-obr-list{list-style:none;padding:0;margin:0 0 22px;display:grid;gap:10px}
.p-obr-list li{display:grid;grid-template-columns:96px minmax(0,1fr);gap:10px;color:var(--t2);font-size:14px;line-height:1.5}
.p-obr-list li b{font-family:var(--mono,monospace);font-size:12px;color:var(--acc);font-weight:500;padding-top:2px;white-space:nowrap}
.p-obr-btns{display:flex;flex-wrap:wrap;gap:12px}
.p-obr-meta{margin:14px 0 0;font-size:13px;color:var(--t3);line-height:1.5}
.p-obr-meta a{color:var(--t2);text-decoration:underline;text-underline-offset:3px}
.p-obr-meta a:hover{color:var(--t1)}

/* объекты */
.rp-ico{display:block;margin:0 0 10px;color:var(--acc);line-height:0}
.rp-ico svg{width:24px;height:24px;stroke-width:1.6}
@media (min-width:901px){.rp-obj th:nth-child(1){width:22%}.rp-obj th:nth-child(2){width:32%}}
.d-table.rp-obj td:first-child{font-size:clamp(16px,1.1vw,19px)}
.d-table.rp-obj td:nth-child(2){color:#c4c4cc}
.rp-tags{display:flex;flex-wrap:wrap;gap:6px;margin-top:10px}
.rp-tag{display:inline-block;padding:2px 10px;border-radius:999px;border:1px solid var(--line2);font-size:13px;line-height:1.6;color:var(--t2);white-space:nowrap;letter-spacing:0}
.rp-tag-h{border-color:rgba(124,134,255,.45);background:rgba(124,134,255,.08);color:var(--acc)}

/* лабораторные исследования */
.d-table.rp-labt{max-width:1100px}
@media (min-width:901px){.rp-labt th:nth-child(1){width:24%}.rp-labt th:nth-child(2){width:40%}}

/* частые ошибки — строками, как .d-terms шаблона, номера красные */
.rp-err.d-terms li::before{color:var(--red)}
.rp-err.d-terms b,.rp-err.d-terms b span{color:var(--t1)}

/* стоимость */
.rp-price{display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1fr);gap:clamp(18px,2vw,32px);align-items:stretch}
.rp-pcard{padding:clamp(24px,2.6vw,44px);display:flex;flex-direction:column;gap:clamp(16px,1.6vw,24px);border-top:2px solid rgba(124,134,255,.45)}
.rp-pcard-h{border-top-color:var(--acc)}
.rp-pcard p{margin:0}
.rp-pname{font-size:clamp(24px,2vw,34px);line-height:1.15;letter-spacing:-.03em;color:var(--t1)}
.rp-pcard-h .rp-pname{color:var(--acc)}
.rp-pfor{color:var(--t2);line-height:1.55;font-size:15px}
.rp-pfigs{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:16px clamp(16px,2vw,32px);padding-top:clamp(18px,1.8vw,26px);border-top:1px solid var(--line2)}
.rp-pk{font-size:14px;color:var(--t3);margin-bottom:6px!important}
.rp-pnum{font-size:clamp(26px,2.3vw,40px);line-height:1.08;letter-spacing:-.035em;font-weight:300;color:var(--t1)}
.rp-pcard .btn{margin-top:auto;align-self:flex-start;white-space:normal;text-align:center;line-height:1.25}
.rp-pnotes{margin-top:clamp(18px,2vw,32px);padding:clamp(24px,2.4vw,40px);display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:20px clamp(24px,3vw,48px)}
.rp-pnotes p{margin:0;color:var(--t2);line-height:1.6}
.rp-pnotes p b{display:block;color:var(--t1);font-weight:500;margin-bottom:4px}

/* автор и принципы */
.rp-author-wrap{display:grid;grid-template-columns:minmax(0,.75fr) minmax(0,1.25fr);gap:clamp(24px,3vw,56px);align-items:start}
.rp-author{display:flex;gap:20px;align-items:center;padding:clamp(24px,2.4vw,36px)}
.rp-avatar{flex:none;display:block;width:112px;height:112px;border-radius:50%;object-fit:cover;background:#18181b;border:1px solid rgba(124,134,255,.4)}
.rp-author p{margin:0}
.rp-author-name{font-size:clamp(20px,1.5vw,26px);color:var(--t1);letter-spacing:-.02em;margin-bottom:4px!important}
.rp-author-role{color:var(--t2);margin-bottom:4px!important}
.rp-author-date{color:var(--t3);font-size:14px}
.rp-author-note{color:var(--t3);font-size:13px;margin-top:6px!important}
.rp-principles{list-style:none;padding:0;margin:0;border-top:1px solid var(--line2)}
.rp-principles li{padding:18px 0;border-bottom:1px solid var(--line2);color:var(--t2);line-height:1.6}
.rp-principles b{color:var(--t1);font-weight:500}

/* нормативная база */
.rp-base{list-style:none;padding:0;margin:0;border-top:1px solid var(--line2);max-width:1200px}
.rp-base li{position:relative;padding:14px 0 14px 30px;border-bottom:1px solid var(--line2);color:var(--t2);line-height:1.6;font-size:15px}
.rp-base li::before{content:"§";position:absolute;left:4px;top:14px;color:var(--acc)}
.rp-base a{color:var(--t1);border-bottom:1px solid rgba(124,134,255,.45);transition:border-color .25s}
.rp-base a:hover{border-color:var(--t1)}
#normativnaya-baza .sub a{color:var(--t1);border-bottom:1px solid rgba(124,134,255,.45);transition:border-color .25s}
#normativnaya-baza .sub a:hover{border-color:var(--t1)}

@media (max-width:1100px){
.p-obr{grid-template-columns:minmax(0,1fr)}
}
@media (min-width:901px) and (max-width:1180px){.rp-pfigs{grid-template-columns:minmax(0,1fr)}}
/* широкие таблицы — карточками уже на планшете */
@media (max-width:900px){
.rp-when thead,.rp-items thead,.rp-obj thead,.rp-labt thead{display:none}
.rp-when,.rp-when tbody,.rp-when tr,.rp-when td,.rp-items,.rp-items tbody,.rp-items tr,.rp-items td,.rp-obj,.rp-obj tbody,.rp-obj tr,.rp-obj td,.rp-labt,.rp-labt tbody,.rp-labt tr,.rp-labt td{display:block;width:100%}
.rp-when tr,.rp-items tr,.rp-obj tr,.rp-labt tr{border:1px solid var(--line2);border-radius:var(--r);padding:6px 18px;margin-bottom:12px}
.rp-when td,.rp-items td,.rp-obj td,.rp-labt td{border:0;padding:10px 0}
.rp-when td+td,.rp-items td+td,.rp-obj td+td,.rp-labt td+td{border-top:1px solid var(--line)}
.rp-when td::before,.rp-items td::before,.rp-obj td::before,.rp-labt td::before{content:attr(data-l);display:block;font-size:13px;color:var(--t3);margin-bottom:4px}
.rp-when td:first-child,.rp-obj td:first-child,.rp-labt td:first-child{font-size:17px;color:var(--t1)}
.rp-when td:first-child::before,.rp-obj td:first-child::before,.rp-labt td:first-child::before,.rp-items td:first-child::before{content:none}
.rp-items tr{display:grid;grid-template-columns:auto minmax(0,1fr);column-gap:14px;align-items:start}
.rp-items td:nth-child(1){grid-column:1;grid-row:1;padding-top:12px}
.rp-items td:nth-child(2){grid-column:2;grid-row:1;border-top:0;font-size:16px}
.rp-items td:nth-child(2)::before{content:none}
.rp-items td:nth-child(3){grid-column:1/-1}
.rp-items td:nth-child(3)::before{color:var(--acc)}
.rp-docs{grid-template-columns:repeat(2,minmax(0,1fr))}
.rp-price,.rp-author-wrap,.rp-pnotes{grid-template-columns:minmax(0,1fr)}
.rp-hlist{grid-template-columns:repeat(2,minmax(0,1fr))}
.rp-cmp thead{display:none}
.rp-cmp,.rp-cmp tbody,.rp-cmp tr,.rp-cmp th,.rp-cmp td{display:block;width:100%}
.rp-cmp tr{border:1px solid var(--line2);border-radius:var(--r);padding:6px 18px;margin-bottom:12px}
.rp-cmp th,.rp-cmp td{border:0;padding:10px 0}
.rp-cmp tbody th{font-size:17px;color:var(--t1);padding-top:12px}
.rp-cmp td{border-top:1px solid var(--line)}
.rp-cmp td::before{content:attr(data-l);display:block;font-size:13px;color:var(--t3);margin-bottom:4px}
.rp-cmp td+td::before{color:var(--acc)}
.rp-cmp tr.rp-cmp-s{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));column-gap:16px}
.rp-cmp tr.rp-cmp-s th{grid-column:1/-1}
}
@media (max-width:760px){
.rp-page .f-hero .f-hero-img{object-position:50% 50%}
.rp-page .hero h1{font-size:clamp(28px,8.6vw,42px)}
.rp-trust{font-size:13px}
}
@media (max-width:600px){
.rp-short th{display:block;width:100%;border:0;padding:12px 0 2px;font-size:13px}
.d-table.rp-short td{padding:0 0 12px}
.d-table.rp-short tr{padding:4px 16px}
.rp-docs{grid-template-columns:minmax(0,1fr)}
.p-obr-btns .btn{width:100%;white-space:normal;text-align:center;line-height:1.25}
.p-obr-page{font-size:12px}
.p-obr-page b{font-size:12px}
.p-obr-page small{display:none}
.p-obr-pages{gap:10px}
.p-obr-list li{grid-template-columns:84px minmax(0,1fr);gap:8px;font-size:13.5px}
.p-obr-list li b{font-size:11px}
.rp-pcard .btn{width:100%;align-self:stretch}
.rp-pfigs,.rp-hlist{grid-template-columns:minmax(0,1fr)}
.rp-author{align-items:flex-start}
.rp-avatar{width:80px;height:80px}
.rp-pnotes,.rp-pcard{padding:22px 20px}
}

/* опросный лист заказчика (#oprosnyy-list; разметка — tools/razrabotka-ppk/oprosnyy/block.py) */
.rp-steps a,.rp-pnotes a,.rp-ol-dn a,.rp-ol-ways a,.rp-ol-cta a,.rp-olf-mail a,.rp-olf .ok a,#voprosy .ans a{color:var(--t1);border-bottom:1px solid rgba(124,134,255,.45);transition:border-color .25s,color .25s}
.rp-steps a:hover,.rp-pnotes a:hover,.rp-ol-dn a:hover,.rp-ol-ways a:hover,.rp-ol-cta a:hover,.rp-olf-mail a:hover,.rp-olf .ok a:hover,#voprosy .ans a:hover{border-color:var(--t1)}
.rp-ol-ways a,.rp-ol-dn a,.rp-olf-mail a{white-space:nowrap}
.d-table.rp-ol-t{max-width:1200px}
@media (min-width:901px){.rp-ol-t th:nth-child(1){width:30%}.rp-ol-t th:nth-child(2){width:36%}}
.rp-ol-sn{display:flex;align-items:flex-start;gap:12px}
.rp-ol-sn b{font-weight:400;color:var(--t1);font-size:clamp(16px,1.1vw,19px);line-height:1.4;padding-top:1px}
.rp-ol-t .rp-tag{margin:10px 0 0 56px}
.d-table.rp-ol-t td:nth-child(2){color:#c4c4cc}
.rp-ol-t td:nth-child(3){font-size:15px;color:var(--t3)}
.rp-ol{display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1fr);gap:clamp(18px,2vw,32px);margin-top:clamp(28px,3vw,48px);align-items:start}
.rp-ol h3{font-size:clamp(19px,1.4vw,24px);font-weight:400;letter-spacing:-.02em;line-height:1.25;margin:0 0 18px;color:var(--t1)}
.rp-ol-docs,.rp-ol-how{padding:clamp(22px,2.4vw,36px)}
.rp-ol-how{border-top:2px solid var(--acc)}
.rp-ol-dl{list-style:none;padding:0;margin:0;display:grid;gap:10px}
.rp-ol-dl li{position:relative;padding-left:30px;color:var(--t2);line-height:1.5;font-size:15px}
.rp-ol-dl li::before{content:"";position:absolute;left:0;top:.2em;width:16px;height:16px;border:1.4px solid rgba(124,134,255,.6);border-radius:4px}
.rp-ol-dh{margin:22px 0 12px;font-size:13px;letter-spacing:.08em;text-transform:uppercase;color:var(--acc)}
.rp-ol-dn{margin:20px 0 0;padding-top:16px;border-top:1px solid var(--line2);font-size:14px;color:var(--t3);line-height:1.6}
.rp-ol-get{display:grid;gap:clamp(14px,1.6vw,20px)}
.rp-ol-ways{list-style:none;counter-reset:ow;padding:0;margin:0;display:grid;gap:14px}
.rp-ol-ways li{position:relative;padding-left:40px;color:var(--t2);line-height:1.55;font-size:15px}
.rp-ol-ways li::before{counter-increment:ow;content:"0" counter(ow);position:absolute;left:0;top:1px;color:var(--acc);font-size:13px}
.rp-ol-ways b{display:block;color:var(--t1);font-weight:500;margin-bottom:2px}
.rp-ol-how .btn{margin-top:24px;white-space:normal;text-align:center;line-height:1.25}
.rp-ol-pdfs{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:14px}
.rp-ol-pdf{display:grid;grid-template-columns:88px minmax(0,1fr);gap:16px;align-items:center;padding:14px;border:1px solid var(--line2);border-radius:var(--r);background:var(--card);transition:border-color .25s}
.rp-ol-pdf:hover,.rp-ol-pdf:focus-visible{border-color:var(--acc)}
.rp-ol-th{display:block;border-radius:6px;overflow:hidden;background:#fff;box-shadow:0 10px 26px rgba(0,0,0,.45)}
.rp-ol-th img{display:block;width:100%;height:auto;aspect-ratio:720/1018}
.rp-ol-pt b{display:block;color:var(--t1);font-weight:500;line-height:1.35;font-size:15px}
.rp-ol-pt small{display:block;color:var(--t3);font-size:13px;margin-top:6px}
.rp-ol-pt em{display:inline-block;margin-top:10px;font-style:normal;color:var(--acc);font-size:14px}
.rp-ol-cta{margin:26px 0 0;color:#c4c4cc;line-height:1.6;max-width:560px}
/* онлайн-форма */
.rp-ol-box{margin-top:clamp(28px,3vw,48px);scroll-margin-top:90px}
.form.rp-olf{max-width:940px;margin:0 auto;background:rgba(9,9,11,.88);backdrop-filter:none;-webkit-backdrop-filter:none}
.rp-olf-top{margin-bottom:8px}
.rp-olf .rp-olf-top h3{font-size:clamp(22px,1.7vw,30px);letter-spacing:-.02em}
.rp-olf-fs{font-size:14px;color:var(--t3);line-height:1.5;margin:0 0 12px}
.rp-olf-sec{border:0;margin:0;padding:clamp(22px,2vw,30px) 0 6px;border-top:1px solid var(--line2);min-width:0}
.rp-olf-sec[hidden]{display:none}
.rp-olf-sec legend{float:left;width:100%;display:flex;align-items:center;gap:12px;padding:0;margin:0 0 18px;font-size:clamp(18px,1.3vw,22px);color:var(--t1);font-weight:400;letter-spacing:-.01em;line-height:1.3}
.rp-olf-sec legend+*{clear:both}
.rp-olf-sec legend .rp-pt{min-width:38px}
.rp-olf-sn{clear:both;margin:-6px 0 16px;font-size:14px;color:var(--t3);line-height:1.5}
.rp-olf-prog .rp-olf-sn{margin:14px 0 18px}
.rp-olf-sec legend .rp-olf-req{margin-left:6px}
.rp-olf-g{clear:both;display:grid;grid-template-columns:minmax(0,1fr);gap:22px}
.rp-olf-q>label,.rp-olf-l{display:block;margin:0 0 9px;font-size:15px;line-height:1.45;color:#d4d4d8}
.rp-olf-q>label i,.rp-olf-l i{font-style:normal;color:var(--acc);margin-right:8px;font-size:14px}
.rp-olf-h{display:block;margin:-4px 0 10px;font-size:13px;color:var(--t3);line-height:1.45}
.rp-olf-req{color:var(--acc);font-weight:400;margin-left:4px}
.rp-olf .field input{height:52px}
.rp-olf .field textarea{height:96px}
.rp-olf .field label{display:block;margin:0 0 9px;font-size:15px;line-height:1.45;color:#d4d4d8}
.rp-olf .field label.sr-only{position:absolute;margin:0}
.rp-olf-x{margin-top:10px}
.rp-chips{display:flex;flex-wrap:wrap;gap:8px}
.rp-chip{position:relative;display:inline-flex;max-width:100%;min-width:0}
.rp-chip>input{position:absolute;inset:0;width:100%;height:100%;margin:0;opacity:0;cursor:pointer}
.rp-chip>span{display:inline-flex;align-items:center;gap:10px;min-width:0;min-height:44px;padding:9px 16px;border-radius:999px;border:1.4px solid var(--line2);background:rgba(24,24,27,.6);color:var(--t2);font-size:15px;line-height:1.3;transition:border-color .2s,background .2s,color .2s}
.rp-chip>span::before{content:"";flex:none;width:14px;height:14px;border:1.4px solid var(--t3);border-radius:50%;transition:border-color .2s,background .2s}
.rp-chip>input[type=checkbox]+span::before{border-radius:4px}
.rp-chip:hover>span{border-color:rgba(124,134,255,.55)}
.rp-chip>input:checked+span{border-color:var(--acc);background:rgba(124,134,255,.14);color:var(--t1)}
.rp-chip>input:checked+span::before{border-color:var(--acc);background:var(--acc);box-shadow:inset 0 0 0 3px #18181b}
.rp-ct{min-width:0}
.rp-chip>input:focus-visible+span{box-shadow:0 0 0 4px rgba(124,134,255,.3)}
.rp-olf-q.err .rp-chip>span{border-color:var(--red)}
.rp-olf-q .ferr{padding-left:2px}
.rp-olf-c .fg{clear:both}
.rp-olf-send{display:flex;flex-wrap:wrap;align-items:center;gap:12px 24px;margin-top:26px;padding-top:24px;border-top:1px solid var(--line2)}
.rp-olf-send .btn{width:auto;min-width:min(100%,380px);margin-top:0}
.rp-olf-reset{background:none;border:0;padding:10px 0;color:var(--t3);font:inherit;font-size:14px;cursor:pointer;border-bottom:1px solid var(--line2)}
.rp-olf-reset:hover{color:var(--t1)}
.rp-olf .legal{text-align:left}
.rp-olf-mail{margin:6px 0 0;font-size:13px;color:var(--t3);line-height:1.5}
@media (max-width:900px){
.rp-ol-t thead{display:none}
.rp-ol-t,.rp-ol-t tbody,.rp-ol-t tr,.rp-ol-t td{display:block;width:100%}
.rp-ol-t tr{border:1px solid var(--line2);border-radius:var(--r);padding:6px 18px;margin-bottom:12px}
.rp-ol-t td{border:0;padding:10px 0}
.rp-ol-t td+td{border-top:1px solid var(--line)}
.rp-ol-t td::before{content:attr(data-l);display:block;font-size:13px;color:var(--t3);margin-bottom:4px}
.rp-ol-t td:first-child::before{content:none}
.rp-ol-t .rp-tag{margin-left:56px}
.rp-ol{grid-template-columns:minmax(0,1fr)}
}
@media (max-width:600px){
.rp-ol-pdfs{grid-template-columns:minmax(0,1fr)}
.rp-ol-pdf{grid-template-columns:72px minmax(0,1fr)}
.rp-ol-docs,.rp-ol-how{padding:22px 20px}
.rp-ol-how .btn{width:100%}
.rp-chip>span{font-size:14px;padding:8px 14px}
.rp-olf-send .btn{width:100%}
.rp-ol-t .rp-tag{margin-left:0}
}</style>
<script type="application/ld+json">{"@context": "https://schema.org", "@graph": [{"@type": "BreadcrumbList", "itemListElement": [{"@type": "ListItem", "position": 1, "name": "Главная", "item": "https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/"}, {"@type": "ListItem", "position": 2, "name": "Разработка ППК", "item": "https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/razrabotka-ppk/"}]}, {"@type": "Service", "@id": "https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/razrabotka-ppk/#service", "name": "Разработка программы производственного контроля (ППК)", "alternateName": ["Разработка ППК", "Разработка ППК по ХАССП", "Разработка плана производственного контроля"], "serviceType": "Разработка программы производственного контроля по СП 1.1.1058-01, в том числе с процедурами ХАССП", "description": "Разработка ППК под ваш объект: от 5 900 ₽ за 1 рабочий день, ППК по ХАССП для общепита и пищевых производств — от 19 900 ₽ за 3 рабочих дня. Нормы 2026 года, план-график исследований, приказ и журналы.", "url": "https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/razrabotka-ppk/", "provider": {"@type": "Organization", "@id": "https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/#org", "name": "ПЕСТКОНТРОЛЬ Центр", "legalName": "ООО «Центр дезинфекционных услуг»", "url": "https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/", "telephone": "+7 495 104-35-70", "email": "b2b@pestcontrol-center.ru"}, "areaServed": [{"@type": "City", "name": "Москва"}, {"@type": "AdministrativeArea", "name": "Московская область"}], "audience": {"@type": "BusinessAudience", "audienceType": "Офисы, склады, магазины и торговые сети, гостиницы, рестораны и кафе, пищевые и фармацевтические производства"}, "offers": [{"@type": "Offer", "name": "Разработка ППК", "priceSpecification": {"@type": "PriceSpecification", "minPrice": 5900, "priceCurrency": "RUB"}, "description": "Для объектов, где не изготавливают пищевую продукцию: офисы, склады, магазины без собственного производства, гостиницы без ресторана. Срок — 1 рабочий день после получения сведений об объекте (опросный лист заказчика); лабораторные исследования в стоимость не входят"}, {"@type": "Offer", "name": "Разработка ППК по ХАССП", "priceSpecification": {"@type": "PriceSpecification", "minPrice": 19900, "priceCurrency": "RUB"}, "description": "Для пищевых производств, ресторанов и кафе, магазинов с кулинарией или пекарней: ППК с процедурами ХАССП. Срок — 3 рабочих дня после получения сведений об объекте (опросный лист заказчика с разделами о продукции и технологии); лабораторные исследования в стоимость не входят"}]}, {"@type": "WebPage", "@id": "https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/razrabotka-ppk/#webpage", "url": "https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/razrabotka-ppk/", "name": "Разработка программы производственного контроля (ППК) и ППК по ХАССП в Москве — ПЕСТКОНТРОЛЬ Центр", "description": "Разработка ППК под ваш объект: от 5 900 ₽ за 1 рабочий день, ППК по ХАССП для общепита и пищевых производств — от 19 900 ₽ за 3 рабочих дня. Нормы 2026 года, план-график исследований, приказ и журналы.", "inLanguage": "ru", "datePublished": "2026-11-08", "dateModified": "2026-11-08", "author": {"@type": "Person", "name": "Марианна Семерина", "jobTitle": "Санитарный врач"}, "about": [{"@id": "https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/razrabotka-ppk/#service"}, {"@id": "https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/razrabotka-ppk/#ppk"}], "hasPart": [{"@id": "https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/razrabotka-ppk/#oprosnyy-ppk"}, {"@id": "https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/razrabotka-ppk/#oprosnyy-haccp"}], "primaryImageOfPage": {"@type": "ImageObject", "url": "https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/img/rppk-hero.webp", "width": 1920, "height": 1072}}, {"@type": "DefinedTerm", "@id": "https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/razrabotka-ppk/#ppk", "name": "Программа производственного контроля", "alternateName": ["ППК", "План производственного контроля"], "description": "Программа производственного контроля (ППК) — внутренний документ организации или индивидуального предпринимателя, по которому они сами контролируют соблюдение санитарных правил на своём объекте: действующие нормы, ответственные, лабораторные исследования, медосмотры, журналы и действия при авариях. Требования к программе установлены СП 1.1.1058-01. Если на объекте изготавливают пищевую продукцию, в программу входят процедуры на принципах ХАССП — такую программу называют ППК по ХАССП.", "subjectOf": {"@type": "CreativeWork", "name": "СП 1.1.1058-01", "url": "https://13.rospotrebnadzor.ru/sites/default/files/1.1.1058-01.rtf"}}, {"@type": "DigitalDocument", "@id": "https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/razrabotka-ppk/#oprosnyy-ppk", "name": "Опросный лист для разработки программы производственного контроля (ППК)", "url": "https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/razrabotka-ppk/oprosnyy-list-ppk.pdf", "encodingFormat": "application/pdf", "inLanguage": "ru", "datePublished": "2026-11-08", "description": "Опросный лист заказчика: сведения об объекте, по которым разрабатываем ППК. Заполняется онлайн на странице или в PDF.", "publisher": {"@id": "https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/#org"}, "isPartOf": {"@id": "https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/razrabotka-ppk/#webpage"}}, {"@type": "DigitalDocument", "@id": "https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/razrabotka-ppk/#oprosnyy-haccp", "name": "Опросный лист для разработки программы производственного контроля по ХАССП", "url": "https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/razrabotka-ppk/oprosnyy-list-ppk-po-haccp.pdf", "encodingFormat": "application/pdf", "inLanguage": "ru", "datePublished": "2026-11-08", "description": "Опросный лист заказчика: сведения об объекте, по которым разрабатываем ППК по ХАССП — с разделами о продукции и технологических процессах. Заполняется онлайн на странице или в PDF.", "publisher": {"@id": "https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/#org"}, "isPartOf": {"@id": "https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/razrabotka-ppk/#webpage"}}, {"@type": "FAQPage", "@id": "https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/razrabotka-ppk/#faq", "mainEntity": [{"@type": "Question", "name": "Сколько стоит разработка ППК?", "acceptedAnswer": {"@type": "Answer", "text": "ППК — от 5 900 ₽, ППК по ХАССП — от 19 900 ₽. Точная сумма зависит от вида деятельности, площади, числа помещений и сотрудников, а для ППК по ХАССП — ещё и от числа технологических процессов; называем её до начала работы. Для сети считаем по количеству и типам объектов."}}, {"@type": "Question", "name": "Сколько времени занимает разработка ППК?", "acceptedAnswer": {"@type": "Answer", "text": "ППК — 1 рабочий день, ППК по ХАССП — 3 рабочих дня. Срок считаем с момента, когда получили сведения об объекте — заполненный опросный лист, а если нужен выезд — после выезда. Для сети объектов срок называем при расчёте."}}, {"@type": "Question", "name": "Что нужно для разработки ППК?", "acceptedAnswer": {"@type": "Answer", "text": "Сведения об объекте: реквизиты и адрес, виды деятельности, площадь и помещения, персонал по должностям, водоснабжение, канализация и вентиляция, оборудование, отходы, договоры на дезинсекцию и дератизацию и с лабораторией, действующая программа и предписания, если были. Всё это собрано в опросном листе заказчика — его можно заполнить онлайн на этой странице или в PDF. Из документов пригодятся план помещений, штатное расписание и перечень оборудования, но начать можно и без них."}}, {"@type": "Question", "name": "Какие сведения нужны для ППК по ХАССП?", "acceptedAnswer": {"@type": "Answer", "text": "Всё, что для ППК, и сведения о продукции и технологии: ассортимент или меню, объём выпуска, основное сырьё, сроки годности и хранение, операции от приёмки сырья до выдачи, тепловая обработка и охлаждение, цеха, холодильное оборудование и действующие документы ХАССП. По ним составляют блок-схемы процессов и определяют критические контрольные точки (ТР ТС 021/2011, ст. 10–11). В опросном листе это разделы 5 и 6."}}, {"@type": "Question", "name": "Нужно ли согласовывать ППК с Роспотребнадзором?", "acceptedAnswer": {"@type": "Answer", "text": "Нет. По СП 1.1.1058-01 программу утверждает руководитель организации, ИП или уполномоченное лицо (п. 2.6), согласование с Роспотребнадзором не предусмотрено. При проверке инспектор смотрит и саму программу, и документы о её выполнении."}}, {"@type": "Question", "name": "Сколько действует ППК и когда её обновлять?", "acceptedAnswer": {"@type": "Answer", "text": "Срок действия не ограничен (СП 1.1.1058-01, п. 2.6). Изменения вносят при смене вида деятельности, технологии и других существенных изменениях, а также когда отменены правила, на которые программа ссылается: с 1 сентября 2026 года это затронуло общепит, торговлю пищевой продукцией и объекты услуг."}}, {"@type": "Question", "name": "Нужна ли ППК индивидуальному предпринимателю?", "acceptedAnswer": {"@type": "Answer", "text": "Да. Программу составляет и юридическое лицо, и индивидуальный предприниматель — до начала деятельности (СП 1.1.1058-01, п. 2.6)."}}, {"@type": "Question", "name": "Кто отвечает за ППК, если её разработали вы?", "acceptedAnswer": {"@type": "Answer", "text": "За организацию и выполнение производственного контроля отвечает сама организация или ИП (СП 1.1.1058-01, п. 2.7). Мы отвечаем за содержание документа: состав по разделу 3, действующие нормы и соответствие программы вашему объекту."}}, {"@type": "Question", "name": "Чем ППК отличается от ППК по ХАССП?", "acceptedAnswer": {"@type": "Answer", "text": "ППК по ХАССП — это ППК по СП 1.1.1058-01, в которую включены процедуры на принципах ХАССП: опасные факторы, критические контрольные точки и их пределы, мониторинг и действия при отклонениях (ТР ТС 021/2011, ст. 11, ч. 3). Такая программа нужна всем, кто изготавливает пищевую продукцию: производствам, ресторанам, кафе, кулинариям. Офису, складу или магазину без собственного производства достаточно ППК."}}, {"@type": "Question", "name": "Какая ППК нужна продуктовому магазину или складу продуктов?", "acceptedAnswer": {"@type": "Answer", "text": "Если магазин или склад только хранит и продаёт готовую продукцию, достаточно ППК — от 5 900 ₽ за 1 рабочий день. Если в магазине есть своя кулинария, пекарня или другое изготовление пищевой продукции, нужна ППК по ХАССП (ТР ТС 021/2011, ст. 10–11)."}}, {"@type": "Question", "name": "Входят ли лабораторные исследования в разработку ППК?", "acceptedAnswer": {"@type": "Answer", "text": "В разработку входит план-график исследований: что, где и как часто исследовать. Сами исследования проводит организация или аккредитованная лаборатория (СП 1.1.1058-01, п. 2.5), в стоимость разработки они не входят. Измерения недавней специальной оценки условий труда можно использовать, если они проведены не раньше чем за шесть месяцев (ст. 32 Федерального закона № 52-ФЗ, п. 1.1)."}}, {"@type": "Question", "name": "Можно ли разработать ППК без выезда на объект?", "acceptedAnswer": {"@type": "Answer", "text": "Да, ППК обычно разрабатываем по опросному листу, планировке и фотографиям помещений. Для ППК по ХАССП нужно разобрать технологические процессы, поэтому нужен ли выезд специалиста, согласуем при расчёте."}}, {"@type": "Question", "name": "Нужна ли отдельная ППК для каждого объекта сети?", "acceptedAnswer": {"@type": "Answer", "text": "Программа должна описывать конкретный объект: его помещения, точки отбора проб и ответственных (СП 1.1.1058-01, раздел 3). Для сети мы делаем общую часть и приложения по каждому объекту — так программу проще обновлять сразу для всех."}}, {"@type": "Question", "name": "Что будет, если ППК нет?", "acceptedAnswer": {"@type": "Answer", "text": "Отсутствие программы — нарушение обязанности вести производственный контроль (ст. 11 и 32 Федерального закона № 52-ФЗ). Штрафы за санитарные нарушения по КоАП собраны в таблице на странице санитарного аудита."}}]}]}</script>
<style id="srch-st">/* лупа поиска в шапке и раскладка шапки с ней (tools/menu/apply_menu.py) */.srch-btn{flex:none;width:44px;height:44px;padding:0;border-radius:50%;display:grid;place-items:center;background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.1);color:#fff;cursor:pointer;transition:color .25s,border-color .3s,background .3s,transform .35s cubic-bezier(.16,1,.3,1)}.srch-btn:hover{border-color:#7c86ff;background:rgba(97,95,255,.2);transform:translateY(-2px)}.srch-btn:focus-visible{outline:2px solid #7c86ff;outline-offset:2px}.srch-btn svg{width:18px;height:18px;display:block}@media (min-width:761px){.hdr .wrap{gap:16px}.hdr .msg{display:none}.srch-btn{width:38px;height:38px;background:none;border-color:transparent;color:var(--t2);margin-right:calc(4px - clamp(14px,2vw,40px))}.srch-btn svg{width:20px;height:20px}.srch-btn:hover{color:#fff;background:rgba(255,255,255,.07);border-color:rgba(255,255,255,.1);transform:none}}@media (min-width:761px) and (max-width:1440px){.hdr-right{gap:18px}.srch-btn{margin-right:-14px}}@media (min-width:761px) and (max-width:1000px){.hdr-right{gap:12px}.srch-btn{margin-right:-8px}}@media (max-width:900px){.logo-txt{display:flex;flex-direction:column;align-items:flex-start}.logo-sub{margin:0}}@media (max-width:760px){.hdr .wrap{gap:12px}.hdr-right{gap:8px}}@media (max-width:400px){.hdr .wrap{gap:10px}.srch-btn{width:40px;height:40px}}@media (max-width:360px){.hdr .wrap{gap:8px}.hdr-right{gap:6px}.srch-btn,.phone i,.burger{width:38px;height:38px}}@media (max-width:340px){.logo-mark{display:none}.logo-sub{display:block}}</style><script id="srch-js">/* поиск по сайту: движок и индекс загружаются по первому нажатию на лупу или «/» (tools/search) */(function(r,v){var d=document,ld=0,w=null;function go(o){if(window.PCSearch)return window.PCSearch.open(r,v,o);w=o;if(ld)return;ld=1;var s=d.createElement("script");s.src=r+"search.min.js?v="+v;s.async=true;s.onload=function(){window.PCSearch&&window.PCSearch.open(r,v,w)};s.onerror=function(){ld=0};d.head.appendChild(s)}d.addEventListener("click",function(e){var b=e.target.closest&&e.target.closest("[data-srch]");if(b){e.preventDefault();go({btn:b})}});d.addEventListener("keydown",function(e){if(e.key!=="/"||e.ctrlKey||e.metaKey||e.altKey)return;var t=e.target,n=t&&t.tagName;if(n==="INPUT"||n==="TEXTAREA"||n==="SELECT"||t.isContentEditable)return;e.preventDefault();go({})});if(/^#q\d+$/.test(location.hash)){var c=0,t=setInterval(function(){var b=d.getElementById(location.hash.slice(1));if(b&&d.documentElement.classList.contains("anim-ready")){clearInterval(t);if(b.getAttribute("aria-expanded")==="false")b.click()}else if(++c>60)clearInterval(t)},150)}})("../","20261108");</script>
<style data-fx>
/* подсветка рамки карточек за курсором — как у .card на главной (tools/site/fx.py) */
:where(.d-card,.p-sec,.p-fcard,.p-duty-box,.p-dl-card,.pm-step-card,.pm-scen,.pm-link-card,.k-err,.w-sample,.d-doc-prev){position:relative}
:where(.d-card,.p-sec,.p-fcard,.p-duty-box,.p-dl-card,.pm-step-card,.pm-scen,.pm-link-card,.k-err,.w-sample,.d-doc-prev)::after{content:"";position:absolute;inset:0;border-radius:inherit;padding:1.4px;pointer-events:none;background:radial-gradient(360px circle at var(--mx,-999px) var(--my,-999px),rgba(124,134,255,.85),rgba(124,134,255,.15) 35%,transparent 60%);-webkit-mask:linear-gradient(#000 0 0) content-box,linear-gradient(#000 0 0);-webkit-mask-composite:xor;mask:linear-gradient(#000 0 0) content-box,linear-gradient(#000 0 0);mask-composite:exclude;opacity:0;transition:opacity .4s;z-index:2}
@media (hover:hover) and (pointer:fine){:where(.d-card,.p-sec,.p-fcard,.p-duty-box,.p-dl-card,.pm-step-card,.pm-scen,.pm-link-card,.k-err,.w-sample,.d-doc-prev):hover::after{opacity:1}}
/* «фонарь» на фото первого экрана — как на главной (tools/site/fx.py) */
.fx-lit{position:absolute;inset:0;opacity:0;pointer-events:none;-webkit-mask-image:radial-gradient(circle var(--sr,320px) at var(--sx,72%) var(--sy,46%),#000 0%,rgba(0,0,0,.55) 45%,transparent 72%);mask-image:radial-gradient(circle var(--sr,320px) at var(--sx,72%) var(--sy,46%),#000 0%,rgba(0,0,0,.55) 45%,transparent 72%);transition:opacity 1.8s cubic-bezier(.16,1,.3,1)}
#hero :is(.d-hero-media,.hero-media)>picture>img{transition:filter 1.8s cubic-bezier(.16,1,.3,1)}
#hero.fx-lit-on :is(.d-hero-media,.hero-media)>picture>img{filter:grayscale(.3) brightness(.56)}
#hero.fx-lit-on .fx-lit img{filter:brightness(1.08) contrast(1.06) saturate(1.06)}
#hero.fx-lit-on .fx-lit{opacity:1}
</style>
<style id="m-crumbs">/* крошки на телефоне не показываем: для SEO хватает BreadcrumbList и ссылок в HTML */@media (max-width:900px){.d-crumbs,.f-crumbs{display:none!important}}</style>
<style id="hero-fold">/* кнопки первого экрана видны целиком на любом экране (tools/site/hero_fold.py) */@media (max-width:760px){#hero.hero:not(.f-hero) .hero-copy{display:flex;flex-direction:column}#hero.hero:not(.f-hero) .hero-copy>*{order:6}#hero.hero:not(.f-hero) .hero-copy>.badge{order:1;align-self:flex-start}#hero.hero:not(.f-hero) .hero-copy>h1{order:2;margin-bottom:0}#hero.hero:not(.f-hero) .hero-copy>.hero-ctas{order:3;margin-top:22px}#hero.hero:not(.f-hero) .hero-copy>.lead{order:4;margin-top:24px}}@media (max-width:760px) and (max-height:620px){#hero.hero:not(.f-hero){padding-top:92px}#hero.hero:not(.f-hero) h1{margin-top:18px}}@media (max-width:900px){#hero.f-hero .hero-copy{display:flex;flex-direction:column}#hero.f-hero .hero-copy>*{order:6}#hero.f-hero .hero-copy>.f-crumbs{order:0}#hero.f-hero .hero-copy>.badge{order:1;align-self:flex-start}#hero.f-hero .hero-copy>h1{order:2;margin-bottom:0}#hero.f-hero .hero-copy>.hero-ctas{order:3;margin-top:22px}#hero.f-hero .hero-copy>.lead{order:4;margin-top:24px}#hero.f-hero .hero-media{aspect-ratio:auto;height:clamp(104px,calc(100vh - 440px),56.25vw);height:clamp(104px,calc(100svh - 440px),56.25vw)}}@media (max-width:760px){#hero.f-hero .hero-media{height:clamp(104px,calc(100vh - 440px),75vw);height:clamp(104px,calc(100svh - 440px),75vw)}.rp-page #hero.f-hero .hero-media,.lb-page #hero.f-hero .hero-media{height:clamp(104px,calc(100vh - 480px),75vw);height:clamp(104px,calc(100svh - 480px),75vw)}}@media (max-width:900px) and (max-height:620px){#hero.f-hero .hero-copy>.badge{display:none}#hero.f-hero .hero-media{height:clamp(96px,calc(100vh - 400px),75vw);height:clamp(96px,calc(100svh - 400px),75vw)}.rp-page #hero.f-hero .hero-copy>h1{font-size:clamp(26px,7.6vw,34px)}#hero.f-hero .hero-copy>h1{margin-top:30px}}@media (max-width:860px){#hero.d-hero .d-hero-media{aspect-ratio:auto;height:clamp(104px,calc(100vh - 380px),56.25vw);height:clamp(104px,calc(100svh - 380px),56.25vw)}}@media (max-width:860px) and (max-height:620px){#hero.d-hero{padding-top:84px}#hero.d-hero .d-hero-media{margin-top:14px}#hero.d-hero .d-btns{margin-top:16px}}@media (max-width:860px) and (max-height:520px){#hero.d-hero .d-hero-media{display:none}#hero.d-hero h1{margin-bottom:0}}@media (max-width:900px) and (max-height:520px){#hero.f-hero{padding-top:76px}#hero.f-hero .hero-media{display:none}#hero.f-hero .wrap{margin-top:0}#hero.f-hero .hero-copy>h1{margin-top:0}}@media (max-width:400px){#hero .hero-copy{min-width:0}#hero .hero-ctas .btn{min-width:0;max-width:100%;white-space:normal;padding:0 14px}#hero .hero-ctas .btn-t{white-space:normal;text-align:center}}@media (max-width:860px) and (max-height:620px){#hero.d-hero .d-hero-media{height:clamp(104px,calc(100vh - 410px),56.25vw);height:clamp(104px,calc(100svh - 410px),56.25vw)}}@media (max-height:520px){#hero.p-hero .p-hero-copy>.d-btns{order:3;margin-top:18px}#hero.p-hero .p-hero-copy>.p-def{order:4;margin-top:18px}}@media (max-width:760px) and (max-height:620px){#hero.p-hero .p-hero-copy>.d-btns{order:3;margin-top:18px}#hero.p-hero .p-hero-copy>.p-def{order:4;margin-top:18px}}@media (min-width:761px) and (max-height:520px){#hero.hero:not(.f-hero){padding-top:84px;min-height:0}#hero.hero:not(.f-hero) .hero-copy{display:flex;flex-direction:column}#hero.hero:not(.f-hero) .hero-copy>*{order:6}#hero.hero:not(.f-hero) .hero-copy>.badge{order:1;align-self:flex-start}#hero.hero:not(.f-hero) .hero-copy>h1{order:2;margin:14px 0 0}#hero.hero:not(.f-hero) .hero-copy>.hero-ctas{order:3;margin-top:18px}#hero.hero:not(.f-hero) .hero-copy>.lead{order:4;margin-top:18px}}@media (min-width:861px){#hero.d-hero .d-hero-copy{display:flex;flex-direction:column}#hero.d-hero .d-hero-copy>*{order:6}#hero.d-hero .d-hero-copy>.d-crumbs{order:0}#hero.d-hero .d-hero-copy>.eyebrow{order:1}#hero.d-hero .d-hero-copy>h1{order:2}#hero.d-hero .d-hero-copy>:is(.lead,.sub,.p-def):not(:is(.lead,.sub,.p-def)~*){order:3}#hero.d-hero .d-hero-copy>.d-btns:not(.d-btns~*){order:4}#hero.d-hero .d-hero-copy>.d-ticks{margin-bottom:0}}@media (min-width:901px){#hero.f-hero .hero-copy{display:flex;flex-direction:column}#hero.f-hero .hero-copy>*{order:6}#hero.f-hero .hero-copy>.f-crumbs{order:0}#hero.f-hero .hero-copy>.badge{order:1;align-self:flex-start}#hero.f-hero .hero-copy>h1{order:2}#hero.f-hero .hero-copy>.lead{order:3}#hero.f-hero .hero-copy>.hero-ctas{order:4}#hero.f-hero .hero-copy>.rp-hero-list{margin-top:26px}}@media (min-width:861px) and (max-height:820px){#hero.d-hero{padding-top:calc(clamp(68px,6vw,115px) + 8px)}#hero.d-hero .d-hero-copy>.d-crumbs{margin-bottom:0}#hero.d-hero .d-hero-copy>.eyebrow{margin:16px 0 0}#hero.d-hero .d-hero-copy>h1{margin-top:14px;line-height:1.02}#hero.d-hero .d-hero-copy>:is(.lead,.sub,.p-def){margin-top:16px}#hero.d-hero .d-btns{margin-top:20px}}@media (min-width:901px) and (max-height:820px){#hero.f-hero{padding-top:80px}#hero.f-hero .hero-copy>.f-crumbs{margin-bottom:10px}#hero.f-hero .hero-copy>h1{font-size:min(8.2vh,4.4vw);margin:16px 0 14px}.rp-page #hero.f-hero .hero-copy>h1,.lb-page #hero.f-hero .hero-copy>h1{font-size:min(8vh,3.4vw)}#hero.f-hero .hero-copy>.lead{line-height:1.5}#hero.f-hero .hero-copy>.hero-ctas{margin-top:26px}}@media (min-width:761px) and (max-height:820px){#hero.p-hero h1{font-size:min(8.4vh,4.4vw)}#hero.p-hero .p-hero-copy>.d-btns{margin-top:20px}}@media (min-width:761px) and (max-height:820px){#hero.hero:not(.f-hero) h1{font-size:min(8.4vh,4.4vw);margin:22px 0 18px}#hero.hero:not(.f-hero) .hero-ctas{margin-top:28px}}</style>
</head>
<body class="d-page rp-page">
<a class="skip" href="#main">Перейти к содержанию</a>

<!-- ============ INTRO ============ -->
<div class="intro" id="intro" aria-hidden="true">
  <div class="intro-in">
    <svg class="intro-mark" viewBox="0 0 24 24" fill="none" stroke-width="1" stroke-linejoin="round"><path class="im-shield" pathLength="100" d="M12 2.5l7.5 3v6c0 5-3.2 8.6-7.5 10-4.3-1.4-7.5-5-7.5-10v-6z" stroke="#fff"/><circle class="im-c" pathLength="100" cx="12" cy="11.5" r="2.6" stroke="#7c86ff"/><path class="im-x" pathLength="100" d="M12 6.2v2.7M12 14.1v2.7M6.8 11.5h2.6M14.6 11.5h2.6" stroke="#7c86ff"/></svg>
    <div class="intro-word"><span>ПЕСТКОНТРОЛЬ</span><b>Центр</b></div>
    <div class="intro-bar"><i></i></div>
  </div>
</div>

<div class="progress" aria-hidden="true"><i id="progress"></i></div>
<div class="cursor" aria-hidden="true"><i class="cursor-dot"></i><i class="cursor-ring"></i></div>
<div class="grain" aria-hidden="true"></div>

<header class="hdr" id="hdr">
  <div class="wrap">
    <a href="../" class="logo" aria-label="ПЕСТКОНТРОЛЬ Центр — на главную">
      <span class="logo-mark"><svg viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="1.6" stroke-linejoin="round" aria-hidden="true"><path d="M12 2.5l7.5 3v6c0 5-3.2 8.6-7.5 10-4.3-1.4-7.5-5-7.5-10v-6z"/><circle cx="12" cy="11.5" r="2.6" stroke="#7c86ff"/><path d="M12 6.2v2.7M12 14.1v2.7M6.8 11.5h2.6M14.6 11.5h2.6" stroke="#7c86ff"/></svg></span>
      <span class="logo-txt"><span class="logo-name">ПЕСТКОНТРОЛЬ</span> <span class="logo-sub">Центр</span></span>
    </a>
    <nav class="nav" aria-label="Основное меню">
      <div class="nav-dd"><button class="nav-dd-btn active" type="button" aria-expanded="false" aria-controls="nav-uslugi">Услуги<svg viewBox="0 0 12 12" aria-hidden="true"><path d="M2.5 4.5 6 8l3.5-3.5" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></button><div class="nav-dd-panel" id="nav-uslugi"><a href="../dezinfektsiya/">Дезинфекция для организаций<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../deratizatsiya/">Дератизация для организаций<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../dezinsektsiya/">Дезинсекция для организаций<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../sanitarnyy-audit/"><span>Санитарный аудит <span class="nw">(СЭС-аудит)</span></span><svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="./" aria-current="page">Разработка ППК<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../normativnaya-baza/dokumenty-dlya-rospotrebnadzora/">Документы для Роспотребнадзора<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../ochistka-dezinfektsiya-ventilyatsii/">Очистка и дезинфекция вентиляции<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../dogovor-deratizatsiya-dezinsektsiya/">Договор на обслуживание<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../#podhod" class="nav-dd-all"><span>Пест-контроль по системе IPM</span><svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a></div></div><div class="nav-dd"><button class="nav-dd-btn" type="button" aria-expanded="false" aria-controls="nav-otrasli">Отрасли<svg viewBox="0 0 12 12" aria-hidden="true"><path d="M2.5 4.5 6 8l3.5-3.5" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></button><div class="nav-dd-panel" id="nav-otrasli"><a href="../pishchevoe-proizvodstvo/">Пищевые производства<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../magaziny-i-torgovye-seti/">Магазины и торговые сети<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../restorany-i-kafe/">Рестораны и кафе<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../sklady-i-logistika/">Склады и логистика<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../farmatsevticheskie-proizvodstva/">Фармацевтические производства<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../gostinitsy/">Гостиницы и отели<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../#otrasli" class="nav-dd-all">Все отрасли<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a></div></div><a href="../dogovor-deratizatsiya-dezinsektsiya/">Договор</a><a href="../#podhod">Метод IPM</a><a href="../#usloviya">Цена</a><div class="nav-dd"><button class="nav-dd-btn" type="button" aria-expanded="false" aria-controls="nav-materialy">Материалы<svg viewBox="0 0 12 12" aria-hidden="true"><path d="M2.5 4.5 6 8l3.5-3.5" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></button><div class="nav-dd-panel" id="nav-materialy"><a href="../normativnaya-baza/">Нормативная база<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../normativnaya-baza/dokumenty-dlya-rospotrebnadzora/">Документы для Роспотребнадзора<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../materialy/programma-pest-kontrolya/"><span>Программа <span class="nw">пест-контроля</span></span><svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../materialy/zhurnal-pest-kontrolya/"><span>Журнал <span class="nw">пест-контроля</span></span><svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../materialy/pest-menedzhment-ili-razovaya-obrabotka/"><span><span class="nw">Пест-менеджмент</span> или разовая обработка</span><svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../materialy/programma-proizvodstvennogo-kontrolya-haccp/">Программа производственного контроля по ХАССП<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../materialy/" class="nav-dd-all">Все материалы<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a></div></div>
    </nav>
    <div class="hdr-right">
      <button class="srch-btn" type="button" data-srch aria-label="Поиск по сайту" aria-haspopup="dialog"><svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="11" cy="11" r="7" fill="none" stroke="currentColor" stroke-width="2"/><path d="m20 20-3.6-3.6" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg></button>
      <a class="phone" href="tel:+74951043570" aria-label="Позвонить: +7 (495) 104-35-70"><i><svg viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2" aria-hidden="true"><path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1 1 .4 1.9.7 2.8a2 2 0 0 1-.5 2.1L8 9.9a16 16 0 0 0 6 6l1.3-1.3a2 2 0 0 1 2.1-.4c.9.3 1.8.6 2.8.7a2 2 0 0 1 1.7 2z"/></svg></i><span>+7 (495) 104-35-70</span></a>
      <div class="msg">
        <a href="https://max.ru/u/f9LHodD0cOIlIUXFkt4KMFP88lD8n4TArBiTcV7RI1XML5c4o39QfsDBXUc" class="max" aria-label="Написать в Max" target="_blank" rel="noopener noreferrer"><svg viewBox="0 0 24 24" fill="#fff" aria-hidden="true"><path d="M12 3a9 9 0 0 0-7.7 13.7L3 21l4.4-1.2A9 9 0 1 0 12 3zm-3.6 12.3V8.7h1.6l2 2.8 2-2.8h1.6v6.6h-1.7v-3.9L12 14l-1.9-2.6v3.9z"/></svg></a>
        <a href="https://t.me/Centr_Dezinfection?text=%D0%97%D0%B4%D1%80%D0%B0%D0%B2%D1%81%D1%82%D0%B2%D1%83%D0%B9%D1%82%D0%B5!%20%D0%9F%D0%B8%D1%88%D1%83%20%D1%81%20%D1%81%D0%B0%D0%B9%D1%82%D0%B0%20%D0%BF%D0%B5%D1%81%D1%82%D0%BA%D0%BE%D0%BD%D1%82%D1%80%D0%BE%D0%BB%D1%8C-%D1%86%D0%B5%D0%BD%D1%82%D1%80.%D1%80%D1%84" class="tg" aria-label="Написать в Telegram" target="_blank" rel="noopener noreferrer"><svg viewBox="0 0 24 24" fill="#fff" aria-hidden="true"><path d="M21.4 4.3 2.9 11.4c-1.3.5-1.2 1.2-.2 1.5l4.7 1.5 1.8 5.6c.2.6.4.8.9.8.4 0 .6-.2.9-.4l2.3-2.2 4.7 3.5c.9.5 1.5.2 1.7-.8l3.1-14.6c.3-1.3-.5-1.8-1.4-1.5zM9.6 14.1l8.6-5.4c.4-.3.8-.1.5.2l-7.1 6.4-.3 3.3z"/></svg></a>
      </div>
      <a href="#zayavka" class="btn btn-w btn-sm" data-magnet><span class="btn-t">Бесплатный выезд</span></a>
      <button class="burger" id="burger" aria-label="Открыть меню" aria-expanded="false" aria-controls="mmenu"><span></span></button>
    </div>
  </div>
</header>
<nav class="mmenu" id="mmenu" aria-label="Мобильное меню">
  <div class="mm-group open" data-open><button class="mm-toggle" type="button" aria-expanded="true" aria-controls="mm-uslugi">Услуги<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m6 9 6 6 6-6" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/></svg></button><div class="mm-sub" id="mm-uslugi"><div><a href="../dezinfektsiya/">Дезинфекция для организаций</a><a href="../deratizatsiya/">Дератизация для организаций</a><a href="../dezinsektsiya/">Дезинсекция для организаций</a><a href="../sanitarnyy-audit/"><span>Санитарный аудит <span class="nw">(СЭС-аудит)</span></span></a><a href="./" aria-current="page">Разработка ППК</a><a href="../normativnaya-baza/dokumenty-dlya-rospotrebnadzora/">Документы для Роспотребнадзора</a><a href="../ochistka-dezinfektsiya-ventilyatsii/">Очистка и дезинфекция вентиляции</a><a href="../dogovor-deratizatsiya-dezinsektsiya/">Договор на обслуживание</a><a href="../#podhod"><span class="nw">Пест-контроль</span> по системе IPM</a></div></div></div><div class="mm-group"><button class="mm-toggle" type="button" aria-expanded="false" aria-controls="mm-otrasli">Отрасли<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m6 9 6 6 6-6" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/></svg></button><div class="mm-sub" id="mm-otrasli"><div><a href="../pishchevoe-proizvodstvo/">Пищевые производства</a><a href="../magaziny-i-torgovye-seti/">Магазины и торговые сети</a><a href="../restorany-i-kafe/">Рестораны и кафе</a><a href="../sklady-i-logistika/">Склады и логистика</a><a href="../farmatsevticheskie-proizvodstva/">Фармацевтические производства</a><a href="../gostinitsy/">Гостиницы и отели</a><a href="../#otrasli">Все отрасли</a></div></div></div><a href="../dogovor-deratizatsiya-dezinsektsiya/">Договор <small>на дератизацию и дезинсекцию</small></a><a href="../#podhod">Метод IPM</a><a href="../#usloviya">Цена</a><div class="mm-group"><button class="mm-toggle" type="button" aria-expanded="false" aria-controls="mm-materialy">Материалы<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m6 9 6 6 6-6" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/></svg></button><div class="mm-sub" id="mm-materialy"><div><a href="../normativnaya-baza/">Нормативная база</a><a href="../normativnaya-baza/dokumenty-dlya-rospotrebnadzora/">Документы для Роспотребнадзора</a><a href="../materialy/programma-pest-kontrolya/"><span>Программа <span class="nw">пест-контроля</span></span></a><a href="../materialy/zhurnal-pest-kontrolya/"><span>Журнал <span class="nw">пест-контроля</span></span></a><a href="../materialy/pest-menedzhment-ili-razovaya-obrabotka/"><span><span class="nw">Пест-менеджмент</span> или разовая обработка</span></a><a href="../materialy/programma-proizvodstvennogo-kontrolya-haccp/">Программа производственного контроля по ХАССП</a><a href="../materialy/">Все материалы</a></div></div></div>
  <a href="#zayavka" class="btn btn-w btn-lg"><span class="btn-t">Заказать бесплатное обследование</span></a>
</nav>

<main id="main" tabindex="-1">
<section class="hero f-hero" id="hero">
  <div class="hero-media"><picture><source media="(max-width:760px)" srcset="../img/rppk-hero-mob-760.webp 760w, ../img/rppk-hero-mob.webp 1024w" sizes="100vw" width="1024" height="768"><img class="f-hero-img" src="../img/rppk-hero.webp" srcset="../img/rppk-hero-1440.webp 1440w, ../img/rppk-hero.webp 1920w" sizes="100vw" width="1920" height="1072" alt="Специалист по санитарным документам и владелец пекарни за столом изучают распечатанную программу производственного контроля, за стеклом — цех" fetchpriority="high" decoding="async"></picture><div class="fx-lit" aria-hidden="true"><picture><source media="(max-width:760px)" srcset="../img/rppk-hero-mob-760.webp 760w, ../img/rppk-hero-mob.webp 1024w" sizes="100vw" width="1024" height="768"><img class="f-hero-img fx-lit-img" src="../img/rppk-hero.webp" srcset="../img/rppk-hero-1440.webp 1440w, ../img/rppk-hero.webp 1920w" sizes="100vw" width="1920" height="1072" alt="" decoding="async"></picture></div></div>
  <div class="wrap">
    <div class="hero-copy">
      <nav class="f-crumbs" aria-label="Навигационная цепочка" data-h><a href="../">Главная</a><span aria-hidden="true">→</span><span aria-current="page">Разработка ППК</span></nav>
      <span class="badge" data-h><span class="dot"></span>Для организаций и ИП · Москва и Московская область</span>
      <h1><span class="ln"><span>Разработка программы</span></span> <span class="ln"><span>производственного контроля</span></span> <span class="ln"><span><em>(ППК)</em></span></span></h1>
      <p class="lead" data-h>Разрабатываем ППК под ваш объект по СП <span class="nw">1.1.1058-01</span> и правилам 2026 года, для общепита и пищевых производств — ППК по ХАССП. С проектом приказа и формами журналов.</p>
      <ul class="rp-hero-list">
        <li>ППК — от 5&nbsp;900&nbsp;₽ за 1 рабочий день</li>
        <li>ППК по ХАССП — от 19&nbsp;900&nbsp;₽ за 3 рабочих&nbsp;дня</li>
        <li>Раздел о дезинсекции и дератизации пишет исполнитель с лицензией</li>
      </ul>
      <div class="hero-ctas" data-h>
        <a href="#zayavka" class="btn btn-w btn-lg" data-magnet><span class="btn-t">Рассчитать стоимость ППК</span></a>
        <a href="#obrazets" class="btn btn-o btn-lg" data-magnet><span class="btn-t">Посмотреть образец ППК</span></a>
      </div>
      <p class="rp-trust"><span>Лицензия на дезинфекционную деятельность <a href="https://fp.rospotrebnadzor.ru/licen/?oper=search&amp;numb_history=&amp;numb=&amp;firmget_name=&amp;ogrn_inn_nza=7714462211" target="_blank" rel="noopener">№ Л064-00111-77/01942445</a></span><span>Согласовывать ППК с Роспотребнадзором не нужно — её утверждает руководитель</span></p>
    </div>
  </div>
</section>

<div class="strip" role="group" aria-label="Коротко о разработке ППК">
  <div class="strip-track" id="stripTrack">
    <div class="strip-set">
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-file-badge" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M13 22h5a2 2 0 0 0 2-2V8a2.4 2.4 0 0 0-.706-1.706l-3.588-3.588A2.4 2.4 0 0 0 14 2H6a2 2 0 0 0-2 2v3.3" /> <path d="M14 2v5a1 1 0 0 0 1 1h5" /> <path d="m7.69 16.479 1.29 4.88a.5.5 0 0 1-.698.591l-1.843-.849a1 1 0 0 0-.879.001l-1.846.85a.5.5 0 0 1-.692-.593l1.29-4.88" /> <circle cx="6" cy="14" r="3" /> </svg><b>СП 1.1.1058-01</b> — все 9 пунктов раздела 3</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-calculator" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <rect width="16" height="20" x="4" y="2" rx="2" /> <line x1="8" x2="16" y1="6" y2="6" /> <line x1="16" x2="16" y1="14" y2="18" /> <path d="M16 10h.01" /> <path d="M12 10h.01" /> <path d="M8 10h.01" /> <path d="M12 14h.01" /> <path d="M8 14h.01" /> <path d="M12 18h.01" /> <path d="M8 18h.01" /> </svg><b>ППК от 5 900 ₽</b> — за 1 рабочий день</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-list-checks" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M13 5h8" /> <path d="M13 12h8" /> <path d="M13 19h8" /> <path d="m3 17 2 2 4-4" /> <path d="m3 7 2 2 4-4" /> </svg><b>ППК по ХАССП</b> — от 19 900 ₽ за 3 рабочих дня</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-clipboard-check" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <rect width="8" height="4" x="8" y="2" rx="1" ry="1" /> <path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2" /> <path d="m9 14 2 2 4-4" /> </svg><b>Опросный лист</b> — онлайн или в PDF</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-flask-conical" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M14 2v6a2 2 0 0 0 .245.96l5.51 10.08A2 2 0 0 1 18 22H6a2 2 0 0 1-1.755-2.96l5.51-10.08A2 2 0 0 0 10 8V2" /> <path d="M6.453 15h11.094" /> <path d="M8.5 2h7" /> </svg><b><span class="nw">План-график</span></b> — лабораторных исследований</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-clock" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg><b>Правила 2026 года</b> — в перечне норм программы</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-notebook-pen" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M13.4 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-7.4" /> <path d="M2 6h4" /> <path d="M2 10h4" /> <path d="M2 14h4" /> <path d="M2 18h4" /> <path d="M21.378 5.626a1 1 0 1 0-3.004-3.004l-5.01 5.012a2 2 0 0 0-.506.854l-.837 2.87a.5.5 0 0 0 .62.62l2.87-.837a2 2 0 0 0 .854-.506z" /> </svg><b>Приказ и журналы</b> — в комплекте</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-file-signature" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M14.364 13.634a2 2 0 0 0-.506.854l-.837 2.87a.5.5 0 0 0 .62.62l2.87-.837a2 2 0 0 0 .854-.506l4.013-4.009a1 1 0 0 0-3.004-3.004z" /> <path d="M14.487 7.858A1 1 0 0 1 14 7V2" /> <path d="M20 19.645V20a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.704.706l2.516 2.516" /> <path d="M8 18h1" /> </svg><b>Утверждает руководитель</b> — без согласования с Роспотребнадзором</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-shield-check" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z" /> <path d="m9 12 2 2 4-4" /> </svg><b>Дезинсекция и дератизация</b> — пишет исполнитель с лицензией</div>
    </div>
    <div class="strip-set" aria-hidden="true">
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-file-badge" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M13 22h5a2 2 0 0 0 2-2V8a2.4 2.4 0 0 0-.706-1.706l-3.588-3.588A2.4 2.4 0 0 0 14 2H6a2 2 0 0 0-2 2v3.3" /> <path d="M14 2v5a1 1 0 0 0 1 1h5" /> <path d="m7.69 16.479 1.29 4.88a.5.5 0 0 1-.698.591l-1.843-.849a1 1 0 0 0-.879.001l-1.846.85a.5.5 0 0 1-.692-.593l1.29-4.88" /> <circle cx="6" cy="14" r="3" /> </svg><b>СП 1.1.1058-01</b> — все 9 пунктов раздела 3</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-calculator" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <rect width="16" height="20" x="4" y="2" rx="2" /> <line x1="8" x2="16" y1="6" y2="6" /> <line x1="16" x2="16" y1="14" y2="18" /> <path d="M16 10h.01" /> <path d="M12 10h.01" /> <path d="M8 10h.01" /> <path d="M12 14h.01" /> <path d="M8 14h.01" /> <path d="M12 18h.01" /> <path d="M8 18h.01" /> </svg><b>ППК от 5 900 ₽</b> — за 1 рабочий день</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-list-checks" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M13 5h8" /> <path d="M13 12h8" /> <path d="M13 19h8" /> <path d="m3 17 2 2 4-4" /> <path d="m3 7 2 2 4-4" /> </svg><b>ППК по ХАССП</b> — от 19 900 ₽ за 3 рабочих дня</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-clipboard-check" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <rect width="8" height="4" x="8" y="2" rx="1" ry="1" /> <path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2" /> <path d="m9 14 2 2 4-4" /> </svg><b>Опросный лист</b> — онлайн или в PDF</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-flask-conical" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M14 2v6a2 2 0 0 0 .245.96l5.51 10.08A2 2 0 0 1 18 22H6a2 2 0 0 1-1.755-2.96l5.51-10.08A2 2 0 0 0 10 8V2" /> <path d="M6.453 15h11.094" /> <path d="M8.5 2h7" /> </svg><b><span class="nw">План-график</span></b> — лабораторных исследований</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-clock" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg><b>Правила 2026 года</b> — в перечне норм программы</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-notebook-pen" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M13.4 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-7.4" /> <path d="M2 6h4" /> <path d="M2 10h4" /> <path d="M2 14h4" /> <path d="M2 18h4" /> <path d="M21.378 5.626a1 1 0 1 0-3.004-3.004l-5.01 5.012a2 2 0 0 0-.506.854l-.837 2.87a.5.5 0 0 0 .62.62l2.87-.837a2 2 0 0 0 .854-.506z" /> </svg><b>Приказ и журналы</b> — в комплекте</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-file-signature" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M14.364 13.634a2 2 0 0 0-.506.854l-.837 2.87a.5.5 0 0 0 .62.62l2.87-.837a2 2 0 0 0 .854-.506l4.013-4.009a1 1 0 0 0-3.004-3.004z" /> <path d="M14.487 7.858A1 1 0 0 1 14 7V2" /> <path d="M20 19.645V20a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.704.706l2.516 2.516" /> <path d="M8 18h1" /> </svg><b>Утверждает руководитель</b> — без согласования с Роспотребнадзором</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-shield-check" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z" /> <path d="m9 12 2 2 4-4" /> </svg><b>Дезинсекция и дератизация</b> — пишет исполнитель с лицензией</div>
    </div>
  </div>
</div>

<section class="s" id="chto-takoe">
  <div class="wrap">
    <div class="head"><div class="eyebrow" data-eyebrow>Коротко</div><h2 data-split>Что такое ППК — <em>программа производственного контроля</em></h2></div>
    <p class="rp-def" data-fade><b>Программа производственного контроля (ППК)</b> — внутренний документ организации или индивидуального предпринимателя, по которому они сами контролируют соблюдение санитарных правил на своём объекте. В ППК записано, какие нормы действуют, кто отвечает за контроль, какие лабораторные исследования и как часто проводятся, кто проходит медосмотры и гигиеническое обучение, какие журналы ведутся и кого информировать при аварии. Обязанность вести производственный контроль установлена ст. 11 и 32 Федерального закона № <span class="nw">52-ФЗ</span>, требования к программе (её ещё называют планом производственного контроля) — СП <span class="nw">1.1.1058-01</span>. Если на объекте изготавливают пищевую продукцию — на производстве, в кафе, в кулинарии, — в программу входят процедуры на принципах ХАССП: такую программу называют ППК по ХАССП.</p>
    <table class="d-table rp-short" data-fade>
      <caption class="sr-only">ППК коротко</caption>
      <tbody>
        <tr><th scope="row">Кому нужна</th><td>юридическим лицам и ИП, на чью деятельность распространяются санитарные правила: офисам, магазинам, складам, гостиницам, ресторанам и кафе, пищевым и фармацевтическим производствам</td></tr>
        <tr><th scope="row">Когда составляют</th><td>до начала деятельности; изменения вносят при смене вида деятельности, технологии и других существенных изменениях (СП <span class="nw">1.1.1058-01</span>, п. 2.6)</td></tr>
        <tr><th scope="row">Срок действия</th><td>не ограничен (п. 2.6)</td></tr>
        <tr><th scope="row">Кто утверждает</th><td>руководитель, ИП или уполномоченное лицо; согласование с Роспотребнадзором правилами не предусмотрено (п. 2.6)</td></tr>
        <tr><th scope="row">Кто отвечает за выполнение</th><td>сама организация или ИП (п. 2.7; ст. 32 Федерального закона № <span class="nw">52-ФЗ</span>, п. 3)</td></tr>
        <tr><th scope="row">Форма</th><td>произвольная, но с обязательным составом из 9 пунктов (раздел 3 СП <span class="nw">1.1.1058-01</span>)</td></tr>
        <tr><th scope="row">ППК по ХАССП</th><td>ППК с процедурами на принципах ХАССП — для тех, кто изготавливает пищевую продукцию: производств, общепита, кулинарий (<span class="nw">ТР ТС 021/2011</span>, ст. 10–11)</td></tr>
        <tr><th scope="row">Что делаем мы</th><td>разрабатываем ППК и ППК по ХАССП целиком: от сведений об объекте до проекта приказа и форм журналов</td></tr>
        <tr><th scope="row">Цена и срок</th><td>ППК: от 5&nbsp;900&nbsp;₽, 1 рабочий день. ППК по ХАССП: от 19&nbsp;900&nbsp;₽, 3 рабочих дня. Срок считаем после получения сведений об объекте — <a href="#oprosnyy-list">опросного листа</a>, подробнее — в блоке <a href="#stoimost">«Стоимость»</a></td></tr>
      </tbody>
    </table>
    <p class="rp-upd" data-fade>Обновлено 08.11.2026 · Нормативная база проверена на 07.11.2026 · Автор: <a href="#avtor">Марианна Семерина, санитарный врач</a></p>
  </div>
</section>

<section class="s" id="vybor">
  <div class="wrap">
    <div class="head"><div class="eyebrow" data-eyebrow>Выбор программы</div><h2 data-split>ППК или ППК по ХАССП: <em>какая нужна вашему объекту</em></h2><p class="sub" data-fade>Процедуры на принципах ХАССП технический регламент требует от тех, кто изготавливает пищевую продукцию (<span class="nw">ТР ТС 021/2011</span>, ст. 10–11). Остальным объектам нужна ППК по СП <span class="nw">1.1.1058-01</span> и санитарным правилам их вида деятельности.</p></div>
    <table class="d-table rp-cmp" data-fade>
      <caption class="sr-only">Чем ППК отличается от ППК по ХАССП</caption>
      <thead><tr><th scope="col"><span class="sr-only">Параметр</span></th><th scope="col">ППК</th><th scope="col">ППК по ХАССП</th></tr></thead>
      <tbody>
        <tr><th scope="row">Для каких объектов</th><td data-l="ППК">офисы и <span class="nw">бизнес-центры</span>, склады — в том числе склады продуктов, магазины без собственного производства — в том числе продуктовые, гостиницы без ресторана, производства непищевой продукции, бытовые услуги</td><td data-l="ППК по ХАССП">пищевые производства, рестораны, кафе, кофейни и столовые, магазины с собственной кулинарией или пекарней, гостиницы с рестораном или пищеблоком</td></tr>
        <tr><th scope="row">Основание</th><td data-l="ППК">СП <span class="nw">1.1.1058-01</span> и санитарные правила вашего вида деятельности</td><td data-l="ППК по ХАССП">то же и <span class="nw">ТР ТС 021/2011</span>, ст. 10–11; для общепита — п. 4 СанПиН <span class="nw">2.3/2.4.4282-26</span></td></tr>
        <tr><th scope="row">Что внутри</th><td data-l="ППК">9 пунктов раздела 3 СП <span class="nw">1.1.1058-01</span>, <span class="nw">план-график</span> лабораторных исследований, проект приказа, формы журналов</td><td data-l="ППК по ХАССП">всё, что в ППК, и процедуры ХАССП: <span class="nw">блок-схемы</span> процессов, опасные факторы, критические контрольные точки и их пределы, мониторинг, действия при отклонениях</td></tr>
        <tr class="rp-cmp-s"><th scope="row">Срок</th><td data-l="ППК">1 рабочий день</td><td data-l="ППК по ХАССП">3 рабочих дня</td></tr>
        <tr class="rp-cmp-s"><th scope="row">Стоимость</th><td data-l="ППК"><b>от 5&nbsp;900&nbsp;₽</b></td><td data-l="ППК по ХАССП"><b>от 19&nbsp;900&nbsp;₽</b></td></tr>
      </tbody>
    </table>
    <p class="d-note" data-fade>Срок считаем с момента, когда получили сведения об объекте — заполненный <a href="#oprosnyy-list">опросный лист</a>. Не уверены, какая программа нужна? Опишите объект в <a href="#zayavka">заявке</a> — подскажем до начала работы.</p>
  </div>
</section>

<section class="s" id="kogda">
  <div class="wrap">
    <div class="head"><div class="eyebrow" data-eyebrow>Когда нужна</div><h2 data-split>Когда разрабатывать ППК <em>и когда её менять</em></h2></div>
    <table class="d-table rp-when" data-fade>
      <thead><tr><th scope="col">Ситуация</th><th scope="col">Что сделать</th><th scope="col">Основание</th></tr></thead>
      <tbody>
        <tr><td data-l="Ситуация">Открываете объект или начинаете новый вид деятельности</td><td data-l="Что сделать">Разработать ППК до начала работы</td><td data-l="Основание">СП <span class="nw">1.1.1058-01</span>, п. 2.6</td></tr>
        <tr><td data-l="Ситуация">Изменили технологию или ассортимент, открыли цех, кухню или кулинарию</td><td data-l="Что сделать">Внести в программу изменения и дополнения; если появилось изготовление пищевой продукции — добавить процедуры ХАССП</td><td data-l="Основание">СП <span class="nw">1.1.1058-01</span>, п. 2.6; <span class="nw">ТР ТС 021/2011</span>, ст. 10</td></tr>
        <tr><td data-l="Ситуация">В ППК остались ссылки на СанПиН <span class="nw">2.3/2.4.3590-20</span>, СП <span class="nw">2.3.6.3668-20</span>, СП <span class="nw">2.1.3678-20</span> или СП <span class="nw">2.2.3670-20</span></td><td data-l="Что сделать">Заменить их ссылками на правила, действующие с 1 сентября 2026 года</td><td data-l="Основание">Роспотребнадзор: <a href="https://cgon.rospotrebnadzor.ru/biznesu/articles/novye-sanitarnye-pravila-dlya-torgovykh-obektov-i-rynkov-realizuyushchikh-pishchevuyu-produktsiyu/" target="_blank" rel="noopener">«Не забудьте внести изменения в программу производственного контроля»</a></td></tr>
        <tr><td data-l="Ситуация">Открываете ещё один объект сети</td><td data-l="Что сделать">Подготовить программу или приложение для нового объекта: его помещения, точки отбора проб, ответственные</td><td data-l="Основание">СП <span class="nw">1.1.1058-01</span>, пп. 3.2–3.3</td></tr>
        <tr><td data-l="Ситуация">Программа взята из интернета: в ней чужое оборудование, нет плана исследований или раздела о вредителях</td><td data-l="Что сделать">Переработать под объект</td><td data-l="Основание">СП <span class="nw">1.1.1058-01</span>, п. 3.9: состав мероприятий зависит от вида деятельности и мощности объекта</td></tr>
        <tr><td data-l="Ситуация">Получили предписание по производственному контролю</td><td data-l="Что сделать">Исправить программу и документы по пунктам предписания</td><td data-l="Основание">предписание Роспотребнадзора</td></tr>
      </tbody>
    </table>
    <p class="d-note" data-fade>Не уверены, что действующую программу можно оставить? Пришлите её — посмотрим, что в ней устарело, и назовём стоимость обновления.</p>
  </div>
</section>

<section class="s" id="sostav">
  <div class="wrap">
    <div class="head"><div class="eyebrow" data-eyebrow>Состав программы</div><h2 data-split>Что входит в ППК: <em>9 обязательных пунктов</em></h2><p class="sub" data-fade>Состав программы задаёт раздел 3 СП <span class="nw">1.1.1058-01</span> — он одинаков для ППК и ППК по ХАССП. В правой колонке — как этот пункт выглядит в программе, которую разрабатываем мы.</p></div>
    <table class="d-table rp-items" data-fade>
      <thead><tr><th scope="col">Пункт</th><th scope="col">Что должно быть в программе</th><th scope="col">Как это сделано у нас</th></tr></thead>
      <tbody>
        <tr><td data-l="Пункт"><span class="rp-pt">3.1</span></td><td data-l="Что должно быть в программе">Перечень санитарных правил, методов и методик контроля</td><td data-l="Как это сделано у нас">Только действующие документы для вашего вида деятельности, с правилами 2026 года и датой проверки перечня</td></tr>
        <tr><td data-l="Пункт"><span class="rp-pt">3.2</span></td><td data-l="Что должно быть в программе">Должностные лица, на которых возложен производственный контроль</td><td data-l="Как это сделано у нас">Должности и зоны ответственности, проект приказа о назначении</td></tr>
        <tr><td data-l="Пункт"><span class="rp-pt">3.3</span></td><td data-l="Что должно быть в программе">Объекты производственного контроля, требующие лабораторных исследований, точки отбора проб и периодичность</td><td data-l="Как это сделано у нас"><span class="nw">План-график</span>: смывы, воздух, вода, сырьё и продукция, факторы на рабочих местах — по вашим помещениям</td></tr>
        <tr><td data-l="Пункт"><span class="rp-pt">3.4</span></td><td data-l="Что должно быть в программе">Должности, подлежащие медосмотрам, гигиенической подготовке и аттестации</td><td data-l="Как это сделано у нас">Таблица по должностям с периодичностью</td></tr>
        <tr><td data-l="Пункт"><span class="rp-pt">3.5</span></td><td data-l="Что должно быть в программе">Работы, услуги и продукция, подлежащие оценке соответствия, сертификации, лицензированию</td><td data-l="Как это сделано у нас">Перечень по вашему ассортименту и услугам</td></tr>
        <tr><td data-l="Пункт"><span class="rp-pt">3.6</span></td><td data-l="Что должно быть в программе">Обоснование безопасности продукции и технологии</td><td data-l="Как это сделано у нас">В ППК по ХАССП — <span class="nw">блок-схемы</span> процессов, ссылки на технологическую документацию и процедуры ХАССП</td></tr>
        <tr><td data-l="Пункт"><span class="rp-pt">3.7</span></td><td data-l="Что должно быть в программе">Формы учёта и отчётности</td><td data-l="Как это сделано у нас">Перечень журналов и сами формы</td></tr>
        <tr><td data-l="Пункт"><span class="rp-pt">3.8</span></td><td data-l="Что должно быть в программе">Аварийные ситуации и порядок информирования</td><td data-l="Как это сделано у нас">Ситуации вашего объекта: отключение воды или электроэнергии, авария канализации, поломка холодильного оборудования — и кого информировать</td></tr>
        <tr><td data-l="Пункт"><span class="rp-pt">3.9</span></td><td data-l="Что должно быть в программе">Другие мероприятия, необходимые для контроля</td><td data-l="Как это сделано у нас">Уборка и дезинфекция, дезинсекция и дератизация, обращение с отходами, личная гигиена — в объёме, который нужен объекту</td></tr>
      </tbody>
    </table>
    <div class="rp-haccp" id="haccp" data-fade>
      <h3>Что добавляется в ППК по ХАССП</h3>
      <p>Если объект изготавливает пищевую продукцию, программу дополняют процедурами на принципах ХАССП. <span class="nw">ТР ТС 021/2011</span> требует определять контролируемые этапы технологических операций «в программах производственного контроля» (ст. 10, ч. 3, п. 3), а для общепита производственный контроль на принципах ХАССП установлен п. 4 СанПиН <span class="nw">2.3/2.4.4282-26</span>. Что изготовитель должен определить, перечислено в ст. 11, ч. 3 регламента — эти пункты и входят в ППК по ХАССП вместе с <span class="nw">блок-схемами</span> процессов:</p>
      <ol class="rp-hlist">
        <li><b>Опасные факторы</b><span>что в процессе может привести к выпуску небезопасной продукции (п. 1)</span></li>
        <li><b>Критические контрольные точки</b><span>параметры операций, сырья и упаковки, которые нужно контролировать, чтобы устранить эти факторы (п. 2)</span></li>
        <li><b>Предельные значения</b><span>пределы параметров в каждой критической контрольной точке (п. 3)</span></li>
        <li><b>Мониторинг</b><span>порядок контроля точек: кто, как и как часто проверяет и куда записывает (п. 4)</span></li>
        <li><b>Действия при отклонении</b><span>что делать, если показатель вышел за предел (п. 5)</span></li>
        <li><b>Проверки, уборка и вредители</b><span>периодичность проверки продукции, уборки, мойки, дезинфекции, дератизации и дезинсекции и меры против проникновения грызунов, насекомых и птиц (пп. 6–8)</span></li>
      </ol>
    </div>
  </div>
</section>

<section class="s" id="rezultat">
  <div class="wrap">
    <div class="head"><div class="eyebrow" data-eyebrow>Результат</div><h2 data-split>Что вы получите <em>вместе с программой</em></h2></div>
    <ol class="rp-docs" data-fade>
      <li><b>Программа производственного контроля</b><span>все 9 пунктов раздела 3 СП <span class="nw">1.1.1058-01</span>, сведения об объекте, титул с грифом «Утверждаю», лист ознакомления</span></li>
      <li><b>Проект приказа</b><span>об утверждении ППК и назначении ответственных за производственный контроль — его подписывает руководитель</span></li>
      <li><b><span class="nw">План-график</span> лабораторных исследований</b><span>что исследовать, где отбирать пробы, как часто и кто выполняет — в составе программы</span></li>
      <li><b>Формы журналов</b><span>журналы, которые требуют программа и санитарные правила вашего вида деятельности</span></li>
      <li><b>Процедуры ХАССП</b><span>в ППК по ХАССП: <span class="nw">блок-схемы</span> процессов, опасные факторы, критические контрольные точки, пределы, мониторинг и действия при отклонениях</span></li>
      <li><b>Раздел «Дезинсекция и дератизация»</b><span>периодичность, способы и документы — раздел пишет исполнитель с лицензией на дезинфекционную деятельность</span></li>
    </ol>
    <p class="d-note" data-fade>Документы передаём в электронном виде, готовыми к печати и подписи.</p>
  </div>
</section>

<section class="s" id="kak-rabotaem">
  <div class="wrap">
    <div class="head"><div class="eyebrow" data-eyebrow>Порядок работы</div><h2 data-split>Как мы разрабатываем ППК <em>и ППК по ХАССП</em></h2></div>
    <ol class="d-steps rp-steps" data-group="steps">
      <li><b>Заявка</b><span>Вид деятельности, площадь, адрес и сроки. Подскажем, нужна ли ППК по ХАССП, и назовём стоимость до начала работы.</span></li>
      <li><b>Сведения об объекте</b><span>Помещения, оборудование, персонал, ассортимент и действующие договоры — по <a href="#oprosnyy-list">опросному листу</a> и документам. Для ППК по ХАССП разбираем технологические процессы, при необходимости специалист приезжает на объект. Если программа уже есть, пришлите её.</span></li>
      <li><b>Программа — за 1 или 3 рабочих дня</b><span>ППК готовим за 1 рабочий день, ППК по ХАССП — за 3: все пункты раздела 3, <span class="nw">план-график</span> исследований, раздел о дезинсекции и дератизации, в ППК по ХАССП — ещё процедуры ХАССП и <span class="nw">блок-схемы</span>.</span></li>
      <li><b>Согласование с вами</b><span>Вносим ваши правки и передаём итоговую версию.</span></li>
      <li><b>Утверждение и запуск</b><span>Руководитель утверждает ППК приказом, ответственный получает <span class="nw">план-график</span> и формы журналов. Отвечаем на вопросы, как их вести.</span></li>
    </ol>
    <p class="d-note" data-fade>Когда меняются санитарные правила, технология или вид деятельности, в программу вносят изменения и дополнения (СП <span class="nw">1.1.1058-01</span>, п. 2.6) — их тоже готовим мы.</p>
  </div>
</section>

<section class="s" id="oprosnyy-list">
  <div class="wrap">
    <div class="head"><div class="eyebrow" data-eyebrow>Опросный лист</div><h2 data-split>Что нужно для разработки ППК: <em>опросный лист заказчика</em></h2><p class="sub" data-fade>Чтобы программа описывала ваш объект, нужны сведения о нём: организация, помещения, персонал, вода, вентиляция, оборудование, отходы и действующие договоры. Мы собираем их опросным листом заказчика: для ППК в нём 29 вопросов, для ППК по ХАССП — ещё 13 о продукции и технологических процессах. Отвечайте на то, что знаете, остальное уточним по телефону. По заполненному листу называем точную цену и срок.</p></div>
    <table class="d-table rp-ol-t" data-fade>
      <caption class="sr-only">Разделы опросного листа заказчика для разработки ППК и ППК по ХАССП</caption>
      <thead><tr><th scope="col">Раздел</th><th scope="col">Что спрашиваем</th><th scope="col">Для чего в программе</th></tr></thead>
      <tbody>
        <tr><td data-l="Раздел"><span class="rp-ol-sn"><span class="rp-pt">1</span><b>Организация и объект</b></span></td><td data-l="Что спрашиваем">реквизиты, адрес, вид деятельности, площадь и помещения, режим работы</td><td data-l="Для чего в программе">титул программы и перечень норм для вашего вида деятельности (СП <span class="nw">1.1.1058-01</span>, п. 3.1)</td></tr>
        <tr><td data-l="Раздел"><span class="rp-ol-sn"><span class="rp-pt">2</span><b>Персонал</b></span></td><td data-l="Что спрашиваем">численность и должности, кто работает с пищевой продукцией или водой, ответственный, спецоценка условий труда</td><td data-l="Для чего в программе">ответственные, медосмотры и гигиеническое обучение, контроль условий труда (пп. 3.2, 3.4; СП <span class="nw">2.2.4285-26</span>)</td></tr>
        <tr><td data-l="Раздел"><span class="rp-ol-sn"><span class="rp-pt">3</span><b>Помещения, инженерные системы и оборудование</b></span></td><td data-l="Что спрашиваем">вода, канализация, вентиляция, оборудование, рабочие места с особыми условиями</td><td data-l="Для чего в программе">точки лабораторного контроля и аварийные ситуации (пп. 3.3, 3.8)</td></tr>
        <tr><td data-l="Раздел"><span class="rp-ol-sn"><span class="rp-pt">4</span><b>Отходы, подрядчики и документы</b></span></td><td data-l="Что спрашиваем">отходы, договоры на дезинсекцию и дератизацию и с лабораторией, лицензии, действующая ППК, проверки</td><td data-l="Для чего в программе">обращение с отходами, дезинсекция и дератизация, лицензии и формы учёта (пп. 3.5, 3.7, 3.9)</td></tr>
        <tr><td data-l="Раздел"><span class="rp-ol-sn"><span class="rp-pt">5</span><b>Продукция и сырьё</b></span><span class="rp-tag rp-tag-h">только ППК по ХАССП</span></td><td data-l="Что спрашиваем">ассортимент или меню, объём выпуска, сырьё, сроки годности и хранение</td><td data-l="Для чего в программе">описание продукции и опасные факторы (ТР ТС 021/2011, ст. 11, ч. 3, п. 1)</td></tr>
        <tr><td data-l="Раздел"><span class="rp-ol-sn"><span class="rp-pt">6</span><b>Технологические процессы</b></span><span class="rp-tag rp-tag-h">только ППК по ХАССП</span></td><td data-l="Что спрашиваем">операции от приёмки до выдачи, тепловая обработка и охлаждение, цеха, холодильное оборудование, документы ХАССП</td><td data-l="Для чего в программе"><span class="nw">блок-схемы</span>, критические контрольные точки и их пределы (ТР ТС 021/2011, ст. 10, ч. 3; ст. 11, ч. 3)</td></tr>
      </tbody>
    </table>
    <div class="rp-ol" data-fade>
      <div class="card rp-ol-docs">
        <h3>Документы, которые пригодятся</h3>
        <ul class="rp-ol-dl"><li>Реквизиты организации (карточка предприятия)</li><li>План помещений с их назначением (поэтажный план, экспликация) — или фото помещений</li><li>Штатное расписание или список должностей с численностью</li><li>Перечень оборудования</li><li>Действующая ППК и протоколы лабораторных исследований за последний год — если есть</li><li>Отчёт о специальной оценке условий труда — если проводилась</li><li>Договоры: дезинсекция и дератизация, вывоз отходов, лаборатория, стирка — если есть</li><li>Предписания Роспотребнадзора — если были</li></ul>
        <p class="rp-ol-dh">Для ППК по ХАССП — ещё</p>
        <ul class="rp-ol-dl"><li>Меню или ассортиментный перечень</li><li>Технологические карты, рецептуры, ТУ и ТИ</li><li>План цехов с расстановкой оборудования</li><li>Действующие документы ХАССП и журналы — если есть</li></ul>
        <p class="rp-ol-dn">Без документов тоже можно начать — по ответам на вопросы. Документы присылайте на <a href="mailto:b2b@pestcontrol-center.ru">b2b@pestcontrol-center.ru</a>, в теме письма — название организации.</p>
      </div>
      <div class="rp-ol-get">
        <div class="card rp-ol-how">
          <h3>Как заполнить опросный лист</h3>
          <ol class="rp-ol-ways">
            <li><b>Онлайн на этой странице</b><span>ответы придут нам вместе с вашими контактами, незаконченный лист сохраняется в этом браузере</span></li>
            <li><b>В PDF</b><span>распечатайте, заполните и пришлите скан или фото на <a href="mailto:b2b@pestcontrol-center.ru">b2b@pestcontrol-center.ru</a></span></li>
            <li><b>По телефону</b><span>специалист задаст вопросы сам: <a href="tel:+74951043570">+7 (495) <span class="nw">104-35-70</span></a></span></li>
          </ol>
          <a href="#oprosnyy-online" class="btn btn-w btn-lg" data-ol-open><span class="btn-t">Заполнить опросный лист онлайн</span></a>
        </div>
        <div class="rp-ol-pdfs">
        <a class="rp-ol-pdf" href="oprosnyy-list-ppk.pdf" target="_blank" rel="noopener" data-dl="oprosnyy_ppk"><span class="rp-ol-th"><img src="../img/oprosnyy-ppk-p1-360.webp" srcset="../img/oprosnyy-ppk-p1-240.webp 240w, ../img/oprosnyy-ppk-p1-360.webp 360w, ../img/oprosnyy-ppk-p1-720.webp 720w" sizes="(max-width:600px) 30vw, 120px" width="360" height="509" loading="lazy" decoding="async" alt="Опросный лист для разработки ППК, лист 1: шапка ПЕСТКОНТРОЛЬ Центра, способы отправки, цена и срок, вопросы раздела «Организация и объект»"></span><span class="rp-ol-pt"><b>Опросный лист для ППК</b><small>PDF · 3 листа · 256 КБ</small><em>Скачать PDF</em></span></a>
        <a class="rp-ol-pdf" href="oprosnyy-list-ppk-po-haccp.pdf" target="_blank" rel="noopener" data-dl="oprosnyy_haccp"><span class="rp-ol-th"><img src="../img/oprosnyy-haccp-p1-360.webp" srcset="../img/oprosnyy-haccp-p1-240.webp 240w, ../img/oprosnyy-haccp-p1-360.webp 360w, ../img/oprosnyy-haccp-p1-720.webp 720w" sizes="(max-width:600px) 30vw, 120px" width="360" height="509" loading="lazy" decoding="async" alt="Опросный лист для разработки ППК по ХАССП, лист 1: шапка ПЕСТКОНТРОЛЬ Центра, способы отправки, цена и срок, вопросы раздела «Организация и объект»"></span><span class="rp-ol-pt"><b>Опросный лист для ППК по ХАССП</b><small>PDF · 4 листа · 294 КБ</small><em>Скачать PDF</em></span></a>
        </div>
      </div>
    </div>
    <div class="rp-ol-box" id="oprosnyy-online" hidden></div>
    <template id="olTpl"><form class="form rp-olf" id="olForm" novalidate aria-labelledby="olTitle"><div class="fbody"><div class="rp-olf-top"><h3 id="olTitle">Опросный лист заказчика для разработки ППК</h3><p class="rp-olf-fs">Обязательны только программа, вид объекта, имя и телефон. Ответы сохраняются в этом браузере, пока вы не отправите лист.</p></div><fieldset class="rp-olf-sec rp-olf-prog"><legend><span>Какая программа нужна<b class="rp-olf-req" aria-hidden="true">*</b></span></legend><div class="rp-olf-q" data-req="prog" role="radiogroup" aria-required="true" aria-label="Какая программа нужна"><div class="rp-chips"><label class="rp-chip"><input type="radio" name="prog" value="ППК"><span><span class="rp-ct">ППК</span></span></label><label class="rp-chip"><input type="radio" name="prog" value="ППК по ХАССП"><span><span class="rp-ct">ППК по ХАССП</span></span></label><label class="rp-chip"><input type="radio" name="prog" value="Не знаю, какая нужна"><span><span class="rp-ct">Не знаю, какая нужна</span></span></label></div><small class="ferr">Выберите программу</small></div><p class="rp-olf-sn">Для ППК по ХАССП добавятся разделы 5 и 6 — о продукции и технологических процессах.</p></fieldset><fieldset class="rp-olf-sec" data-sec="1" data-title="Организация и объект"><legend><span class="rp-pt">1</span><span>Организация и объект</span></legend><div class="rp-olf-g"><div class="field rp-olf-q" data-q="1.1" data-label="Организация или ИП"><label for="ol-1-1"><i>1.1</i>Организация или ИП</label><input id="ol-1-1" name="q1.1" maxlength="250" placeholder="ООО «…» или ИП Фамилия И. О." autocomplete="organization"></div><div class="field rp-olf-q" data-q="1.2" data-label="ИНН"><label for="ol-1-2"><i>1.2</i>ИНН</label><input id="ol-1-2" name="q1.2" maxlength="20" placeholder="10 или 12 цифр" inputmode="numeric"></div><div class="field rp-olf-q rp-olf-w" data-q="1.3" data-label="Руководитель, который утвердит программу"><label for="ol-1-3"><i>1.3</i>Руководитель, который утвердит программу</label><input id="ol-1-3" name="q1.3" maxlength="200" placeholder="должность, фамилия, имя, отчество"></div><div class="field rp-olf-q" data-q="1.4" data-label="Адрес объекта"><label for="ol-1-4"><i>1.4</i>Адрес объекта</label><input id="ol-1-4" name="q1.4" maxlength="300" placeholder="город, улица, дом, помещение"></div><div class="rp-olf-q rp-olf-w" data-q="1.5" data-label="Вид объекта" data-req="type" role="radiogroup" aria-required="true" aria-labelledby="ol-1-5-l"><p class="rp-olf-l" id="ol-1-5-l"><i>1.5</i>Вид объекта<b class="rp-olf-req" aria-hidden="true">*</b></p><div class="rp-chips"><label class="rp-chip"><input type="radio" name="otype" value="Ресторан, кафе, столовая" data-type="Ресторан или кафе"><span><span class="rp-ct">Ресторан, кафе, столовая</span></span></label><label class="rp-chip"><input type="radio" name="otype" value="Магазин или торговая сеть" data-type="Магазин или торговая сеть"><span><span class="rp-ct">Магазин или торговая сеть</span></span></label><label class="rp-chip"><input type="radio" name="otype" value="Пищевое производство" data-type="Пищевое производство"><span><span class="rp-ct">Пищевое производство</span></span></label><label class="rp-chip"><input type="radio" name="otype" value="Склад, логистика" data-type="Склад, логистика"><span><span class="rp-ct">Склад, логистика</span></span></label><label class="rp-chip"><input type="radio" name="otype" value="Гостиница" data-type="Гостиница"><span><span class="rp-ct">Гостиница</span></span></label><label class="rp-chip"><input type="radio" name="otype" value="Фармацевтическое производство" data-type="Фармацевтическое производство"><span><span class="rp-ct">Фармацевтическое производство</span></span></label><label class="rp-chip"><input type="radio" name="otype" value="Офис, бизнес-центр" data-type="Другое"><span><span class="rp-ct">Офис, <span class="nw">бизнес-центр</span></span></span></label><label class="rp-chip"><input type="radio" name="otype" value="Бытовые услуги" data-type="Другое"><span><span class="rp-ct">Бытовые услуги</span></span></label><label class="rp-chip"><input type="radio" name="otype" value="Другое" data-type="Другое"><span><span class="rp-ct">Другое</span></span></label></div><small class="ferr">Выберите вид объекта</small></div><div class="field rp-olf-q rp-olf-w" data-q="1.6" data-label="Что делаете на объекте"><label for="ol-1-6"><i>1.6</i>Что делаете на объекте</label><textarea id="ol-1-6" name="q1.6" maxlength="600" placeholder="виды деятельности, услуги, товары; коды ОКВЭД, если знаете"></textarea></div><div class="rp-olf-q rp-olf-w" data-q="1.7" data-label="Где расположен объект" role="radiogroup" aria-labelledby="ol-1-7-l"><p class="rp-olf-l" id="ol-1-7-l"><i>1.7</i>Где расположен объект</p><div class="rp-chips"><label class="rp-chip"><input type="radio" name="q1.7" value="отдельное здание"><span><span class="rp-ct">отдельное здание</span></span></label><label class="rp-chip"><input type="radio" name="q1.7" value="помещение в жилом доме"><span><span class="rp-ct">помещение в жилом доме</span></span></label><label class="rp-chip"><input type="radio" name="q1.7" value="в торговом или бизнес-центре"><span><span class="rp-ct">в торговом или <span class="nw">бизнес-центре</span></span></span></label><label class="rp-chip"><input type="radio" name="q1.7" value="другое"><span><span class="rp-ct">другое</span></span></label></div></div><div class="field rp-olf-q" data-q="1.8" data-label="Площадь и помещения"><label for="ol-1-8"><i>1.8</i>Площадь и помещения</label><input id="ol-1-8" name="q1.8" maxlength="300" placeholder="например: 320 м², 12 помещений, есть подвал"></div><div class="field rp-olf-q" data-q="1.9" data-label="Режим работы"><label for="ol-1-9"><i>1.9</i>Режим работы</label><input id="ol-1-9" name="q1.9" maxlength="200" placeholder="дни, часы, число смен"></div></div></fieldset><fieldset class="rp-olf-sec" data-sec="2" data-title="Персонал"><legend><span class="rp-pt">2</span><span>Персонал</span></legend><div class="rp-olf-g"><div class="field rp-olf-q" data-q="2.1" data-label="Сколько человек работает"><label for="ol-2-1"><i>2.1</i>Сколько человек работает</label><input id="ol-2-1" name="q2.1" maxlength="150" placeholder="всего и в самую большую смену"></div><div class="field rp-olf-q rp-olf-w" data-q="2.2" data-label="Должности и число работников на каждой"><label for="ol-2-2"><i>2.2</i>Должности и число работников на каждой</label><textarea id="ol-2-2" name="q2.2" maxlength="800" placeholder="или приложите штатное расписание"></textarea></div><div class="field rp-olf-q rp-olf-w" data-q="2.3" data-label="Кто работает с пищевой продукцией, питьевой водой, детьми или оказывает бытовые услуги"><label for="ol-2-3"><i>2.3</i>Кто работает с пищевой продукцией, питьевой водой, детьми или оказывает бытовые услуги</label><textarea id="ol-2-3" name="q2.3" maxlength="500" placeholder="должности — для медосмотров и гигиенического обучения"></textarea></div><div class="field rp-olf-q rp-olf-w" data-q="2.4" data-label="Ответственный за производственный контроль"><label for="ol-2-4"><i>2.4</i>Ответственный за производственный контроль</label><input id="ol-2-4" name="q2.4" maxlength="200" placeholder="должность, ФИО — если уже назначен"></div><div class="rp-olf-q rp-olf-w" data-q="2.5" data-label="Специальная оценка условий труда" role="radiogroup" aria-labelledby="ol-2-5-l"><p class="rp-olf-l" id="ol-2-5-l"><i>2.5</i>Специальная оценка условий труда</p><div class="rp-chips"><label class="rp-chip"><input type="radio" name="q2.5" value="проводилась"><span><span class="rp-ct">проводилась</span></span></label><label class="rp-chip"><input type="radio" name="q2.5" value="не проводилась"><span><span class="rp-ct">не проводилась</span></span></label><label class="rp-chip"><input type="radio" name="q2.5" value="не знаю"><span><span class="rp-ct">не знаю</span></span></label></div><div class="field rp-olf-x"><label class="sr-only" for="ol-2-5-x">Специальная оценка условий труда: год, если проводилась</label><input id="ol-2-5-x" name="q2.5x" maxlength="200" placeholder="год, если проводилась" data-x="год, если проводилась"></div></div></div></fieldset><fieldset class="rp-olf-sec" data-sec="3" data-title="Помещения, инженерные системы и оборудование"><legend><span class="rp-pt">3</span><span>Помещения, инженерные системы и оборудование</span></legend><div class="rp-olf-g"><div class="rp-olf-q rp-olf-w" data-q="3.1" data-label="Холодная вода" role="radiogroup" aria-labelledby="ol-3-1-l"><p class="rp-olf-l" id="ol-3-1-l"><i>3.1</i>Холодная вода</p><div class="rp-chips"><label class="rp-chip"><input type="radio" name="q3.1" value="центральный водопровод"><span><span class="rp-ct">центральный водопровод</span></span></label><label class="rp-chip"><input type="radio" name="q3.1" value="своя скважина"><span><span class="rp-ct">своя скважина</span></span></label><label class="rp-chip"><input type="radio" name="q3.1" value="привозная вода"><span><span class="rp-ct">привозная вода</span></span></label></div></div><div class="rp-olf-q rp-olf-w" data-q="3.2" data-label="Горячая вода" role="radiogroup" aria-labelledby="ol-3-2-l"><p class="rp-olf-l" id="ol-3-2-l"><i>3.2</i>Горячая вода</p><div class="rp-chips"><label class="rp-chip"><input type="radio" name="q3.2" value="центральная"><span><span class="rp-ct">центральная</span></span></label><label class="rp-chip"><input type="radio" name="q3.2" value="водонагреватели на объекте"><span><span class="rp-ct">водонагреватели на объекте</span></span></label><label class="rp-chip"><input type="radio" name="q3.2" value="нет горячей воды"><span><span class="rp-ct">нет горячей воды</span></span></label></div></div><div class="rp-olf-q rp-olf-w" data-q="3.3" data-label="Канализация" role="radiogroup" aria-labelledby="ol-3-3-l"><p class="rp-olf-l" id="ol-3-3-l"><i>3.3</i>Канализация</p><div class="rp-chips"><label class="rp-chip"><input type="radio" name="q3.3" value="центральная"><span><span class="rp-ct">центральная</span></span></label><label class="rp-chip"><input type="radio" name="q3.3" value="локальная: септик, очистные"><span><span class="rp-ct">локальная: септик, очистные</span></span></label></div></div><div class="rp-olf-q rp-olf-w" data-q="3.4" data-label="Вентиляция" role="group" aria-labelledby="ol-3-4-l"><p class="rp-olf-l" id="ol-3-4-l"><i>3.4</i>Вентиляция</p><div class="rp-chips"><label class="rp-chip"><input type="checkbox" name="q3.4" value="приточно-вытяжная механическая"><span><span class="rp-ct"><span class="nw">приточно-вытяжная</span> механическая</span></span></label><label class="rp-chip"><input type="checkbox" name="q3.4" value="только естественная"><span><span class="rp-ct">только естественная</span></span></label><label class="rp-chip"><input type="checkbox" name="q3.4" value="кондиционеры, сплит-системы"><span><span class="rp-ct">кондиционеры, <span class="nw">сплит-системы</span></span></span></label></div><div class="field rp-olf-x"><label class="sr-only" for="ol-3-4-x">Вентиляция: когда последний раз чистили</label><input id="ol-3-4-x" name="q3.4x" maxlength="200" placeholder="когда последний раз чистили" data-x="когда последний раз чистили"></div></div><div class="field rp-olf-q rp-olf-w" data-q="3.5" data-label="Основное оборудование"><label for="ol-3-5"><i>3.5</i>Основное оборудование</label><textarea id="ol-3-5" name="q3.5" maxlength="800" placeholder="холодильное и технологическое оборудование, сколько компьютеров, источники шума, тепла, излучения"></textarea></div><div class="field rp-olf-q rp-olf-w" data-q="3.6" data-label="Рабочие места с особыми условиями"><label for="ol-3-6"><i>3.6</i>Рабочие места с особыми условиями</label><textarea id="ol-3-6" name="q3.6" maxlength="500" placeholder="работа в холоде или жаре, с химическими средствами, на улице, ночью"></textarea></div></div></fieldset><fieldset class="rp-olf-sec" data-sec="4" data-title="Отходы, подрядчики и документы"><legend><span class="rp-pt">4</span><span>Отходы, подрядчики и документы</span></legend><div class="rp-olf-g"><div class="rp-olf-q rp-olf-w" data-q="4.1" data-label="Какие отходы образуются" role="group" aria-labelledby="ol-4-1-l"><p class="rp-olf-l" id="ol-4-1-l"><i>4.1</i>Какие отходы образуются</p><div class="rp-chips"><label class="rp-chip"><input type="checkbox" name="q4.1" value="твёрдые коммунальные"><span><span class="rp-ct">твёрдые коммунальные</span></span></label><label class="rp-chip"><input type="checkbox" name="q4.1" value="пищевые"><span><span class="rp-ct">пищевые</span></span></label><label class="rp-chip"><input type="checkbox" name="q4.1" value="ртутьсодержащие лампы"><span><span class="rp-ct">ртутьсодержащие лампы</span></span></label><label class="rp-chip"><input type="checkbox" name="q4.1" value="медицинские"><span><span class="rp-ct">медицинские</span></span></label><label class="rp-chip"><input type="checkbox" name="q4.1" value="производственные"><span><span class="rp-ct">производственные</span></span></label></div><div class="field rp-olf-x"><label class="sr-only" for="ol-4-1-x">Какие отходы образуются: есть ли договор с региональным оператором</label><input id="ol-4-1-x" name="q4.1x" maxlength="200" placeholder="есть ли договор с региональным оператором" data-x="есть ли договор с региональным оператором"></div></div><div class="rp-olf-q rp-olf-w" data-q="4.2" data-label="Дезинсекция и дератизация" role="radiogroup" aria-labelledby="ol-4-2-l"><p class="rp-olf-l" id="ol-4-2-l"><i>4.2</i>Дезинсекция и дератизация</p><div class="rp-chips"><label class="rp-chip"><input type="radio" name="q4.2" value="есть договор"><span><span class="rp-ct">есть договор</span></span></label><label class="rp-chip"><input type="radio" name="q4.2" value="нет договора"><span><span class="rp-ct">нет договора</span></span></label></div><div class="field rp-olf-x"><label class="sr-only" for="ol-4-2-x">Дезинсекция и дератизация: исполнитель по договору</label><input id="ol-4-2-x" name="q4.2x" maxlength="200" placeholder="исполнитель по договору" data-x="исполнитель по договору"></div></div><div class="rp-olf-q rp-olf-w" data-q="4.3" data-label="Лаборатория для исследований" role="radiogroup" aria-labelledby="ol-4-3-l"><p class="rp-olf-l" id="ol-4-3-l"><i>4.3</i>Лаборатория для исследований</p><div class="rp-chips"><label class="rp-chip"><input type="radio" name="q4.3" value="есть договор"><span><span class="rp-ct">есть договор</span></span></label><label class="rp-chip"><input type="radio" name="q4.3" value="нет договора"><span><span class="rp-ct">нет договора</span></span></label></div><div class="field rp-olf-x"><label class="sr-only" for="ol-4-3-x">Лаборатория для исследований: какая лаборатория</label><input id="ol-4-3-x" name="q4.3x" maxlength="200" placeholder="какая лаборатория" data-x="какая лаборатория"></div></div><div class="rp-olf-q rp-olf-w" data-q="4.4" data-label="Стирка белья и спецодежды" role="radiogroup" aria-labelledby="ol-4-4-l"><p class="rp-olf-l" id="ol-4-4-l"><i>4.4</i>Стирка белья и спецодежды</p><div class="rp-chips"><label class="rp-chip"><input type="radio" name="q4.4" value="на объекте"><span><span class="rp-ct">на объекте</span></span></label><label class="rp-chip"><input type="radio" name="q4.4" value="по договору"><span><span class="rp-ct">по договору</span></span></label><label class="rp-chip"><input type="radio" name="q4.4" value="не нужна"><span><span class="rp-ct">не нужна</span></span></label></div></div><div class="field rp-olf-q rp-olf-w" data-q="4.5" data-label="Лицензии, сертификаты, декларации"><label for="ol-4-5"><i>4.5</i>Лицензии, сертификаты, декларации</label><textarea id="ol-4-5" name="q4.5" maxlength="500" placeholder="на какие работы, услуги или продукцию оформлены"></textarea></div><div class="rp-olf-q rp-olf-w" data-q="4.6" data-label="Действующая ППК" role="radiogroup" aria-labelledby="ol-4-6-l"><p class="rp-olf-l" id="ol-4-6-l"><i>4.6</i>Действующая ППК</p><div class="rp-chips"><label class="rp-chip"><input type="radio" name="q4.6" value="есть"><span><span class="rp-ct">есть</span></span></label><label class="rp-chip"><input type="radio" name="q4.6" value="нет"><span><span class="rp-ct">нет</span></span></label></div><div class="field rp-olf-x"><label class="sr-only" for="ol-4-6-x">Действующая ППК: год утверждения, если есть</label><input id="ol-4-6-x" name="q4.6x" maxlength="200" placeholder="год утверждения, если есть" data-x="год утверждения, если есть"></div></div><div class="field rp-olf-q" data-q="4.7" data-label="Проверки Роспотребнадзора"><label for="ol-4-7"><i>4.7</i>Проверки Роспотребнадзора</label><input id="ol-4-7" name="q4.7" maxlength="300" placeholder="дата последней проверки, было ли предписание"></div><div class="field rp-olf-q rp-olf-w" data-q="4.8" data-label="Что нужно и к какому сроку"><label for="ol-4-8"><i>4.8</i>Что нужно и к какому сроку</label><textarea id="ol-4-8" name="q4.8" maxlength="500" placeholder="новая программа, обновление, исполнение предписания; сколько объектов в сети"></textarea></div></div></fieldset><fieldset class="rp-olf-sec" data-sec="5" data-title="Продукция и сырьё" data-haccp hidden><legend><span class="rp-pt">5</span><span>Продукция и сырьё</span></legend><p class="rp-olf-sn">Раздел для ППК по ХАССП: заполните, если на объекте изготавливают пищевую продукцию.</p><div class="rp-olf-g"><div class="field rp-olf-q rp-olf-w" data-q="5.1" data-label="Что изготавливаете"><label for="ol-5-1"><i>5.1</i>Что изготавливаете</label><textarea id="ol-5-1" name="q5.1" maxlength="800" placeholder="группы продукции или блюд; приложите меню или ассортиментный перечень"></textarea></div><div class="field rp-olf-q" data-q="5.2" data-label="Объём выпуска"><label for="ol-5-2"><i>5.2</i>Объём выпуска</label><input id="ol-5-2" name="q5.2" maxlength="200" placeholder="кг, штук или порций в смену; для общепита — посадочных мест"></div><div class="rp-olf-q rp-olf-w" data-q="5.3" data-label="Как продукция попадает к потребителю" role="group" aria-labelledby="ol-5-3-l"><p class="rp-olf-l" id="ol-5-3-l"><i>5.3</i>Как продукция попадает к потребителю</p><div class="rp-chips"><label class="rp-chip"><input type="checkbox" name="q5.3" value="зал или раздача"><span><span class="rp-ct">зал или раздача</span></span></label><label class="rp-chip"><input type="checkbox" name="q5.3" value="на вынос"><span><span class="rp-ct">на вынос</span></span></label><label class="rp-chip"><input type="checkbox" name="q5.3" value="доставка"><span><span class="rp-ct">доставка</span></span></label><label class="rp-chip"><input type="checkbox" name="q5.3" value="оптовая продажа"><span><span class="rp-ct">оптовая продажа</span></span></label><label class="rp-chip"><input type="checkbox" name="q5.3" value="кейтеринг"><span><span class="rp-ct">кейтеринг</span></span></label></div></div><div class="rp-olf-q rp-olf-w" data-q="5.4" data-label="Основное сырьё" role="group" aria-labelledby="ol-5-4-l"><p class="rp-olf-l" id="ol-5-4-l"><i>5.4</i>Основное сырьё</p><div class="rp-chips"><label class="rp-chip"><input type="checkbox" name="q5.4" value="мясо и птица"><span><span class="rp-ct">мясо и птица</span></span></label><label class="rp-chip"><input type="checkbox" name="q5.4" value="рыба и морепродукты"><span><span class="rp-ct">рыба и морепродукты</span></span></label><label class="rp-chip"><input type="checkbox" name="q5.4" value="молоко и молочная продукция"><span><span class="rp-ct">молоко и молочная продукция</span></span></label><label class="rp-chip"><input type="checkbox" name="q5.4" value="яйцо"><span><span class="rp-ct">яйцо</span></span></label><label class="rp-chip"><input type="checkbox" name="q5.4" value="овощи и фрукты"><span><span class="rp-ct">овощи и фрукты</span></span></label><label class="rp-chip"><input type="checkbox" name="q5.4" value="мука и крупы"><span><span class="rp-ct">мука и крупы</span></span></label><label class="rp-chip"><input type="checkbox" name="q5.4" value="полуфабрикаты"><span><span class="rp-ct">полуфабрикаты</span></span></label></div><div class="field rp-olf-x"><label class="sr-only" for="ol-5-4-x">Основное сырьё: другое сырьё</label><input id="ol-5-4-x" name="q5.4x" maxlength="200" placeholder="другое сырьё" data-x="другое сырьё"></div></div><div class="field rp-olf-q rp-olf-w" data-q="5.5" data-label="Сроки годности и хранение готовой продукции"><label for="ol-5-5"><i>5.5</i>Сроки годности и хранение готовой продукции</label><textarea id="ol-5-5" name="q5.5" maxlength="500" placeholder="скоропортящаяся продукция, температура хранения, упаковка"></textarea></div></div></fieldset><fieldset class="rp-olf-sec" data-sec="6" data-title="Технологические процессы" data-haccp hidden><legend><span class="rp-pt">6</span><span>Технологические процессы</span></legend><p class="rp-olf-sn">Раздел для ППК по ХАССП: заполните, если на объекте изготавливают пищевую продукцию.</p><div class="rp-olf-g"><div class="field rp-olf-q rp-olf-w" data-q="6.1" data-label="Операции от приёмки сырья до выдачи"><label for="ol-6-1"><i>6.1</i>Операции от приёмки сырья до выдачи</label><textarea id="ol-6-1" name="q6.1" maxlength="800" placeholder="по порядку: приёмка → хранение → обработка → … → выдача или отгрузка"></textarea></div><div class="rp-olf-q rp-olf-w" data-q="6.2" data-label="Тепловая обработка и охлаждение" role="group" aria-labelledby="ol-6-2-l"><p class="rp-olf-l" id="ol-6-2-l"><i>6.2</i>Тепловая обработка и охлаждение</p><div class="rp-chips"><label class="rp-chip"><input type="checkbox" name="q6.2" value="варка, жарка, запекание"><span><span class="rp-ct">варка, жарка, запекание</span></span></label><label class="rp-chip"><input type="checkbox" name="q6.2" value="шоковое охлаждение"><span><span class="rp-ct">шоковое охлаждение</span></span></label><label class="rp-chip"><input type="checkbox" name="q6.2" value="заморозка"><span><span class="rp-ct">заморозка</span></span></label><label class="rp-chip"><input type="checkbox" name="q6.2" value="разморозка"><span><span class="rp-ct">разморозка</span></span></label><label class="rp-chip"><input type="checkbox" name="q6.2" value="пастеризация"><span><span class="rp-ct">пастеризация</span></span></label></div><div class="field rp-olf-x"><label class="sr-only" for="ol-6-2-x">Тепловая обработка и охлаждение: температура и время, если знаете</label><input id="ol-6-2-x" name="q6.2x" maxlength="200" placeholder="температура и время, если знаете" data-x="температура и время, если знаете"></div></div><div class="field rp-olf-q rp-olf-w" data-q="6.3" data-label="Цеха и зоны"><label for="ol-6-3"><i>6.3</i>Цеха и зоны</label><textarea id="ol-6-3" name="q6.3" maxlength="500" placeholder="заготовочный, горячий, холодный, кондитерский цех, моечные, склады"></textarea></div><div class="field rp-olf-q rp-olf-w" data-q="6.4" data-label="Холодильное оборудование"><label for="ol-6-4"><i>6.4</i>Холодильное оборудование</label><textarea id="ol-6-4" name="q6.4" maxlength="500" placeholder="камеры, шкафы, витрины — сколько и при какой температуре; чем контролируете температуру"></textarea></div><div class="rp-olf-q rp-olf-w" data-q="6.5" data-label="Технологическая документация" role="radiogroup" aria-labelledby="ol-6-5-l"><p class="rp-olf-l" id="ol-6-5-l"><i>6.5</i>Технологическая документация</p><small class="rp-olf-h">технологические карты, рецептуры, ТУ и ТИ</small><div class="rp-chips"><label class="rp-chip"><input type="radio" name="q6.5" value="есть"><span><span class="rp-ct">есть</span></span></label><label class="rp-chip"><input type="radio" name="q6.5" value="частично"><span><span class="rp-ct">частично</span></span></label><label class="rp-chip"><input type="radio" name="q6.5" value="нет"><span><span class="rp-ct">нет</span></span></label></div></div><div class="rp-olf-q rp-olf-w" data-q="6.6" data-label="Документы ХАССП и журналы" role="radiogroup" aria-labelledby="ol-6-6-l"><p class="rp-olf-l" id="ol-6-6-l"><i>6.6</i>Документы ХАССП и журналы</p><small class="rp-olf-h">план ХАССП, бракеражный и температурный журналы, журнал здоровья</small><div class="rp-chips"><label class="rp-chip"><input type="radio" name="q6.6" value="есть"><span><span class="rp-ct">есть</span></span></label><label class="rp-chip"><input type="radio" name="q6.6" value="частично"><span><span class="rp-ct">частично</span></span></label><label class="rp-chip"><input type="radio" name="q6.6" value="нет"><span><span class="rp-ct">нет</span></span></label></div></div><div class="field rp-olf-q" data-q="6.7" data-label="Кто войдёт в рабочую группу ХАССП"><label for="ol-6-7"><i>6.7</i>Кто войдёт в рабочую группу ХАССП</label><input id="ol-6-7" name="q6.7" maxlength="300" placeholder="должности, ФИО"></div><div class="rp-olf-q rp-olf-w" data-q="6.8" data-label="Перевозка продукции" role="radiogroup" aria-labelledby="ol-6-8-l"><p class="rp-olf-l" id="ol-6-8-l"><i>6.8</i>Перевозка продукции</p><div class="rp-chips"><label class="rp-chip"><input type="radio" name="q6.8" value="свой транспорт"><span><span class="rp-ct">свой транспорт</span></span></label><label class="rp-chip"><input type="radio" name="q6.8" value="сторонний перевозчик"><span><span class="rp-ct">сторонний перевозчик</span></span></label><label class="rp-chip"><input type="radio" name="q6.8" value="не перевозим"><span><span class="rp-ct">не перевозим</span></span></label></div></div></div></fieldset><fieldset class="rp-olf-sec" data-sec="+" data-title="Дополнительно"><legend><span class="rp-pt">+</span><span>Дополнительно</span></legend><div class="rp-olf-g"><div class="field rp-olf-q rp-olf-w" data-q="+" data-label="Что ещё важно знать о вашем объекте"><label for="ol-extra">Что ещё важно знать о вашем объекте</label><textarea id="ol-extra" name="qextra" maxlength="800" placeholder="особенности объекта, сроки, вопросы к нам"></textarea></div></div></fieldset><fieldset class="rp-olf-sec rp-olf-c"><legend><span>Контакты для связи</span></legend><div class="fg"><div class="field"><label for="ol-name">Ваше имя<b class="rp-olf-req" aria-hidden="true">*</b></label><input id="ol-name" name="ol_c_name" maxlength="150" autocomplete="name" required aria-describedby="ol-name-e"><small class="ferr" id="ol-name-e">Укажите имя</small></div><div class="field"><label for="ol-phone">Телефон<b class="rp-olf-req" aria-hidden="true">*</b></label><input id="ol-phone" name="ol_c_phone" type="tel" inputmode="tel" placeholder="+7 (___) ___-__-__" autocomplete="tel" required aria-describedby="ol-phone-e"><small class="ferr" id="ol-phone-e">Укажите телефон полностью</small></div><div class="field full"><label for="ol-email">Электронная почта — пришлём расчёт</label><input id="ol-email" name="ol_c_email" type="email" inputmode="email" maxlength="254" autocomplete="email" aria-describedby="ol-email-e"><small class="ferr" id="ol-email-e">Проверьте адрес почты</small></div></div></fieldset><div class="rp-olf-send"><button type="submit" class="btn btn-w btn-lg" id="olSubmit"><span class="btn-t">Отправить опросный лист</span><svg class="btn-ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M5 12h14M13 6l6 6-6 6"/></svg><i class="spin" aria-hidden="true"></i></button><button type="button" class="rp-olf-reset" id="olReset">Очистить ответы</button></div><p class="legal">Нажимая кнопку, вы даёте <a href="../soglasie/" target="_blank" rel="noopener">согласие на обработку персональных данных</a> и подтверждаете, что ознакомились с <a href="../privacy/" target="_blank" rel="noopener">политикой конфиденциальности</a>.</p><p class="rp-olf-mail">Документы из списка выше можно прислать на <a href="mailto:b2b@pestcontrol-center.ru">b2b@pestcontrol-center.ru</a>.</p></div><div class="ok" role="status" aria-live="polite"><svg class="ok-ic" viewBox="0 0 52 52" aria-hidden="true"><circle cx="26" cy="26" r="24" fill="none"/><path fill="none" d="M15 27l7 7 15-16"/></svg><h3>Опросный лист отправлен</h3><p>Перезвоним в ближайшее рабочее время, назовём стоимость и срок. Документы можно прислать на <a href="mailto:b2b@pestcontrol-center.ru">b2b@pestcontrol-center.ru</a>.</p></div></form></template>
  </div>
</section>
<section class="s" id="obrazets">
  <div class="wrap">
    <div class="head"><div class="eyebrow" data-eyebrow>Образец · PDF, 27 страниц</div><h2 data-split>Так выглядит ППК по ХАССП, <em>которую мы разрабатываем</em></h2><p class="sub" data-fade>Полный образец ППК по ХАССП для хлебопекарного и кондитерского производства с кремовым цехом. Реквизиты условные: по образцу видно структуру и глубину проработки. В ППК для объекта без производства нет раздела ХАССП, остальная структура та же.</p></div>
    <div class="p-obr k-obr" data-fade>
      <div class="p-obr-pages">
        <a class="p-obr-page" href="../materialy/programma-proizvodstvennogo-kontrolya-haccp/obrazets-programmy-proizvodstvennogo-kontrolya.pdf" target="_blank" rel="noopener" data-dl="obrazets"><span><img src="../img/ppk-sample-p1-360.webp" srcset="../img/ppk-sample-p1-240.webp 240w, ../img/ppk-sample-p1-360.webp 360w, ../img/ppk-sample-p1-720.webp 720w" sizes="(max-width:600px) 28vw, 200px" width="360" height="509" loading="lazy" decoding="async" alt="Образец программы производственного контроля, страница 1: титульный лист с грифами «Согласовано» и «Утверждаю» и сведения об объекте"></span><b>Стр. 1</b><small>Титул и сведения об объекте</small></a>
        <a class="p-obr-page" href="../materialy/programma-proizvodstvennogo-kontrolya-haccp/obrazets-programmy-proizvodstvennogo-kontrolya.pdf#page=11" target="_blank" rel="noopener" data-dl="obrazets"><span><img src="../img/ppk-sample-p11-360.webp" srcset="../img/ppk-sample-p11-240.webp 240w, ../img/ppk-sample-p11-360.webp 360w, ../img/ppk-sample-p11-720.webp 720w" sizes="(max-width:600px) 28vw, 200px" width="360" height="509" loading="lazy" decoding="async" alt="Образец программы производственного контроля, страница 11: критические контрольные точки ХАССП с пределами, мониторингом и корректирующими действиями"></span><b>Стр. 11</b><small>Критические контрольные точки</small></a>
        <a class="p-obr-page" href="../materialy/programma-proizvodstvennogo-kontrolya-haccp/obrazets-programmy-proizvodstvennogo-kontrolya.pdf#page=20" target="_blank" rel="noopener" data-dl="obrazets"><span><img src="../img/ppk-sample-p20-360.webp" srcset="../img/ppk-sample-p20-240.webp 240w, ../img/ppk-sample-p20-360.webp 360w, ../img/ppk-sample-p20-720.webp 720w" sizes="(max-width:600px) 28vw, 200px" width="360" height="509" loading="lazy" decoding="async" alt="Образец программы производственного контроля, страница 20: план-схема производства с точками отбора проб и точками пест-контроля"></span><b>Стр. 20</b><small><span class="nw">План-схема</span> точек</small></a>
      </div>
      <div class="p-obr-info">
        <h3>Что видно по образцу</h3>
        <ol class="p-obr-list">
          <li><b>Нормы</b><span>все пункты раздела 3 СП <span class="nw">1.1.1058-01</span> и 28 документов в перечне — с правилами 2026 года</span></li>
          <li><b>Лаборатория</b><span>контроль сырья, продукции, смывов, воздуха и воды: точки, показатели, периодичность</span></li>
          <li><b>ХАССП</b><span>4 критические контрольные точки с пределами и корректирующими действиями</span></li>
          <li><b>Персонал</b><span>медосмотры, гигиеническая подготовка и прививки по должностям</span></li>
          <li><b>Вредители</b><span>раздел о дезинсекции и дератизации и <span class="nw">план-схема</span> точек контроля</span></li>
          <li><b>Учёт</b><span>8 аварийных ситуаций с порядком информирования и 19 форм учёта</span></li>
        </ol>
        <div class="p-obr-btns">
          <a href="../materialy/programma-proizvodstvennogo-kontrolya-haccp/obrazets-programmy-proizvodstvennogo-kontrolya.pdf" class="btn btn-w btn-lg" target="_blank" rel="noopener" data-dl="obrazets"><span class="btn-t">Открыть образец ППК, PDF</span></a>
        </div>
        <p class="p-obr-meta">PDF — 27 страниц, 0,7 МБ. Подробный разбор образца и раздела о дезинсекции и дератизации — в материале <a href="../materialy/programma-proizvodstvennogo-kontrolya-haccp/">«Образец ППК по ХАССП»</a>.</p>
      </div>
    </div>
  </div>
</section>

<section class="s" id="obekty">
  <div class="wrap">
    <div class="head"><div class="eyebrow" data-eyebrow>Объекты</div><h2 data-split>ППК для ресторана, магазина, производства, <em>склада и гостиницы</em></h2><p class="sub" data-fade>Какая программа нужна объекту и на какие нормы она опирается.</p></div>
    <table class="d-table rp-obj" data-fade>
      <thead><tr><th scope="col">Объект</th><th scope="col">На какие нормы опирается программа</th><th scope="col">Что важно в ППК</th></tr></thead>
      <tbody>
        <tr><td data-l="Объект"><span class="rp-ico"><svg aria-hidden="true" focusable="false" class="lucide lucide-utensils" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M3 2v7c0 1.1.9 2 2 2h4a2 2 0 0 0 2-2V2" /> <path d="M7 2v20" /> <path d="M21 15V2a5 5 0 0 0-5 5v6c0 1.1.9 2 2 2h3Zm0 0v7" /> </svg></span>Ресторан, кафе, столовая<span class="rp-tags"><span class="rp-tag rp-tag-h">ППК по ХАССП</span></span></td><td data-l="На какие нормы опирается программа">СанПиН <span class="nw">2.3/2.4.4282-26</span>: производственный контроль на принципах ХАССП (п. 4)</td><td data-l="Что важно в ППК">Процедуры ХАССП для приёмки, хранения, приготовления и раздачи, контроль температуры холодильного оборудования, лабораторный контроль блюд и смывов, защита кухни и зон хранения от вредителей</td></tr>
        <tr><td data-l="Объект"><span class="rp-ico"><svg aria-hidden="true" focusable="false" class="lucide lucide-shopping-cart" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="m2.05 2.05 1.099-.028a1 1 0 0 1 1.008.815l2.69 14.347A1 1 0 0 0 7.83 18H18" /> <path d="M4.563 5h16.435a1 1 0 0 1 .981 1.204l-1.026 6.226A2 2 0 0 1 18.962 14H6.25" /> <circle cx="18" cy="20" r="2" /> <circle cx="8" cy="20" r="2" /> </svg></span>Магазин, торговая сеть<span class="rp-tags"><span class="rp-tag">ППК</span><span class="rp-tag rp-tag-h">с кулинарией — ППК по ХАССП</span></span></td><td data-l="На какие нормы опирается программа">СП <span class="nw">2.3.6.4281-26</span>: производственный контроль (п. 3), дезинсекция и дератизация (п. 78)</td><td data-l="Что важно в ППК">Раздельное хранение, сроки годности, температура. Магазину с собственной кулинарией или пекарней нужна ППК по ХАССП: это изготовление пищевой продукции (<span class="nw">ТР ТС 021/2011</span>, ст. 10). Для сети — общая часть и приложения по объектам</td></tr>
        <tr><td data-l="Объект"><span class="rp-ico"><svg aria-hidden="true" focusable="false" class="lucide lucide-factory" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M12 16h.01" /> <path d="M16 16h.01" /> <path d="M3 19a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V8.5a.5.5 0 0 0-.769-.422l-4.462 2.844A.5.5 0 0 1 15 10.5v-2a.5.5 0 0 0-.769-.422L9.77 10.922A.5.5 0 0 1 9 10.5V5a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2z" /> <path d="M8 16h.01" /> </svg></span>Пищевое производство<span class="rp-tags"><span class="rp-tag rp-tag-h">ППК по ХАССП</span></span></td><td data-l="На какие нормы опирается программа"><span class="nw">ТР ТС 021/2011</span>, ст. 10–11, и технические регламенты на отдельные виды продукции</td><td data-l="Что важно в ППК">Критические контрольные точки и пределы, лабораторный контроль сырья и продукции, прослеживаемость, программы предварительных мероприятий</td></tr>
        <tr><td data-l="Объект"><span class="rp-ico"><svg aria-hidden="true" focusable="false" class="lucide lucide-warehouse" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M18 21V10a1 1 0 0 0-1-1H7a1 1 0 0 0-1 1v11" /> <path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V8a2 2 0 0 1 1.132-1.803l7.95-3.974a2 2 0 0 1 1.837 0l7.948 3.974A2 2 0 0 1 22 8z" /> <path d="M6 13h12" /> <path d="M6 17h12" /> </svg></span>Склад, логистика<span class="rp-tags"><span class="rp-tag">ППК</span></span></td><td data-l="На какие нормы опирается программа"><span class="nw">ТР ТС 021/2011</span> (хранение и перевозка пищевой продукции), СанПиН <span class="nw">3.3686-21</span></td><td data-l="Что важно в ППК">Температурный режим, приёмка, условия хранения, защита от грызунов и птиц — в том числе на складе продуктов</td></tr>
        <tr><td data-l="Объект"><span class="rp-ico"><svg aria-hidden="true" focusable="false" class="lucide lucide-bed-double" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M2 20v-8a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v8" /> <path d="M4 10V6a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v4" /> <path d="M12 4v6" /> <path d="M2 18h20" /> </svg></span>Гостиница<span class="rp-tags"><span class="rp-tag">ППК</span><span class="rp-tag rp-tag-h">с рестораном — ППК по ХАССП</span></span></td><td data-l="На какие нормы опирается программа">СП <span class="nw">2.1.4284-26</span>: дезинсекция и дератизация (п. 14)</td><td data-l="Что важно в ППК">Уборка и дезинфекция номеров и общих зон, бельё, вода; если есть ресторан или пищеблок — ППК по ХАССП с требованиями к общепиту</td></tr>
        <tr><td data-l="Объект"><span class="rp-ico"><svg aria-hidden="true" focusable="false" class="lucide lucide-pill" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="m10.5 20.5 10-10a4.95 4.95 0 1 0-7-7l-10 10a4.95 4.95 0 1 0 7 7Z" /> <path d="m8.5 8.5 7 7" /> </svg></span>Фармацевтическое производство<span class="rp-tags"><span class="rp-tag">ППК</span></span></td><td data-l="На какие нормы опирается программа">санитарные правила и Правила надлежащей производственной практики ЕАЭС</td><td data-l="Что важно в ППК">Программа для Роспотребнадзора дополняет систему GMP: условия труда, медосмотры, отходы, <span class="nw">пест-контроль</span></td></tr>
      </tbody>
    </table>
    <p class="d-note" data-fade>Офисам и <span class="nw">бизнес-центрам</span>, объектам бытовых услуг и производствам непищевой продукции нужна ППК без ХАССП. На любом объекте в ППК входит контроль условий труда на рабочих местах: СП <span class="nw">2.2.4285-26</span> требует указать ответственных, факторы и точки измерений с периодичностью (пп. 10 и 13).</p>
  </div>
</section>

<section class="s" id="laboratoriya">
  <div class="wrap">
    <div class="head"><div class="eyebrow" data-eyebrow>Лабораторный контроль</div><h2 data-split>Лабораторные исследования <em>по ППК</em></h2><p class="sub" data-fade>Номенклатуру, объём и периодичность исследований определяют по <span class="nw">санитарно-эпидемиологической</span> характеристике производства и вредным факторам (СП <span class="nw">1.1.1058-01</span>, п. 2.5). В программе мы указываем, что исследовать, где отбирать пробы и как часто.</p></div>
    <table class="d-table rp-labt" data-fade>
      <thead><tr><th scope="col">Что исследуют</th><th scope="col">Где</th><th scope="col">Что определяют</th></tr></thead>
      <tbody>
        <tr><td data-l="Что исследуют">Смывы</td><td data-l="Где">поверхности, оборудование, инвентарь, руки персонала</td><td data-l="Что определяют"><span class="nw">санитарно-показательные</span> микроорганизмы</td></tr>
        <tr><td data-l="Что исследуют">Воздух</td><td data-l="Где">производственные помещения, холодильные камеры</td><td data-l="Что определяют">микробная обсеменённость</td></tr>
        <tr><td data-l="Что исследуют">Вода</td><td data-l="Где">точки водоразбора</td><td data-l="Что определяют">микробиологические и химические показатели</td></tr>
        <tr><td data-l="Что исследуют">Сырьё и продукция</td><td data-l="Где">по ассортименту и плану ХАССП</td><td data-l="Что определяют">микробиологические и <span class="nw">физико-химические</span> показатели</td></tr>
        <tr><td data-l="Что исследуют">Рабочие места</td><td data-l="Где">цеха, кухни, офисы</td><td data-l="Что определяют">микроклимат, освещённость, шум</td></tr>
      </tbody>
    </table>
    <p class="d-note" data-fade>Сами исследования в стоимость разработки ППК не входят: их проводит организация или аккредитованная лаборатория (СП <span class="nw">1.1.1058-01</span>, п. 2.5). Если на объекте недавно проводили специальную оценку условий труда, её измерения можно использовать в производственном контроле — при условии, что они сделаны не раньше чем за шесть месяцев (ст. 32 Федерального закона № <span class="nw">52-ФЗ</span>, п. 1.1). Смывы и пробы воздуха входят в наш <a href="../sanitarnyy-audit/">санитарный аудит</a>.</p>
  </div>
</section>

<section class="s" id="oshibki">
  <div class="wrap">
    <div class="head"><div class="eyebrow" data-eyebrow>Частые ошибки</div><h2 data-split>Что чаще всего <em>не так в ППК</em></h2></div>
    <ol class="d-terms rp-err" data-group="steps">
      <li><b>Ссылки на отменённые правила</b><span>С 1 сентября 2026 года вместо СанПиН <span class="nw">2.3/2.4.3590-20</span>, СП <span class="nw">2.3.6.3668-20</span>, СП <span class="nw">2.1.3678-20</span> и СП <span class="nw">2.2.3670-20</span> действуют правила 2026 года.</span></li>
      <li><b>Чужая программа</b><span>В тексте не те помещения, оборудование и ассортимент, точки отбора проб не совпадают с объектом.</span></li>
      <li><b>ППК без ХАССП на пищевом объекте</b><span>В кафе, кулинарии или цехе программа без процедур ХАССП. Их требуют <span class="nw">ТР ТС 021/2011</span> (ст. 10–11), а для общепита — ещё и п. 4 СанПиН <span class="nw">2.3/2.4.4282-26</span>.</span></li>
      <li><b>Нет <span class="nw">плана-графика</span> исследований</b><span>Пункт 3.3 требует указать точки отбора проб и периодичность.</span></li>
      <li><b>Ответственные только на бумаге</b><span>Должности в программе есть (п. 3.2), но приказа нет, и сотрудники не знают своих обязанностей.</span></li>
      <li><b>Вредители — одной строкой</b><span>Нет периодичности, способов и ссылки на договор с исполнителем. Для пищевых производств эту процедуру прямо требует <span class="nw">ТР ТС 021/2011</span> (ст. 10, ч. 3, п. 10).</span></li>
    </ol>
    <p class="d-note" data-fade>Программа — только часть дела. За полноту и достоверность производственного контроля отвечает сама организация (СП <span class="nw">1.1.1058-01</span>, п. 2.7), поэтому журналы и протоколы должны совпадать с тем, что написано в ППК.</p>
  </div>
</section>

<section class="s" id="stoimost">
  <div class="wrap">
    <div class="head"><div class="eyebrow" data-eyebrow>Цена и срок</div><h2 data-split>Сколько стоит <em>разработка ППК</em></h2></div>
    <div class="rp-price" data-group="cards">
      <div class="card rp-pcard">
        <p class="rp-pname">ППК</p>
        <p class="rp-pfor">Офисы и <span class="nw">бизнес-центры</span>, склады, магазины без собственного производства, гостиницы без ресторана, производства непищевой продукции, бытовые услуги</p>
        <div class="rp-pfigs">
          <div class="rp-pfig"><p class="rp-pk">Стоимость</p><p class="rp-pnum">от 5&nbsp;900&nbsp;₽</p></div>
          <div class="rp-pfig"><p class="rp-pk">Срок</p><p class="rp-pnum">1 рабочий день</p></div>
        </div>
        <a href="#zayavka" class="btn btn-w btn-lg" data-goal="Разработать ППК"><span class="btn-t">Рассчитать ППК</span></a>
      </div>
      <div class="card rp-pcard rp-pcard-h">
        <p class="rp-pname">ППК по ХАССП</p>
        <p class="rp-pfor">Пищевые производства, рестораны, кафе, кофейни и столовые, магазины с собственной кулинарией или пекарней, гостиницы с рестораном или пищеблоком</p>
        <div class="rp-pfigs">
          <div class="rp-pfig"><p class="rp-pk">Стоимость</p><p class="rp-pnum">от 19&nbsp;900&nbsp;₽</p></div>
          <div class="rp-pfig"><p class="rp-pk">Срок</p><p class="rp-pnum">3 рабочих дня</p></div>
        </div>
        <a href="#zayavka" class="btn btn-w btn-lg" data-goal="Разработать ППК по ХАССП"><span class="btn-t">Рассчитать ППК по ХАССП</span></a>
      </div>
    </div>
    <div class="card rp-pnotes" data-fade>
      <p><b>Что входит</b>программа по разделу 3 СП <span class="nw">1.1.1058-01</span>, проект приказа, <span class="nw">план-график</span> лабораторных исследований, формы журналов, раздел о дезинсекции и дератизации; в ППК по ХАССП — ещё процедуры ХАССП и <span class="nw">блок-схемы</span> процессов.</p>
      <p><b>От чего зависит цена</b>вид деятельности, площадь и число помещений, численность персонала, для ППК по ХАССП — число технологических процессов, количество объектов. Точную сумму называем до начала работы.</p>
      <p><b>Срок</b>считаем с момента, когда получили сведения об объекте — заполненный <a href="#oprosnyy-list">опросный лист</a>, а если нужен выезд — после выезда. Для сети объектов срок и цену называем при расчёте: считаем по количеству и типам объектов.</p>
      <p><b>Не входит</b>лабораторные исследования: их проводит аккредитованная лаборатория по <span class="nw">плану-графику</span> из программы.</p>
    </div>
  </div>
</section>

<section class="s" id="avtor">
  <div class="wrap">
    <div class="head"><div class="eyebrow" data-eyebrow>Автор и принципы</div><h2 data-split>Кто подготовил материал и <em>как мы разрабатываем ППК</em></h2></div>
    <div class="rp-author-wrap" data-fade>
      <div class="card rp-author">
        <img class="rp-avatar" src="../img/san-author-photo-240.webp" srcset="../img/san-author-photo-240.webp 240w, ../img/san-author-photo-480.webp 480w" sizes="(max-width:600px) 80px, 112px" width="240" height="240" loading="lazy" decoding="async" alt="Иллюстративное фото санитарного врача, изображение сгенерировано">
        <div><p class="rp-author-name">Марианна Семерина</p><p class="rp-author-role">Санитарный врач, автор материала</p><p class="rp-author-date">Дата обновления — 08.11.2026</p><p class="rp-author-note">Фото иллюстративное</p></div>
      </div>
      <ul class="rp-principles">
        <li><b>Под объект.</b> Каждый раздел опирается на сведения о вашем объекте: помещения, оборудование, персонал и ассортимент, а не на чужой шаблон.</li>
        <li><b>Нормы на сегодня.</b> Перечень документов сверяем с действующими правилами и указываем дату проверки.</li>
        <li><b><span class="nw">Пест-контроль</span> изнутри.</b> Раздел о дезинсекции и дератизации пишет исполнитель с лицензией ООО «Центр дезинфекционных услуг» <a href="https://fp.rospotrebnadzor.ru/licen/?oper=search&amp;numb_history=&amp;numb=&amp;firmget_name=&amp;ogrn_inn_nza=7714462211" target="_blank" rel="noopener">№ Л064-00111-77/01942445</a>, поэтому периодичность и документы совпадают с тем, что реально делается на объекте.</li>
        <li><b>Честно о результате.</b> ППК — основа производственного контроля, но итог проверки зависит от того, как программа выполняется. Решение принимает инспектор.</li>
      </ul>
    </div>
  </div>
</section>

<section class="s" id="normativnaya-baza">
  <div class="wrap">
    <div class="head"><div class="eyebrow" data-eyebrow>Источники</div><h2 data-split>Нормативная база <em>(проверено 07.11.2026)</em></h2><p class="sub" data-fade>Действующие и отменённые документы о дезинсекции и дератизации со сроками — в разделе <a href="../normativnaya-baza/">«Нормативная база»</a>.</p></div>
    <ul class="rp-base" data-fade>
      <li>Федеральный закон от 30.03.1999 № <span class="nw">52-ФЗ</span> «О <span class="nw">санитарно-эпидемиологическом</span> благополучии населения» — <a href="https://www.consultant.ru/document/cons_doc_LAW_22481/ecf7d99dfedfce263c69b78e069fa4ac904ab9c0/" target="_blank" rel="noopener">ст. 11 и 32</a></li>
      <li>СП <span class="nw">1.1.1058-01</span> «Организация и проведение производственного контроля за соблюдением санитарных правил и выполнением <span class="nw">санитарно-противоэпидемических</span> (профилактических) мероприятий» — пп. 2.5–2.7 и раздел 3 (<a href="https://13.rospotrebnadzor.ru/sites/default/files/1.1.1058-01.rtf" target="_blank" rel="noopener">текст на сайте Роспотребнадзора</a>)</li>
      <li><span class="nw">ТР ТС 021/2011</span> «О безопасности пищевой продукции» — ст. 10 и 11 (<a href="https://eec.eaeunion.org/comission/department/deptexreg/tr/PischevayaProd.php" target="_blank" rel="noopener">Евразийская экономическая комиссия</a>)</li>
      <li>СанПиН <span class="nw">2.3/2.4.4282-26</span> (<a href="http://publication.pravo.gov.ru/document/0001202606020084" target="_blank" rel="noopener">общественное питание</a>), СП <span class="nw">2.3.6.4281-26</span> (<a href="http://publication.pravo.gov.ru/document/0001202606020079" target="_blank" rel="noopener">торговля пищевой продукцией</a>), СП <span class="nw">2.1.4284-26</span> (<a href="http://publication.pravo.gov.ru/document/0001202606020088" target="_blank" rel="noopener">эксплуатация помещений и услуги</a>), СП <span class="nw">2.2.4285-26</span> (<a href="https://www.consultant.ru/document/cons_doc_LAW_535845/69252b917d81980eee80a287c3a241c76c90f105/" target="_blank" rel="noopener">условия труда</a>) — действуют с 01.09.2026 до 01.09.2032</li>
      <li>СанПиН <span class="nw">3.3686-21</span> «<span class="nw">Санитарно-эпидемиологические</span> требования по профилактике инфекционных болезней» — разделы о дезинсекции и дератизации (<a href="http://pravo.gov.ru/proxy/ips/?docbody=&amp;nd=602107773&amp;rdk=0" target="_blank" rel="noopener">текст</a>)</li>
    </ul>
  </div>
</section>


<!-- ============ СМОТРИТЕ ТАКЖЕ (перелинковка) ============ -->
<section class="s s-rel" id="smotrite-takzhe">
  <div class="wrap">
    <div class="head">
      <div class="eyebrow" data-eyebrow>Смотрите также</div>
      <h2 data-split>Связанные услуги <em>и материалы</em></h2>
    </div>
    <div class="rel-grid" data-group="cards">
      <a class="card rel-card" href="../materialy/programma-proizvodstvennogo-kontrolya-haccp/"><span class="rel-k">Материал</span><span class="rel-t">Образец ППК по ХАССП</span><span class="rel-d">Полная программа для пищевого производства в PDF, 27 страниц, и разбор раздела о дезинсекции и дератизации.</span><span class="rel-a" aria-hidden="true"><svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></span></a>
      <a class="card rel-card" href="../sanitarnyy-audit/"><span class="rel-k">Услуга</span><span class="rel-t">Санитарный аудит (<span class="nw">СЭС-аудит</span>)</span><span class="rel-d">Проверка по проверочным листам и СанПиН 2026 года, смывы и пробы воздуха, акт с реестром нарушений.</span><span class="rel-a" aria-hidden="true"><svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></span></a>
      <a class="card rel-card" href="../dogovor-deratizatsiya-dezinsektsiya/"><span class="rel-k">Обслуживание</span><span class="rel-t">Договор на дератизацию и дезинсекцию</span><span class="rel-d">Одно или оба направления в одном договоре: график визитов, акт после выезда, цена до подписания.</span><span class="rel-a" aria-hidden="true"><svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></span></a>
      <a class="card rel-card" href="../normativnaya-baza/"><span class="rel-k">Нормативная база</span><span class="rel-t">СанПиН и требования к дезинсекции и дератизации</span><span class="rel-d">Действующие документы 2026 года, периодичность обследований, лицензия исполнителя и отменённые СП и СанПиН.</span><span class="rel-a" aria-hidden="true"><svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></span></a>
    </div>
  </div>
</section>

<section class="s" id="voprosy">
  <div class="wrap">
    <div class="head"><div class="eyebrow" data-eyebrow>Вопросы</div><h2 data-split>Вопросы о разработке <em>ППК и ППК по ХАССП</em></h2></div>
    <div class="faq">
      <div class="faq-col" data-group="faq">
        <div class="card qa"><button aria-expanded="false" aria-controls="a1" id="q1"><span>Сколько стоит разработка ППК?</span><span class="pm"></span></button><div class="ans" id="a1" role="region" aria-labelledby="q1"><div><p>ППК — от 5&nbsp;900&nbsp;₽, ППК по ХАССП — от 19&nbsp;900&nbsp;₽. Точная сумма зависит от вида деятельности, площади, числа помещений и сотрудников, а для ППК по ХАССП — ещё и от числа технологических процессов; называем её до начала работы. Для сети считаем по количеству и типам объектов.</p></div></div></div>
        <div class="card qa"><button aria-expanded="false" aria-controls="a2" id="q2"><span>Сколько времени занимает разработка ППК?</span><span class="pm"></span></button><div class="ans" id="a2" role="region" aria-labelledby="q2"><div><p>ППК — 1 рабочий день, ППК по ХАССП — 3 рабочих дня. Срок считаем с момента, когда получили сведения об объекте — заполненный <a href="#oprosnyy-list">опросный лист</a>, а если нужен выезд — после выезда. Для сети объектов срок называем при расчёте.</p></div></div></div>
        <div class="card qa"><button aria-expanded="false" aria-controls="a3" id="q3"><span>Что нужно для разработки ППК?</span><span class="pm"></span></button><div class="ans" id="a3" role="region" aria-labelledby="q3"><div><p>Сведения об объекте: реквизиты и адрес, виды деятельности, площадь и помещения, персонал по должностям, водоснабжение, канализация и вентиляция, оборудование, отходы, договоры на дезинсекцию и дератизацию и с лабораторией, действующая программа и предписания, если были. Всё это собрано в <a href="#oprosnyy-list">опросном листе заказчика</a> — его можно заполнить онлайн на этой странице или в PDF. Из документов пригодятся план помещений, штатное расписание и перечень оборудования, но начать можно и без них.</p></div></div></div>
        <div class="card qa"><button aria-expanded="false" aria-controls="a4" id="q4"><span>Какие сведения нужны для ППК по ХАССП?</span><span class="pm"></span></button><div class="ans" id="a4" role="region" aria-labelledby="q4"><div><p>Всё, что для ППК, и сведения о продукции и технологии: ассортимент или меню, объём выпуска, основное сырьё, сроки годности и хранение, операции от приёмки сырья до выдачи, тепловая обработка и охлаждение, цеха, холодильное оборудование и действующие документы ХАССП. По ним составляют <span class="nw">блок-схемы</span> процессов и определяют критические контрольные точки (<span class="nw">ТР ТС 021/2011</span>, ст. 10–11). В опросном листе это разделы 5 и 6.</p></div></div></div>
        <div class="card qa"><button aria-expanded="false" aria-controls="a5" id="q5"><span>Нужно ли согласовывать ППК с Роспотребнадзором?</span><span class="pm"></span></button><div class="ans" id="a5" role="region" aria-labelledby="q5"><div><p>Нет. По СП <span class="nw">1.1.1058-01</span> программу утверждает руководитель организации, ИП или уполномоченное лицо (п. 2.6), согласование с Роспотребнадзором не предусмотрено. При проверке инспектор смотрит и саму программу, и документы о её выполнении.</p></div></div></div>
        <div class="card qa"><button aria-expanded="false" aria-controls="a6" id="q6"><span>Сколько действует ППК и когда её обновлять?</span><span class="pm"></span></button><div class="ans" id="a6" role="region" aria-labelledby="q6"><div><p>Срок действия не ограничен (СП <span class="nw">1.1.1058-01</span>, п. 2.6). Изменения вносят при смене вида деятельности, технологии и других существенных изменениях, а также когда отменены правила, на которые программа ссылается: с 1 сентября 2026 года это затронуло общепит, торговлю пищевой продукцией и объекты услуг.</p></div></div></div>
        <div class="card qa"><button aria-expanded="false" aria-controls="a7" id="q7"><span>Нужна ли ППК индивидуальному предпринимателю?</span><span class="pm"></span></button><div class="ans" id="a7" role="region" aria-labelledby="q7"><div><p>Да. Программу составляет и юридическое лицо, и индивидуальный предприниматель — до начала деятельности (СП <span class="nw">1.1.1058-01</span>, п. 2.6).</p></div></div></div>
      </div>
      <div class="faq-col" data-group="faq">
        <div class="card qa"><button aria-expanded="false" aria-controls="a8" id="q8"><span>Кто отвечает за ППК, если её разработали вы?</span><span class="pm"></span></button><div class="ans" id="a8" role="region" aria-labelledby="q8"><div><p>За организацию и выполнение производственного контроля отвечает сама организация или ИП (СП <span class="nw">1.1.1058-01</span>, п. 2.7). Мы отвечаем за содержание документа: состав по разделу 3, действующие нормы и соответствие программы вашему объекту.</p></div></div></div>
        <div class="card qa"><button aria-expanded="false" aria-controls="a9" id="q9"><span>Чем ППК отличается от ППК по ХАССП?</span><span class="pm"></span></button><div class="ans" id="a9" role="region" aria-labelledby="q9"><div><p>ППК по ХАССП — это ППК по СП <span class="nw">1.1.1058-01</span>, в которую включены процедуры на принципах ХАССП: опасные факторы, критические контрольные точки и их пределы, мониторинг и действия при отклонениях (<span class="nw">ТР ТС 021/2011</span>, ст. 11, ч. 3). Такая программа нужна всем, кто изготавливает пищевую продукцию: производствам, ресторанам, кафе, кулинариям. Офису, складу или магазину без собственного производства достаточно ППК.</p></div></div></div>
        <div class="card qa"><button aria-expanded="false" aria-controls="a10" id="q10"><span>Какая ППК нужна продуктовому магазину или складу продуктов?</span><span class="pm"></span></button><div class="ans" id="a10" role="region" aria-labelledby="q10"><div><p>Если магазин или склад только хранит и продаёт готовую продукцию, достаточно ППК — от 5&nbsp;900&nbsp;₽ за 1 рабочий день. Если в магазине есть своя кулинария, пекарня или другое изготовление пищевой продукции, нужна ППК по ХАССП (<span class="nw">ТР ТС 021/2011</span>, ст. 10–11).</p></div></div></div>
        <div class="card qa"><button aria-expanded="false" aria-controls="a11" id="q11"><span>Входят ли лабораторные исследования в разработку ППК?</span><span class="pm"></span></button><div class="ans" id="a11" role="region" aria-labelledby="q11"><div><p>В разработку входит <span class="nw">план-график</span> исследований: что, где и как часто исследовать. Сами исследования проводит организация или аккредитованная лаборатория (СП <span class="nw">1.1.1058-01</span>, п. 2.5), в стоимость разработки они не входят. Измерения недавней специальной оценки условий труда можно использовать, если они проведены не раньше чем за шесть месяцев (ст. 32 Федерального закона № <span class="nw">52-ФЗ</span>, п. 1.1).</p></div></div></div>
        <div class="card qa"><button aria-expanded="false" aria-controls="a12" id="q12"><span>Можно ли разработать ППК без выезда на объект?</span><span class="pm"></span></button><div class="ans" id="a12" role="region" aria-labelledby="q12"><div><p>Да, ППК обычно разрабатываем по <a href="#oprosnyy-list">опросному листу</a>, планировке и фотографиям помещений. Для ППК по ХАССП нужно разобрать технологические процессы, поэтому нужен ли выезд специалиста, согласуем при расчёте.</p></div></div></div>
        <div class="card qa"><button aria-expanded="false" aria-controls="a13" id="q13"><span>Нужна ли отдельная ППК для каждого объекта сети?</span><span class="pm"></span></button><div class="ans" id="a13" role="region" aria-labelledby="q13"><div><p>Программа должна описывать конкретный объект: его помещения, точки отбора проб и ответственных (СП <span class="nw">1.1.1058-01</span>, раздел 3). Для сети мы делаем общую часть и приложения по каждому объекту — так программу проще обновлять сразу для всех.</p></div></div></div>
        <div class="card qa"><button aria-expanded="false" aria-controls="a14" id="q14"><span>Что будет, если ППК нет?</span><span class="pm"></span></button><div class="ans" id="a14" role="region" aria-labelledby="q14"><div><p>Отсутствие программы — нарушение обязанности вести производственный контроль (ст. 11 и 32 Федерального закона № <span class="nw">52-ФЗ</span>). Штрафы за санитарные нарушения по КоАП собраны в таблице на странице <a href="../sanitarnyy-audit/#shtrafy">санитарного аудита</a>.</p></div></div></div>
      </div>
    </div>
  </div>
</section>

<section class="cta" id="zayavka"><div class="cta-bg f-lazy" aria-hidden="true" data-parallax-bg></div><div class="cta-orb" id="orb" aria-hidden="true"></div>
  <div class="wrap">
    <div>
      <div class="eyebrow" data-eyebrow>Заявка</div>
      <h2 data-split>Рассчитаем стоимость ППК <em>для вашего объекта</em></h2>
      <p class="sub" data-fade>Опишите объект — перезвоним, уточним детали, подскажем, какая программа нужна, и назовём цену и срок.</p>
      <ul class="cta-list" data-group="ctalist">
        <li><svg aria-hidden="true" focusable="false" class="lucide lucide-circle-check" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <circle cx="12" cy="12" r="10" /> <path d="m16 9-5.5 5.5L8 12" /> </svg>ППК — от 5&nbsp;900&nbsp;₽ за 1 рабочий день</li>
        <li><svg aria-hidden="true" focusable="false" class="lucide lucide-circle-check" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <circle cx="12" cy="12" r="10" /> <path d="m16 9-5.5 5.5L8 12" /> </svg>ППК по ХАССП — от 19&nbsp;900&nbsp;₽ за 3 рабочих&nbsp;дня</li>
        <li><svg aria-hidden="true" focusable="false" class="lucide lucide-circle-check" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <circle cx="12" cy="12" r="10" /> <path d="m16 9-5.5 5.5L8 12" /> </svg>Москва и Московская область</li>
      </ul>
      <p class="rp-ol-cta" data-fade>Удобнее ответить письменно? <a href="#oprosnyy-online" data-ol-open>Заполните опросный лист</a> — по нему сразу назовём точную цену и срок.</p>
      <div class="cta-contacts" data-fade>
        <a class="ph" href="tel:+74951043570">+7 (495) 104-35-70</a>
        <div class="msg">
          <a href="https://max.ru/u/f9LHodD0cOIlIUXFkt4KMFP88lD8n4TArBiTcV7RI1XML5c4o39QfsDBXUc" class="max" aria-label="Написать в Max" target="_blank" rel="noopener noreferrer"><svg viewBox="0 0 24 24" fill="#fff" aria-hidden="true"><path d="M12 3a9 9 0 0 0-7.7 13.7L3 21l4.4-1.2A9 9 0 1 0 12 3zm-3.6 12.3V8.7h1.6l2 2.8 2-2.8h1.6v6.6h-1.7v-3.9L12 14l-1.9-2.6v3.9z"/></svg></a>
          <a href="https://t.me/Centr_Dezinfection?text=%D0%97%D0%B4%D1%80%D0%B0%D0%B2%D1%81%D1%82%D0%B2%D1%83%D0%B9%D1%82%D0%B5!%20%D0%9F%D0%B8%D1%88%D1%83%20%D1%81%20%D1%81%D0%B0%D0%B9%D1%82%D0%B0%20%D0%BF%D0%B5%D1%81%D1%82%D0%BA%D0%BE%D0%BD%D1%82%D1%80%D0%BE%D0%BB%D1%8C-%D1%86%D0%B5%D0%BD%D1%82%D1%80.%D1%80%D1%84" class="tg" aria-label="Написать в Telegram" target="_blank" rel="noopener noreferrer"><svg viewBox="0 0 24 24" fill="#fff" aria-hidden="true"><path d="M21.4 4.3 2.9 11.4c-1.3.5-1.2 1.2-.2 1.5l4.7 1.5 1.8 5.6c.2.6.4.8.9.8.4 0 .6-.2.9-.4l2.3-2.2 4.7 3.5c.9.5 1.5.2 1.7-.8l3.1-14.6c.3-1.3-.5-1.8-1.4-1.5zM9.6 14.1l8.6-5.4c.4-.3.8-.1.5.2l-7.1 6.4-.3 3.3z"/></svg></a>
        </div>
      </div>
    </div>
    <form class="form" id="form" novalidate data-form>
      <div class="fbody">
        <h3>Расчёт стоимости ППК</h3>
        <p class="fs">Заполнение займёт меньше минуты</p>
        <div class="fg">
<div class="field"><label class="sr-only" for="f-name">Ваше имя</label><input id="f-name" name="name" placeholder="Ваше имя" required autocomplete="name"><small class="ferr">Укажите имя</small></div>
<div class="field"><label class="sr-only" for="phone">Телефон</label><input name="phone" id="phone" type="tel" inputmode="tel" placeholder="+7 (___) ___-__-__" required autocomplete="tel"><small class="ferr">Укажите телефон полностью</small></div>
<div class="field full"><label class="sr-only" for="f-company">Компания</label><input id="f-company" name="company" placeholder="Компания (необязательно)" autocomplete="organization"></div>
<div class="field full"><label class="sr-only" for="f-type">Вид объекта</label><select id="f-type" name="type" required><option value="" selected>Вид объекта</option><option>Ресторан или кафе</option><option>Магазин или торговая сеть</option><option>Пищевое производство</option><option>Склад, логистика</option><option>Гостиница</option><option value="Другое">Офис или бытовые услуги</option><option>Фармацевтическое производство</option><option>Другое</option></select><small class="ferr">Выберите вид объекта</small></div>
<div class="field full"><label class="sr-only" for="f-goal">Что нужно</label><select id="f-goal" name="goal"><option value="" selected>Что нужно</option><option>Разработать ППК</option><option>Разработать ППК по ХАССП</option><option>Не знаю, какая ППК нужна</option><option>Обновить ППК под правила 2026 года</option><option>Проверить действующую ППК</option><option>ППК для сети объектов</option></select></div>
<div class="field full"><label class="sr-only" for="f-addr">Адрес или район</label><input id="f-addr" name="address" placeholder="Адрес или район" autocomplete="street-address"></div>
<div class="field full"><label class="sr-only" for="f-msg">Комментарий</label><textarea id="f-msg" name="comment" placeholder="Комментарий: площадь, число сотрудников, сроки"></textarea></div>
<input type="hidden" name="msg" value="">
<div class="field" hidden><input type="hidden" name="email" value=""></div>
<input type="hidden" name="page" value="Разработка ППК">
</div>
        <button type="submit" class="btn btn-w btn-lg" id="submitBtn"><span class="btn-t">Рассчитать стоимость</span><svg class="btn-ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M5 12h14M13 6l6 6-6 6"/></svg><i class="spin" aria-hidden="true"></i></button>
        <p class="legal">Нажимая кнопку, вы даёте <a href="../soglasie/" target="_blank" rel="noopener">согласие на обработку персональных данных</a> и подтверждаете, что ознакомились с <a href="../privacy/" target="_blank" rel="noopener">политикой конфиденциальности</a>.</p>
      </div>
      <div class="ok" role="status" aria-live="polite">
        <svg class="ok-ic" viewBox="0 0 52 52" aria-hidden="true"><circle cx="26" cy="26" r="24" fill="none"/><path fill="none" d="M15 27l7 7 15-16"/></svg>
        <h3>Заявка отправлена</h3><p>Перезвоним в ближайшее рабочее время, назовём стоимость и срок.</p>
      </div>
    </form>
  </div>
</section>
</main>


<footer>
  <div class="wrap">
    <div class="ft">
      <div>
        <a href="../" class="logo" aria-label="ПЕСТКОНТРОЛЬ Центр — на главную"><span class="logo-mark"><svg viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="1.6" stroke-linejoin="round" aria-hidden="true"><path d="M12 2.5l7.5 3v6c0 5-3.2 8.6-7.5 10-4.3-1.4-7.5-5-7.5-10v-6z"/><circle cx="12" cy="11.5" r="2.6" stroke="#7c86ff"/><path d="M12 6.2v2.7M12 14.1v2.7M6.8 11.5h2.6M14.6 11.5h2.6" stroke="#7c86ff"/></svg></span><span class="logo-txt"><span class="logo-name">ПЕСТКОНТРОЛЬ</span> <span class="logo-sub">Центр</span></span></a>
        <p class="d"><span class="nw">Пест-контроль</span> и <span class="nw">пест-менеджмент</span> по системе IPM для бизнеса в Москве и Московской области: бесплатный аудит, оценка <span class="nw">пест-риска</span>, мониторинг вредителей и отчётность.</p>
      </div>
      <div><h4>Услуги</h4><ul><li><a href="../dezinfektsiya/">Дезинфекция для организаций</a></li><li><a href="../deratizatsiya/">Дератизация для организаций</a></li><li><a href="../dezinsektsiya/">Дезинсекция для организаций</a></li><li><a href="../sanitarnyy-audit/"><span>Санитарный аудит <span class="nw">(СЭС-аудит)</span></span></a></li><li><a href="./" aria-current="page">Разработка ППК</a></li><li><a href="../normativnaya-baza/dokumenty-dlya-rospotrebnadzora/">Документы для Роспотребнадзора</a></li><li><a href="../ochistka-dezinfektsiya-ventilyatsii/">Очистка и дезинфекция вентиляции</a></li><li><a href="../dogovor-deratizatsiya-dezinsektsiya/">Договор на дератизацию и дезинсекцию</a></li><li><a href="../#podhod"><span><span class="nw">Пест-контроль</span> по системе IPM</span></a></li><li><a href="../#etapy">Этапы работы</a></li><li><a href="../#vrediteli">Вредители</a></li><li><a href="../#usloviya">Цена</a></li><li><a href="../#voprosy">Вопросы</a></li></ul></div>
      <div><h4>Отрасли</h4><ul><li><a href="../pishchevoe-proizvodstvo/">Пищевые производства</a></li><li><a href="../magaziny-i-torgovye-seti/">Магазины и торговые сети</a></li><li><a href="../restorany-i-kafe/">Рестораны и кафе</a></li><li><a href="../sklady-i-logistika/">Склады и логистика</a></li><li><a href="../farmatsevticheskie-proizvodstva/">Фармацевтические производства</a></li><li><a href="../gostinitsy/">Гостиницы и отели</a></li></ul></div>
      <div><h4>Материалы</h4><ul><li><a href="../normativnaya-baza/">Нормативная база</a></li><li><a href="../normativnaya-baza/proverochnye-listy/">Проверочные листы 2026</a></li><li><a href="../normativnaya-baza/dokumenty-dlya-rospotrebnadzora/">Документы для Роспотребнадзора</a></li><li><a href="../materialy/programma-pest-kontrolya/"><span>Программа <span class="nw">пест-контроля</span></span></a></li><li><a href="../materialy/zhurnal-pest-kontrolya/"><span>Журнал <span class="nw">пест-контроля</span></span></a></li><li><a href="../materialy/pest-menedzhment-ili-razovaya-obrabotka/"><span><span class="nw">Пест-менеджмент</span> или разовая обработка</span></a></li><li><a href="../materialy/programma-proizvodstvennogo-kontrolya-haccp/">Программа производственного контроля по ХАССП</a></li><li><a href="../materialy/">Все материалы</a></li></ul></div>
      <div><h4>Контакты</h4><ul><li><a href="tel:+74951043570">+7 (495) 104-35-70</a></li><li><a href="mailto:b2b@pestcontrol-center.ru">b2b@<wbr><span style="white-space:nowrap">pestcontrol-center.ru</span></a></li><li>Пн–Пт: 8:00–20:00</li><li>Срочные выезды: 24/7</li></ul>
        <div class="msg"><a href="https://max.ru/u/f9LHodD0cOIlIUXFkt4KMFP88lD8n4TArBiTcV7RI1XML5c4o39QfsDBXUc" class="max" aria-label="Написать в Max" target="_blank" rel="noopener noreferrer"><svg viewBox="0 0 24 24" fill="#fff" aria-hidden="true"><path d="M12 3a9 9 0 0 0-7.7 13.7L3 21l4.4-1.2A9 9 0 1 0 12 3zm-3.6 12.3V8.7h1.6l2 2.8 2-2.8h1.6v6.6h-1.7v-3.9L12 14l-1.9-2.6v3.9z"/></svg></a><a href="https://t.me/Centr_Dezinfection?text=%D0%97%D0%B4%D1%80%D0%B0%D0%B2%D1%81%D1%82%D0%B2%D1%83%D0%B9%D1%82%D0%B5!%20%D0%9F%D0%B8%D1%88%D1%83%20%D1%81%20%D1%81%D0%B0%D0%B9%D1%82%D0%B0%20%D0%BF%D0%B5%D1%81%D1%82%D0%BA%D0%BE%D0%BD%D1%82%D1%80%D0%BE%D0%BB%D1%8C-%D1%86%D0%B5%D0%BD%D1%82%D1%80.%D1%80%D1%84" class="tg" aria-label="Написать в Telegram" target="_blank" rel="noopener noreferrer"><svg viewBox="0 0 24 24" fill="#fff" aria-hidden="true"><path d="M21.4 4.3 2.9 11.4c-1.3.5-1.2 1.2-.2 1.5l4.7 1.5 1.8 5.6c.2.6.4.8.9.8.4 0 .6-.2.9-.4l2.3-2.2 4.7 3.5c.9.5 1.5.2 1.7-.8l3.1-14.6c.3-1.3-.5-1.8-1.4-1.5zM9.6 14.1l8.6-5.4c.4-.3.8-.1.5.2l-7.1 6.4-.3 3.3z"/></svg></a></div>
      </div>
    </div>
    <div class="fb"><span>© 2026 ПЕСТКОНТРОЛЬ Центр</span><a href="../privacy/">Политика конфиденциальности</a><a href="../soglasie/">Согласие на обработку данных</a><span>Информация на сайте не является публичной офертой</span></div>
  </div>
</footer>

<div class="mbar" id="mbar">
  <a href="tel:+74951043570" class="c1"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1 1 .4 1.9.7 2.8a2 2 0 0 1-.5 2.1L8 9.9a16 16 0 0 0 6 6l1.3-1.3a2 2 0 0 1 2.1-.4c.9.3 1.8.6 2.8.7a2 2 0 0 1 1.7 2z"/></svg>Позвонить</a>
  <a href="#zayavka" class="c2"><span>Обследование</span></a>
</div>
<div class="fab" role="group" aria-label="Написать в мессенджер">
  <a href="https://max.ru/u/f9LHodD0cOIlIUXFkt4KMFP88lD8n4TArBiTcV7RI1XML5c4o39QfsDBXUc" class="max" aria-label="Написать в Max" target="_blank" rel="noopener noreferrer"><svg viewBox="0 0 24 24" fill="#fff" aria-hidden="true"><path d="M12 3a9 9 0 0 0-7.7 13.7L3 21l4.4-1.2A9 9 0 1 0 12 3zm-3.6 12.3V8.7h1.6l2 2.8 2-2.8h1.6v6.6h-1.7v-3.9L12 14l-1.9-2.6v3.9z"/></svg></a>
  <a href="https://t.me/Centr_Dezinfection?text=%D0%97%D0%B4%D1%80%D0%B0%D0%B2%D1%81%D1%82%D0%B2%D1%83%D0%B9%D1%82%D0%B5!%20%D0%9F%D0%B8%D1%88%D1%83%20%D1%81%20%D1%81%D0%B0%D0%B9%D1%82%D0%B0%20%D0%BF%D0%B5%D1%81%D1%82%D0%BA%D0%BE%D0%BD%D1%82%D1%80%D0%BE%D0%BB%D1%8C-%D1%86%D0%B5%D0%BD%D1%82%D1%80.%D1%80%D1%84" class="tg" aria-label="Написать в Telegram" target="_blank" rel="noopener noreferrer"><svg viewBox="0 0 24 24" fill="#fff" aria-hidden="true"><path d="M21.4 4.3 2.9 11.4c-1.3.5-1.2 1.2-.2 1.5l4.7 1.5 1.8 5.6c.2.6.4.8.9.8.4 0 .6-.2.9-.4l2.3-2.2 4.7 3.5c.9.5 1.5.2 1.7-.8l3.1-14.6c.3-1.3-.5-1.8-1.4-1.5zM9.6 14.1l8.6-5.4c.4-.3.8-.1.5.2l-7.1 6.4-.3 3.3z"/></svg></a>
</div>

<script>
/* Предпросмотр: вне рабочего домена заявка не отправляется (на пестконтроль-центр.рф этот блок не срабатывает) */
(function(){if(/^(www\.)?xn----itbbsflddbfpfdodg9d0f\.xn--p1ai$/i.test(location.hostname))return;var f=window.fetch;window.fetch=function(u){if(typeof u==='string'&&u.indexOf('send.php')>-1)return new Promise(function(r){setTimeout(function(){r(new Response('{"success":true}',{status:200,headers:{'Content-Type':'application/json'}}))},500)});return f.apply(this,arguments)};document.addEventListener('DOMContentLoaded',function(){var p=document.querySelector('.form .fs');if(p)p.textContent='Предпросмотр: заявка никуда не отправляется'})})();
</script>
<script data-fx>
/* Эффекты под курсором, как на главной (tools/site/fx.py) */
(function(){
  var mm=window.matchMedia;if(!mm)return;
  var fine=mm('(hover: hover) and (pointer: fine)').matches;
  /* «фонарь»: следует за мышью, без движения мыши плавно ходит сам; на сенсорных экранах ходит сам (30 кадров в секунду).
     Не считаем, пока первый экран не виден или вкладка скрыта. Старт — вместе со входом первого экрана */
  var hero=document.getElementById('hero'),lit=hero&&hero.querySelector('.fx-lit');
  if(lit&&!mm('(prefers-reduced-motion: reduce)').matches){
    var media=lit.parentNode,small=mm('(max-width:860px)').matches,full=hero.classList.contains('f-hero');
    lit.style.setProperty('--sr',small?'150px':'clamp(240px, 21vw, 400px)');
    var cx=small?.5:(full?.68:.74),ax=small?.24:(full?.16:.13),cy=small?.5:.47,ay=small?.2:.17;
    var sx=cx,sy=cy,tx=cx,ty=cy,last=-1e9,vis=true,on=false,raf=0,lt=0;
    var frame=function(now){
      raf=0;if(!on||!vis||document.hidden)return;
      var dt=now-lt;if(!fine&&dt<30){raf=requestAnimationFrame(frame);return;}
      lt=now;if(now-last>2600){var t=now/1000;tx=cx+ax*Math.sin(t*.33);ty=cy+ay*Math.sin(t*.47+1.3);}
      var k=1-Math.pow(.94,Math.min(dt,100)/16.67);sx+=(tx-sx)*k;sy+=(ty-sy)*k;
      lit.style.setProperty('--sx',(sx*100).toFixed(2)+'%');lit.style.setProperty('--sy',(sy*100).toFixed(2)+'%');
      raf=requestAnimationFrame(frame);
    };
    var kick=function(){if(!raf&&on&&vis&&!document.hidden){lt=performance.now();raf=requestAnimationFrame(frame);}};
    hero.addEventListener('pointermove',function(e){
      if(e.pointerType!=='mouse')return;var r=media.getBoundingClientRect();if(!r.width||!r.height)return;
      tx=(e.clientX-r.left)/r.width;ty=(e.clientY-r.top)/r.height;last=performance.now();kick();
    },{passive:true});
    if('IntersectionObserver' in window)new IntersectionObserver(function(es){vis=es[0].isIntersecting;kick();}).observe(hero);
    document.addEventListener('visibilitychange',kick);
    var start=function(){if(on)return;on=true;hero.classList.add('fx-lit-on');kick();};
    var eb=hero.querySelector('.eyebrow');
    if(eb&&'MutationObserver' in window){
      if(eb.classList.contains('in'))start();
      else{var mo=new MutationObserver(function(){if(eb.classList.contains('in')){mo.disconnect();start();}});mo.observe(eb,{attributes:true,attributeFilter:['class']});}
    }
    setTimeout(start,eb?5000:2500);
  }
  /* подсветка рамки карточек за курсором — как у .card на главной */
  if(fine)document.addEventListener('pointermove',function(e){
    var c=e.target.closest&&e.target.closest('.d-card,.p-sec,.p-fcard,.p-duty-box,.p-dl-card,.pm-step-card,.pm-scen,.pm-link-card,.k-err,.w-sample,.d-doc-prev');if(!c)return;
    var r=c.getBoundingClientRect();c.style.setProperty('--mx',(e.clientX-r.left)+'px');c.style.setProperty('--my',(e.clientY-r.top)+'px');
  },{passive:true});
})();
</script>
<script>
  /* скрипты анимаций подключаются сразу после первой отрисовки: фото и заголовок первого экрана не ждут их загрузки */
  (function (r, l) {
    var go = function () { l.forEach(function (u) { var e = document.createElement('script'); e.src = r + u; e.async = false; document.body.appendChild(e); }); };
    if (document.visibilityState === 'hidden' || !window.requestAnimationFrame) setTimeout(go, 0);
    else requestAnimationFrame(function () { setTimeout(go, 0); });
  })('../', ['vendor/gsap.min.js', 'vendor/ScrollTrigger.min.js', 'vendor/lenis.min.js', 'app.min.js?v=20261106s2']);
</script>
<script>/* Форма: что нужно, адрес, комментарий и страница — в поле msg, которое читает send.php;
   «Офис или бытовые услуги» уходит на сервер как «Другое» (список send.php), название вида — в msg */
document.addEventListener('submit',function(ev){var f=ev.target;if(!f||f.id!=='form')return;var e=f.elements,g=e.goal.value||'не выбрано',a=e.address.value.trim()||'не указан',c=e.comment.value.trim(),o=e.type.options[e.type.selectedIndex],k=o&&o.value&&o.text!==o.value?'Вид объекта: '+o.text+'\n':'';e.msg.value=k+'Что нужно: '+g+'\nАдрес: '+a+(c?'\nКомментарий: '+c:'')+'\nСтраница: Разработка ППК (/razrabotka-ppk/)';},true);
/* кнопки в карточках цен сразу выбирают в форме «Что нужно» */
document.addEventListener('click',function(e){var b=e.target.closest&&e.target.closest('[data-goal]');if(!b)return;var g=document.getElementById('f-goal');if(g)g.value=b.getAttribute('data-goal');});
/* клик по образцу ППК — цель Метрики ppk_obrazets, как на странице образца */
document.addEventListener('click',function(e){var a=e.target.closest&&e.target.closest('[data-dl]');if(!a)return;try{if(window.ym)ym(113675622,'reachGoal','ppk_'+a.getAttribute('data-dl'))}catch(_){}});</script>
<script>/* Опросный лист заказчика (tools/razrabotka-ppk/oprosnyy/block.py): форма из <template id="olTpl"> по кнопке
   «Заполнить онлайн» или по адресу #oprosnyy-online; черновик — localStorage (без имени, телефона и почты);
   отправка — send.php частями до 3000 знаков в msg; цели Метрики audit и ppk_oprosnyy_send, UIS — как в app.js */
(function(){
var box=document.getElementById('oprosnyy-online'),tpl=document.getElementById('olTpl');if(!box||!tpl)return;
var KEY='rppk-ol-v1',LIM=2800,f=null,saveT=0,sending=false,done={key:'',next:0};
var PROD=/^(www\.)?xn----itbbsflddbfpfdodg9d0f\.xn--p1ai$/i.test(location.hostname);
var FAIL='Не удалось отправить опросный лист. Попробуйте ещё раз или позвоните нам: +7 (495) 104-35-70.';
function q(s,c){return (c||f).querySelector(s)}function qa(s,c){return Array.prototype.slice.call((c||f).querySelectorAll(s))}
function txt(s){return String(s||'').replace(/\s+/g,' ').trim()}
function refresh(ms){setTimeout(function(){try{if(window.ScrollTrigger)ScrollTrigger.refresh()}catch(_){}},ms||120)}
function prog(){var r=q('input[name=prog]:checked');return r?r.value:''}
function sync(){var p=prog(),show=p&&p!=='ППК';qa('[data-haccp]').forEach(function(s){s.hidden=!show});}
function save(){clearTimeout(saveT);saveT=setTimeout(function(){var d={};qa('input,textarea').forEach(function(el){
  if(!el.name||el.name.indexOf('ol_c_')===0)return;
  if(el.type==='radio'||el.type==='checkbox'){if(el.checked)(d[el.name]=d[el.name]||[]).push(el.value)}else if(el.value)d[el.name]=el.value;});
  try{localStorage.setItem(KEY,JSON.stringify(d))}catch(_){}},300)}
function restore(){var d=null;try{d=JSON.parse(localStorage.getItem(KEY)||'null')}catch(_){}if(!d)return;
  qa('input,textarea').forEach(function(el){var v=d[el.name];if(v==null)return;
    if(el.type==='radio'||el.type==='checkbox')el.checked=v.indexOf(el.value)>-1;else el.value=v;});}
function mask(ph){var d=ph.value.replace(/\D/g,'');if(d[0]==='8')d='7'+d.slice(1);if(d[0]!=='7')d='7'+d;d=d.slice(0,11);
  var p=d.slice(1),s='+7';if(p.length)s+=' ('+p.slice(0,3);if(p.length>=3)s+=')';if(p.length>3)s+=' '+p.slice(3,6);
  if(p.length>6)s+='-'+p.slice(6,8);if(p.length>8)s+='-'+p.slice(8,10);ph.value=s;}
function init(){
  if(!PROD){var fs=q('.rp-olf-fs');if(fs)fs.textContent='Предпросмотр: опросный лист никуда не отправляется';}
  restore();sync();
  f.addEventListener('change',function(e){if(e.target.name==='prog'){sync();refresh();}var g=e.target.closest('.err');if(g)g.classList.remove('err');save();});
  f.addEventListener('input',function(e){var g=e.target.closest('.err');if(g){g.classList.remove('err');e.target.removeAttribute('aria-invalid');}save();});
  var ph=q('#ol-phone');ph.addEventListener('focus',function(){if(!ph.value)ph.value='+7 ('});
  ph.addEventListener('blur',function(){if(ph.value.replace(/\D/g,'').length<=1)ph.value=''});ph.addEventListener('input',function(){mask(ph)});
  q('#olReset').addEventListener('click',function(){if(!confirm('Очистить все ответы опросного листа?'))return;
    qa('input,textarea').forEach(function(el){if(el.type==='radio'||el.type==='checkbox')el.checked=false;else el.value=''});
    try{localStorage.removeItem(KEY)}catch(_){}sync();refresh();});
  f.addEventListener('submit',submit);
}
function open(p,ms){
  if(!f){box.appendChild(tpl.content.cloneNode(true));f=box.querySelector('form');init();}
  if(p){var r=q('input[name=prog][value="'+p+'"]');if(r){r.checked=true;sync();save();}}
  box.hidden=false;refresh(ms);
}
/* открываем раньше, чем app.js плавно прокрутит к #oprosnyy-online (обработчик на этапе перехвата);
   пересчёт ScrollTrigger — после прокрутки, чтобы не прервать её */
document.addEventListener('click',function(e){var a=e.target.closest&&e.target.closest('[data-ol-open]');if(a)open(a.getAttribute('data-ol-open'),1700);},true);
if(location.hash==='#oprosnyy-online'){open();setTimeout(function(){box.scrollIntoView()},60);}
function answer(b){
  var vals=qa('input:checked',b).map(function(el){return el.value});
  if(vals.length){var x=q('[data-x]',b),xv=x?txt(x.value):'';return vals.join(', ')+(xv?'; '+x.getAttribute('data-x')+': '+xv:'');}
  var t=q('input:not([type=radio]):not([type=checkbox]),textarea',b);
  if(t&&!t.hasAttribute('data-x'))return txt(t.value);
  var x2=q('[data-x]',b);return x2&&txt(x2.value)?x2.getAttribute('data-x')+': '+txt(x2.value):'';}
function compose(){
  var units=[],empty=[];
  qa('.rp-olf-sec[data-sec]').forEach(function(s){if(s.hidden||s.classList.contains('rp-olf-prog')||s.classList.contains('rp-olf-c'))return;
    var head=(s.getAttribute('data-sec')==='+'?'':s.getAttribute('data-sec')+'. ')+s.getAttribute('data-title'),first=true;
    qa('.rp-olf-q[data-q]',s).forEach(function(b){var n=b.getAttribute('data-q'),v=answer(b);
      if(!v){if(n!=='+')empty.push(n);return;}
      var line=(n==='+'?'':n+' ')+b.getAttribute('data-label')+': '+v;
      units.push(first?'— '+head+'\n'+line:line);first=false;});});
  if(empty.length)units.push('Без ответа: '+empty.join(', '));
  var top='Опросный лист заказчика: '+prog(),foot='Страница: Разработка ППК (/razrabotka-ppk/), опросный лист',parts=[],cur='';
  units.forEach(function(u){if(cur&&(cur.length+u.length+1)>LIM-top.length-foot.length-40){parts.push(cur);cur='';}cur+=(cur?'\n':'')+u;});
  if(cur||!parts.length)parts.push(cur);
  return parts.map(function(b,i){return top+(parts.length>1?' (часть '+(i+1)+' из '+parts.length+')':'')+'\n'+b+'\n'+foot;});}
function bad(el,box2){var g=box2||el.closest('.field');g.classList.remove('err');void g.offsetWidth;g.classList.add('err');if(el)el.setAttribute('aria-invalid','true');return g;}
function submit(e){
  e.preventDefault();if(sending)return;
  var first=null,nm=q('#ol-name'),ph=q('#ol-phone'),em=q('#ol-email'),pg=q('[data-req=prog]'),tp=q('[data-req=type]'),ot=q('input[name=otype]:checked');
  function chk(cond,el,g){if(cond){var b=bad(el,g);first=first||b;}}
  chk(!prog(),null,pg);chk(!ot,null,tp);chk(txt(nm.value).length<2,nm);chk(ph.value.replace(/\D/g,'').length!==11,ph);
  chk(txt(em.value)&&!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(txt(em.value)),em);
  if(first){var fi=q('input',first);first.scrollIntoView({block:'center'});if(fi)fi.focus({preventScroll:true});return;}
  var parts=compose(),key=parts.join('\u0001');if(key!==done.key)done={key:key,next:0};
  var co=q('#ol-1-1'),btn=q('#olSubmit');sending=true;btn.disabled=true;btn.classList.add('is-loading');
  function fd(m){var d=new FormData();d.append('name',txt(nm.value));d.append('phone',txt(ph.value));d.append('email',txt(em.value));
    d.append('company',txt(co?co.value:'').slice(0,250));d.append('type',ot.getAttribute('data-type'));d.append('msg',m);
    d.append('page','Разработка ППК — опросный лист');return d;}
  function step(){
    if(done.next>=parts.length)return ok();
    window.fetch('/send.php',{method:'POST',body:fd(parts[done.next]),headers:{'Accept':'application/json'},credentials:'same-origin'})
      .then(function(res){return res.text().then(function(t){var j=null;try{j=JSON.parse(t)}catch(_){}
        if(!res.ok||!j||!j.success){var er=new Error('send failed: '+res.status);er.userMessage=j&&j.message?j.message:'';throw er;}})})
      .then(function(){done.next++;step();})
      .catch(function(err){console.error('Опросный лист:',err);sending=false;btn.disabled=false;btn.classList.remove('is-loading');
        var m=err&&err.userMessage?err.userMessage:FAIL;if(done.next>0)m+=' Часть ответов уже у нас — при повторной отправке уйдут остальные.';alert(m);});}
  function ok(){
    try{if(typeof ym==='function'){ym(113675622,'reachGoal','audit');ym(113675622,'reachGoal','ppk_oprosnyy_send');}}catch(err){console.error('Яндекс Метрика:',err)}
    try{if(typeof Comagic!=='undefined'&&typeof Comagic.addOfflineRequest==='function')Comagic.addOfflineRequest({name:txt(nm.value),phone:txt(ph.value)});}catch(err){console.error('UIS:',err)}
    try{localStorage.removeItem(KEY)}catch(_){}
    f.classList.add('sent');window.scrollTo(0,box.getBoundingClientRect().top+window.pageYOffset-90);refresh();}
  step();
}
})();</script>
<!-- Yandex.Metrika counter + UIS + Radist: загружаются после первого действия посетителя (касание, прокрутка, мышь, клавиатура) или через 5 с после загрузки страницы -->
<script type="text/javascript">
    (function (w, d) {
        w.ym = w.ym || function () { (w.ym.a = w.ym.a || []).push(arguments); };
        w.ym.l = 1 * new Date();
        ym(113675622, 'init', {ssr:true, webvisor:true, clickmap:true, ecommerce:"dataLayer", referrer: document.referrer, url: location.href, accurateTrackBounce:true, trackLinks:true});
        var done = false, ready = false, wait = null, ev = ['pointerdown', 'touchstart', 'keydown', 'scroll', 'wheel', 'mousemove'];
        w.__cs = w.__cs || [];
        w.__cs.push(['waitForTrackViewAndRun', function () { ready = true; }]);
        // Radist: код заявки в ссылках Telegram и MAX — сразу, скрипт Radist загрузится вместе со счётчиками
        var rmsg = 'Здравствуйте! Пишу с сайта пестконтроль-центр.рф. Номер заявки: {radist_tracker}';
        w.radist_tracker = w.radist_tracker || function () { (w.radist_tracker.a = w.radist_tracker.a || []).push(arguments); };
        w.radist_tracker.l = 1 * new Date();
        w.radist_tracker({ message: rmsg, whatsapp_enabled: true, tgbot_enabled: true, tg_enabled: true, max_enabled: true, vk_enabled: true });
        (function () {
            var id = null, abc = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789', s = 'ro', i, txt;
            try {
                id = sessionStorage.getItem('radistVisit');
                if (!id || id.length !== 12) {
                    for (i = 0; i < 10; i++) s += abc.charAt(Math.floor(Math.random() * abc.length));
                    sessionStorage.setItem('radistVisit', s);
                    id = sessionStorage.getItem('radistVisit');
                }
            } catch (e) { id = null; }
            if (!id || id.length !== 12) return;
            txt = encodeURIComponent(rmsg.replace(/{radist_tracker}/g, id));
            [].forEach.call(d.querySelectorAll('a[href*="//t.me/"], a[href*="//max.ru/"]'), function (a) {
                try {
                    var u = new URL(a.href), n = u.pathname.split('/')[1] || '';
                    if (u.host === 'max.ru') a.href = 'https://max.ru/' + u.pathname.substring(1) + '?start=' + id;
                    else if (u.host === 't.me' && !/bot$/i.test(n)) a.href = 'https://t.me' + u.pathname + '?text=' + txt;
                } catch (e) {}
            });
        })();
        function add(src) { var k = d.createElement('script'); k.async = true; k.src = src; d.head.appendChild(k); return k; }
        function load() {
            if (done) return; done = true;
            ev.forEach(function (e) { w.removeEventListener(e, load, true); });
            add('https://mc.yandex.ru/metrika/tag.js?id=113675622');
            var p = d.createElement('link'); p.rel = 'preconnect'; p.href = 'https://tracker.comagic.ru'; d.head.appendChild(p);
            add('https://app.uiscom.ru/static/cs.min.js?k=ICWycQx6m3NSBe3WlCeDAdAKMTmNhMHC').onerror = function () { ready = true; };
            add('https://track.radist.me/tracker.min.js');
        }
        ev.forEach(function (e) { w.addEventListener(e, load, { capture: true, passive: true }); });
        function later() { setTimeout(load, 5000); }
        if (d.readyState === 'complete') later(); else w.addEventListener('load', later);
        // Ожидание подмены номера при первом касании: набор откладывается до ответа UIS, максимум 0,8–1 с
        d.addEventListener('click', function (e) {
            if (ready) return;
            var a = e.target && e.target.closest ? e.target.closest('a[href^="tel:"]') : null;
            if (!a || e.button || e.ctrlKey || e.metaKey || e.shiftKey || e.altKey) return;
            e.preventDefault();
            if (wait) return;
            load();
            var href = a.getAttribute('href'), op = a.style.opacity, max = 'GestureEvent' in w ? 800 : 1000, t;
            function go() {
                for (var i = 0; i < wait.length; i++) clearTimeout(wait[i]);
                wait = null; ready = true; a.style.opacity = op;
                w.location.href = a.href;
            }
            function check(last) { return function () { if (wait && (last || ready || a.getAttribute('href') !== href)) go(); }; }
            wait = [];
            a.style.opacity = '.6';
            for (t = 50; t <= max; t += 50) wait.push(setTimeout(check(t === max), t));
        }, true);
    })(window, document);
</script>
<noscript><div><img src="https://mc.yandex.ru/watch/113675622" style="position:absolute; left:-9999px;" alt="" /></div></noscript>
<!-- /Yandex.Metrika counter -->
</body>
</html>
