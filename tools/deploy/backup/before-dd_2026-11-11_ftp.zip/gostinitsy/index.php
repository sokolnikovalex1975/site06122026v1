<!doctype html>
<html lang="ru">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>Пест-контроль гостиниц и отелей в Москве и области — ПЕСТКОНТРОЛЬ Центр</title>
<meta name="description" content="Пест-контроль гостиниц и отелей по СанПиН 3.3686-21: осмотр номеров 2 раза в месяц, обработка от клопов без гостей, журнал для проверки. Бесплатное обследование.">
<link rel="canonical" href="https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/gostinitsy/">
<meta name="theme-color" content="#000000">
<meta property="og:type" content="website">
<meta property="og:locale" content="ru_RU">
<meta property="og:site_name" content="ПЕСТКОНТРОЛЬ Центр">
<meta property="og:url" content="https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/gostinitsy/">
<meta property="og:title" content="Пест-контроль гостиниц и отелей в Москве и области">
<meta property="og:description" content="Пест-контроль гостиниц и отелей по СанПиН 3.3686-21: осмотр номеров 2 раза в месяц, обработка от клопов без гостей, журнал для проверки. Бесплатное обследование.">
<meta property="og:image" content="https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/img/gost-og.jpg">
<meta property="og:image:type" content="image/jpeg">
<meta property="og:image:width" content="1200">
<meta property="og:image:height" content="630">
<meta property="og:image:alt" content="Специалист ПЕСТКОНТРОЛЬ Центра проверяет шов матраса в гостиничном номере">
<meta name="twitter:card" content="summary_large_image">
<link rel="icon" href="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 32 32'%3E%3Ccircle cx='16' cy='16' r='15' fill='%2309090b' stroke='%237c86ff' stroke-width='2'/%3E%3Cpath d='M16 7l7 3v5c0 5-3 8.5-7 10-4-1.5-7-5-7-10v-5z' fill='none' stroke='%23fff' stroke-width='2'/%3E%3C/svg%3E">
<link rel="preload" href="../fonts/inter-ru-wght-normal.woff2" as="font" type="font/woff2" crossorigin>
<link rel="preload" as="image" media="(min-width:761px)" imagesrcset="../img/gost-hero-1440.webp 1440w, ../img/gost-hero.webp 1920w" imagesizes="100vw" fetchpriority="high">
<link rel="preload" as="image" media="(max-width:760px)" imagesrcset="../img/gost-hero-mob-760.webp 760w, ../img/gost-hero-mob.webp 1024w" imagesizes="100vw" fetchpriority="high">
<script>
  /* начальные состояния анимаций — только при работающем JS; страховка — через 4 с всё показывается.
     Заставка — один раз за посещение: при переходе по ссылке с якорем и между страницами сайта её нет */
  (function (d) {
    d.classList.add('js');
    try { if (location.hash || sessionStorage.getItem('pc-intro')) d.classList.add('no-intro'); else sessionStorage.setItem('pc-intro', '1'); }
    catch (e) { if (location.hash) d.classList.add('no-intro'); }
    setTimeout(function () { if (!d.classList.contains('anim-ready')) d.classList.add('anim-fail'); }, 4000);
  })(document.documentElement);
</script>
<link rel="stylesheet" href="../style.css?v=20261106s2">
<style>.d-page .s{padding:clamp(64px,7vw,128px) 0;border-top:1px solid var(--line)}.d-crumbs{padding-top:calc(clamp(68px,6vw,115px) + 20px);font-size:14px;color:var(--t3);display:flex;flex-wrap:wrap;gap:8px}.d-crumbs a{color:var(--t2)}.d-crumbs a:hover{color:var(--t1)}.d-hero{padding:clamp(28px,3vw,56px) 0 clamp(64px,7vw,128px)}.d-hero .wrap{display:grid;grid-template-columns:minmax(0,1.15fr) minmax(0,.85fr);gap:clamp(28px,4vw,80px);align-items:center}.d-hero h1{font-size:clamp(34px,4.2vw,80px);line-height:1.05;letter-spacing:-.045em;font-weight:300;margin:18px 0 0}.d-ticks{list-style:none;padding:0;margin:28px 0 34px;display:grid;gap:12px}.d-ticks li{position:relative;padding-left:30px;line-height:1.5}.d-ticks li::before{content:"";position:absolute;left:2px;top:.42em;width:13px;height:7px;border-left:2px solid var(--acc);border-bottom:2px solid var(--acc);transform:rotate(-45deg)}.d-btns{display:flex;flex-wrap:wrap;gap:12px}.ph-img{aspect-ratio:4/3;border:1.5px dashed var(--line2);border-radius:var(--r);display:flex;align-items:center;justify-content:center;text-align:center;padding:28px;color:var(--t3);font-size:14px;line-height:1.5;background:rgba(255,255,255,.02)}.ph-doc{aspect-ratio:3/4;max-width:340px}.d-cards{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:16px}.d-card{background:var(--card);border:1px solid var(--line2);border-radius:var(--r);padding:clamp(22px,2vw,34px)}.d-card h3{font-size:clamp(20px,1.5vw,26px);font-weight:400;letter-spacing:-.02em;margin:0 0 12px}.d-card p{color:var(--t2);line-height:1.6;margin:0}.d-note{color:var(--t2);margin:24px 0 0;line-height:1.6}.d-strong{color:var(--t1);font-size:clamp(18px,1.3vw,22px)}.d-split{display:grid;grid-template-columns:minmax(0,1fr) minmax(0,340px);gap:clamp(28px,4vw,80px);align-items:start}.d-two{display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1fr);gap:clamp(28px,4vw,80px);align-items:start}.d-two .head{margin-bottom:0}.d-two .d-ticks{margin:0}.d-terms{list-style:none;counter-reset:t;padding:0;margin:0;border-top:1px solid var(--line2)}.d-terms li{display:grid;grid-template-columns:44px minmax(0,.42fr) minmax(0,1fr);gap:16px;padding:18px 0;border-bottom:1px solid var(--line2);line-height:1.55}.d-terms li::before{counter-increment:t;content:counter(t,decimal-leading-zero);color:var(--t3)}.d-terms b{font-weight:500}.d-terms span{color:var(--t2)}.d-doc{display:grid;gap:16px;justify-items:start}.d-small{font-size:14px;color:var(--t3);margin:0}.d-steps{list-style:none;counter-reset:st;padding:0;margin:0;display:grid;grid-template-columns:repeat(5,minmax(0,1fr));gap:18px}.d-steps li{border-top:2px solid var(--line2);padding-top:18px;line-height:1.55}.d-steps li::before{counter-increment:st;content:"0" counter(st);display:block;color:var(--acc);font-size:14px;margin-bottom:12px}.d-steps b{display:block;font-weight:500;margin-bottom:8px}.d-steps span{color:var(--t2)}.d-table{width:100%;border-collapse:collapse;line-height:1.5}.d-table th,.d-table td{text-align:left;vertical-align:top;padding:16px 20px 16px 0;border-bottom:1px solid var(--line2)}.d-table th{color:var(--t3);font-weight:400;font-size:14px}.d-table td{color:var(--t2)}.d-table td:first-child{color:var(--t1)}.d-vs td:first-child{color:var(--t2)}.d-vs th:last-child,.d-vs td:last-child{color:var(--t1);background:rgba(124,134,255,.07);padding-left:20px}.d-cols2{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:16px;margin-top:28px}.d-chips{list-style:none;padding:0;margin:0;display:flex;flex-wrap:wrap;gap:10px}.d-chips a{display:inline-block;padding:12px 18px;border:1px solid var(--line2);border-radius:999px;color:var(--t1);transition:border-color .2s}.d-chips a:hover{border-color:var(--acc)}.tbd{background:rgba(255,209,102,.14);color:#ffd166;border-radius:4px;padding:0 .2em}.d-page .cta .sub{margin-bottom:30px}@media (max-width:1100px){.d-steps{grid-template-columns:repeat(2,minmax(0,1fr))}}@media (max-width:860px){.d-hero .wrap,.d-split,.d-two,.d-cols2,.d-cards{grid-template-columns:minmax(0,1fr)}.d-terms li{grid-template-columns:36px minmax(0,1fr);gap:6px 12px}.d-terms span{grid-column:2}.ph-doc{display:none}}@media (max-width:600px){.d-steps{grid-template-columns:minmax(0,1fr)}.d-table thead{display:none}.d-table,.d-table tbody,.d-table tr,.d-table td{display:block;width:100%}.d-table tr{border:1px solid var(--line2);border-radius:var(--r);padding:6px 16px;margin-bottom:12px}.d-table td{border:0;padding:10px 0}.d-table td+td{border-top:1px solid var(--line)}.d-table td::before{content:attr(data-l);display:block;font-size:13px;color:var(--t3);margin-bottom:4px}.d-vs td:last-child{background:none;padding-left:0}.d-page .form .btn-lg{padding:0 16px}}.hdr .nav a{white-space:nowrap}.f-lazy:not(.bg-in){background-image:none!important}
.f-hero .hero-media{overflow:hidden}.f-hero .hero-media::after{content:"";position:absolute;inset:0 0 auto;height:200px;background:linear-gradient(180deg,rgba(9,9,11,.72),rgba(9,9,11,0));pointer-events:none}.f-hero .f-hero-img{position:absolute;inset:0;width:100%;height:100%;object-fit:cover;object-position:64% 50%;filter:saturate(.95)}.f-hero::before{background:linear-gradient(90deg,rgba(9,9,11,.92) 0%,rgba(9,9,11,.84) 40%,rgba(9,9,11,.32) 58%,rgba(9,9,11,0) 74%)}.f-hero::after{height:22%}.f-hero p.lead{max-width:600px}.f-crumbs{display:flex;flex-wrap:wrap;gap:8px;font-size:14px;color:var(--t3);margin:0 0 26px}.f-crumbs a{color:var(--t2)}.f-crumbs a:hover{color:var(--t1)}.f-urgent{margin:22px 0 0;color:var(--t2);font-size:15px}.f-urgent::before{content:"";display:inline-block;width:8px;height:8px;border-radius:50%;background:var(--grn);margin-right:10px;vertical-align:middle}
.f-checks{position:relative;padding:clamp(28px,3vw,56px) 0 clamp(56px,6vw,110px)}.f-check.panel{max-width:none}.f-check-in{position:relative;z-index:1;display:grid;grid-template-columns:minmax(0,.9fr) minmax(0,1.1fr);gap:clamp(24px,4vw,80px);padding:clamp(24px,3vw,52px)}.f-check-t{font-size:clamp(28px,2.6vw,48px);line-height:1.08;letter-spacing:-.04em;font-weight:300;margin:0}.f-check-res{margin:22px 0 10px;color:var(--t2);font-size:15px}.f-check-res b{font-size:clamp(40px,3.4vw,64px);font-weight:300;letter-spacing:-.04em;color:var(--acc);margin-right:6px;line-height:1;transition:color .3s}.f-check-res.full b{color:var(--grn)}.f-check-note{color:var(--t2);line-height:1.6;margin:0 0 28px;max-width:440px}.f-check-list{list-style:none;margin:0;padding:0;display:grid;align-content:center;border-top:1px solid var(--line)}.f-check-list li{border-bottom:1px solid var(--line)}.f-check-list label{display:flex;gap:18px;align-items:center;padding:18px 4px;cursor:pointer;font-size:clamp(16px,1.15vw,20px);line-height:1.4;color:var(--t2);transition:color .25s}.f-check-list label:hover{color:var(--t1)}.f-check-list input{appearance:none;-webkit-appearance:none;flex:none;width:26px;height:26px;margin:0;border-radius:8px;border:1.4px solid var(--line2);background:rgba(255,255,255,.03) center/14px no-repeat;cursor:pointer;transition:background-color .25s,border-color .25s}.f-check-list input:checked{background-color:var(--acc2);border-color:var(--acc);background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 14 14'%3E%3Cpath d='M2.5 7.5l3 3 6-7' fill='none' stroke='%23fff' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'/%3E%3C/svg%3E")}.f-check-list input:focus-visible{outline:2px solid var(--acc);outline-offset:3px}.f-check-list input:checked+span{color:var(--t1)}
.d-card .f-num{font-size:clamp(28px,2.4vw,44px);line-height:1.05;letter-spacing:-.035em;font-weight:300;color:var(--acc);margin:0 0 16px}.f-req .d-card{border-top:2px solid rgba(124,134,255,.45)}
.f-zmap{display:grid;grid-template-columns:minmax(0,1.4fr) minmax(0,1fr);gap:clamp(20px,2.4vw,44px);align-items:start}.f-plan{margin:0;padding:clamp(14px,1.4vw,26px)}.f-plan svg{display:block;width:100%;height:auto}.f-plan svg *{pointer-events:none}.f-plan .zf,.f-plan .bdg{pointer-events:all}.f-plan .zf{fill:transparent;transition:fill .3s,stroke .3s}.f-plan .z.on .zf{fill:rgba(124,134,255,.14)}.f-plan .z6.on .zf{fill:rgba(124,134,255,.05);stroke:#7c86ff}.f-plan .bdg circle{fill:#09090b;stroke:#7c86ff;stroke-width:2;transition:fill .3s}.f-plan .bdg text{fill:#7c86ff;font:500 22px Inter,system-ui,sans-serif;text-anchor:middle;dominant-baseline:central;transition:fill .3s}.f-plan .bdg.on circle{fill:#7c86ff}.f-plan .bdg.on text{fill:#fff}.f-plan .lbl text{fill:#84848e;font:400 15px Inter,system-ui,sans-serif}.f-legend{display:flex;flex-wrap:wrap;gap:10px 22px;margin:16px 4px 2px;font-size:13px;color:var(--t3)}.f-legend span{display:inline-flex;align-items:center;gap:9px}.f-legend i{flex:none;display:inline-block}.lg-st{width:11px;height:11px;border-radius:2px;background:var(--yel)}.lg-tr{width:11px;height:11px;border-radius:50%;background:var(--acc)}.lg-uv{width:20px;height:7px;border-radius:4px;background:#c4b5fd;box-shadow:0 0 8px rgba(167,139,250,.9)}.lg-fl{width:24px;border-top:2px dashed var(--acc)}.f-zlist{list-style:none;padding:0;margin:0;display:grid;gap:10px;counter-reset:zl}.f-zlist li{display:grid;grid-template-columns:40px minmax(0,1fr);gap:2px 14px;align-items:start;padding:15px 18px;border:1.4px solid var(--line);border-radius:var(--r);background:var(--card);transition:border-color .3s,background .3s;outline:none;cursor:default}.f-zlist li::before{counter-increment:zl;content:counter(zl);grid-row:1/span 2;width:34px;height:34px;border-radius:50%;border:1.4px solid var(--acc);color:var(--acc);display:flex;align-items:center;justify-content:center;font-size:15px;transition:background .3s,color .3s}.f-zlist b{font-weight:500;font-size:clamp(16px,1.05vw,19px);line-height:1.3}.f-zlist span{color:var(--t2);font-size:clamp(14px,.9vw,16px);line-height:1.5}.f-zlist li.on,.f-zlist li:hover,.f-zlist li:focus-visible{border-color:rgba(124,134,255,.6);background:rgba(124,134,255,.08)}.f-zlist li.on::before{background:var(--acc);color:#fff}
.f-steps4{grid-template-columns:repeat(4,minmax(0,1fr))}.d-steps li.f-alert{border-top-color:var(--yel)}.d-steps li.f-alert::before{color:var(--yel)}
.inds.f-inds{grid-template-columns:repeat(6,minmax(0,1fr))}.inds.f-inds>*{grid-column:span 2}.inds.f-inds>:nth-child(n+4){grid-column:span 3}.inds.f-inds>:nth-child(n+4) .ind-img{aspect-ratio:834/275}
.f-lbl{display:block;font-size:12px;letter-spacing:.08em;text-transform:uppercase;color:var(--acc);margin:4px 0 8px}.f-mb{margin:0 0 4px}.f-pricecard .f-price{margin:22px 0 26px;color:var(--t2);line-height:1.6}.f-pricecard .f-price b{display:block;color:var(--t1);font-weight:400;font-size:clamp(20px,1.6vw,28px);letter-spacing:-.02em;line-height:1.25;margin-bottom:6px}.d-card .btn{max-width:100%;white-space:normal;text-align:center;line-height:1.25}
@media (max-width:1100px){.f-steps4{grid-template-columns:repeat(2,minmax(0,1fr))}.f-zmap,.f-check-in{grid-template-columns:minmax(0,1fr)}.inds.f-inds{grid-template-columns:repeat(2,minmax(0,1fr))}.inds.f-inds>*,.inds.f-inds>:nth-child(n+4){grid-column:auto}.inds.f-inds>:nth-child(n+4) .ind-img{aspect-ratio:556/275}.inds.f-inds>:last-child{grid-column:1/-1}.inds.f-inds>:last-child .ind-img{aspect-ratio:834/275}}
@media (max-width:900px){.hdr{background:rgba(0,0,0,.72);backdrop-filter:blur(18px);-webkit-backdrop-filter:blur(18px);border-color:var(--line)}.f-hero{display:block;min-height:0;padding:68px 0 clamp(44px,8vw,72px)}.f-hero::before,.f-hero::after{display:none}.f-hero .hero-media{position:relative;inset:auto;width:100%;aspect-ratio:16/9}.f-hero .hero-media::after{height:100%;background:linear-gradient(180deg,rgba(0,0,0,0) 62%,#000 100%)}.f-hero .f-hero-img{object-position:70% 50%;filter:none}.f-hero .wrap{margin-top:-24px}.f-hero p.lead{max-width:760px}}@media (max-width:760px){.f-hero .hero-media{aspect-ratio:4/3}.f-hero .f-hero-img{object-position:50% 50%}.f-crumbs{font-size:13px;margin-bottom:18px}.inds.f-inds{grid-template-columns:minmax(0,1fr)}.inds.f-inds>:last-child{grid-column:auto}.inds.f-inds>:last-child .ind-img{aspect-ratio:556/275}}
@media (max-width:600px){.f-steps4{grid-template-columns:minmax(0,1fr)}.d-btns .btn,.d-card .btn,.f-check .btn{width:100%;white-space:normal;text-align:center;line-height:1.25}.d-page .btn-lg{padding:0 16px}.f-plan .lbl{display:none}.f-check-in{padding:24px 20px}.f-check-list label{padding:15px 2px;gap:14px}.f-zlist li{padding:14px}}
@media (max-width:400px){.hdr .wrap{gap:10px}.hdr-right{gap:8px}.logo{gap:8px}.logo-mark{width:34px;height:34px}.logo-name{font-size:15px}.phone i,.burger{width:40px;height:40px}}@media (max-width:340px){.logo-sub{display:none}}
/* ===== Страница «Пест-контроль гостиниц и отелей» (/gostinitsy/): дополнения к стилям отраслевой страницы ===== */
.g-page .f-hero .f-hero-img{object-position:60% 50%}
.g-short{margin:0 0 clamp(28px,3vw,44px);padding:clamp(18px,1.6vw,26px) clamp(20px,2vw,30px);border:1px solid var(--line2);border-left:2px solid var(--acc);border-radius:var(--r);background:var(--card);color:var(--t2);line-height:1.65;max-width:1000px;font-size:clamp(16px,1.05vw,19px)}
.g-short b{color:var(--t1);font-weight:500}
.g-upd{display:block;margin-top:10px;font-size:13px;color:var(--t3)}
.g-check-h{font-size:clamp(22px,1.8vw,32px);line-height:1.15;font-weight:300;letter-spacing:-.03em;margin:clamp(44px,4.4vw,72px) 0 10px}
.g-check-src{color:var(--t3);font-size:14px;line-height:1.6;margin:0 0 18px;max-width:900px}
.g-check-src a,.g-risk a,.g-steps a,.g-note a,.g-short a{color:var(--t2);border-bottom:1px solid var(--line2);transition:color .25s,border-color .25s}
.g-check-src a:hover,.g-risk a:hover,.g-steps a:hover,.g-note a:hover,.g-short a:hover{color:var(--t1);border-color:var(--acc)}
.g-qn{display:inline-flex;align-items:center;justify-content:center;min-width:56px;height:30px;padding:0 10px;border-radius:999px;border:1px solid rgba(124,134,255,.5);color:var(--acc);font-size:14px;font-variant-numeric:tabular-nums;white-space:nowrap}
.d-table.g-ql td:nth-child(2){color:var(--t1)}
.g-ql small{display:block;color:var(--t3);font-size:13px;margin-top:4px}
@media (min-width:761px){.d-table.g-ql td:first-child{width:96px}.d-table.g-ql td:nth-child(2){width:46%}}
/* схема: номер с сигналом и соседние номера */
.f-plan .g-hot{fill:rgba(253,199,0,.1);stroke:#fdc700;stroke-width:2}
.f-plan .g-adj{fill:none;stroke:#7c86ff;stroke-width:1.6;stroke-dasharray:6 6}
@media (prefers-reduced-motion:no-preference){.f-plan .g-hot{animation:g-pulse 2.6s ease-in-out infinite}@keyframes g-pulse{0%,100%{opacity:1}50%{opacity:.5}}}
.lg-hot{width:15px;height:11px;border-radius:3px;border:2px solid var(--yel);background:rgba(253,199,0,.12)}
.lg-adj{width:15px;height:11px;border-radius:3px;border:1.6px dashed var(--acc)}
/* протокол при жалобе гостя */
.g-proto{display:grid;grid-template-columns:minmax(0,.92fr) minmax(0,1.08fr);gap:clamp(28px,4vw,80px);align-items:start}
.g-proto-side{position:sticky;top:110px;display:grid;gap:16px}
.g-photo{position:relative;margin:0;border-radius:var(--r);overflow:hidden;border:1px solid var(--line2);background:#0d0d10;aspect-ratio:900/542}
.g-photo img{position:absolute;inset:0;width:100%;height:100%;object-fit:cover}
.g-photo-43{aspect-ratio:4/3}
.g-risk{padding:clamp(20px,1.8vw,30px)}
.g-risk h3,.g-do h3{font-size:clamp(18px,1.25vw,22px);font-weight:400;letter-spacing:-.02em;margin:0 0 10px}
.g-risk p,.g-do p{margin:0;color:var(--t2);line-height:1.6}
.g-steps{list-style:none;margin:0;padding:0;counter-reset:gs;border-top:1px solid var(--line)}
.g-steps li{display:grid;grid-template-columns:44px minmax(0,1fr);column-gap:16px;padding:22px 0;border-bottom:1px solid var(--line)}
.g-steps li::before{counter-increment:gs;content:counter(gs,decimal-leading-zero);grid-row:1/span 3;color:var(--t3);font-size:14px;padding-top:2px;font-variant-numeric:tabular-nums}
.g-meta{display:flex;flex-wrap:wrap;align-items:center;gap:6px 14px;margin:0 0 8px}
.g-when{color:var(--acc);font-size:12px;letter-spacing:.08em;text-transform:uppercase}
.g-who{color:var(--t3);font-size:13px}
.g-who::before{content:"";display:inline-block;width:4px;height:4px;border-radius:50%;background:var(--t3);margin:0 10px 2px 0;vertical-align:middle}
.g-steps h3{font-size:clamp(18px,1.3vw,22px);font-weight:400;letter-spacing:-.02em;line-height:1.3;margin:0 0 8px}
.g-steps p{margin:0;color:var(--t2);line-height:1.6}
.g-steps li.g-alert .g-when{color:var(--yel)}
/* сервис без огласки */
.g-quiet{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:16px}
.g-ic{display:flex;align-items:center;justify-content:center;width:46px;height:46px;border-radius:12px;background:rgba(124,134,255,.12);border:1px solid rgba(124,134,255,.28);color:var(--acc);margin:0 0 20px}
.g-ic svg{width:22px;height:22px}
.g-quiet .d-card h3{font-size:clamp(18px,1.3vw,22px)}
/* обучение горничных */
.g-train{display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1fr);gap:clamp(28px,4vw,80px);align-items:start}
.g-train .d-strong{margin:0 0 26px;line-height:1.55;color:var(--t1)}
.g-sub{font-size:13px;letter-spacing:.08em;text-transform:uppercase;color:var(--acc);font-weight:500;margin:0 0 6px}
.g-signs{list-style:none;margin:0 0 22px;padding:0;counter-reset:sg;border-top:1px solid var(--line)}
.g-signs li{display:grid;grid-template-columns:30px minmax(0,1fr);gap:14px;align-items:start;padding:14px 0;border-bottom:1px solid var(--line);color:var(--t2);line-height:1.55}
.g-signs li::before{counter-increment:sg;content:counter(sg);width:28px;height:28px;border-radius:50%;border:1.4px solid var(--acc);color:var(--acc);display:flex;align-items:center;justify-content:center;font-size:13px}
.g-signs b{color:var(--t1);font-weight:500}
.g-do{padding:clamp(18px,1.6vw,26px);border-left:2px solid var(--yel)}
/* форматы гостиниц: 2 × 2 */
.inds.g-inds{grid-template-columns:repeat(2,minmax(0,1fr))}
.g-inds .ind-img{aspect-ratio:900/420}
.g-note{color:var(--t2);margin:24px 0 0;line-height:1.6}
@media (max-width:1100px){.g-proto,.g-train{grid-template-columns:minmax(0,1fr)}.g-proto-side{position:static}.g-proto-side .g-photo{max-width:760px}.g-quiet{grid-template-columns:repeat(2,minmax(0,1fr))}}
@media (max-width:760px){.inds.g-inds{grid-template-columns:minmax(0,1fr)}.g-inds .ind-img{aspect-ratio:556/300}}
@media (max-width:600px){.g-quiet{grid-template-columns:minmax(0,1fr)}.g-steps li{grid-template-columns:34px minmax(0,1fr);column-gap:12px}.g-short{font-size:16px}}
/* фон блока заявки — коридор гостиницы ночью (ленивая загрузка — как у остальных фонов) */
.g-page .cta-bg{background-image:url(../img/gost-cta.webp);filter:grayscale(.25) brightness(.42)}
@media (max-width:760px){.g-page .cta-bg{background-image:url(../img/gost-cta-m.webp)}}
/* узкие экраны 320–374 px: колонка первого экрана не шире экрана, длинная кнопка переносится на две строки */
@media (max-width:374px){.g-page .f-hero .wrap{grid-template-columns:minmax(0,1fr)}.g-page .hero-ctas .btn{white-space:normal;text-align:center;line-height:1.25;height:auto;min-height:56px;padding:12px 22px}}</style>
<script type="application/ld+json">{"@context": "https://schema.org", "@graph": [{"@type": "BreadcrumbList", "itemListElement": [{"@type": "ListItem", "position": 1, "name": "Главная", "item": "https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/"}, {"@type": "ListItem", "position": 2, "name": "Пест-контроль гостиниц и отелей", "item": "https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/gostinitsy/"}]}, {"@type": "Service", "@id": "https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/gostinitsy/#service", "name": "Пест-контроль гостиниц и отелей", "serviceType": "Пест-контроль по системе IPM: дезинсекция и дератизация гостиниц (СанПиН 3.3686-21, СП 2.1.4284-26)", "description": "Пест-контроль гостиниц и отелей по СанПиН 3.3686-21: осмотр номеров 2 раза в месяц, обработка от клопов без гостей, журнал для проверки. Бесплатное обследование.", "url": "https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/gostinitsy/", "provider": {"@type": "Organization", "@id": "https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/#org", "name": "ПЕСТКОНТРОЛЬ Центр", "legalName": "ООО «Центр дезинфекционных услуг»", "url": "https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/", "telephone": "+7 495 104-35-70", "email": "b2b@pestcontrol-center.ru"}, "areaServed": [{"@type": "City", "name": "Москва"}, {"@type": "AdministrativeArea", "name": "Московская область"}], "audience": {"@type": "BusinessAudience", "audienceType": "Гостиницы, отели, апарт-отели, хостелы, базы отдыха"}, "offers": {"@type": "Offer", "name": "Разовая обработка номера", "priceCurrency": "RUB", "price": 3500, "priceSpecification": {"@type": "UnitPriceSpecification", "minPrice": 3500, "priceCurrency": "RUB", "unitText": "за выезд"}}}, {"@type": "FAQPage", "@id": "https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/gostinitsy/#faq", "mainEntity": [{"@type": "Question", "name": "Как часто нужно проводить дезинсекцию в гостинице?", "acceptedAnswer": {"@type": "Answer", "text": "Гостиница — объект особого эпидемиологического значения: обследования на насекомых — не реже 2 раз в месяц, оценка заселённости грызунами — ежемесячно (пп. 98, 101, 110 СанПиН 3.3686-21). Обработки проводят по результатам обследований и при появлении вредителей."}}, {"@type": "Question", "name": "Что делать, если гость пожаловался на клопов?", "acceptedAnswer": {"@type": "Answer", "text": "Переселить гостя в номер на другом этаже, снять номер с продажи, бельё отправить в прачечную в закрытом мешке и вызвать специалиста. Мы осмотрим номер и соседние — слева, справа, сверху и снизу, обработаем очаг и проведём контрольный осмотр через 10–14 дней."}}, {"@type": "Question", "name": "Нужно ли закрывать этаж или выселять соседей?", "acceptedAnswer": {"@type": "Answer", "text": "Обычно нет. Выборочную дезинсекцию проводят в отдельных номерах, где нашли насекомых, в отсутствие людей (п. 127 СанПиН 3.3686-21). Соседние номера осматриваем и обрабатываем, если в них тоже есть находки."}}, {"@type": "Question", "name": "Когда номер можно вернуть в продажу?", "acceptedAnswer": {"@type": "Answer", "text": "После проветривания по инструкции к средству и влажной уборки. Срок зависит от средства, поэтому называем его до начала работ."}}, {"@type": "Question", "name": "Сколько стоит обработка номера от клопов?", "acceptedAnswer": {"@type": "Answer", "text": "Разовая обработка номера от клопов — от 3 500 ₽ за выезд: локализация очага, уничтожение клопов и акт выполненных работ. Абонентское обслуживание гостиницы считаем после бесплатного обследования; при переходе на годовой договор стоимость первой обработки учитываем в расчёте."}}, {"@type": "Question", "name": "Что проверяет Роспотребнадзор в гостинице по вредителям?", "acceptedAnswer": {"@type": "Answer", "text": "По проверочному листу (приказ Роспотребнадзора от 20.07.2026 № 578): нет ли насекомых и грызунов, кто и как проводит обработки, соблюдается ли кратность обследований — 2 раза в месяц на насекомых и ежемесячно на грызунов, обследуются ли мусоросборные камеры и контейнерная площадка."}}, {"@type": "Question", "name": "Работаете ли вы ночью и без огласки?", "acceptedAnswer": {"@type": "Answer", "text": "Да. Выезжаем без броской символики, ночью и в выходные — без наценки. Срочный выезд — в течение 3 часов по Москве и Московской области, 24/7."}}, {"@type": "Question", "name": "Проводите ли вы обучение горничных?", "acceptedAnswer": {"@type": "Answer", "text": "Да. Инструктаж проводим на объекте: признаки клопов, порядок действий при находке и как не разнести насекомых с бельём по этажам."}}, {"@type": "Question", "name": "Чем пест-контроль отличается от разовой обработки?", "acceptedAnswer": {"@type": "Answer", "text": "Разовая обработка убирает очаг. Пест-контроль — постоянная система: осмотры по графику, точки контроля, журнал и обучение персонала, чтобы очаг не повторился. Подробнее — в материале «Пест-менеджмент или разовая обработка»."}}, {"@type": "Question", "name": "Есть ли у вас лицензия?", "acceptedAnswer": {"@type": "Answer", "text": "Да. С 1 марта 2025 года услуги дезинфекции, дезинсекции и дератизации лицензируются. У ООО «Центр дезинфекционных услуг» действующая лицензия № Л064-00111-77/01942445 — запись можно проверить в реестре лицензий Роспотребнадзора."}}]}]}</script>
<style id="m-crumbs">/* крошки на телефоне не показываем: для SEO хватает BreadcrumbList и ссылок в HTML */@media (max-width:900px){.d-crumbs,.f-crumbs{display:none!important}}</style>
<style id="t-inset">/* таблицы: текст не прижимается к краю — отступ первой и последней колонки */@media (min-width:901px){.d-table tr>:first-child{padding-left:clamp(16px,1.5vw,24px)}.d-table tr>:last-child{padding-right:clamp(16px,1.5vw,24px)}}</style>
<style id="srch-st">/* лупа поиска в шапке и раскладка шапки с ней (tools/menu/apply_menu.py) */.srch-btn{flex:none;width:44px;height:44px;padding:0;border-radius:50%;display:grid;place-items:center;background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.1);color:#fff;cursor:pointer;transition:color .25s,border-color .3s,background .3s,transform .35s cubic-bezier(.16,1,.3,1)}.srch-btn:hover{border-color:#7c86ff;background:rgba(97,95,255,.2);transform:translateY(-2px)}.srch-btn:focus-visible{outline:2px solid #7c86ff;outline-offset:2px}.srch-btn svg{width:18px;height:18px;display:block}@media (min-width:761px){.hdr .wrap{gap:16px}.hdr .msg{display:none}.srch-btn{width:38px;height:38px;background:none;border-color:transparent;color:var(--t2);margin-right:calc(4px - clamp(14px,2vw,40px))}.srch-btn svg{width:20px;height:20px}.srch-btn:hover{color:#fff;background:rgba(255,255,255,.07);border-color:rgba(255,255,255,.1);transform:none}}@media (min-width:761px) and (max-width:1440px){.hdr-right{gap:18px}.srch-btn{margin-right:-14px}}@media (min-width:761px) and (max-width:1000px){.hdr-right{gap:12px}.srch-btn{margin-right:-8px}}@media (max-width:900px){.logo-txt{display:flex;flex-direction:column;align-items:flex-start}.logo-sub{margin:0}}@media (max-width:760px){.hdr .wrap{gap:12px}.hdr-right{gap:8px}}@media (max-width:400px){.hdr .wrap{gap:10px}.srch-btn{width:40px;height:40px}}@media (max-width:360px){.hdr .wrap{gap:8px}.hdr-right{gap:6px}.srch-btn,.phone i,.burger{width:38px;height:38px}}@media (max-width:340px){.logo-mark{display:none}.logo-sub{display:block}}</style><script id="srch-js">/* поиск по сайту: движок и индекс загружаются по первому нажатию на лупу или «/» (tools/search) */(function(r,v){var d=document,ld=0,w=null;function go(o){if(window.PCSearch)return window.PCSearch.open(r,v,o);w=o;if(ld)return;ld=1;var s=d.createElement("script");s.src=r+"search.min.js?v="+v;s.async=true;s.onload=function(){window.PCSearch&&window.PCSearch.open(r,v,w)};s.onerror=function(){ld=0};d.head.appendChild(s)}d.addEventListener("click",function(e){var b=e.target.closest&&e.target.closest("[data-srch]");if(b){e.preventDefault();go({btn:b})}});d.addEventListener("keydown",function(e){if(e.key!=="/"||e.ctrlKey||e.metaKey||e.altKey)return;var t=e.target,n=t&&t.tagName;if(n==="INPUT"||n==="TEXTAREA"||n==="SELECT"||t.isContentEditable)return;e.preventDefault();go({})});if(/^#q\d+$/.test(location.hash)){var c=0,t=setInterval(function(){var b=d.getElementById(location.hash.slice(1));if(b&&d.documentElement.classList.contains("anim-ready")){clearInterval(t);if(b.getAttribute("aria-expanded")==="false")b.click()}else if(++c>60)clearInterval(t)},150)}})("../","20261108");</script>
<style data-fx>
/* подсветка рамки карточек за курсором — как у .card на главной (tools/site/fx.py) */
:where(.d-card,.p-sec,.p-fcard,.p-duty-box,.p-dl-card,.pm-step-card,.pm-scen,.pm-link-card,.k-err,.w-sample,.d-doc-prev){position:relative}
:where(.d-card,.p-sec,.p-fcard,.p-duty-box,.p-dl-card,.pm-step-card,.pm-scen,.pm-link-card,.k-err,.w-sample,.d-doc-prev)::after{content:"";position:absolute;inset:0;border-radius:inherit;padding:1.4px;pointer-events:none;background:radial-gradient(360px circle at var(--mx,-999px) var(--my,-999px),rgba(124,134,255,.85),rgba(124,134,255,.15) 35%,transparent 60%);-webkit-mask:linear-gradient(#000 0 0) content-box,linear-gradient(#000 0 0);-webkit-mask-composite:xor;mask:linear-gradient(#000 0 0) content-box,linear-gradient(#000 0 0);mask-composite:exclude;opacity:0;transition:opacity .4s;z-index:2}
@media (hover:hover) and (pointer:fine){:where(.d-card,.p-sec,.p-fcard,.p-duty-box,.p-dl-card,.pm-step-card,.pm-scen,.pm-link-card,.k-err,.w-sample,.d-doc-prev):hover::after{opacity:1}}
/* «фонарь» на фото первого экрана — как на главной (tools/site/fx.py) */
.fx-lit{position:absolute;inset:0;opacity:0;pointer-events:none;-webkit-mask-image:radial-gradient(circle var(--sr,320px) at var(--sx,72%) var(--sy,46%),#000 0%,rgba(0,0,0,.55) 45%,transparent 72%);mask-image:radial-gradient(circle var(--sr,320px) at var(--sx,72%) var(--sy,46%),#000 0%,rgba(0,0,0,.55) 45%,transparent 72%);transition:opacity 1.8s cubic-bezier(.16,1,.3,1)}
#hero :is(.d-hero-media,.hero-media)>picture>img{transition:filter 1.8s cubic-bezier(.16,1,.3,1)}
#hero.fx-lit-on :is(.d-hero-media,.hero-media)>picture>img{filter:grayscale(.3) brightness(.56)}
#hero.fx-lit-on .fx-lit img{filter:brightness(1.08) contrast(1.06) saturate(1.06)}
#hero.fx-lit-on .fx-lit{opacity:1}
</style>
<style id="hero-fold">/* кнопки первого экрана видны целиком на любом экране (tools/site/hero_fold.py) */@media (max-width:760px){#hero.hero:not(.f-hero) .hero-copy{display:flex;flex-direction:column}#hero.hero:not(.f-hero) .hero-copy>*{order:6}#hero.hero:not(.f-hero) .hero-copy>.badge{order:1;align-self:flex-start}#hero.hero:not(.f-hero) .hero-copy>h1{order:2;margin-bottom:0}#hero.hero:not(.f-hero) .hero-copy>.hero-ctas{order:3;margin-top:22px}#hero.hero:not(.f-hero) .hero-copy>.lead{order:4;margin-top:24px}}@media (max-width:760px) and (max-height:620px){#hero.hero:not(.f-hero){padding-top:92px}#hero.hero:not(.f-hero) h1{margin-top:18px}}@media (max-width:900px){#hero.f-hero .hero-copy{display:flex;flex-direction:column}#hero.f-hero .hero-copy>*{order:6}#hero.f-hero .hero-copy>.f-crumbs{order:0}#hero.f-hero .hero-copy>.badge{order:1;align-self:flex-start}#hero.f-hero .hero-copy>h1{order:2;margin-bottom:0}#hero.f-hero .hero-copy>.hero-ctas{order:3;margin-top:22px}#hero.f-hero .hero-copy>.lead{order:4;margin-top:24px}#hero.f-hero .hero-media{aspect-ratio:auto;height:clamp(104px,calc(100vh - 440px),56.25vw);height:clamp(104px,calc(100svh - 440px),56.25vw)}}@media (max-width:760px){#hero.f-hero .hero-media{height:clamp(104px,calc(100vh - 440px),75vw);height:clamp(104px,calc(100svh - 440px),75vw)}.rp-page #hero.f-hero .hero-media,.lb-page #hero.f-hero .hero-media{height:clamp(104px,calc(100vh - 480px),75vw);height:clamp(104px,calc(100svh - 480px),75vw)}}@media (max-width:900px) and (max-height:620px){#hero.f-hero .hero-copy>.badge{display:none}#hero.f-hero .hero-media{height:clamp(96px,calc(100vh - 400px),75vw);height:clamp(96px,calc(100svh - 400px),75vw)}.rp-page #hero.f-hero .hero-copy>h1{font-size:clamp(26px,7.6vw,34px)}#hero.f-hero .hero-copy>h1{margin-top:30px}}@media (max-width:860px){#hero.d-hero .d-hero-media{aspect-ratio:auto;height:clamp(104px,calc(100vh - 380px),56.25vw);height:clamp(104px,calc(100svh - 380px),56.25vw)}}@media (max-width:860px) and (max-height:620px){#hero.d-hero{padding-top:84px}#hero.d-hero .d-hero-media{margin-top:14px}#hero.d-hero .d-btns{margin-top:16px}}@media (max-width:860px) and (max-height:520px){#hero.d-hero .d-hero-media{display:none}#hero.d-hero h1{margin-bottom:0}}@media (max-width:900px) and (max-height:520px){#hero.f-hero{padding-top:76px}#hero.f-hero .hero-media{display:none}#hero.f-hero .wrap{margin-top:0}#hero.f-hero .hero-copy>h1{margin-top:0}}@media (max-width:400px){#hero .hero-copy{min-width:0}#hero .hero-ctas .btn{min-width:0;max-width:100%;white-space:normal;padding:0 14px}#hero .hero-ctas .btn-t{white-space:normal;text-align:center}}@media (max-width:860px) and (max-height:620px){#hero.d-hero .d-hero-media{height:clamp(104px,calc(100vh - 410px),56.25vw);height:clamp(104px,calc(100svh - 410px),56.25vw)}}@media (max-height:520px){#hero.p-hero .p-hero-copy>.d-btns{order:3;margin-top:18px}#hero.p-hero .p-hero-copy>.p-def{order:4;margin-top:18px}}@media (max-width:760px) and (max-height:620px){#hero.p-hero .p-hero-copy>.d-btns{order:3;margin-top:18px}#hero.p-hero .p-hero-copy>.p-def{order:4;margin-top:18px}}@media (min-width:761px) and (max-height:520px){#hero.hero:not(.f-hero){padding-top:84px;min-height:0}#hero.hero:not(.f-hero) .hero-copy{display:flex;flex-direction:column}#hero.hero:not(.f-hero) .hero-copy>*{order:6}#hero.hero:not(.f-hero) .hero-copy>.badge{order:1;align-self:flex-start}#hero.hero:not(.f-hero) .hero-copy>h1{order:2;margin:14px 0 0}#hero.hero:not(.f-hero) .hero-copy>.hero-ctas{order:3;margin-top:18px}#hero.hero:not(.f-hero) .hero-copy>.lead{order:4;margin-top:18px}}@media (min-width:861px){#hero.d-hero .d-hero-copy{display:flex;flex-direction:column}#hero.d-hero .d-hero-copy>*{order:6}#hero.d-hero .d-hero-copy>.d-crumbs{order:0}#hero.d-hero .d-hero-copy>.eyebrow{order:1}#hero.d-hero .d-hero-copy>h1{order:2}#hero.d-hero .d-hero-copy>:is(.lead,.sub,.p-def):not(:is(.lead,.sub,.p-def)~*){order:3}#hero.d-hero .d-hero-copy>.d-btns:not(.d-btns~*){order:4}#hero.d-hero .d-hero-copy>.d-ticks{margin-bottom:0}}@media (min-width:901px){#hero.f-hero .hero-copy{display:flex;flex-direction:column}#hero.f-hero .hero-copy>*{order:6}#hero.f-hero .hero-copy>.f-crumbs{order:0}#hero.f-hero .hero-copy>.badge{order:1;align-self:flex-start}#hero.f-hero .hero-copy>h1{order:2}#hero.f-hero .hero-copy>.lead{order:3}#hero.f-hero .hero-copy>.hero-ctas{order:4}#hero.f-hero .hero-copy>.rp-hero-list{margin-top:26px}}@media (min-width:861px) and (max-height:820px){#hero.d-hero{padding-top:calc(clamp(68px,6vw,115px) + 8px)}#hero.d-hero .d-hero-copy>.d-crumbs{margin-bottom:0}#hero.d-hero .d-hero-copy>.eyebrow{margin:16px 0 0}#hero.d-hero .d-hero-copy>h1{margin-top:14px;line-height:1.02}#hero.d-hero .d-hero-copy>:is(.lead,.sub,.p-def){margin-top:16px}#hero.d-hero .d-btns{margin-top:20px}}@media (min-width:901px) and (max-height:820px){#hero.f-hero{padding-top:80px}#hero.f-hero .hero-copy>.f-crumbs{margin-bottom:10px}#hero.f-hero .hero-copy>h1{font-size:min(8.2vh,4.4vw);margin:16px 0 14px}.rp-page #hero.f-hero .hero-copy>h1,.lb-page #hero.f-hero .hero-copy>h1{font-size:min(8vh,3.4vw)}#hero.f-hero .hero-copy>.lead{line-height:1.5}#hero.f-hero .hero-copy>.hero-ctas{margin-top:26px}}@media (min-width:761px) and (max-height:820px){#hero.p-hero h1{font-size:min(8.4vh,4.4vw)}#hero.p-hero .p-hero-copy>.d-btns{margin-top:20px}}@media (min-width:761px) and (max-height:820px){#hero.hero:not(.f-hero) h1{font-size:min(8.4vh,4.4vw);margin:22px 0 18px}#hero.hero:not(.f-hero) .hero-ctas{margin-top:28px}}</style>
</head>
<body class="d-page g-page">
<a class="skip" href="#main">Перейти к содержанию</a>

<!-- ============ INTRO ============ -->
<div class="intro" id="intro" aria-hidden="true">
  <div class="intro-in">
    <svg class="intro-mark" viewBox="0 0 24 24" fill="none" stroke-width="1" stroke-linejoin="round"><path class="im-shield" pathLength="100" d="M12 2.5l7.5 3v6c0 5-3.2 8.6-7.5 10-4.3-1.4-7.5-5-7.5-10v-6z" stroke="#fff"/><circle class="im-c" pathLength="100" cx="12" cy="11.5" r="2.6" stroke="#7c86ff"/><path class="im-x" pathLength="100" d="M12 6.2v2.7M12 14.1v2.7M6.8 11.5h2.6M14.6 11.5h2.6" stroke="#7c86ff"/></svg>
    <div class="intro-word"><span>ПЕСТКОНТРОЛЬ</span><b>Центр</b></div>
    <div class="intro-bar"><i></i></div>
  </div>
</div>

<div class="progress" aria-hidden="true"><i id="progress"></i></div>
<div class="cursor" aria-hidden="true"><i class="cursor-dot"></i><i class="cursor-ring"></i></div>
<div class="grain" aria-hidden="true"></div>

<header class="hdr" id="hdr">
  <div class="wrap">
    <a href="../" class="logo" aria-label="ПЕСТКОНТРОЛЬ Центр — на главную">
      <span class="logo-mark"><svg viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="1.6" stroke-linejoin="round" aria-hidden="true"><path d="M12 2.5l7.5 3v6c0 5-3.2 8.6-7.5 10-4.3-1.4-7.5-5-7.5-10v-6z"/><circle cx="12" cy="11.5" r="2.6" stroke="#7c86ff"/><path d="M12 6.2v2.7M12 14.1v2.7M6.8 11.5h2.6M14.6 11.5h2.6" stroke="#7c86ff"/></svg></span>
      <span class="logo-txt"><span class="logo-name">ПЕСТКОНТРОЛЬ</span> <span class="logo-sub">Центр</span></span>
    </a>
    <nav class="nav" aria-label="Основное меню">
      <div class="nav-dd"><button class="nav-dd-btn" type="button" aria-expanded="false" aria-controls="nav-uslugi">Услуги<svg viewBox="0 0 12 12" aria-hidden="true"><path d="M2.5 4.5 6 8l3.5-3.5" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></button><div class="nav-dd-panel" id="nav-uslugi"><a href="../dezinfektsiya/">Дезинфекция для организаций<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../deratizatsiya/">Дератизация для организаций<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../dezinsektsiya/">Дезинсекция для организаций<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../sanitarnyy-audit/"><span>Санитарный аудит <span class="nw">(СЭС-аудит)</span></span><svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../laboratornye-issledovaniya/">Лабораторные исследования<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../razrabotka-ppk/">Разработка ППК<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../normativnaya-baza/dokumenty-dlya-rospotrebnadzora/">Документы для Роспотребнадзора<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../ochistka-dezinfektsiya-ventilyatsii/">Очистка и дезинфекция вентиляции<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../dogovor-deratizatsiya-dezinsektsiya/">Договор на обслуживание<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../#podhod" class="nav-dd-all"><span>Пест-контроль по системе IPM</span><svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a></div></div><div class="nav-dd"><button class="nav-dd-btn active" type="button" aria-expanded="false" aria-controls="nav-otrasli">Отрасли<svg viewBox="0 0 12 12" aria-hidden="true"><path d="M2.5 4.5 6 8l3.5-3.5" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></button><div class="nav-dd-panel" id="nav-otrasli"><a href="../pishchevoe-proizvodstvo/">Пищевые производства<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../magaziny-i-torgovye-seti/">Магазины и торговые сети<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../restorany-i-kafe/">Рестораны и кафе<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../sklady-i-logistika/">Склады и логистика<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../farmatsevticheskie-proizvodstva/">Фармацевтические производства<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="./" aria-current="page">Гостиницы и отели<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../#otrasli" class="nav-dd-all">Все отрасли<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a></div></div><a href="../dogovor-deratizatsiya-dezinsektsiya/">Договор</a><a href="../#podhod">Метод IPM</a><a href="../#usloviya">Цена</a><div class="nav-dd"><button class="nav-dd-btn" type="button" aria-expanded="false" aria-controls="nav-materialy">Материалы<svg viewBox="0 0 12 12" aria-hidden="true"><path d="M2.5 4.5 6 8l3.5-3.5" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></button><div class="nav-dd-panel" id="nav-materialy"><a href="../normativnaya-baza/">Нормативная база<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../normativnaya-baza/dokumenty-dlya-rospotrebnadzora/">Документы для Роспотребнадзора<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../materialy/programma-pest-kontrolya/"><span>Программа <span class="nw">пест-контроля</span></span><svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../materialy/zhurnal-pest-kontrolya/"><span>Журнал <span class="nw">пест-контроля</span></span><svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../materialy/pest-menedzhment-ili-razovaya-obrabotka/"><span><span class="nw">Пест-менеджмент</span> или разовая обработка</span><svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../materialy/programma-proizvodstvennogo-kontrolya-haccp/">Программа производственного контроля по ХАССП<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../materialy/" class="nav-dd-all">Все материалы<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a></div></div>
    </nav>
    <div class="hdr-right">
      <button class="srch-btn" type="button" data-srch aria-label="Поиск по сайту" aria-haspopup="dialog"><svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="11" cy="11" r="7" fill="none" stroke="currentColor" stroke-width="2"/><path d="m20 20-3.6-3.6" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg></button>
      <a class="phone" href="tel:+74951043570" aria-label="Позвонить: +7 (495) 104-35-70"><i><svg viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2" aria-hidden="true"><path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1 1 .4 1.9.7 2.8a2 2 0 0 1-.5 2.1L8 9.9a16 16 0 0 0 6 6l1.3-1.3a2 2 0 0 1 2.1-.4c.9.3 1.8.6 2.8.7a2 2 0 0 1 1.7 2z"/></svg></i><span>+7 (495) 104-35-70</span></a>
      <div class="msg">
        <a href="https://max.ru/u/f9LHodD0cOIlIUXFkt4KMFP88lD8n4TArBiTcV7RI1XML5c4o39QfsDBXUc" class="max" aria-label="Написать в Max" target="_blank" rel="noopener noreferrer"><svg viewBox="0 0 24 24" fill="#fff" aria-hidden="true"><path d="M12 3a9 9 0 0 0-7.7 13.7L3 21l4.4-1.2A9 9 0 1 0 12 3zm-3.6 12.3V8.7h1.6l2 2.8 2-2.8h1.6v6.6h-1.7v-3.9L12 14l-1.9-2.6v3.9z"/></svg></a>
        <a href="https://t.me/Centr_Dezinfection?text=%D0%97%D0%B4%D1%80%D0%B0%D0%B2%D1%81%D1%82%D0%B2%D1%83%D0%B9%D1%82%D0%B5!%20%D0%9F%D0%B8%D1%88%D1%83%20%D1%81%20%D1%81%D0%B0%D0%B9%D1%82%D0%B0%20%D0%BF%D0%B5%D1%81%D1%82%D0%BA%D0%BE%D0%BD%D1%82%D1%80%D0%BE%D0%BB%D1%8C-%D1%86%D0%B5%D0%BD%D1%82%D1%80.%D1%80%D1%84" class="tg" aria-label="Написать в Telegram" target="_blank" rel="noopener noreferrer"><svg viewBox="0 0 24 24" fill="#fff" aria-hidden="true"><path d="M21.4 4.3 2.9 11.4c-1.3.5-1.2 1.2-.2 1.5l4.7 1.5 1.8 5.6c.2.6.4.8.9.8.4 0 .6-.2.9-.4l2.3-2.2 4.7 3.5c.9.5 1.5.2 1.7-.8l3.1-14.6c.3-1.3-.5-1.8-1.4-1.5zM9.6 14.1l8.6-5.4c.4-.3.8-.1.5.2l-7.1 6.4-.3 3.3z"/></svg></a>
      </div>
      <a href="#zayavka" class="btn btn-w btn-sm" data-magnet><span class="btn-t">Бесплатный выезд</span></a>
      <button class="burger" id="burger" aria-label="Открыть меню" aria-expanded="false" aria-controls="mmenu"><span></span></button>
    </div>
  </div>
</header>
<nav class="mmenu" id="mmenu" aria-label="Мобильное меню">
  <div class="mm-group"><button class="mm-toggle" type="button" aria-expanded="false" aria-controls="mm-uslugi">Услуги<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m6 9 6 6 6-6" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/></svg></button><div class="mm-sub" id="mm-uslugi"><div><a href="../dezinfektsiya/">Дезинфекция для организаций</a><a href="../deratizatsiya/">Дератизация для организаций</a><a href="../dezinsektsiya/">Дезинсекция для организаций</a><a href="../sanitarnyy-audit/"><span>Санитарный аудит <span class="nw">(СЭС-аудит)</span></span></a><a href="../laboratornye-issledovaniya/">Лабораторные исследования</a><a href="../razrabotka-ppk/">Разработка ППК</a><a href="../normativnaya-baza/dokumenty-dlya-rospotrebnadzora/">Документы для Роспотребнадзора</a><a href="../ochistka-dezinfektsiya-ventilyatsii/">Очистка и дезинфекция вентиляции</a><a href="../dogovor-deratizatsiya-dezinsektsiya/">Договор на обслуживание</a><a href="../#podhod"><span class="nw">Пест-контроль</span> по системе IPM</a></div></div></div><div class="mm-group open" data-open><button class="mm-toggle" type="button" aria-expanded="true" aria-controls="mm-otrasli">Отрасли<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m6 9 6 6 6-6" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/></svg></button><div class="mm-sub" id="mm-otrasli"><div><a href="../pishchevoe-proizvodstvo/">Пищевые производства</a><a href="../magaziny-i-torgovye-seti/">Магазины и торговые сети</a><a href="../restorany-i-kafe/">Рестораны и кафе</a><a href="../sklady-i-logistika/">Склады и логистика</a><a href="../farmatsevticheskie-proizvodstva/">Фармацевтические производства</a><a href="./" aria-current="page">Гостиницы и отели</a><a href="../#otrasli">Все отрасли</a></div></div></div><a href="../dogovor-deratizatsiya-dezinsektsiya/">Договор <small>на дератизацию и дезинсекцию</small></a><a href="../#podhod">Метод IPM</a><a href="../#usloviya">Цена</a><div class="mm-group"><button class="mm-toggle" type="button" aria-expanded="false" aria-controls="mm-materialy">Материалы<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m6 9 6 6 6-6" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/></svg></button><div class="mm-sub" id="mm-materialy"><div><a href="../normativnaya-baza/">Нормативная база</a><a href="../normativnaya-baza/dokumenty-dlya-rospotrebnadzora/">Документы для Роспотребнадзора</a><a href="../materialy/programma-pest-kontrolya/"><span>Программа <span class="nw">пест-контроля</span></span></a><a href="../materialy/zhurnal-pest-kontrolya/"><span>Журнал <span class="nw">пест-контроля</span></span></a><a href="../materialy/pest-menedzhment-ili-razovaya-obrabotka/"><span><span class="nw">Пест-менеджмент</span> или разовая обработка</span></a><a href="../materialy/programma-proizvodstvennogo-kontrolya-haccp/">Программа производственного контроля по ХАССП</a><a href="../materialy/">Все материалы</a></div></div></div>
  <a href="#zayavka" class="btn btn-w btn-lg"><span class="btn-t">Заказать бесплатное обследование</span></a>
</nav>

<main id="main" tabindex="-1">
<section class="hero f-hero" id="hero">
  <div class="hero-media"><picture><source media="(max-width:760px)" srcset="../img/gost-hero-mob-760.webp 760w, ../img/gost-hero-mob.webp 1024w" sizes="100vw" width="1024" height="768"><img class="f-hero-img" src="../img/gost-hero.webp" srcset="../img/gost-hero-1440.webp 1440w, ../img/gost-hero.webp 1920w" sizes="100vw" width="1920" height="1072" alt="Специалист с фонарём проверяет шов матраса у изголовья кровати в гостиничном номере" fetchpriority="high" decoding="async"></picture><div class="fx-lit" aria-hidden="true"><picture><source media="(max-width:760px)" srcset="../img/gost-hero-mob-760.webp 760w, ../img/gost-hero-mob.webp 1024w" sizes="100vw" width="1024" height="768"><img class="f-hero-img fx-lit-img" src="../img/gost-hero.webp" srcset="../img/gost-hero-1440.webp 1440w, ../img/gost-hero.webp 1920w" sizes="100vw" width="1920" height="1072" alt="" decoding="async"></picture></div></div>
  <div class="wrap">
    <div class="hero-copy">
      <nav class="f-crumbs" aria-label="Навигационная цепочка" data-h><a href="../">Главная</a><span aria-hidden="true">→</span><span aria-current="page"><span class="nw">Пест-контроль</span> гостиниц и отелей</span></nav>
      <span class="badge" data-h><span class="dot"></span>Гостиницы, отели, хостелы · Москва и область</span>
      <h1><span class="ln"><span><span class="nw">Пест-контроль</span></span></span> <span class="ln"><span>гостиниц</span></span> <span class="ln"><span><em>и отелей</em></span></span></h1>
      <p class="lead" data-h>Постоянная защита номеров, ресторана и подвалов от клопов, тараканов и грызунов по системе IPM: осмотры не реже 2 раз в месяц, протокол на случай жалобы гостя и журнал для проверки Роспотребнадзора. Выезжаем без броской символики.</p>
      <div class="hero-ctas" data-h>
        <a href="#zayavka" class="btn btn-w btn-lg" data-magnet><span class="btn-t">Заказать бесплатное обследование</span></a>
        <a href="tel:+74951043570" class="btn btn-o btn-lg" data-magnet><span class="btn-t">+7 (495) 104-35-70</span></a>
      </div>
      <p class="f-urgent" data-h>Жалоба гостя на клопов — выезд в течение 3 часов, 24/7</p>
    </div>
  </div>
</section>

<div class="strip" role="group" aria-label="Коротко о пест-контроле гостиниц">
  <div class="strip-track" id="stripTrack">
    <div class="strip-set">
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-crosshair" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <circle cx="12" cy="12" r="10" /> <line x1="22" x2="18" y1="12" y2="12" /> <line x1="6" x2="2" y1="12" y2="12" /> <line x1="12" x2="12" y1="6" y2="2" /> <line x1="12" x2="12" y1="22" y2="18" /> </svg><b>IPM</b> для гостиниц и отелей</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-scan-search" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M3 7V5a2 2 0 0 1 2-2h2" /> <path d="M17 3h2a2 2 0 0 1 2 2v2" /> <path d="M21 17v2a2 2 0 0 1-2 2h-2" /> <path d="M7 21H5a2 2 0 0 1-2-2v-2" /> <circle cx="12" cy="12" r="3" /> <path d="m16 16-1.9-1.9" /> </svg><b>Бесплатное обследование</b> гостиницы</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-bed-double" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M2 20v-8a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v8" /> <path d="M4 10V6a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v4" /> <path d="M12 4v6" /> <path d="M2 18h20" /> </svg><b>Номер и соседние</b> — осмотр по сигналу</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-clock" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg><b>Выезд за 3 часа</b> 24/7</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-lock" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><rect width="18" height="11" x="3" y="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg><b>Без огласки</b> — конфиденциальный выезд</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-activity" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M22 12h-2.48a2 2 0 0 0-1.93 1.46l-2.35 8.36a.25.25 0 0 1-.48 0L9.24 2.18a.25.25 0 0 0-.48 0l-2.35 8.36A2 2 0 0 1 4.49 12H2" /> </svg><b>Осмотры</b> не реже 2 раз в месяц</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-notebook-pen" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M13.4 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-7.4" /> <path d="M2 6h4" /> <path d="M2 10h4" /> <path d="M2 14h4" /> <path d="M2 18h4" /> <path d="M21.378 5.626a1 1 0 1 0-3.004-3.004l-5.01 5.012a2 2 0 0 0-.506.854l-.837 2.87a.5.5 0 0 0 .62.62l2.87-.837a2 2 0 0 0 .854-.506z" /> </svg><b>Журнал и акты</b> по проверочному листу</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-ban" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="m4.9 4.9 14.2 14.2"/></svg><b>Без порошков</b> и ядов острого действия</div>
    </div>
    <div class="strip-set" aria-hidden="true">
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-crosshair" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <circle cx="12" cy="12" r="10" /> <line x1="22" x2="18" y1="12" y2="12" /> <line x1="6" x2="2" y1="12" y2="12" /> <line x1="12" x2="12" y1="6" y2="2" /> <line x1="12" x2="12" y1="22" y2="18" /> </svg><b>IPM</b> для гостиниц и отелей</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-scan-search" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M3 7V5a2 2 0 0 1 2-2h2" /> <path d="M17 3h2a2 2 0 0 1 2 2v2" /> <path d="M21 17v2a2 2 0 0 1-2 2h-2" /> <path d="M7 21H5a2 2 0 0 1-2-2v-2" /> <circle cx="12" cy="12" r="3" /> <path d="m16 16-1.9-1.9" /> </svg><b>Бесплатное обследование</b> гостиницы</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-bed-double" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M2 20v-8a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v8" /> <path d="M4 10V6a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v4" /> <path d="M12 4v6" /> <path d="M2 18h20" /> </svg><b>Номер и соседние</b> — осмотр по сигналу</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-clock" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg><b>Выезд за 3 часа</b> 24/7</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-lock" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><rect width="18" height="11" x="3" y="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg><b>Без огласки</b> — конфиденциальный выезд</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-activity" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M22 12h-2.48a2 2 0 0 0-1.93 1.46l-2.35 8.36a.25.25 0 0 1-.48 0L9.24 2.18a.25.25 0 0 0-.48 0l-2.35 8.36A2 2 0 0 1 4.49 12H2" /> </svg><b>Осмотры</b> не реже 2 раз в месяц</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-notebook-pen" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M13.4 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-7.4" /> <path d="M2 6h4" /> <path d="M2 10h4" /> <path d="M2 14h4" /> <path d="M2 18h4" /> <path d="M21.378 5.626a1 1 0 1 0-3.004-3.004l-5.01 5.012a2 2 0 0 0-.506.854l-.837 2.87a.5.5 0 0 0 .62.62l2.87-.837a2 2 0 0 0 .854-.506z" /> </svg><b>Журнал и акты</b> по проверочному листу</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-ban" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="m4.9 4.9 14.2 14.2"/></svg><b>Без порошков</b> и ядов острого действия</div>
    </div>
  </div>
</div>

<section class="f-checks" id="samoproverka" aria-labelledby="chk-t">
  <div class="wrap">
    <div class="panel f-check" data-fade>
      <div class="panel-scan" aria-hidden="true"></div>
      <div class="f-check-in">
        <div class="f-check-l">
          <h2 id="chk-t" class="f-check-t" data-split>Готова ли гостиница <em>к жалобе гостя</em></h2>
          <p class="f-check-res"><b id="chk-n">0</b> из 5</p>
          <p class="f-check-note" id="chk-note" aria-live="polite"><span class="nw">Чего-то</span> не хватает — на бесплатном обследовании покажем, что добавить и в каком порядке.</p>
          <a href="#zayavka" class="btn btn-w btn-lg"><span class="btn-t">Заказать бесплатное обследование</span></a>
        </div>
        <ul class="f-check-list">
          <li><label><input type="checkbox"><span>Горничные знают признаки клопов и кому сообщать о находке</span></label></li>
          <li><label><input type="checkbox"><span>Номер с сигналом сразу снимают с продажи</span></label></li>
          <li><label><input type="checkbox"><span>Номерной фонд осматривают по графику, а не только после жалоб</span></label></li>
          <li><label><input type="checkbox"><span>Кухня, склад, подвал и мусорокамера — на схеме точек контроля</span></label></li>
          <li><label><input type="checkbox"><span>Журнал обследований заполняется не реже 2 раз в месяц</span></label></li>
        </ul>
      </div>
    </div>
  </div>
</section>

<section class="s" id="trebovaniya">
  <div class="wrap">
    <div class="head"><div class="eyebrow" data-eyebrow>Требования 2026</div><h2 data-split>Что проверит Роспотребнадзор <em>в гостинице</em></h2></div>
    <p class="g-short" data-fade><b>Коротко.</b> Гостиница — объект особого эпидемиологического значения (п. 98 <a href="http://pravo.gov.ru/proxy/ips/?docbody=&amp;nd=602107773" target="_blank" rel="noopener">СанПиН 3.3686-21</a>). Обследования на насекомых — не реже 2 раз в месяц, оценка заселённости грызунами — каждый месяц, мусоросборные камеры — не реже раза в месяц. С 1 сентября 2026 года действуют санитарные правила <a href="http://publication.pravo.gov.ru/document/0001202606020088" target="_blank" rel="noopener">СП 2.1.4284-26</a>: насекомых, грызунов и следов их жизнедеятельности в помещениях быть не должно, а обработки проводят без гостей и персонала.<span class="g-upd">Актуально на ноябрь 2026 года</span></p>
    <div class="d-cards f-req" data-group="cards">
      <article class="d-card"><p class="f-num">2 раза в месяц</p><p>Плановые обследования на насекомых: клопы, тараканы, муравьи, мухи (пп. 98, 101 СанПиН 3.3686-21).</p></article>
      <article class="d-card"><p class="f-num">Каждый месяц</p><p>Оценка заселённости грызунами, по её итогам — дератизация гостиницы (пп. 108, 110). Мусоросборные камеры — отдельный осмотр (п. 133).</p></article>
      <article class="d-card"><p class="f-num">Без гостей</p><p>Выборочную дезинсекцию проводят в номерах, где нашли насекомых, в отсутствие людей, затем — влажная уборка и проветривание (п. 127). Родентициды острого действия и порошковые приманки в гостиницах запрещены.</p></article>
    </div>
    <h3 class="g-check-h" data-fade>Проверочный лист: <em>шесть вопросов о вредителях</em></h3>
    <p class="g-check-src" data-fade>Вопросы из проверочного листа при предоставлении гостиничных услуг — приложение № 2 к приказу Роспотребнадзора от 20.07.2026 № 578, применяется с 4 октября 2026 года (<a href="https://base.garant.ru/414956074/f7ee959fd36b5699076b35abf4f52c5c/" target="_blank" rel="noopener">текст на «Гаранте»</a>). Справа — что делаем мы, чтобы на каждый вопрос был ответ «да».</p>
    <table class="d-table g-ql" data-fade>
      <thead><tr><th scope="col">Вопрос</th><th scope="col">Что проверяют</th><th scope="col">Как закрываем</th></tr></thead>
      <tbody>
        <tr><td data-l="Вопрос"><span class="g-qn">№ 28</span></td><td data-l="Что проверяют">Уборка, дезинсекция и дератизация контейнерной площадки<small>п. 8 и приложение 1 СанПиН 2.1.3684-21</small></td><td data-l="Как закрываем">Площадка — в периметре дератизации: станции и осмотр при каждом визите.</td></tr>
        <tr><td data-l="Вопрос"><span class="g-qn">№ 39</span></td><td data-l="Что проверяют">В помещениях нет насекомых, грызунов и следов их жизнедеятельности<small>п. 14 СП 2.1.4284-26</small></td><td data-l="Как закрываем">Плановые осмотры номеров и служебных зон, точки контроля, устранение очагов.</td></tr>
        <tr><td data-l="Вопрос"><span class="g-qn">№ 40</span></td><td data-l="Что проверяют">Дезинсекцию и дератизацию проводит организация, осуществляющая дезинфекционную деятельность, в отсутствие работников и гостей<small>п. 14 СП 2.1.4284-26, п. 130 СанПиН 3.3686-21</small></td><td data-l="Как закрываем">Договор с лицензированной организацией; обработки — в свободных номерах и в согласованные окна.</td></tr>
        <tr><td data-l="Вопрос"><span class="g-qn">№ 41</span></td><td data-l="Что проверяют">Кратность плановых обследований на членистоногих<small>пп. 88, 98, 101, 130 СанПиН 3.3686-21</small></td><td data-l="Как закрываем">Визиты не реже 2 раз в месяц, каждая находка — в журнале.</td></tr>
        <tr><td data-l="Вопрос"><span class="g-qn">№ 42</span></td><td data-l="Что проверяют">Ежемесячная оценка заселённости грызунами<small>пп. 88, 98, 108, 110, 130 СанПиН 3.3686-21</small></td><td data-l="Как закрываем">Оценка по точкам контроля каждый месяц, итог — в отчёте.</td></tr>
        <tr><td data-l="Вопрос"><span class="g-qn">№ 43</span></td><td data-l="Что проверяют">Обследование систем мусороудаления и мусоросборных камер не реже раза в месяц<small>п. 133 СанПиН 3.3686-21</small></td><td data-l="Как закрываем">Мусорокамера — отдельная точка в схеме и строка в журнале.</td></tr>
      </tbody>
    </table>
    <p class="g-note" data-fade>Какими документами ответить на эти вопросы и что спросят на других объектах — в разборе <a href="../normativnaya-baza/proverochnye-listy/#dokumenty">«Проверочные листы Роспотребнадзора 2026»</a>.</p>
  </div>
</section>

<section class="s" id="zony">
  <div class="wrap">
    <div class="head"><div class="eyebrow" data-eyebrow>Зоны риска</div><h2 data-split>Где в гостинице <em>заводятся вредители</em></h2></div>
    <div class="f-zmap">
      <figure class="card f-plan" data-fade>
<svg viewBox="0 0 960 600" role="img" aria-labelledby="plan-t plan-d">
  <title id="plan-t">Разрез гостиницы: шесть зон риска, точки контроля и путь белья из номера</title>
  <desc id="plan-d">Номерной фонд на трёх этажах, лобби, ресторан и кухня на первом этаже, в подвале бельевая, склад и мусорокамера; снаружи контейнерная площадка и кровля. Номер с сигналом и соседние номера слева, справа, сверху и снизу выделены.</desc>
  <defs><marker id="g-arw" viewBox="0 0 10 10" refX="7" refY="5" markerWidth="8" markerHeight="8" orient="auto"><path d="M0 0L10 5L0 10z" fill="#7c86ff"/></marker></defs>
  <g class="z z6" data-z="6"><rect class="zf" x="8" y="8" width="944" height="584" rx="22" stroke="rgba(255,255,255,.2)" stroke-width="1.5" stroke-dasharray="7 9"/></g>
  <rect x="36" y="424" width="888" height="128" fill="rgba(255,255,255,.018)"/>
  <path d="M36 424H924" stroke="rgba(255,255,255,.32)" stroke-width="2"/>
  <rect x="150" y="104" width="640" height="400" rx="4" fill="#0d0d10"/>
  <g class="z" data-z="1"><rect class="zf" x="150" y="104" width="640" height="240"/></g>
  <g class="z" data-z="3"><rect class="zf" x="470" y="344" width="320" height="80"/></g>
  <g class="z" data-z="2"><rect class="zf" x="150" y="424" width="200" height="80"/></g>
  <g class="z" data-z="4"><rect class="zf" x="350" y="424" width="200" height="80"/></g>
  <g class="z" data-z="5"><rect class="zf" x="550" y="424" width="240" height="80"/></g>
  <rect class="g-adj" x="283" y="189" width="118" height="70" rx="5"/>
  <rect class="g-adj" x="539" y="189" width="118" height="70" rx="5"/>
  <rect class="g-adj" x="411" y="109" width="118" height="70" rx="5"/>
  <rect class="g-adj" x="411" y="269" width="118" height="70" rx="5"/>
  <rect class="g-hot" x="411" y="189" width="118" height="70" rx="5"/>
  <g fill="none" stroke="rgba(255,255,255,.26)" stroke-width="2.5" stroke-linecap="round">
    <path d="M150 104H790V504H150Z"/>
    <path d="M150 184H790M150 264H790M150 344H790M150 424H790"/>
    <path d="M278 104V344 M406 104V344 M534 104V344 M662 104V344 M470 344V424 M350 424V504 M550 424V504"/>
  </g>
  <path d="M140 104H800" stroke="rgba(255,255,255,.42)" stroke-width="4" stroke-linecap="round"/>
  <g fill="rgba(255,255,255,.04)" stroke="rgba(255,255,255,.16)" stroke-width="1.5"><rect x="574" y="78" width="60" height="26" rx="3"/><path d="M586 78V104M598 78V104M610 78V104M622 78V104"/></g>
  <g fill="rgba(255,255,255,.05)" stroke="rgba(255,255,255,.2)" stroke-width="1.4"><rect x="194" y="160" width="62" height="13" rx="3"/><rect x="256" y="142" width="6" height="31" rx="2"/><rect x="242" y="153" width="12" height="7" rx="2"/><rect x="322" y="160" width="62" height="13" rx="3"/><rect x="384" y="142" width="6" height="31" rx="2"/><rect x="370" y="153" width="12" height="7" rx="2"/><rect x="450" y="160" width="62" height="13" rx="3"/><rect x="512" y="142" width="6" height="31" rx="2"/><rect x="498" y="153" width="12" height="7" rx="2"/><rect x="578" y="160" width="62" height="13" rx="3"/><rect x="640" y="142" width="6" height="31" rx="2"/><rect x="626" y="153" width="12" height="7" rx="2"/><rect x="706" y="160" width="62" height="13" rx="3"/><rect x="768" y="142" width="6" height="31" rx="2"/><rect x="754" y="153" width="12" height="7" rx="2"/><rect x="194" y="240" width="62" height="13" rx="3"/><rect x="256" y="222" width="6" height="31" rx="2"/><rect x="242" y="233" width="12" height="7" rx="2"/><rect x="322" y="240" width="62" height="13" rx="3"/><rect x="384" y="222" width="6" height="31" rx="2"/><rect x="370" y="233" width="12" height="7" rx="2"/><rect x="450" y="240" width="62" height="13" rx="3"/><rect x="512" y="222" width="6" height="31" rx="2"/><rect x="498" y="233" width="12" height="7" rx="2"/><rect x="578" y="240" width="62" height="13" rx="3"/><rect x="640" y="222" width="6" height="31" rx="2"/><rect x="626" y="233" width="12" height="7" rx="2"/><rect x="706" y="240" width="62" height="13" rx="3"/><rect x="768" y="222" width="6" height="31" rx="2"/><rect x="754" y="233" width="12" height="7" rx="2"/><rect x="194" y="320" width="62" height="13" rx="3"/><rect x="256" y="302" width="6" height="31" rx="2"/><rect x="242" y="313" width="12" height="7" rx="2"/><rect x="322" y="320" width="62" height="13" rx="3"/><rect x="384" y="302" width="6" height="31" rx="2"/><rect x="370" y="313" width="12" height="7" rx="2"/><rect x="450" y="320" width="62" height="13" rx="3"/><rect x="512" y="302" width="6" height="31" rx="2"/><rect x="498" y="313" width="12" height="7" rx="2"/><rect x="578" y="320" width="62" height="13" rx="3"/><rect x="640" y="302" width="6" height="31" rx="2"/><rect x="626" y="313" width="12" height="7" rx="2"/><rect x="706" y="320" width="62" height="13" rx="3"/><rect x="768" y="302" width="6" height="31" rx="2"/><rect x="754" y="313" width="12" height="7" rx="2"/></g>
  <g fill="rgba(255,255,255,.04)" stroke="rgba(255,255,255,.16)" stroke-width="1.5">
    <rect x="226" y="392" width="92" height="22" rx="4"/><rect x="352" y="372" width="34" height="42" rx="4"/><rect x="396" y="372" width="34" height="42" rx="4"/>
    <circle cx="524" cy="404" r="11"/><circle cx="566" cy="404" r="11"/><circle cx="608" cy="404" r="11"/>
    <rect x="660" y="384" width="54" height="30" rx="4"/><rect x="722" y="384" width="54" height="30" rx="4"/><rect x="674" y="352" width="66" height="12" rx="4"/>
  </g>
  <g fill="rgba(255,255,255,.04)" stroke="rgba(255,255,255,.16)" stroke-width="1.5">
    <rect x="230" y="466" width="30" height="30" rx="4"/><rect x="268" y="466" width="30" height="30" rx="4"/><rect x="306" y="466" width="30" height="30" rx="4"/>
    <circle cx="245" cy="481" r="8"/><circle cx="283" cy="481" r="8"/><circle cx="321" cy="481" r="8"/>
    <rect x="418" y="466" width="54" height="30" rx="3"/><rect x="480" y="466" width="54" height="30" rx="3"/><path d="M418 481H472M480 481H534"/>
    <rect x="618" y="468" width="34" height="28" rx="3"/><rect x="658" y="468" width="34" height="28" rx="3"/><path d="M752 434V496M766 434V496"/>
  </g>
  <g fill="rgba(255,255,255,.04)" stroke="rgba(255,255,255,.22)" stroke-width="1.5"><rect x="842" y="396" width="34" height="28" rx="3"/><rect x="882" y="396" width="34" height="28" rx="3"/><path d="M840 396H878M880 396H918"/></g>
  <g fill="rgba(255,255,255,.34)"><path d="M690 90c4-6 12-7 16-2l7-3-3 6c2 4 0 7-5 7h-10c-4 0-6-3-5-8z"/><path d="M728 88c4-6 12-7 16-2l7-3-3 6c2 4 0 7-5 7h-10c-4 0-6-3-5-8z"/><path d="M764 91c4-6 12-7 16-2l7-3-3 6c2 4 0 7-5 7h-10c-4 0-6-3-5-8z"/></g>
  <path d="M454 214H166V488H210" fill="none" stroke="#7c86ff" stroke-width="2.5" stroke-dasharray="9 8" marker-end="url(#g-arw)" opacity=".85"/>
  <g fill="#fdc700" stroke="#09090b" stroke-width="2"><rect x="60" y="408" width="13" height="13" rx="2"/><rect x="116" y="408" width="13" height="13" rx="2"/><rect x="804" y="408" width="13" height="13" rx="2"/><rect x="924" y="408" width="13" height="13" rx="2"/><rect x="60" y="516" width="13" height="13" rx="2"/><rect x="924" y="516" width="13" height="13" rx="2"/></g>
  <g fill="#7c86ff"><circle cx="486" cy="414" r="6"/><circle cx="776" cy="414" r="6"/><circle cx="340" cy="492" r="6"/><circle cx="366" cy="492" r="6"/><circle cx="540" cy="492" r="6"/><circle cx="566" cy="492" r="6"/><circle cx="776" cy="492" r="6"/></g>
  <g fill="#c4b5fd"><rect x="752" y="354" width="22" height="8" rx="4"/></g>
  <g class="lbl"><text x="208" y="136">Номера</text><text x="184" y="368">Лобби</text><text x="540" y="370">Ресторан и кухня</text><text x="230" y="455">Бельевая</text><text x="418" y="455">Склад</text><text x="618" y="455">Мусорокамера</text><text x="200" y="94">Кровля</text><text x="830" y="386">Контейнеры</text><text x="40" y="578">Территория</text></g>
  <g class="bdgs">
    <g class="bdg" data-z="1"><circle cx="182" cy="132" r="22"/><text x="182" y="133">1</text></g>
    <g class="bdg" data-z="2"><circle cx="198" cy="450" r="22"/><text x="198" y="451">2</text></g>
    <g class="bdg" data-z="3"><circle cx="504" cy="368" r="22"/><text x="504" y="369">3</text></g>
    <g class="bdg" data-z="4"><circle cx="386" cy="450" r="22"/><text x="386" y="451">4</text></g>
    <g class="bdg" data-z="5"><circle cx="586" cy="450" r="22"/><text x="586" y="451">5</text></g>
    <g class="bdg" data-z="6"><circle cx="50" cy="50" r="22"/><text x="50" y="51">6</text></g>
  </g>
</svg>
        <figcaption class="f-legend"><span><i class="lg-hot"></i>Номер с сигналом</span><span><i class="lg-adj"></i>Соседние номера — осмотр</span><span><i class="lg-st"></i>Станция с приманкой — снаружи</span><span><i class="lg-tr"></i>Ловушка без яда — внутри</span><span><i class="lg-uv"></i>Световая ловушка</span><span><i class="lg-fl"></i>Путь белья в прачечную</span></figcaption>
      </figure>
      <ol class="f-zlist" data-group="steps">
        <li data-z="1" tabindex="0"><b>Номерной фонд</b><span>Клопы приезжают с багажом гостей и расходятся в соседние номера — слева, справа, сверху и снизу.</span></li>
        <li data-z="2" tabindex="0"><b>Бельевая и прачечная</b><span>Бельё из номера с сигналом — в закрытом мешке и отдельно от чистого, иначе клопы разъедутся по этажам.</span></li>
        <li data-z="3" tabindex="0"><b>Ресторан, кухня и бар</b><span>Тараканы у тёплого оборудования, мухи, мыши. Требования — как к общепиту.</span></li>
        <li data-z="4" tabindex="0"><b>Склад и приёмка продуктов</b><span>Грызуны и насекомые заходят с поставками, моль — в сухих продуктах.</span></li>
        <li data-z="5" tabindex="0"><b>Подвал и мусорокамера</b><span>Крысы, мыши, тараканы. Мусоросборную камеру обследуем не реже раза в месяц.</span></li>
        <li data-z="6" tabindex="0"><b>Территория и кровля</b><span>Контейнерная площадка, норы у фундамента, птицы на кровле и козырьках.</span></li>
      </ol>
    </div>
  </div>
</section>

<section class="s" id="zhaloba">
  <div class="wrap">
    <div class="head"><div class="eyebrow" data-eyebrow>Протокол</div><h2 data-split>Гость нашёл клопов: <em>что делать администрации</em></h2><p class="sub" data-fade>Клопы в гостинице — не повод закрывать этаж. Шесть шагов от звонка с ресепшена до записи в журнале: первый шаг делает гостиница, дальше работаем мы вместе с хаусхипингом.</p></div>
    <div class="g-proto">
      <div class="g-proto-side" data-fade>
        <figure class="g-photo"><img src="../img/ind-hotel-room.webp" srcset="../img/ind-hotel-room-480.webp 480w, ../img/ind-hotel-room-720.webp 720w, ../img/ind-hotel-room.webp 900w" sizes="(max-width:1100px) calc(100vw - 40px), 40vw" width="900" height="542" loading="lazy" decoding="async" alt="Специалист с фонарём осматривает шов матраса в гостиничном номере"></figure>
        <div class="card g-risk">
          <h3>Почему счёт идёт на часы</h3>
          <p>Роспотребнадзор советует гостям при заселении искать насекомых и следы их жизнедеятельности. Если номер не в порядке, гость вправе потребовать другой номер, уменьшения цены или отказаться от договора с полным возмещением убытков, а при отказе — обратиться в Роспотребнадзор (<a href="https://04.rospotrebnadzor.ru/index.php/consumer-information/faq/20732-27072026.html" target="_blank" rel="noopener">памятка ведомства</a>).</p>
        </div>
      </div>
      <ol class="g-steps" data-group="steps">
        <li class="g-alert"><div class="g-meta"><span class="g-when">Сразу</span><span class="g-who">Администратор</span></div><h3>Переселить гостя и закрыть номер</h3><p>Новый номер — на другом этаже, не по соседству. Номер с сигналом снять с продажи, бельё — в закрытый мешок и сразу в прачечную, мебель из номера не выносить.</p></li>
        <li><div class="g-meta"><span class="g-when">До 3 часов</span><span class="g-who">Специалист</span></div><h3>Осмотреть номер и соседние</h3><p>Номер с сигналом и соседние — слева, справа, сверху и снизу. Ищем клопов, яйца, сброшенные шкурки и тёмные точки: швы матраса, каркас и изголовье кровати, плинтусы, рамы картин, розетки.</p></li>
        <li><div class="g-meta"><span class="g-when">В тот же день</span><span class="g-who">Специалист</span></div><h3>Обработать очаг без гостей</h3><p>Выборочная дезинсекция номеров, где нашли клопов, — в отсутствие людей (п. 127 СанПиН 3.3686-21): швы мебели, плинтусы, проходки коммуникаций. Если находки в нескольких номерах подряд — обрабатываем блок по этажам и стояку.</p></li>
        <li><div class="g-meta"><span class="g-when">После обработки</span><span class="g-who">Хаусхипинг</span></div><h3>Проветрить, убрать, вернуть в продажу</h3><p>Проветривание по инструкции к средству и влажная уборка. Когда номер можно продавать снова, называем до начала работ.</p></li>
        <li><div class="g-meta"><span class="g-when">Через 10–14 дней</span><span class="g-who">Специалист</span></div><h3>Контрольный осмотр</h3><p>Часть средств не действует на яйца клопов, поэтому без контроля очаг возвращается (<a href="https://cgon.rospotrebnadzor.ru/naseleniyu/infektsionnye-i-parazitarnye-zabolevaniya/chto-eshche-nuzhno-znat/postelnye-klopy/" target="_blank" rel="noopener">ЦГОН Роспотребнадзора</a>). Нашли живых — повторная обработка.</p></li>
        <li><div class="g-meta"><span class="g-when">По итогам</span><span class="g-who">Документы</span></div><h3>Акт и запись в журнале</h3><p>Где нашли, что и чем обработали, результат контроля. Если гость обратится в Роспотребнадзор, у гостиницы будут документы о принятых мерах.</p></li>
      </ol>
    </div>
  </div>
</section>

<section class="s" id="gornichnye">
  <div class="wrap">
    <div class="head"><div class="eyebrow" data-eyebrow>Персонал</div><h2 data-split>Горничная заметит клопов <em>раньше гостя</em></h2></div>
    <div class="g-train" data-fade>
      <figure class="g-photo g-photo-43"><img src="../img/gost-gornichnaya.webp" srcset="../img/gost-gornichnaya-720.webp 720w, ../img/gost-gornichnaya.webp 1200w" sizes="(max-width:1100px) calc(100vw - 40px), 45vw" width="1200" height="896" loading="lazy" decoding="async" alt="Специалист показывает горничной, где в шве матраса искать следы клопов"></figure>
      <div>
        <p class="d-strong">Профилактика клопов в гостинице держится на горничных: они бывают в каждом номере каждый день. Инструктаж проводим на объекте, на настоящей кровати: где искать и что делать, чтобы не разнести клопов по этажу.</p>
        <h3 class="g-sub">Пять признаков, которые проверяют при уборке</h3>
        <ol class="g-signs">
          <li><span><b>Тёмные точки</b> — следы клопов в швах матраса, на каркасе и изголовье кровати.</span></li>
          <li><span><b>Пятна крови</b> — мелкие, на простыне и наволочке.</span></li>
          <li><span><b>Шкурки и яйца</b> — сброшенные шкурки личинок и белые яйца в складках и стыках мебели.</span></li>
          <li><span><b>Живые клопы</b> — за изголовьем и плинтусом, под рамами картин, в розетках.</span></li>
          <li><span><b>Укусы цепочкой</b> — гость жалуется на зудящие следы после ночи.</span></li>
        </ol>
        <div class="card g-do"><h3>Если нашли признаки</h3><p>Не стряхивать бельё и не класть его в общую тележку — сразу в мешок. Закрыть номер, сфотографировать находку и сообщить старшей горничной или администратору.</p></div>
      </div>
    </div>
  </div>
</section>

<section class="s" id="mesyac">
  <div class="wrap">
    <div class="head"><div class="eyebrow" data-eyebrow>Регламент</div><h2 data-split>Как выглядит <em>месяц обслуживания</em></h2></div>
    <ol class="d-steps f-steps4" data-group="steps">
      <li><b>Визит 1</b><span>Номера по графику ротации и все номера с сигналами от горничных; точки контроля на кухне, складе и в подвале; записи в журнале.</span></li>
      <li><b>Визит 2</b><span>Повторный осмотр, проверка выполненных замечаний, мусорокамера и контейнерная площадка, замена клеевых пластин.</span></li>
      <li><b>Конец месяца</b><span>Оценка по грызунам и отчёт: номера под наблюдением, находки по зонам, задачи инженерной службе и хаусхипингу.</span></li>
      <li class="f-alert"><b>По сигналу</b><span>Внеплановый выезд по жалобе гостя или сообщению горничной — в течение 3 часов, 24/7.</span></li>
    </ol>
    <p class="d-note" data-fade>Перед стартом: бесплатное обследование → программа и схема точек → график осмотра номерного фонда → инструктаж горничных. Для больших отелей с рестораном и банкетами частоту визитов увеличиваем в программе.</p>
  </div>
</section>

<section class="s" id="bez-oglaski">
  <div class="wrap">
    <div class="head"><div class="eyebrow" data-eyebrow>Без огласки</div><h2 data-split>Работаем так, <em>чтобы гости не заметили</em></h2></div>
    <div class="g-quiet" data-group="cards">
      <article class="d-card"><span class="g-ic" aria-hidden="true"><svg aria-hidden="true" focusable="false" class="lucide lucide-eye-off" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M10.733 5.076a10.744 10.744 0 0 1 11.205 6.575 1 1 0 0 1 0 .696 10.747 10.747 0 0 1-1.444 2.49"/><path d="M14.084 14.158a3 3 0 0 1-4.242-4.242"/><path d="M17.479 17.499a10.75 10.75 0 0 1-15.417-5.151 1 1 0 0 1 0-.696 10.75 10.75 0 0 1 4.446-5.143"/><path d="m2 2 20 20"/></svg></span><h3>Конфиденциальный выезд</h3><p>Без броской символики. Приезжаем к служебному входу в согласованное с администратором время.</p></article>
      <article class="d-card"><span class="g-ic" aria-hidden="true"><svg aria-hidden="true" focusable="false" class="lucide lucide-moon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3a6 6 0 0 0 9 9 9 9 0 1 1-9-9Z"/></svg></span><h3>Ночь и выходные — без наценки</h3><p>Работы ставим под загрузку отеля: в свободные номера и в окна, согласованные с хаусхипингом.</p></article>
      <article class="d-card"><span class="g-ic" aria-hidden="true"><svg aria-hidden="true" focusable="false" class="lucide lucide-door-closed" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M18 20V6a2 2 0 0 0-2-2H8a2 2 0 0 0-2 2v14"/><path d="M2 20h20"/><path d="M14 12v.01"/></svg></span><h3>Только без людей</h3><p>Дезинсекцию и дератизацию проводим в отсутствие гостей и персонала — так требует п. 14 СП 2.1.4284-26.</p></article>
      <article class="d-card"><span class="g-ic" aria-hidden="true"><svg aria-hidden="true" focusable="false" class="lucide lucide-shield-check" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z"/><path d="m9 12 2 2 4-4"/></svg></span><h3>Без порошков и ядов острого действия</h3><p>В гостиницах они запрещены (п. 127 СанПиН 3.3686-21). Приманки — в закрытых станциях, вне доступа гостей и детей.</p></article>
    </div>
  </div>
</section>

<section class="s pests-s" id="vrediteli">
  <div class="pests-bg f-lazy" aria-hidden="true"></div>
  <div class="wrap">
    <div class="head"><div class="eyebrow" data-eyebrow>Вредители</div><h2 data-split>Кого контролируем <em>в гостинице</em></h2></div>
    <div class="pests" data-group="pests">
      <article class="card pest"><div class="pest-img"><img width="240" height="240" decoding="async" loading="lazy" src="../img/p-bedbug-macro.webp" alt="Постельный клоп"><i class="scan" aria-hidden="true"></i></div><div class="pest-b"><div class="pest-t"><h3>Постельные клопы</h3><span class="lvl z">Зоны 1 · 2</span></div><p>Приезжают с багажом гостей. Осмотр номера и соседних, выборочная дезинсекция, контроль через 10–14 дней.</p></div></article>
      <article class="card pest"><div class="pest-img"><img width="240" height="240" decoding="async" loading="lazy" src="../img/p-cockroach.webp" alt="Рыжий таракан"><i class="scan" aria-hidden="true"></i></div><div class="pest-b"><div class="pest-t"><h3>Тараканы</h3><span class="lvl z">Зоны 3 · 5</span></div><p>Кухня, бар, <span class="nw">мини-кухни</span> апартаментов, подвал. Гели и ловушки — в санитарное окно ресторана.</p></div></article>
      <article class="card pest"><div class="pest-img"><img width="240" height="240" decoding="async" loading="lazy" src="../img/p-rat.webp" alt="Серая крыса"><i class="scan" aria-hidden="true"></i></div><div class="pest-b"><div class="pest-t"><h3>Крысы и мыши</h3><span class="lvl z">Зоны 4 · 5 · 6</span></div><p>Подвал, склад, мусорокамера, контейнерная площадка. Станции снаружи, ловушки без яда внутри.</p></div></article>
      <article class="card pest"><div class="pest-img"><img width="240" height="240" decoding="async" loading="lazy" src="../img/p-fly.webp" alt="Комнатная муха"><i class="scan" aria-hidden="true"></i></div><div class="pest-b"><div class="pest-t"><h3>Мухи</h3><span class="lvl z">Зоны 3 · 6</span></div><p>Ресторан, зона завтраков, контейнеры. Световые ловушки на кухне, контроль отходов.</p></div></article>
      <article class="card pest"><div class="pest-img"><img width="240" height="240" decoding="async" loading="lazy" src="../img/p-ant.webp" alt="Фараонов муравей"><i class="scan" aria-hidden="true"></i></div><div class="pest-b"><div class="pest-t"><h3>Муравьи</h3><span class="lvl z">Зоны 1 · 3</span></div><p>Тёплые стены, кухня, номера с <span class="nw">мини-барами</span>. Приманки — вне доступа гостей.</p></div></article>
      <article class="card pest"><div class="pest-img"><img width="240" height="240" decoding="async" loading="lazy" src="../img/p-pigeon.webp" alt="Голубь"><i class="scan" aria-hidden="true"></i></div><div class="pest-b"><div class="pest-t"><h3>Птицы</h3><span class="lvl z">Зона 6</span></div><p>Кровля, козырьки, террасы: закрытие проёмов и противоприсадочные системы.</p></div></article>
    </div>
  </div>
</section>

<section class="s" id="formaty">
  <div class="wrap">
    <div class="head"><div class="eyebrow" data-eyebrow>Форматы</div><h2 data-split>Подстраиваем программу <em>под формат гостиницы</em></h2></div>
    <div class="inds g-inds" data-group="inds">
      <article class="card ind" data-tilt><div class="ind-img"><img width="900" height="542" decoding="async" loading="lazy" src="../img/gost-gorodskoy.webp" srcset="../img/gost-gorodskoy-720.webp 720w, ../img/gost-gorodskoy.webp 900w" sizes="(max-width:760px) calc(100vw - 40px), 50vw" alt="Специалист проверяет станцию контроля грызунов в служебном коридоре у кухни отеля" data-parallax></div><div class="ind-b"><h3><span>Городские и <span class="nw">бизнес-отели</span></span></h3><p>Сотни номеров, ресторан, банкеты и подвалы: отдельные графики для номерного фонда и для кухни.</p></div></article>
      <article class="card ind" data-tilt><div class="ind-img"><img width="900" height="542" decoding="async" loading="lazy" src="../img/gost-apart.webp" srcset="../img/gost-apart-720.webp 720w, ../img/gost-apart.webp 900w" sizes="(max-width:760px) calc(100vw - 40px), 50vw" alt="Специалист с фонарём осматривает пространство под кухонным гарнитуром в студии апарт-отеля" data-parallax></div><div class="ind-b"><h3><span><span class="nw">Апарт-отели</span></span></h3><p>Кухни в номерах: тараканы и муравьи наравне с клопами. Осматриваем и спальную зону, и кухонный блок.</p></div></article>
      <article class="card ind" data-tilt><div class="ind-img"><img width="900" height="542" decoding="async" loading="lazy" src="../img/gost-hostel.webp" srcset="../img/gost-hostel-720.webp 720w, ../img/gost-hostel.webp 900w" sizes="(max-width:760px) calc(100vw - 40px), 50vw" alt="Специалист проверяет шов матраса на двухъярусной кровати в хостеле" data-parallax></div><div class="ind-b"><h3><span>Хостелы и <span class="nw">мини-отели</span></span></h3><p>Двухъярусные кровати и частая смена гостей: спальные места осматриваем при каждом визите.</p></div></article>
      <article class="card ind" data-tilt><div class="ind-img"><img width="900" height="542" decoding="async" loading="lazy" src="../img/gost-zagorodny.webp" srcset="../img/gost-zagorodny-720.webp 720w, ../img/gost-zagorodny.webp 900w" sizes="(max-width:760px) calc(100vw - 40px), 50vw" alt="Специалист обходит фасад загородного отеля и проверяет станцию с приманкой у фундамента" data-parallax></div><div class="ind-b"><h3>Загородные отели и базы отдыха</h3><p>Большая территория и отдельные корпуса: периметр от грызунов, осмотры корпусов, кухни и прачечной.</p></div></article>
    </div>
  </div>
</section>

<section class="s" id="dokumenty">
  <div class="wrap">
    <div class="head"><div class="eyebrow" data-eyebrow>Документы</div><h2 data-split>Документы для проверки <em>и для собственника</em></h2></div>
    <table class="d-table" data-fade>
      <thead><tr><th scope="col">Документ</th><th scope="col">Кому нужен</th></tr></thead>
      <tbody>
        <tr><td data-l="Документ">Договор с лицензированной организацией</td><td data-l="Кому нужен">Роспотребнадзор — вопрос № 40 проверочного листа</td></tr>
        <tr><td data-l="Документ">Программа <span class="nw">пест-контроля</span> гостиницы</td><td data-l="Кому нужен">Собственник, управляющая компания, сеть</td></tr>
        <tr><td data-l="Документ">Схема точек контроля с номерами</td><td data-l="Кому нужен">Роспотребнадзор, инженерная служба</td></tr>
        <tr><td data-l="Документ">Журнал обследований и учёта численности</td><td data-l="Кому нужен">Роспотребнадзор — вопросы № 41–43</td></tr>
        <tr><td data-l="Документ">График осмотра номерного фонда</td><td data-l="Кому нужен">Хаусхипинг, генеральный менеджер</td></tr>
        <tr><td data-l="Документ">Акты выполненных работ</td><td data-l="Кому нужен">Бухгалтерия, Роспотребнадзор</td></tr>
        <tr><td data-l="Документ">Перечень средств с СГР и инструкциями</td><td data-l="Кому нужен">Охрана труда, Роспотребнадзор</td></tr>
        <tr><td data-l="Документ">Ежемесячный отчёт</td><td data-l="Кому нужен">Генеральный менеджер, собственник</td></tr>
        <tr><td data-l="Документ">Лицензия и удостоверения специалистов</td><td data-l="Кому нужен">Все проверяющие</td></tr>
      </tbody>
    </table>
    <p class="g-note" data-fade>Образцы — в материалах: <a href="../materialy/programma-pest-kontrolya/">программа <span class="nw">пест-контроля</span></a> и <a href="../materialy/zhurnal-pest-kontrolya/">журнал <span class="nw">пест-контроля</span></a>.</p>
    <nav class="more" data-more="dok" aria-label="Для проверки" data-fade><span class="more-k">Для проверки</span><a href="../normativnaya-baza/dokumenty-dlya-rospotrebnadzora/?obekt=gostinitsy"><span>Полный перечень документов для Роспотребнадзора</span><svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a></nav>
  </div>
</section>

<section class="s" id="stoimost">
  <div class="wrap">
    <div class="head"><div class="eyebrow" data-eyebrow>Стоимость</div><h2 data-split>Сколько стоит <em><span class="nw">пест-контроль</span> гостиницы</em></h2></div>
    <div class="d-two">
      <div>
        <p class="d-strong f-mb" data-fade>Цена зависит от:</p>
        <ul class="d-ticks" data-group="ctalist">
          <li>числа номеров и этажей;</li>
          <li>ресторана, кухни и банкетных залов;</li>
          <li>площади подвалов, техэтажей и складов;</li>
          <li>территории и контейнерной площадки;</li>
          <li>кратности визитов — от 2 в месяц;</li>
          <li>требований сети или управляющей компании к отчётности.</li>
        </ul>
      </div>
      <div class="d-card f-pricecard" data-fade>
        <h3>Входит в абонентскую плату</h3>
        <p>Визиты по графику, осмотр номерного фонда по ротации, расходники для точек контроля, журнал и акты, ежемесячный отчёт, инструктаж горничных.</p>
        <p class="f-price"><b>Расчёт — после бесплатного обследования.</b> Сумма абонентской платы фиксируется в договоре.</p>
        <a href="#zayavka" class="btn btn-w btn-lg"><span class="btn-t">Рассчитать для моей гостиницы</span></a>
      </div>
    </div>
    <p class="d-note" data-fade>Разовая обработка номера — от 3 500 ₽ за выезд. При переходе на годовой договор стоимость первой обработки учитывается в расчёте.</p>
  </div>
</section>


<!-- ============ СМОТРИТЕ ТАКЖЕ (перелинковка) ============ -->
<section class="s s-rel" id="smotrite-takzhe">
  <div class="wrap">
    <div class="head">
      <div class="eyebrow" data-eyebrow>Смотрите также</div>
      <h2 data-split>Связанные услуги <em>и материалы</em></h2>
    </div>
    <div class="rel-grid" data-group="cards">
      <a class="card rel-card" href="../dezinsektsiya/"><span class="rel-k">Услуга</span><span class="rel-t">Дезинсекция для организаций</span><span class="rel-d">Контроль насекомых по IPM без остановки работы, ротация средств, журнал и акты по СанПиН.</span><span class="rel-a" aria-hidden="true"><svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></span></a>
      <a class="card rel-card" href="../deratizatsiya/"><span class="rel-k">Услуга</span><span class="rel-t">Дератизация для организаций</span><span class="rel-d">Три контура защиты от крыс и мышей, контейнеры КИК и ловушки без яда в цехах, схема точек и акты.</span><span class="rel-a" aria-hidden="true"><svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></span></a>
      <a class="card rel-card" href="../dogovor-deratizatsiya-dezinsektsiya/"><span class="rel-k">Обслуживание</span><span class="rel-t">Договор на дератизацию и дезинсекцию</span><span class="rel-d">Одно или оба направления в одном договоре: график визитов, акт после выезда, цена до подписания.</span><span class="rel-a" aria-hidden="true"><svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></span></a>
      <a class="card rel-card" href="../materialy/zhurnal-pest-kontrolya/"><span class="rel-k">Материал</span><span class="rel-t">Журнал <span class="nw">пест-контроля</span></span><span class="rel-d">Образец заполнения и шаблон в PDF: 9 разделов на 10 листах — точки контроля, ловушки, предписания.</span><span class="rel-a" aria-hidden="true"><svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></span></a>
    </div>
  </div>
</section>

<section class="s" id="voprosy">
  <div class="wrap">
    <div class="head"><div class="eyebrow" data-eyebrow>Вопросы</div><h2 data-split>Вопросы <em>о <span class="nw">пест-контроле</span> гостиниц</em></h2></div>
    <div class="faq">
      <div class="faq-col" data-group="faq">
        <div class="card qa"><button aria-expanded="false" aria-controls="a1" id="q1"><span>Как часто нужно проводить дезинсекцию в гостинице?</span><span class="pm"></span></button><div class="ans" id="a1" role="region" aria-labelledby="q1"><div><p>Гостиница — объект особого эпидемиологического значения: обследования на насекомых — не реже 2 раз в месяц, оценка заселённости грызунами — ежемесячно (пп. 98, 101, 110 СанПиН 3.3686-21). Обработки проводят по результатам обследований и при появлении вредителей.</p></div></div></div>
        <div class="card qa"><button aria-expanded="false" aria-controls="a2" id="q2"><span>Что делать, если гость пожаловался на клопов?</span><span class="pm"></span></button><div class="ans" id="a2" role="region" aria-labelledby="q2"><div><p>Переселить гостя в номер на другом этаже, снять номер с продажи, бельё отправить в прачечную в закрытом мешке и вызвать специалиста. Мы осмотрим номер и соседние — слева, справа, сверху и снизу, обработаем очаг и проведём контрольный осмотр через 10–14 дней.</p></div></div></div>
        <div class="card qa"><button aria-expanded="false" aria-controls="a3" id="q3"><span>Нужно ли закрывать этаж или выселять соседей?</span><span class="pm"></span></button><div class="ans" id="a3" role="region" aria-labelledby="q3"><div><p>Обычно нет. Выборочную дезинсекцию проводят в отдельных номерах, где нашли насекомых, в отсутствие людей (п. 127 СанПиН 3.3686-21). Соседние номера осматриваем и обрабатываем, если в них тоже есть находки.</p></div></div></div>
        <div class="card qa"><button aria-expanded="false" aria-controls="a4" id="q4"><span>Когда номер можно вернуть в продажу?</span><span class="pm"></span></button><div class="ans" id="a4" role="region" aria-labelledby="q4"><div><p>После проветривания по инструкции к средству и влажной уборки. Срок зависит от средства, поэтому называем его до начала работ.</p></div></div></div>
        <div class="card qa"><button aria-expanded="false" aria-controls="a5" id="q5"><span>Сколько стоит обработка номера от клопов?</span><span class="pm"></span></button><div class="ans" id="a5" role="region" aria-labelledby="q5"><div><p>Разовая обработка номера от клопов — от 3 500 ₽ за выезд: локализация очага, уничтожение клопов и акт выполненных работ. Абонентское обслуживание гостиницы считаем после бесплатного обследования; при переходе на годовой договор стоимость первой обработки учитываем в расчёте.</p></div></div></div>
      </div>
      <div class="faq-col" data-group="faq">
        <div class="card qa"><button aria-expanded="false" aria-controls="a6" id="q6"><span>Что проверяет Роспотребнадзор в гостинице по вредителям?</span><span class="pm"></span></button><div class="ans" id="a6" role="region" aria-labelledby="q6"><div><p>По проверочному листу (приказ Роспотребнадзора от 20.07.2026 № 578): нет ли насекомых и грызунов, кто и как проводит обработки, соблюдается ли кратность обследований — 2 раза в месяц на насекомых и ежемесячно на грызунов, обследуются ли мусоросборные камеры и контейнерная площадка.</p></div></div></div>
        <div class="card qa"><button aria-expanded="false" aria-controls="a7" id="q7"><span>Работаете ли вы ночью и без огласки?</span><span class="pm"></span></button><div class="ans" id="a7" role="region" aria-labelledby="q7"><div><p>Да. Выезжаем без броской символики, ночью и в выходные — без наценки. Срочный выезд — в течение 3 часов по Москве и Московской области, 24/7.</p></div></div></div>
        <div class="card qa"><button aria-expanded="false" aria-controls="a8" id="q8"><span>Проводите ли вы обучение горничных?</span><span class="pm"></span></button><div class="ans" id="a8" role="region" aria-labelledby="q8"><div><p>Да. Инструктаж проводим на объекте: признаки клопов, порядок действий при находке и как не разнести насекомых с бельём по этажам.</p></div></div></div>
        <div class="card qa"><button aria-expanded="false" aria-controls="a9" id="q9"><span>Чем <span class="nw">пест-контроль</span> отличается от разовой обработки?</span><span class="pm"></span></button><div class="ans" id="a9" role="region" aria-labelledby="q9"><div><p>Разовая обработка убирает очаг. <span class="nw">Пест-контроль</span> — постоянная система: осмотры по графику, точки контроля, журнал и обучение персонала, чтобы очаг не повторился. Подробнее — в материале <a href="../materialy/pest-menedzhment-ili-razovaya-obrabotka/">«<span class="nw">Пест-менеджмент</span> или разовая обработка»</a>.</p></div></div></div>
        <div class="card qa"><button aria-expanded="false" aria-controls="a10" id="q10"><span>Есть ли у вас лицензия?</span><span class="pm"></span></button><div class="ans" id="a10" role="region" aria-labelledby="q10"><div><p>Да. С 1 марта 2025 года услуги дезинфекции, дезинсекции и дератизации лицензируются. У ООО «Центр дезинфекционных услуг» действующая лицензия № Л064-00111-77/01942445 — запись можно проверить в <a href="https://fp.rospotrebnadzor.ru/licen/?oper=search&amp;numb_history=&amp;numb=&amp;firmget_name=&amp;ogrn_inn_nza=7714462211" target="_blank" rel="noopener">реестре лицензий Роспотребнадзора</a>.</p></div></div></div>
      </div>
    </div>
  </div>
</section>

<section class="cta" id="zayavka"><div class="cta-bg f-lazy" aria-hidden="true" data-parallax-bg></div><div class="cta-orb" id="orb" aria-hidden="true"></div>
  <div class="wrap">
    <div>
      <div class="eyebrow" data-eyebrow>Заявка</div>
      <h2 data-split>Начните с бесплатного <em>обследования гостиницы</em></h2>
      <p class="sub" data-fade><span class="nw">Пест-менеджер</span> осмотрит номера, кухню, подвал и мусорокамеру, проверит договор и журнал. После выезда вы узнаете, что исправить до ближайшей проверки, и получите расчёт обслуживания.</p>
      <ul class="cta-list" data-group="ctalist">
        <li><svg aria-hidden="true" focusable="false" class="lucide lucide-circle-check" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <circle cx="12" cy="12" r="10" /> <path d="m16 9-5.5 5.5L8 12" /> </svg>Выезд по Москве и Московской области</li>
        <li><svg aria-hidden="true" focusable="false" class="lucide lucide-circle-check" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <circle cx="12" cy="12" r="10" /> <path d="m16 9-5.5 5.5L8 12" /> </svg>Обследование гостиницы — бесплатно</li>
        <li><svg aria-hidden="true" focusable="false" class="lucide lucide-circle-check" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <circle cx="12" cy="12" r="10" /> <path d="m16 9-5.5 5.5L8 12" /> </svg>Конфиденциально, в удобное для отеля время</li>
      </ul>
      <div class="cta-contacts" data-fade>
        <a class="ph" href="tel:+74951043570">+7 (495) 104-35-70</a>
        <div class="msg">
          <a href="https://max.ru/u/f9LHodD0cOIlIUXFkt4KMFP88lD8n4TArBiTcV7RI1XML5c4o39QfsDBXUc" class="max" aria-label="Написать в Max" target="_blank" rel="noopener noreferrer"><svg viewBox="0 0 24 24" fill="#fff" aria-hidden="true"><path d="M12 3a9 9 0 0 0-7.7 13.7L3 21l4.4-1.2A9 9 0 1 0 12 3zm-3.6 12.3V8.7h1.6l2 2.8 2-2.8h1.6v6.6h-1.7v-3.9L12 14l-1.9-2.6v3.9z"/></svg></a>
          <a href="https://t.me/Centr_Dezinfection?text=%D0%97%D0%B4%D1%80%D0%B0%D0%B2%D1%81%D1%82%D0%B2%D1%83%D0%B9%D1%82%D0%B5!%20%D0%9F%D0%B8%D1%88%D1%83%20%D1%81%20%D1%81%D0%B0%D0%B9%D1%82%D0%B0%20%D0%BF%D0%B5%D1%81%D1%82%D0%BA%D0%BE%D0%BD%D1%82%D1%80%D0%BE%D0%BB%D1%8C-%D1%86%D0%B5%D0%BD%D1%82%D1%80.%D1%80%D1%84" class="tg" aria-label="Написать в Telegram" target="_blank" rel="noopener noreferrer"><svg viewBox="0 0 24 24" fill="#fff" aria-hidden="true"><path d="M21.4 4.3 2.9 11.4c-1.3.5-1.2 1.2-.2 1.5l4.7 1.5 1.8 5.6c.2.6.4.8.9.8.4 0 .6-.2.9-.4l2.3-2.2 4.7 3.5c.9.5 1.5.2 1.7-.8l3.1-14.6c.3-1.3-.5-1.8-1.4-1.5zM9.6 14.1l8.6-5.4c.4-.3.8-.1.5.2l-7.1 6.4-.3 3.3z"/></svg></a>
        </div>
      </div>
    </div>
    <form class="form" id="form" novalidate data-form>
      <div class="fbody">
        <h3>Заявка на бесплатное обследование</h3>
        <p class="fs">Заполнение займёт меньше минуты</p>
        <div class="fg">
<div class="field"><label class="sr-only" for="f-name">Ваше имя</label><input id="f-name" type="text" name="name" placeholder="Ваше имя *" required autocomplete="name"><small class="ferr">Укажите имя</small></div>
<div class="field"><label class="sr-only" for="phone">Телефон</label><input name="phone" id="phone" type="tel" inputmode="tel" placeholder="+7 (___) ___-__-__ *" required autocomplete="tel"><small class="ferr">Укажите телефон полностью</small></div>
<div class="field full"><label class="sr-only" for="f-type">Тип объекта</label><select id="f-type" name="type" required><option value="" disabled>Тип объекта *</option><option>Пищевое производство</option><option>Магазин или торговая сеть</option><option>Ресторан или кафе</option><option>Склад, логистика</option><option>Фармацевтическое производство</option><option value="Гостиница" selected>Гостиница *</option><option>Другое</option></select><small class="ferr">Выберите тип объекта</small></div>
<div class="field full"><label class="sr-only" for="f-rooms">Номерной фонд</label><select id="f-rooms" name="rooms"><option value="" selected>Номерной фонд</option><option>До 20 номеров</option><option>20–50 номеров</option><option>50–150 номеров</option><option>150–300 номеров</option><option>Больше 300 номеров</option></select></div>
<div class="field full"><label class="sr-only" for="f-task">Задача</label><select id="f-task" name="task"><option value="" selected>Задача</option><option>Плановое обслуживание по договору</option><option>Срочно: гость пожаловался на клопов</option><option>Тараканы или грызуны на кухне</option><option>Подготовка к проверке Роспотребнадзора</option><option>Другое</option></select></div>
<div class="field full"><label class="sr-only" for="f-msg">Комментарий</label><textarea id="f-msg" name="comment" placeholder="Комментарий: адрес, ресторан, сроки"></textarea></div>
<input type="hidden" name="msg" value="">
<div class="field" hidden><input type="hidden" name="email" value=""></div>

<input type="hidden" name="page" value="Пест-контроль гостиниц и отелей">
</div>
        <button type="submit" class="btn btn-w btn-lg" id="submitBtn"><span class="btn-t">Заказать обследование</span><svg class="btn-ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M5 12h14M13 6l6 6-6 6"/></svg><i class="spin" aria-hidden="true"></i></button>
        <p class="legal">Нажимая кнопку, вы даёте <a href="../soglasie/" target="_blank" rel="noopener">согласие на обработку персональных данных</a> и подтверждаете, что ознакомились с <a href="../privacy/" target="_blank" rel="noopener">политикой конфиденциальности</a>.</p>
      </div>
      <div class="ok" role="status" aria-live="polite">
        <svg class="ok-ic" viewBox="0 0 52 52" aria-hidden="true"><circle cx="26" cy="26" r="24" fill="none"/><path fill="none" d="M15 27l7 7 15-16"/></svg>
        <h3>Заявка отправлена</h3><p>Перезвоним в ближайшее рабочее время, чтобы согласовать день обследования.</p>
      </div>
    </form>
  </div>
</section>
</main>


<footer>
  <div class="wrap">
    <div class="ft">
      <div>
        <a href="../" class="logo" aria-label="ПЕСТКОНТРОЛЬ Центр — на главную"><span class="logo-mark"><svg viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="1.6" stroke-linejoin="round" aria-hidden="true"><path d="M12 2.5l7.5 3v6c0 5-3.2 8.6-7.5 10-4.3-1.4-7.5-5-7.5-10v-6z"/><circle cx="12" cy="11.5" r="2.6" stroke="#7c86ff"/><path d="M12 6.2v2.7M12 14.1v2.7M6.8 11.5h2.6M14.6 11.5h2.6" stroke="#7c86ff"/></svg></span><span class="logo-txt"><span class="logo-name">ПЕСТКОНТРОЛЬ</span> <span class="logo-sub">Центр</span></span></a>
        <p class="d"><span class="nw">Пест-контроль</span> и <span class="nw">пест-менеджмент</span> по системе IPM для бизнеса в Москве и Московской области: бесплатный аудит, оценка <span class="nw">пест-риска</span>, мониторинг вредителей и отчётность.</p>
      </div>
      <div><h4>Услуги</h4><ul><li><a href="../dezinfektsiya/">Дезинфекция для организаций</a></li><li><a href="../deratizatsiya/">Дератизация для организаций</a></li><li><a href="../dezinsektsiya/">Дезинсекция для организаций</a></li><li><a href="../sanitarnyy-audit/"><span>Санитарный аудит <span class="nw">(СЭС-аудит)</span></span></a></li><li><a href="../laboratornye-issledovaniya/">Лабораторные исследования</a></li><li><a href="../razrabotka-ppk/">Разработка ППК</a></li><li><a href="../normativnaya-baza/dokumenty-dlya-rospotrebnadzora/">Документы для Роспотребнадзора</a></li><li><a href="../ochistka-dezinfektsiya-ventilyatsii/">Очистка и дезинфекция вентиляции</a></li><li><a href="../dogovor-deratizatsiya-dezinsektsiya/">Договор на дератизацию и дезинсекцию</a></li><li><a href="../#podhod"><span><span class="nw">Пест-контроль</span> по системе IPM</span></a></li><li><a href="../#etapy">Этапы работы</a></li><li><a href="../#vrediteli">Вредители</a></li><li><a href="../#usloviya">Цена</a></li><li><a href="../#voprosy">Вопросы</a></li></ul></div>
      <div><h4>Отрасли</h4><ul><li><a href="../pishchevoe-proizvodstvo/">Пищевые производства</a></li><li><a href="../magaziny-i-torgovye-seti/">Магазины и торговые сети</a></li><li><a href="../restorany-i-kafe/">Рестораны и кафе</a></li><li><a href="../sklady-i-logistika/">Склады и логистика</a></li><li><a href="../farmatsevticheskie-proizvodstva/">Фармацевтические производства</a></li><li><a href="./" aria-current="page">Гостиницы и отели</a></li></ul></div>
      <div><h4>Материалы</h4><ul><li><a href="../normativnaya-baza/">Нормативная база</a></li><li><a href="../normativnaya-baza/proverochnye-listy/">Проверочные листы 2026</a></li><li><a href="../normativnaya-baza/dokumenty-dlya-rospotrebnadzora/">Документы для Роспотребнадзора</a></li><li><a href="../materialy/programma-pest-kontrolya/"><span>Программа <span class="nw">пест-контроля</span></span></a></li><li><a href="../materialy/zhurnal-pest-kontrolya/"><span>Журнал <span class="nw">пест-контроля</span></span></a></li><li><a href="../materialy/pest-menedzhment-ili-razovaya-obrabotka/"><span><span class="nw">Пест-менеджмент</span> или разовая обработка</span></a></li><li><a href="../materialy/programma-proizvodstvennogo-kontrolya-haccp/">Программа производственного контроля по ХАССП</a></li><li><a href="../materialy/">Все материалы</a></li></ul></div>
      <div><h4>Контакты</h4><ul><li><a href="tel:+74951043570">+7 (495) 104-35-70</a></li><li><a href="mailto:b2b@pestcontrol-center.ru">b2b@<wbr><span style="white-space:nowrap">pestcontrol-center.ru</span></a></li><li>Пн–Пт: 8:00–20:00</li><li>Срочные выезды: 24/7</li></ul>
        <div class="msg"><a href="https://max.ru/u/f9LHodD0cOIlIUXFkt4KMFP88lD8n4TArBiTcV7RI1XML5c4o39QfsDBXUc" class="max" aria-label="Написать в Max" target="_blank" rel="noopener noreferrer"><svg viewBox="0 0 24 24" fill="#fff" aria-hidden="true"><path d="M12 3a9 9 0 0 0-7.7 13.7L3 21l4.4-1.2A9 9 0 1 0 12 3zm-3.6 12.3V8.7h1.6l2 2.8 2-2.8h1.6v6.6h-1.7v-3.9L12 14l-1.9-2.6v3.9z"/></svg></a><a href="https://t.me/Centr_Dezinfection?text=%D0%97%D0%B4%D1%80%D0%B0%D0%B2%D1%81%D1%82%D0%B2%D1%83%D0%B9%D1%82%D0%B5!%20%D0%9F%D0%B8%D1%88%D1%83%20%D1%81%20%D1%81%D0%B0%D0%B9%D1%82%D0%B0%20%D0%BF%D0%B5%D1%81%D1%82%D0%BA%D0%BE%D0%BD%D1%82%D1%80%D0%BE%D0%BB%D1%8C-%D1%86%D0%B5%D0%BD%D1%82%D1%80.%D1%80%D1%84" class="tg" aria-label="Написать в Telegram" target="_blank" rel="noopener noreferrer"><svg viewBox="0 0 24 24" fill="#fff" aria-hidden="true"><path d="M21.4 4.3 2.9 11.4c-1.3.5-1.2 1.2-.2 1.5l4.7 1.5 1.8 5.6c.2.6.4.8.9.8.4 0 .6-.2.9-.4l2.3-2.2 4.7 3.5c.9.5 1.5.2 1.7-.8l3.1-14.6c.3-1.3-.5-1.8-1.4-1.5zM9.6 14.1l8.6-5.4c.4-.3.8-.1.5.2l-7.1 6.4-.3 3.3z"/></svg></a></div>
      </div>
    </div>
    <div class="fb"><span>© 2026 ПЕСТКОНТРОЛЬ Центр</span><a href="../privacy/">Политика конфиденциальности</a><a href="../soglasie/">Согласие на обработку данных</a><span>Информация на сайте не является публичной офертой</span></div>
  </div>
</footer>

<div class="mbar" id="mbar">
  <a href="tel:+74951043570" class="c1"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1 1 .4 1.9.7 2.8a2 2 0 0 1-.5 2.1L8 9.9a16 16 0 0 0 6 6l1.3-1.3a2 2 0 0 1 2.1-.4c.9.3 1.8.6 2.8.7a2 2 0 0 1 1.7 2z"/></svg>Позвонить</a>
  <a href="#zayavka" class="c2"><span>Обследование</span></a>
</div>
<div class="fab" role="group" aria-label="Написать в мессенджер">
  <a href="https://max.ru/u/f9LHodD0cOIlIUXFkt4KMFP88lD8n4TArBiTcV7RI1XML5c4o39QfsDBXUc" class="max" aria-label="Написать в Max" target="_blank" rel="noopener noreferrer"><svg viewBox="0 0 24 24" fill="#fff" aria-hidden="true"><path d="M12 3a9 9 0 0 0-7.7 13.7L3 21l4.4-1.2A9 9 0 1 0 12 3zm-3.6 12.3V8.7h1.6l2 2.8 2-2.8h1.6v6.6h-1.7v-3.9L12 14l-1.9-2.6v3.9z"/></svg></a>
  <a href="https://t.me/Centr_Dezinfection?text=%D0%97%D0%B4%D1%80%D0%B0%D0%B2%D1%81%D1%82%D0%B2%D1%83%D0%B9%D1%82%D0%B5!%20%D0%9F%D0%B8%D1%88%D1%83%20%D1%81%20%D1%81%D0%B0%D0%B9%D1%82%D0%B0%20%D0%BF%D0%B5%D1%81%D1%82%D0%BA%D0%BE%D0%BD%D1%82%D1%80%D0%BE%D0%BB%D1%8C-%D1%86%D0%B5%D0%BD%D1%82%D1%80.%D1%80%D1%84" class="tg" aria-label="Написать в Telegram" target="_blank" rel="noopener noreferrer"><svg viewBox="0 0 24 24" fill="#fff" aria-hidden="true"><path d="M21.4 4.3 2.9 11.4c-1.3.5-1.2 1.2-.2 1.5l4.7 1.5 1.8 5.6c.2.6.4.8.9.8.4 0 .6-.2.9-.4l2.3-2.2 4.7 3.5c.9.5 1.5.2 1.7-.8l3.1-14.6c.3-1.3-.5-1.8-1.4-1.5zM9.6 14.1l8.6-5.4c.4-.3.8-.1.5.2l-7.1 6.4-.3 3.3z"/></svg></a>
</div>

<script>
/* Предпросмотр: вне рабочего домена заявка не отправляется (на пестконтроль-центр.рф этот блок не срабатывает) */
(function(){if(/^(www\.)?xn----itbbsflddbfpfdodg9d0f\.xn--p1ai$/i.test(location.hostname))return;var f=window.fetch;window.fetch=function(u){if(typeof u==='string'&&u.indexOf('send.php')>-1)return new Promise(function(r){setTimeout(function(){r(new Response('{"success":true}',{status:200,headers:{'Content-Type':'application/json'}}))},500)});return f.apply(this,arguments)};document.addEventListener('DOMContentLoaded',function(){var p=document.querySelector('.form .fs');if(p)p.textContent='Предпросмотр: заявка никуда не отправляется'})})();
/* самопроверка: счётчик отмеченных пунктов */
document.addEventListener('change',function(e){if(!e.target.closest('.f-check-list'))return;var n=0;document.querySelectorAll('.f-check-list input').forEach(function(i){n+=i.checked?1:0});document.getElementById('chk-n').textContent=n;document.querySelector('.f-check-res').classList.toggle('full',n===5);document.getElementById('chk-note').textContent=n===5?'Всё на месте — на обследовании проверим, как это работает в номерах и на кухне.':'Чего-то не хватает — на бесплатном обследовании покажем, что добавить и в каком порядке.'});
/* схема зон: подсветка зоны по пункту списка и наоборот */
(function(){var map=document.querySelector('.f-zmap');if(!map)return;var plan=map.querySelector('.f-plan'),items=map.querySelectorAll('.f-zlist li');function set(z){plan.querySelectorAll('[data-z]').forEach(function(g){g.classList.toggle('on',g.getAttribute('data-z')===z)});items.forEach(function(li){li.classList.toggle('on',li.getAttribute('data-z')===z)})}items.forEach(function(li){var z=li.getAttribute('data-z');li.addEventListener('mouseenter',function(){set(z)});li.addEventListener('focus',function(){set(z)});li.addEventListener('click',function(){set(z)})});plan.querySelectorAll('.zf,.bdg').forEach(function(el){var g=el.closest('[data-z]');el.addEventListener('mouseenter',function(){set(g.getAttribute('data-z'))})});map.addEventListener('mouseleave',function(){set(null)})})();
</script>
<script data-fx>
/* Эффекты под курсором, как на главной (tools/site/fx.py) */
(function(){
  var mm=window.matchMedia;if(!mm)return;
  var fine=mm('(hover: hover) and (pointer: fine)').matches;
  /* «фонарь»: следует за мышью, без движения мыши плавно ходит сам; на сенсорных экранах ходит сам (30 кадров в секунду).
     Не считаем, пока первый экран не виден или вкладка скрыта. Старт — вместе со входом первого экрана */
  var hero=document.getElementById('hero'),lit=hero&&hero.querySelector('.fx-lit');
  if(lit&&!mm('(prefers-reduced-motion: reduce)').matches){
    var media=lit.parentNode,small=mm('(max-width:860px)').matches,full=hero.classList.contains('f-hero');
    lit.style.setProperty('--sr',small?'150px':'clamp(240px, 21vw, 400px)');
    var cx=small?.5:(full?.68:.74),ax=small?.24:(full?.16:.13),cy=small?.5:.47,ay=small?.2:.17;
    var sx=cx,sy=cy,tx=cx,ty=cy,last=-1e9,vis=true,on=false,raf=0,lt=0;
    var frame=function(now){
      raf=0;if(!on||!vis||document.hidden)return;
      var dt=now-lt;if(!fine&&dt<30){raf=requestAnimationFrame(frame);return;}
      lt=now;if(now-last>2600){var t=now/1000;tx=cx+ax*Math.sin(t*.33);ty=cy+ay*Math.sin(t*.47+1.3);}
      var k=1-Math.pow(.94,Math.min(dt,100)/16.67);sx+=(tx-sx)*k;sy+=(ty-sy)*k;
      lit.style.setProperty('--sx',(sx*100).toFixed(2)+'%');lit.style.setProperty('--sy',(sy*100).toFixed(2)+'%');
      raf=requestAnimationFrame(frame);
    };
    var kick=function(){if(!raf&&on&&vis&&!document.hidden){lt=performance.now();raf=requestAnimationFrame(frame);}};
    hero.addEventListener('pointermove',function(e){
      if(e.pointerType!=='mouse')return;var r=media.getBoundingClientRect();if(!r.width||!r.height)return;
      tx=(e.clientX-r.left)/r.width;ty=(e.clientY-r.top)/r.height;last=performance.now();kick();
    },{passive:true});
    if('IntersectionObserver' in window)new IntersectionObserver(function(es){vis=es[0].isIntersecting;kick();}).observe(hero);
    document.addEventListener('visibilitychange',kick);
    var start=function(){if(on)return;on=true;hero.classList.add('fx-lit-on');kick();};
    var eb=hero.querySelector('.eyebrow');
    if(eb&&'MutationObserver' in window){
      if(eb.classList.contains('in'))start();
      else{var mo=new MutationObserver(function(){if(eb.classList.contains('in')){mo.disconnect();start();}});mo.observe(eb,{attributes:true,attributeFilter:['class']});}
    }
    setTimeout(start,eb?5000:2500);
  }
  /* подсветка рамки карточек за курсором — как у .card на главной */
  if(fine)document.addEventListener('pointermove',function(e){
    var c=e.target.closest&&e.target.closest('.d-card,.p-sec,.p-fcard,.p-duty-box,.p-dl-card,.pm-step-card,.pm-scen,.pm-link-card,.k-err,.w-sample,.d-doc-prev');if(!c)return;
    var r=c.getBoundingClientRect();c.style.setProperty('--mx',(e.clientX-r.left)+'px');c.style.setProperty('--my',(e.clientY-r.top)+'px');
  },{passive:true});
})();
</script>
<script>
  /* скрипты анимаций подключаются сразу после первой отрисовки: фото и заголовок первого экрана не ждут их загрузки */
  (function (r, l) {
    var go = function () { l.forEach(function (u) { var e = document.createElement('script'); e.src = r + u; e.async = false; document.body.appendChild(e); }); };
    if (document.visibilityState === 'hidden' || !window.requestAnimationFrame) setTimeout(go, 0);
    else requestAnimationFrame(function () { setTimeout(go, 0); });
  })('../', ['vendor/gsap.min.js', 'vendor/ScrollTrigger.min.js', 'vendor/lenis.min.js', 'app.min.js?v=20261106s2']);
</script>
<script>/* Форма: номерной фонд, задача, комментарий и страница — в поле msg, которое читает send.php */
document.addEventListener('submit',function(ev){var f=ev.target;if(!f||f.id!=='form')return;var e=f.elements,r=e.rooms.value||'не указан',t=e.task.value||'не выбрана',c=e.comment.value.trim();e.msg.value='Номерной фонд: '+r+'\nЗадача: '+t+(c?'\nКомментарий: '+c:'')+'\nСтраница: Пест-контроль гостиниц и отелей (/gostinitsy/)';},true);</script>
<!-- Yandex.Metrika counter + UIS + Radist: загружаются после первого действия посетителя (касание, прокрутка, мышь, клавиатура) или через 5 с после загрузки страницы -->
<script type="text/javascript">
    (function (w, d) {
        w.ym = w.ym || function () { (w.ym.a = w.ym.a || []).push(arguments); };
        w.ym.l = 1 * new Date();
        ym(113675622, 'init', {ssr:true, webvisor:true, clickmap:true, ecommerce:"dataLayer", referrer: document.referrer, url: location.href, accurateTrackBounce:true, trackLinks:true});
        var done = false, ready = false, wait = null, ev = ['pointerdown', 'touchstart', 'keydown', 'scroll', 'wheel', 'mousemove'];
        w.__cs = w.__cs || [];
        w.__cs.push(['waitForTrackViewAndRun', function () { ready = true; }]);
        // Radist: код заявки в ссылках Telegram и MAX — сразу, скрипт Radist загрузится вместе со счётчиками
        var rmsg = 'Здравствуйте! Пишу с сайта пестконтроль-центр.рф. Номер заявки: {radist_tracker}';
        w.radist_tracker = w.radist_tracker || function () { (w.radist_tracker.a = w.radist_tracker.a || []).push(arguments); };
        w.radist_tracker.l = 1 * new Date();
        w.radist_tracker({ message: rmsg, whatsapp_enabled: true, tgbot_enabled: true, tg_enabled: true, max_enabled: true, vk_enabled: true });
        (function () {
            var id = null, abc = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789', s = 'ro', i, txt;
            try {
                id = sessionStorage.getItem('radistVisit');
                if (!id || id.length !== 12) {
                    for (i = 0; i < 10; i++) s += abc.charAt(Math.floor(Math.random() * abc.length));
                    sessionStorage.setItem('radistVisit', s);
                    id = sessionStorage.getItem('radistVisit');
                }
            } catch (e) { id = null; }
            if (!id || id.length !== 12) return;
            txt = encodeURIComponent(rmsg.replace(/{radist_tracker}/g, id));
            [].forEach.call(d.querySelectorAll('a[href*="//t.me/"], a[href*="//max.ru/"]'), function (a) {
                try {
                    var u = new URL(a.href), n = u.pathname.split('/')[1] || '';
                    if (u.host === 'max.ru') a.href = 'https://max.ru/' + u.pathname.substring(1) + '?start=' + id;
                    else if (u.host === 't.me' && !/bot$/i.test(n)) a.href = 'https://t.me' + u.pathname + '?text=' + txt;
                } catch (e) {}
            });
        })();
        function add(src) { var k = d.createElement('script'); k.async = true; k.src = src; d.head.appendChild(k); return k; }
        function load() {
            if (done) return; done = true;
            ev.forEach(function (e) { w.removeEventListener(e, load, true); });
            add('https://mc.yandex.ru/metrika/tag.js?id=113675622');
            var p = d.createElement('link'); p.rel = 'preconnect'; p.href = 'https://tracker.comagic.ru'; d.head.appendChild(p);
            add('https://app.uiscom.ru/static/cs.min.js?k=ICWycQx6m3NSBe3WlCeDAdAKMTmNhMHC').onerror = function () { ready = true; };
            add('https://track.radist.me/tracker.min.js');
        }
        ev.forEach(function (e) { w.addEventListener(e, load, { capture: true, passive: true }); });
        function later() { setTimeout(load, 5000); }
        if (d.readyState === 'complete') later(); else w.addEventListener('load', later);
        // Ожидание подмены номера при первом касании: набор откладывается до ответа UIS, максимум 0,8–1 с
        d.addEventListener('click', function (e) {
            if (ready) return;
            var a = e.target && e.target.closest ? e.target.closest('a[href^="tel:"]') : null;
            if (!a || e.button || e.ctrlKey || e.metaKey || e.shiftKey || e.altKey) return;
            e.preventDefault();
            if (wait) return;
            load();
            var href = a.getAttribute('href'), op = a.style.opacity, max = 'GestureEvent' in w ? 800 : 1000, t;
            function go() {
                for (var i = 0; i < wait.length; i++) clearTimeout(wait[i]);
                wait = null; ready = true; a.style.opacity = op;
                w.location.href = a.href;
            }
            function check(last) { return function () { if (wait && (last || ready || a.getAttribute('href') !== href)) go(); }; }
            wait = [];
            a.style.opacity = '.6';
            for (t = 50; t <= max; t += 50) wait.push(setTimeout(check(t === max), t));
        }, true);
    })(window, document);
</script>
<noscript><div><img src="https://mc.yandex.ru/watch/113675622" style="position:absolute; left:-9999px;" alt="" /></div></noscript>
<!-- /Yandex.Metrika counter -->
</body>
</html>
