<!doctype html>
<html lang="ru">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>Замер освещённости на рабочих местах — цена от 350 ₽ за точку, Москва — ПЕСТКОНТРОЛЬ Центр</title>
<meta name="description" content="Измерение освещённости люксметром по ГОСТ 24940-2016 и МУК 4.3.3975-24 — от 350 ₽ за точку. Офисы, цеха, склады, салоны красоты; сравнение с нормами СанПиН 1.2.3685-21 и протокол для ППК.">
<link rel="canonical" href="https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/laboratornye-issledovaniya/zamer-osveshchennosti/">
<meta name="theme-color" content="#000000">
<meta property="og:type" content="website">
<meta property="og:locale" content="ru_RU">
<meta property="og:site_name" content="ПЕСТКОНТРОЛЬ Центр">
<meta property="og:url" content="https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/laboratornye-issledovaniya/zamer-osveshchennosti/">
<meta property="og:title" content="Замер освещённости на рабочих местах — от 350 ₽ за точку">
<meta property="og:description" content="Измерение освещённости люксметром по ГОСТ 24940-2016 и МУК 4.3.3975-24 — от 350 ₽ за точку. Офисы, цеха, склады, салоны красоты; сравнение с нормами СанПиН 1.2.3685-21 и протокол для ППК.">
<meta property="og:image" content="https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/img/lab-osveshchennost-og.jpg">
<meta property="og:image:type" content="image/jpeg">
<meta property="og:image:width" content="1200">
<meta property="og:image:height" content="630">
<meta property="og:image:alt" content="Специалист лаборатории измеряет освещённость рабочего стола люксметром в офисе в тёмное время суток">
<meta name="twitter:card" content="summary_large_image">
<link rel="icon" href="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 32 32'%3E%3Ccircle cx='16' cy='16' r='15' fill='%2309090b' stroke='%237c86ff' stroke-width='2'/%3E%3Cpath d='M16 7l7 3v5c0 5-3 8.5-7 10-4-1.5-7-5-7-10v-5z' fill='none' stroke='%23fff' stroke-width='2'/%3E%3C/svg%3E">
<link rel="preload" href="../../fonts/inter-ru-wght-normal.woff2" as="font" type="font/woff2" crossorigin>
<link rel="preload" as="image" media="(min-width:761px)" imagesrcset="../../img/lab-osveshchennost-hero-1440.webp 1440w, ../../img/lab-osveshchennost-hero.webp 1920w" imagesizes="100vw" fetchpriority="high">
<link rel="preload" as="image" media="(max-width:760px)" imagesrcset="../../img/lab-osveshchennost-hero-mob-760.webp 760w, ../../img/lab-osveshchennost-hero-mob.webp 1024w" imagesizes="100vw" fetchpriority="high">
<script>
  /* начальные состояния анимаций — только при работающем JS; страховка — через 4 с всё показывается.
     Заставка — один раз за посещение: при переходе по ссылке с якорем и между страницами сайта её нет */
  (function (d) {
    d.classList.add('js');
    try { if (location.hash || sessionStorage.getItem('pc-intro')) d.classList.add('no-intro'); else sessionStorage.setItem('pc-intro', '1'); }
    catch (e) { if (location.hash) d.classList.add('no-intro'); }
    setTimeout(function () { if (!d.classList.contains('anim-ready')) d.classList.add('anim-fail'); }, 4000);
  })(document.documentElement);
</script>
<link rel="stylesheet" href="../../style.css?v=20261106s2">
<style>.d-page .s{padding:clamp(64px,7vw,128px) 0;border-top:1px solid var(--line)}.d-crumbs{padding-top:calc(clamp(68px,6vw,115px) + 20px);font-size:14px;color:var(--t3);display:flex;flex-wrap:wrap;gap:8px}.d-crumbs a{color:var(--t2)}.d-crumbs a:hover{color:var(--t1)}.d-hero{padding:clamp(28px,3vw,56px) 0 clamp(64px,7vw,128px)}.d-hero .wrap{display:grid;grid-template-columns:minmax(0,1.15fr) minmax(0,.85fr);gap:clamp(28px,4vw,80px);align-items:center}.d-hero h1{font-size:clamp(34px,4.2vw,80px);line-height:1.05;letter-spacing:-.045em;font-weight:300;margin:18px 0 0}.d-ticks{list-style:none;padding:0;margin:28px 0 34px;display:grid;gap:12px}.d-ticks li{position:relative;padding-left:30px;line-height:1.5}.d-ticks li::before{content:"";position:absolute;left:2px;top:.42em;width:13px;height:7px;border-left:2px solid var(--acc);border-bottom:2px solid var(--acc);transform:rotate(-45deg)}.d-btns{display:flex;flex-wrap:wrap;gap:12px}.ph-img{aspect-ratio:4/3;border:1.5px dashed var(--line2);border-radius:var(--r);display:flex;align-items:center;justify-content:center;text-align:center;padding:28px;color:var(--t3);font-size:14px;line-height:1.5;background:rgba(255,255,255,.02)}.ph-doc{aspect-ratio:3/4;max-width:340px}.d-cards{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:16px}.d-card{background:var(--card);border:1px solid var(--line2);border-radius:var(--r);padding:clamp(22px,2vw,34px)}.d-card h3{font-size:clamp(20px,1.5vw,26px);font-weight:400;letter-spacing:-.02em;margin:0 0 12px}.d-card p{color:var(--t2);line-height:1.6;margin:0}.d-note{color:var(--t2);margin:24px 0 0;line-height:1.6}.d-strong{color:var(--t1);font-size:clamp(18px,1.3vw,22px)}.d-split{display:grid;grid-template-columns:minmax(0,1fr) minmax(0,340px);gap:clamp(28px,4vw,80px);align-items:start}.d-two{display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1fr);gap:clamp(28px,4vw,80px);align-items:start}.d-two .head{margin-bottom:0}.d-two .d-ticks{margin:0}.d-terms{list-style:none;counter-reset:t;padding:0;margin:0;border-top:1px solid var(--line2)}.d-terms li{display:grid;grid-template-columns:44px minmax(0,.42fr) minmax(0,1fr);gap:16px;padding:18px 0;border-bottom:1px solid var(--line2);line-height:1.55}.d-terms li::before{counter-increment:t;content:counter(t,decimal-leading-zero);color:var(--t3)}.d-terms b{font-weight:500}.d-terms span{color:var(--t2)}.d-doc{display:grid;gap:16px;justify-items:start}.d-small{font-size:14px;color:var(--t3);margin:0}.d-steps{list-style:none;counter-reset:st;padding:0;margin:0;display:grid;grid-template-columns:repeat(5,minmax(0,1fr));gap:18px}.d-steps li{border-top:2px solid var(--line2);padding-top:18px;line-height:1.55}.d-steps li::before{counter-increment:st;content:"0" counter(st);display:block;color:var(--acc);font-size:14px;margin-bottom:12px}.d-steps b{display:block;font-weight:500;margin-bottom:8px}.d-steps span{color:var(--t2)}.d-table{width:100%;border-collapse:collapse;line-height:1.5}.d-table th,.d-table td{text-align:left;vertical-align:top;padding:16px 20px 16px 0;border-bottom:1px solid var(--line2)}.d-table th{color:var(--t3);font-weight:400;font-size:14px}.d-table td{color:var(--t2)}.d-table td:first-child{color:var(--t1)}.d-vs td:first-child{color:var(--t2)}.d-vs th:last-child,.d-vs td:last-child{color:var(--t1);background:rgba(124,134,255,.07);padding-left:20px}.d-cols2{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:16px;margin-top:28px}.d-chips{list-style:none;padding:0;margin:0;display:flex;flex-wrap:wrap;gap:10px}.d-chips a{display:inline-block;padding:12px 18px;border:1px solid var(--line2);border-radius:999px;color:var(--t1);transition:border-color .2s}.d-chips a:hover{border-color:var(--acc)}.tbd{background:rgba(255,209,102,.14);color:#ffd166;border-radius:4px;padding:0 .2em}.d-page .cta .sub{margin-bottom:30px}@media (max-width:1100px){.d-steps{grid-template-columns:repeat(2,minmax(0,1fr))}}@media (max-width:860px){.d-hero .wrap,.d-split,.d-two,.d-cols2,.d-cards{grid-template-columns:minmax(0,1fr)}.d-terms li{grid-template-columns:36px minmax(0,1fr);gap:6px 12px}.d-terms span{grid-column:2}.ph-doc{display:none}}@media (max-width:600px){.d-steps{grid-template-columns:minmax(0,1fr)}.d-table thead{display:none}.d-table,.d-table tbody,.d-table tr,.d-table td{display:block;width:100%}.d-table tr{border:1px solid var(--line2);border-radius:var(--r);padding:6px 16px;margin-bottom:12px}.d-table td{border:0;padding:10px 0}.d-table td+td{border-top:1px solid var(--line)}.d-table td::before{content:attr(data-l);display:block;font-size:13px;color:var(--t3);margin-bottom:4px}.d-vs td:last-child{background:none;padding-left:0}.d-page .form .btn-lg{padding:0 16px}}.hdr .nav a{white-space:nowrap}.f-lazy:not(.bg-in){background-image:none!important}
.f-hero .hero-media{overflow:hidden}.f-hero .hero-media::after{content:"";position:absolute;inset:0 0 auto;height:200px;background:linear-gradient(180deg,rgba(9,9,11,.72),rgba(9,9,11,0));pointer-events:none}.f-hero .f-hero-img{position:absolute;inset:0;width:100%;height:100%;object-fit:cover;object-position:64% 50%;filter:saturate(.95)}.f-hero::before{background:linear-gradient(90deg,rgba(9,9,11,.92) 0%,rgba(9,9,11,.84) 40%,rgba(9,9,11,.32) 58%,rgba(9,9,11,0) 74%)}.f-hero::after{height:22%}.f-hero p.lead{max-width:600px}.f-crumbs{display:flex;flex-wrap:wrap;gap:8px;font-size:14px;color:var(--t3);margin:0 0 26px}.f-crumbs a{color:var(--t2)}.f-crumbs a:hover{color:var(--t1)}.f-urgent{margin:22px 0 0;color:var(--t2);font-size:15px}.f-urgent::before{content:"";display:inline-block;width:8px;height:8px;border-radius:50%;background:var(--grn);margin-right:10px;vertical-align:middle}
.f-checks{position:relative;padding:clamp(28px,3vw,56px) 0 clamp(56px,6vw,110px)}.f-check.panel{max-width:none}.f-check-in{position:relative;z-index:1;display:grid;grid-template-columns:minmax(0,.9fr) minmax(0,1.1fr);gap:clamp(24px,4vw,80px);padding:clamp(24px,3vw,52px)}.f-check-t{font-size:clamp(28px,2.6vw,48px);line-height:1.08;letter-spacing:-.04em;font-weight:300;margin:0}.f-check-res{margin:22px 0 10px;color:var(--t2);font-size:15px}.f-check-res b{font-size:clamp(40px,3.4vw,64px);font-weight:300;letter-spacing:-.04em;color:var(--acc);margin-right:6px;line-height:1;transition:color .3s}.f-check-res.full b{color:var(--grn)}.f-check-note{color:var(--t2);line-height:1.6;margin:0 0 28px;max-width:440px}.f-check-list{list-style:none;margin:0;padding:0;display:grid;align-content:center;border-top:1px solid var(--line)}.f-check-list li{border-bottom:1px solid var(--line)}.f-check-list label{display:flex;gap:18px;align-items:center;padding:18px 4px;cursor:pointer;font-size:clamp(16px,1.15vw,20px);line-height:1.4;color:var(--t2);transition:color .25s}.f-check-list label:hover{color:var(--t1)}.f-check-list input{appearance:none;-webkit-appearance:none;flex:none;width:26px;height:26px;margin:0;border-radius:8px;border:1.4px solid var(--line2);background:rgba(255,255,255,.03) center/14px no-repeat;cursor:pointer;transition:background-color .25s,border-color .25s}.f-check-list input:checked{background-color:var(--acc2);border-color:var(--acc);background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 14 14'%3E%3Cpath d='M2.5 7.5l3 3 6-7' fill='none' stroke='%23fff' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'/%3E%3C/svg%3E")}.f-check-list input:focus-visible{outline:2px solid var(--acc);outline-offset:3px}.f-check-list input:checked+span{color:var(--t1)}
.d-card .f-num{font-size:clamp(28px,2.4vw,44px);line-height:1.05;letter-spacing:-.035em;font-weight:300;color:var(--acc);margin:0 0 16px}.f-req .d-card{border-top:2px solid rgba(124,134,255,.45)}
.f-zmap{display:grid;grid-template-columns:minmax(0,1.4fr) minmax(0,1fr);gap:clamp(20px,2.4vw,44px);align-items:start}.f-plan{margin:0;padding:clamp(14px,1.4vw,26px)}.f-plan svg{display:block;width:100%;height:auto}.f-plan svg *{pointer-events:none}.f-plan .zf,.f-plan .bdg{pointer-events:all}.f-plan .zf{fill:transparent;transition:fill .3s,stroke .3s}.f-plan .z.on .zf{fill:rgba(124,134,255,.14)}.f-plan .z6.on .zf{fill:rgba(124,134,255,.05);stroke:#7c86ff}.f-plan .bdg circle{fill:#09090b;stroke:#7c86ff;stroke-width:2;transition:fill .3s}.f-plan .bdg text{fill:#7c86ff;font:500 22px Inter,system-ui,sans-serif;text-anchor:middle;dominant-baseline:central;transition:fill .3s}.f-plan .bdg.on circle{fill:#7c86ff}.f-plan .bdg.on text{fill:#fff}.f-plan .lbl text{fill:#84848e;font:400 15px Inter,system-ui,sans-serif}.f-legend{display:flex;flex-wrap:wrap;gap:10px 22px;margin:16px 4px 2px;font-size:13px;color:var(--t3)}.f-legend span{display:inline-flex;align-items:center;gap:9px}.f-legend i{flex:none;display:inline-block}.lg-st{width:11px;height:11px;border-radius:2px;background:var(--yel)}.lg-tr{width:11px;height:11px;border-radius:50%;background:var(--acc)}.lg-uv{width:20px;height:7px;border-radius:4px;background:#c4b5fd;box-shadow:0 0 8px rgba(167,139,250,.9)}.lg-fl{width:24px;border-top:2px dashed var(--acc)}.f-zlist{list-style:none;padding:0;margin:0;display:grid;gap:10px;counter-reset:zl}.f-zlist li{display:grid;grid-template-columns:40px minmax(0,1fr);gap:2px 14px;align-items:start;padding:15px 18px;border:1.4px solid var(--line);border-radius:var(--r);background:var(--card);transition:border-color .3s,background .3s;outline:none;cursor:default}.f-zlist li::before{counter-increment:zl;content:counter(zl);grid-row:1/span 2;width:34px;height:34px;border-radius:50%;border:1.4px solid var(--acc);color:var(--acc);display:flex;align-items:center;justify-content:center;font-size:15px;transition:background .3s,color .3s}.f-zlist b{font-weight:500;font-size:clamp(16px,1.05vw,19px);line-height:1.3}.f-zlist span{color:var(--t2);font-size:clamp(14px,.9vw,16px);line-height:1.5}.f-zlist li.on,.f-zlist li:hover,.f-zlist li:focus-visible{border-color:rgba(124,134,255,.6);background:rgba(124,134,255,.08)}.f-zlist li.on::before{background:var(--acc);color:#fff}
.f-steps4{grid-template-columns:repeat(4,minmax(0,1fr))}.d-steps li.f-alert{border-top-color:var(--yel)}.d-steps li.f-alert::before{color:var(--yel)}
.inds.f-inds{grid-template-columns:repeat(6,minmax(0,1fr))}.inds.f-inds>*{grid-column:span 2}.inds.f-inds>:nth-child(n+4){grid-column:span 3}.inds.f-inds>:nth-child(n+4) .ind-img{aspect-ratio:834/275}
.f-lbl{display:block;font-size:12px;letter-spacing:.08em;text-transform:uppercase;color:var(--acc);margin:4px 0 8px}.f-mb{margin:0 0 4px}.f-pricecard .f-price{margin:22px 0 26px;color:var(--t2);line-height:1.6}.f-pricecard .f-price b{display:block;color:var(--t1);font-weight:400;font-size:clamp(20px,1.6vw,28px);letter-spacing:-.02em;line-height:1.25;margin-bottom:6px}.d-card .btn{max-width:100%;white-space:normal;text-align:center;line-height:1.25}
@media (max-width:1100px){.f-steps4{grid-template-columns:repeat(2,minmax(0,1fr))}.f-zmap,.f-check-in{grid-template-columns:minmax(0,1fr)}.inds.f-inds{grid-template-columns:repeat(2,minmax(0,1fr))}.inds.f-inds>*,.inds.f-inds>:nth-child(n+4){grid-column:auto}.inds.f-inds>:nth-child(n+4) .ind-img{aspect-ratio:556/275}.inds.f-inds>:last-child{grid-column:1/-1}.inds.f-inds>:last-child .ind-img{aspect-ratio:834/275}}
@media (max-width:900px){.hdr{background:rgba(0,0,0,.72);backdrop-filter:blur(18px);-webkit-backdrop-filter:blur(18px);border-color:var(--line)}.f-hero{display:block;min-height:0;padding:68px 0 clamp(44px,8vw,72px)}.f-hero::before,.f-hero::after{display:none}.f-hero .hero-media{position:relative;inset:auto;width:100%;aspect-ratio:16/9}.f-hero .hero-media::after{height:100%;background:linear-gradient(180deg,rgba(0,0,0,0) 62%,#000 100%)}.f-hero .f-hero-img{object-position:70% 50%;filter:none}.f-hero .wrap{margin-top:-24px}.f-hero p.lead{max-width:760px}}@media (max-width:760px){.f-hero .hero-media{aspect-ratio:4/3}.f-hero .f-hero-img{object-position:50% 50%}.f-crumbs{font-size:13px;margin-bottom:18px}.inds.f-inds{grid-template-columns:minmax(0,1fr)}.inds.f-inds>:last-child{grid-column:auto}.inds.f-inds>:last-child .ind-img{aspect-ratio:556/275}}
@media (max-width:600px){.f-steps4{grid-template-columns:minmax(0,1fr)}.d-btns .btn,.d-card .btn,.f-check .btn{width:100%;white-space:normal;text-align:center;line-height:1.25}.d-page .btn-lg{padding:0 16px}.f-plan .lbl{display:none}.f-check-in{padding:24px 20px}.f-check-list label{padding:15px 2px;gap:14px}.f-zlist li{padding:14px}}
@media (max-width:400px){.hdr .wrap{gap:10px}.hdr-right{gap:8px}.logo{gap:8px}.logo-mark{width:34px;height:34px}.logo-name{font-size:15px}.phone i,.burger{width:40px;height:40px}}@media (max-width:340px){.logo-sub{display:none}}
/* ===== Страница «Лабораторные исследования» (/laboratornye-issledovaniya/): дополнения к стилям отраслевой страницы ===== */
.lb-page .f-hero .f-hero-img{object-position:64% 40%}
@media (min-width:761px){.lb-page .hero h1{font-size:clamp(38px,3.4vw,66px)}}
.lb-hero-list{list-style:none;padding:0;margin:26px 0 0;display:grid;gap:10px;max-width:640px}
.lb-hero-list li{position:relative;padding-left:28px;color:#c4c4cc;line-height:1.5;font-size:clamp(15px,.95vw,18px)}
.lb-hero-list li::before{content:"";position:absolute;left:2px;top:.45em;width:12px;height:6px;border-left:2px solid var(--acc);border-bottom:2px solid var(--acc);transform:rotate(-45deg)}
.lb-upd a,.lb-short a,#ceny .d-note a,#nabory .sub a,.lb-principles a{color:var(--t2);border-bottom:1px solid var(--line2);transition:color .25s,border-color .25s}
.lb-upd a:hover,.lb-short a:hover,#ceny .d-note a:hover,#nabory .sub a:hover{color:var(--t1);border-color:var(--acc)}

/* определение и «коротко» */
.lb-def{margin:0 0 clamp(28px,3vw,44px);padding:clamp(18px,1.6vw,26px) clamp(20px,2vw,30px);border:1px solid var(--line2);border-left:2px solid var(--acc);border-radius:var(--r);background:var(--card);color:var(--t2);line-height:1.65;max-width:1100px;font-size:clamp(16px,1.05vw,19px)}
.lb-def b{color:var(--t1);font-weight:500}
.d-table.lb-short{max-width:1100px}
.lb-short th{width:240px;color:var(--t3);font-size:15px}
.d-table.lb-short td,.d-table.lb-short td:first-child{color:#c4c4cc}
.lb-upd{margin:20px 0 0;font-size:14px;line-height:1.6;color:var(--t3)}

/* направления — плитки */
.lb-tiles{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:12px}
.lb-tile{display:grid;grid-template-columns:96px minmax(0,1fr);grid-template-rows:auto auto 1fr;column-gap:18px;row-gap:4px;align-items:start;padding:14px 18px 14px 14px;color:var(--t1);transition:border-color .2s,background .2s}
.lb-tile:hover{border-color:rgba(124,134,255,.6)}
.lb-tile-ic{grid-row:1/4;display:block;width:96px;height:96px;transition:transform .35s cubic-bezier(.2,.7,.2,1)}
.lb-tile:hover .lb-tile-ic{transform:scale(1.06)}
.lb-tile b{grid-column:2;font-weight:500;font-size:16px;line-height:1.3;padding-top:4px}
.lb-tile-d{grid-column:2;color:var(--t3);font-size:13.5px;line-height:1.45}
.lb-tile-p{grid-column:2;padding-top:6px;font-size:17px;letter-spacing:-.02em;color:var(--t1)}
.lb-steps li{display:flex;flex-direction:column;border-top:0;padding-top:0}
.lb-steps .lb-step-ic{order:0;display:block;width:120px;height:120px;margin:0 0 14px -6px}
.lb-steps li::before{order:1;border-top:2px solid rgba(124,134,255,.35);padding-top:14px}
.lb-steps li b{order:2}.lb-steps li span{order:3}

/* прайс — группы */
.lb-price{display:grid;gap:12px}
.lb-grp{border:1px solid var(--line2);border-radius:var(--r);background:var(--card);scroll-margin-top:96px}
.lb-grp>summary{list-style:none;display:grid;grid-template-columns:auto minmax(0,1fr) auto 28px;align-items:center;gap:14px;padding:16px clamp(16px,1.6vw,24px);cursor:pointer;border-radius:var(--r)}
.lb-grp>summary::-webkit-details-marker{display:none}
.lb-grp>summary:focus-visible{outline:2px solid var(--acc);outline-offset:2px}
.lb-grp-ic{display:inline-flex;color:var(--acc)}
.lb-grp-ic svg{width:22px;height:22px}
.lb-grp-n{font-size:clamp(17px,1.15vw,20px);color:var(--t1);letter-spacing:-.01em}
.lb-grp-c{font-size:14px;color:var(--t3);white-space:nowrap}
.lb-grp .pm{position:relative;width:20px;height:20px;justify-self:end}
.lb-grp .pm::before,.lb-grp .pm::after{content:"";position:absolute;left:3px;right:3px;top:9px;height:1.6px;background:var(--t2);transition:transform .25s}
.lb-grp .pm::after{transform:rotate(90deg)}
.lb-grp[open] .pm::after{transform:rotate(0)}
.lb-grp[open]>summary{border-bottom:1px solid var(--line2);border-radius:var(--r) var(--r) 0 0}
.d-table.lb-tbl{margin:0;border:0;border-radius:0}
.lb-tbl thead th{font-size:13px;color:var(--t3);font-weight:400}
.lb-tbl th:nth-child(2),.lb-tbl td:nth-child(2){width:140px}
.lb-tbl th:nth-child(3),.lb-tbl td:nth-child(3){width:160px;text-align:right}
.lb-tbl th:nth-child(4),.lb-tbl td:nth-child(4){width:150px;text-align:right}
.d-table.lb-tbl td{vertical-align:middle;color:#c4c4cc}
.d-table.lb-tbl td.lb-tn{color:var(--t1)}
.lb-tbl td.lb-tp{white-space:nowrap;color:var(--t1);font-variant-numeric:tabular-nums}
.lb-tbl tr.lb-on td{background:rgba(124,134,255,.06)}
.lb-add{display:inline-flex;align-items:center;justify-content:center;width:40px;height:40px;border-radius:50%;border:1.4px solid rgba(124,134,255,.55);background:transparent;color:var(--t1);font-size:22px;line-height:1;cursor:pointer;transition:background .2s,border-color .2s}
.lb-add:hover{background:rgba(124,134,255,.15);border-color:var(--acc)}
.lb-qty{display:inline-flex;align-items:center;border:1.4px solid var(--acc);border-radius:999px;overflow:hidden;height:40px}
.lb-qty button{width:36px;height:100%;background:transparent;border:0;color:var(--t1);font-size:20px;cursor:pointer}
.lb-qty button:hover{background:rgba(124,134,255,.15)}
.lb-qty input{width:46px;height:100%;border:0;background:transparent;color:var(--t1);text-align:center;font:inherit;font-size:16px;-moz-appearance:textfield}
.lb-qty input::-webkit-outer-spin-button,.lb-qty input::-webkit-inner-spin-button{-webkit-appearance:none;margin:0}

/* наборы по видам объектов */
.lb-sets{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:14px}
.lb-set{display:flex;flex-direction:column;gap:12px;padding:clamp(20px,1.8vw,28px)}
.lb-set p{margin:0}
.lb-set-n{font-size:clamp(18px,1.3vw,22px);color:var(--t1);letter-spacing:-.02em}
.lb-set-d{color:var(--t3);font-size:14px;line-height:1.5}
.lb-set-l{list-style:none;padding:0;margin:0;border-top:1px solid var(--line2)}
.lb-set-l li{display:flex;justify-content:space-between;gap:12px;padding:8px 0;border-bottom:1px solid var(--line);font-size:14px;line-height:1.4;color:var(--t2)}
.lb-set-q{white-space:nowrap;color:var(--t1);font-variant-numeric:tabular-nums}
.lb-set-t{margin-top:auto!important;font-size:clamp(18px,1.3vw,22px);color:var(--t1);letter-spacing:-.02em}
.lb-set-f{display:flex;align-items:center;gap:12px;flex-wrap:wrap}
.lb-set-b.btn{margin:0}
.lb-set-ok{color:var(--acc);font-size:14px}
.lb-bar-go.btn{margin:0}

/* что вы получите */
.lb-docs{list-style:none;counter-reset:ld;padding:0;margin:0;display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:14px}
.lb-docs li{background:var(--card);border:1px solid var(--line2);border-top:2px solid rgba(124,134,255,.45);border-radius:var(--r);padding:clamp(20px,1.8vw,28px);line-height:1.5}
.lb-docs li::before{counter-increment:ld;content:"0" counter(ld);display:block;color:var(--acc);font-size:14px;margin-bottom:14px}
.lb-docs b{display:block;font-weight:500;line-height:1.3;margin-bottom:8px;font-size:clamp(17px,1.15vw,20px)}
.lb-docs li>span{color:var(--t2);font-size:15px;line-height:1.55}

/* вместе с услугами */
.lb-with{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:14px}
.lb-with-c{display:flex;flex-direction:column;gap:10px;padding:clamp(20px,1.8vw,28px);color:var(--t1)}
.lb-with-c b{font-weight:500;font-size:clamp(17px,1.15vw,20px)}
.lb-with-c>span:not(.nb-link-go){color:var(--t2);font-size:15px;line-height:1.55}
.lb-with-c .nb-link-go{margin-top:auto;color:var(--t2);font-size:14px}
.lb-with-c:hover{border-color:rgba(124,134,255,.6)}

/* автор */
.lb-author-wrap{display:grid;grid-template-columns:minmax(0,.75fr) minmax(0,1.25fr);gap:clamp(24px,3vw,56px);align-items:start}
.lb-author{display:flex;gap:20px;align-items:center;padding:clamp(24px,2.4vw,36px)}
.lb-avatar{flex:none;display:block;width:112px;height:112px;border-radius:50%;object-fit:cover;background:#18181b;border:1px solid rgba(124,134,255,.4)}
.lb-author p{margin:0}
.lb-author-name{font-size:clamp(20px,1.5vw,26px);color:var(--t1);letter-spacing:-.02em;margin-bottom:4px!important}
.lb-author-role{color:var(--t2);margin-bottom:4px!important}
.lb-author-date{color:var(--t3);font-size:14px}
.lb-author-note{color:var(--t3);font-size:13px;margin-top:6px!important}
.lb-principles{list-style:none;padding:0;margin:0;border-top:1px solid var(--line2)}
.lb-principles li{padding:18px 0;border-bottom:1px solid var(--line2);color:var(--t2);line-height:1.6}
.lb-principles b{color:var(--t1);font-weight:500}

/* нормативная база */
.lb-base{list-style:none;padding:0;margin:0;border-top:1px solid var(--line2);max-width:1200px}
.lb-base li{position:relative;padding:14px 0 14px 30px;border-bottom:1px solid var(--line2);color:var(--t2);line-height:1.6;font-size:15px}
.lb-base li::before{content:"§";position:absolute;left:4px;top:14px;color:var(--acc)}
.lb-base a,#normativnaya-baza .sub a{color:var(--t1);border-bottom:1px solid rgba(124,134,255,.45);transition:border-color .25s}
.lb-base a:hover,#normativnaya-baza .sub a:hover{border-color:var(--t1)}

/* расчёт в заявке */
.lb-fcalc{margin:0 0 18px;padding:14px 16px;border:1px solid rgba(124,134,255,.45);border-radius:12px;background:rgba(124,134,255,.06)}
.lb-fcalc[hidden]{display:none}
.lb-fcalc-h{margin:0 0 8px;font-size:13px;color:var(--acc);text-transform:uppercase;letter-spacing:.08em}
.lb-fcalc ul{list-style:none;padding:0;margin:0;max-height:180px;overflow:auto}
.lb-fcalc li{display:flex;justify-content:space-between;gap:10px;padding:4px 0;font-size:14px;line-height:1.4;color:var(--t2)}
.lb-fcalc li span:last-child{white-space:nowrap;color:var(--t1)}
.lb-fcalc-t{margin:8px 0 0;padding-top:8px;border-top:1px solid var(--line2);color:var(--t1);font-size:16px}

/* панель расчёта внизу экрана */
.lb-bar{position:fixed;left:0;right:0;bottom:0;z-index:60;padding:10px clamp(12px,2vw,24px) calc(10px + env(safe-area-inset-bottom));pointer-events:none}
.lb-bar[hidden]{display:none}
.lb-bar-in{pointer-events:auto;max-width:980px;margin:0 auto;display:flex;align-items:center;gap:14px;padding:10px 10px 10px 22px;border:1px solid rgba(124,134,255,.5);border-radius:999px;background:rgba(14,14,18,.94);backdrop-filter:blur(12px);-webkit-backdrop-filter:blur(12px);box-shadow:0 18px 50px rgba(0,0,0,.55)}
.lb-bar-t{margin:0;display:flex;align-items:baseline;gap:14px;flex:1;min-width:0;color:var(--t2);font-size:15px}
.lb-bar-t b{color:var(--t1);font-weight:400;font-size:clamp(18px,1.4vw,22px);letter-spacing:-.02em;white-space:nowrap}
.lb-bar-clear{background:none;border:0;color:var(--t3);font:inherit;font-size:14px;cursor:pointer;padding:8px}
.lb-bar-clear:hover{color:var(--t1)}
.lb-bar-go{white-space:nowrap}
body.lb-has-bar .float-btns,body.lb-has-bar .fab{bottom:96px}

/* «Подробнее» в прайсе (ссылки на страницы направлений) и материалы раздела — с 11.11.2026 */
.lb-grp .more{margin:0;padding:14px clamp(16px,1.6vw,24px) 18px;border-top:1px solid var(--line)}
.lb-with.lb-with-3{grid-template-columns:repeat(3,minmax(0,1fr))}
.lb-tile-p svg{width:14px;height:14px;margin-left:8px;vertical-align:-1px;color:var(--acc);transition:transform .35s cubic-bezier(.2,.7,.2,1)}
.lb-tile-pg:hover .lb-tile-p svg{transform:translateX(3px)}
#napravleniya .more{margin-top:clamp(20px,2vw,28px)}
@media (max-width:1180px){.lb-tiles{grid-template-columns:repeat(3,minmax(0,1fr))}.lb-with{grid-template-columns:repeat(2,minmax(0,1fr))}}
@media (max-width:900px){
.lb-tiles,.lb-sets{grid-template-columns:repeat(2,minmax(0,1fr))}
.lb-with.lb-with-3{grid-template-columns:minmax(0,1fr)}
.lb-docs{grid-template-columns:minmax(0,1fr)}
.lb-author-wrap{grid-template-columns:minmax(0,1fr)}
.lb-tbl thead{display:none}
.lb-tbl,.lb-tbl tbody{display:block;width:100%}
.d-table.lb-tbl tr{display:grid;grid-template-columns:auto minmax(0,1fr) auto;column-gap:8px;row-gap:4px;align-items:center;padding:12px 16px;margin:0;border:0;border-top:1px solid var(--line);border-radius:0}
.d-table.lb-tbl tr:first-child{border-top:0}
.d-table.lb-tbl tr.lb-on{background:rgba(124,134,255,.06)}
.d-table.lb-tbl tr.lb-on td{background:none}
.d-table.lb-tbl td{display:block;border:0!important;padding:0!important;width:auto!important;text-align:left!important}
.d-table.lb-tbl td:not(.lb-tu)::before{content:none!important;display:none!important}
.d-table.lb-tbl td.lb-tu::before{content:"· "!important;display:inline!important;margin:0!important;font-size:inherit!important;color:inherit!important}
.d-table.lb-tbl td.lb-tn{grid-column:1/3;grid-row:1;font-size:15px;line-height:1.4}
.d-table.lb-tbl td.lb-tp{grid-column:1;grid-row:2;font-size:16px}
.d-table.lb-tbl td.lb-tu{grid-column:2;grid-row:2;font-size:13px;color:var(--t3)}
.d-table.lb-tbl td.lb-tc{grid-column:3;grid-row:1/3;align-self:center}
}
@media (max-width:760px){
.lb-page .f-hero .f-hero-img{object-position:50% 40%}
.lb-page .hero h1{font-size:clamp(28px,8.2vw,40px)}
.lb-grp>summary{grid-template-columns:auto minmax(0,1fr) 24px;row-gap:2px}
.lb-grp-c{grid-column:2;grid-row:2;white-space:normal}
.lb-grp .pm{grid-column:3;grid-row:1/3}
.lb-bar{padding:8px 8px calc(8px + env(safe-area-inset-bottom))}
.lb-bar-in{border-radius:18px;padding:10px 10px 10px 16px;gap:8px}
.lb-bar-t{flex-direction:column;gap:0;font-size:13px}
.lb-bar-clear{display:none}
}
@media (max-width:600px){
.lb-tiles{grid-template-columns:minmax(0,1fr);gap:8px}
.lb-tile{grid-template-columns:64px minmax(0,1fr);grid-template-rows:auto auto;column-gap:14px;row-gap:2px;align-items:center;padding:8px 14px 8px 8px}
.lb-tile-ic{grid-row:1/3;width:64px;height:64px}
.lb-tile-d{display:none}
.lb-tile b{font-size:15px;padding-top:0}
.lb-tile-p{padding-top:0;font-size:14px;color:var(--t2)}
.lb-steps li{display:grid;grid-template-columns:72px minmax(0,1fr);column-gap:14px;align-content:start}
.lb-steps .lb-step-ic{grid-row:1/4;width:72px;height:72px;margin:0}
.lb-steps li::before{grid-column:2;border-top:0;padding-top:0;margin-bottom:4px}
.lb-steps li b,.lb-steps li span{grid-column:2}
.lb-sets,.lb-with{grid-template-columns:minmax(0,1fr)}
.lb-set-f .lb-set-b{width:100%}
.lb-short th{display:block;width:100%;border:0;padding:12px 0 2px;font-size:13px}
.d-table.lb-short td{padding:0 0 12px}
.d-table.lb-short tr{padding:4px 16px}
.lb-author{align-items:flex-start}
.lb-avatar{width:80px;height:80px}
}
/* ===== Страницы направлений и статьи раздела «Лабораторные исследования» (11.11.2026): дополнения к page.css ===== */
.lbs-p{max-width:980px;margin:0 0 18px;color:var(--t2);line-height:1.7;font-size:clamp(16px,1.02vw,18px)}
.lbs-p b{color:var(--t1);font-weight:500}
.lbs-p:last-child{margin-bottom:0}
.lbs-page .lbs-p a,.lbs-page .d-card a,.lbs-page .lbs-t a,.lbs-page .d-ticks a,.lbs-page .d-terms a,.lbs-page .d-note a,.lbs-page .lb-def a,.lbs-page #normativnaya-baza .sub a{color:var(--t1);border-bottom:1px solid rgba(124,134,255,.45);transition:border-color .25s}
.lbs-page .lbs-p a:hover,.lbs-page .d-card a:hover,.lbs-page .lbs-t a:hover,.lbs-page .d-ticks a:hover,.lbs-page .d-terms a:hover,.lbs-page .d-note a:hover,.lbs-page .lb-def a:hover{border-color:var(--t1)}
.lbs-h3{margin:clamp(30px,3vw,46px) 0 16px;font-size:clamp(20px,1.5vw,26px);font-weight:400;letter-spacing:-.02em;color:var(--t1)}
.lbs-h3:first-child{margin-top:0}

/* таблицы с содержанием (показатели, нормы, периодичность) */
.d-table.lbs-t{max-width:1200px}
.d-table.lbs-t thead th{font-size:13px;color:var(--t3);font-weight:400}
.d-table.lbs-t td{color:var(--t2)}
.d-table.lbs-t td:first-child{color:var(--t1)}
.lbs-t td.lbs-n{white-space:nowrap;font-variant-numeric:tabular-nums;color:var(--t1)}
.lbs-cap{max-width:1200px;margin:12px 0 0;font-size:14px;color:var(--t3);line-height:1.5}
.lbs-t+.d-ticks,.lbs-cap+.d-ticks,.lbs-t+.lbs-p,.lbs-cap+.lbs-p,.lbs-cards+.lbs-p,.d-ticks+.lbs-h3,.lbs-t+.lbs-h3{margin-top:28px}

/* карточки и списки */
.d-cards.lbs-cards{margin-top:4px}
.d-cards.lbs-c2{grid-template-columns:repeat(2,minmax(0,1fr))}
.d-card.lbs-card h3{font-size:clamp(18px,1.3vw,22px)}
.d-card.lbs-card p+p,.d-card.lbs-card p+ul,.d-card.lbs-card ul+p{margin-top:10px}
.d-card.lbs-card ul{margin:10px 0 0;padding-left:18px;color:var(--t2);line-height:1.55}
.d-card.lbs-card li+li{margin-top:4px}
.lbs-k{display:block;font-size:12px;letter-spacing:.1em;text-transform:uppercase;color:var(--acc);margin:0 0 10px}
.d-ticks.lbs-ticks{margin:0;max-width:1000px}
.d-ticks.lbs-ticks li{color:var(--t2)}
.d-ticks.lbs-ticks b{color:var(--t1);font-weight:500}
.d-terms.lbs-terms{max-width:1100px}
.d-terms.lbs-terms li{grid-template-columns:44px minmax(0,.4fr) minmax(0,1fr)}
.lbs-split{display:grid;grid-template-columns:minmax(0,1.15fr) minmax(0,.85fr);gap:clamp(24px,3vw,56px);align-items:start}
.lbs-split>*{min-width:0}

/* переход со статьи на страницу услуги */
.lbs-go{display:grid;grid-template-columns:minmax(0,1fr) auto;gap:20px 32px;align-items:center;margin-top:clamp(28px,3vw,44px);padding:clamp(22px,2vw,32px);border-left:2px solid var(--acc)}
.lbs-go p{margin:0;color:var(--t2);line-height:1.6}
.lbs-go b{display:block;color:var(--t1);font-weight:500;font-size:clamp(18px,1.3vw,22px);margin-bottom:6px;letter-spacing:-.01em}
.lbs-go .btn{margin:0;white-space:nowrap}
.lbs-go-b{display:flex;flex-wrap:wrap;gap:10px}


@media (max-width:900px){
.d-cards.lbs-c2,.lbs-split{grid-template-columns:minmax(0,1fr)}
.lbs-t td.lbs-n{white-space:normal}
.d-terms.lbs-terms li{grid-template-columns:36px minmax(0,1fr)}
}
@media (max-width:600px){
.lbs-go{grid-template-columns:minmax(0,1fr)}
.lbs-go .btn{width:100%;white-space:normal;text-align:center}
.lbs-go-b .btn{flex:1 1 100%}
}</style>
<script type="application/ld+json">{"@context": "https://schema.org", "@graph": [{"@type": "Organization", "@id": "https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/#org", "name": "ПЕСТКОНТРОЛЬ Центр", "legalName": "ООО «Центр дезинфекционных услуг»", "url": "https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/", "telephone": "+7 495 104-35-70", "email": "b2b@pestcontrol-center.ru"}, {"@type": "BreadcrumbList", "itemListElement": [{"@type": "ListItem", "position": 1, "name": "Главная", "item": "https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/"}, {"@type": "ListItem", "position": 2, "name": "Лабораторные исследования", "item": "https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/laboratornye-issledovaniya/"}, {"@type": "ListItem", "position": 3, "name": "Замер освещённости", "item": "https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/laboratornye-issledovaniya/zamer-osveshchennosti/"}], "@id": "https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/laboratornye-issledovaniya/zamer-osveshchennosti/#crumbs"}, {"@type": "Service", "@id": "https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/laboratornye-issledovaniya/zamer-osveshchennosti/#service", "name": "Замер освещённости на рабочих местах", "alternateName": ["Измерение освещённости", "Проверка освещённости", "Измерение освещённости люксметром", "Контроль освещённости", "Замер освещённости рабочих мест"], "serviceType": "Инструментальные измерения освещённости по программе производственного контроля", "description": "Измерение освещённости люксметром по ГОСТ 24940-2016 и МУК 4.3.3975-24 — от 350 ₽ за точку. Офисы, цеха, склады, салоны красоты; сравнение с нормами СанПиН 1.2.3685-21 и протокол для ППК.", "url": "https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/laboratornye-issledovaniya/zamer-osveshchennosti/", "provider": {"@id": "https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/#org"}, "areaServed": [{"@type": "City", "name": "Москва"}, {"@type": "AdministrativeArea", "name": "Московская область"}], "isRelatedTo": {"@type": "Service", "name": "Лабораторные исследования по программе производственного контроля", "url": "https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/laboratornye-issledovaniya/"}, "hasOfferCatalog": {"@type": "OfferCatalog", "name": "Цены: Замер освещённости", "itemListElement": [{"@type": "Offer", "itemOffered": {"@type": "Service", "name": "Измерение освещённости"}, "priceSpecification": {"@type": "UnitPriceSpecification", "minPrice": 350, "priceCurrency": "RUB", "unitText": "точка"}}, {"@type": "Offer", "itemOffered": {"@type": "Service", "name": "Измерение микроклимата"}, "priceSpecification": {"@type": "UnitPriceSpecification", "minPrice": 350, "priceCurrency": "RUB", "unitText": "точка"}}, {"@type": "Offer", "itemOffered": {"@type": "Service", "name": "Измерение шума"}, "priceSpecification": {"@type": "UnitPriceSpecification", "minPrice": 500, "priceCurrency": "RUB", "unitText": "точка"}}, {"@type": "Offer", "itemOffered": {"@type": "Service", "name": "Комплекс измерений на рабочих местах"}, "priceSpecification": {"@type": "UnitPriceSpecification", "minPrice": 2600, "priceCurrency": "RUB", "unitText": "комплекс"}}]}}, {"@type": "WebPage", "@id": "https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/laboratornye-issledovaniya/zamer-osveshchennosti/#webpage", "url": "https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/laboratornye-issledovaniya/zamer-osveshchennosti/", "name": "Замер освещённости на рабочих местах — цена от 350 ₽ за точку, Москва — ПЕСТКОНТРОЛЬ Центр", "description": "Измерение освещённости люксметром по ГОСТ 24940-2016 и МУК 4.3.3975-24 — от 350 ₽ за точку. Офисы, цеха, склады, салоны красоты; сравнение с нормами СанПиН 1.2.3685-21 и протокол для ППК.", "inLanguage": "ru", "datePublished": "2026-11-11", "dateModified": "2026-11-11", "author": {"@type": "Person", "name": "Марианна Семерина", "jobTitle": "Санитарный врач"}, "publisher": {"@id": "https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/#org"}, "breadcrumb": {"@id": "https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/laboratornye-issledovaniya/zamer-osveshchennosti/#crumbs"}, "about": [{"@id": "https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/laboratornye-issledovaniya/zamer-osveshchennosti/#service"}, {"@id": "https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/laboratornye-issledovaniya/zamer-osveshchennosti/#term"}], "primaryImageOfPage": {"@type": "ImageObject", "url": "https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/img/lab-osveshchennost-hero.webp", "width": 1920, "height": 1072, "caption": "Специалист лаборатории измеряет освещённость рабочего стола люксметром в офисе в тёмное время суток"}, "image": [{"@type": "ImageObject", "url": "https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/img/lab-osveshchennost-hero.webp", "width": 1920, "height": 1072, "caption": "Специалист лаборатории измеряет освещённость рабочего стола люксметром в офисе в тёмное время суток"}, {"@type": "ImageObject", "url": "https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/img/lab-osveshchennost-og.jpg", "width": 1200, "height": 630}]}, {"@type": "DefinedTerm", "@id": "https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/laboratornye-issledovaniya/zamer-osveshchennosti/#term", "name": "Замер освещённости", "description": "Замер освещённости — измерение освещённости рабочих поверхностей люксметром в контрольных точках помещения и сравнение результата с нормой СанПиН 1.2.3685-21 для вида помещения и характера работы. Методы измерений установлены ГОСТ 24940-2016, порядок оценки световой среды на рабочих местах — МУК 4.3.3975-24. Результат нужен для производственного контроля условий труда."}, {"@type": "FAQPage", "@id": "https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/laboratornye-issledovaniya/zamer-osveshchennosti/#faq", "mainEntity": [{"@type": "Question", "name": "Сколько стоит замер освещённости?", "acceptedAnswer": {"@type": "Answer", "text": "От 350 ₽ за точку. Итог зависит от числа помещений, рабочих мест и расположения светильников. Соберите расчёт или пришлите план помещений — назовём точную сумму до выезда."}}, {"@type": "Question", "name": "Как часто нужно измерять освещённость на рабочих местах?", "acceptedAnswer": {"@type": "Answer", "text": "С кратностью из программы производственного контроля. По п. 15 СП 2.2.4285-26 её устанавливает работодатель — обязательно там, где освещённость не соответствовала нормам при спецоценке или прежних замерах, и после реконструкции или капремонта. В салонах красоты и парикмахерских — 1 раз в год (п. 99.38 СП 2.1.4284-26)."}}, {"@type": "Question", "name": "Какая норма освещённости в офисе?", "acceptedAnswer": {"@type": "Answer", "text": "Для кабинетов, рабочих комнат и офисов — 300 лк при общем освещении и 400 лк при комбинированном, коэффициент пульсации — не более 15 %. Для залов персональных компьютеров — 400 и 500 лк, пульсация — не более 5 % (СанПиН 1.2.3685-21)."}}, {"@type": "Question", "name": "Почему замер проводят вечером?", "acceptedAnswer": {"@type": "Answer", "text": "Искусственное освещение измеряют в тёмное время суток, когда естественный свет не превышает 10 % искусственного (п. 6.1.1 ГОСТ 24940-2016). Днём замер возможен, если плотно занавесить окна."}}, {"@type": "Question", "name": "Чем измеряют освещённость?", "acceptedAnswer": {"@type": "Answer", "text": "Люксметром с погрешностью не более 10 % и действующей поверкой (пп. 4.1–4.2 ГОСТ 24940-2016). Приложение в телефоне для протокола не подходит."}}, {"@type": "Question", "name": "Что такое коэффициент пульсации освещённости?", "acceptedAnswer": {"@type": "Answer", "text": "Это показатель того, насколько сильно мерцает свет. Глаз пульсацию почти не замечает, но она утомляет при долгой работе. Для офисов норма — не более 15 %, для залов персональных компьютеров — не более 5 %. Нужен ли этот показатель в вашем протоколе, сверим с программой производственного контроля."}}, {"@type": "Question", "name": "Сколько точек нужно для замера?", "acceptedAnswer": {"@type": "Answer", "text": "Точки выбирают по плану помещения: минимальную освещённость проверяют под светильниками, между ними и у стен, среднюю — по сетке точек. На каждом рабочем месте измеряют освещённость его рабочей поверхности. Пришлите план — посчитаем точки заранее."}}, {"@type": "Question", "name": "Можно ли использовать результаты спецоценки условий труда?", "acceptedAnswer": {"@type": "Answer", "text": "Можно, если измерения спецоценки проведены аккредитованной лабораторией не раньше чем за 6 месяцев до производственного контроля (п. 1.1 ст. 32 Федерального закона № 52-ФЗ)."}}]}]}</script>
<style id="srch-st">/* лупа поиска в шапке и раскладка шапки с ней (tools/menu/apply_menu.py) */.srch-btn{flex:none;width:44px;height:44px;padding:0;border-radius:50%;display:grid;place-items:center;background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.1);color:#fff;cursor:pointer;transition:color .25s,border-color .3s,background .3s,transform .35s cubic-bezier(.16,1,.3,1)}.srch-btn:hover{border-color:#7c86ff;background:rgba(97,95,255,.2);transform:translateY(-2px)}.srch-btn:focus-visible{outline:2px solid #7c86ff;outline-offset:2px}.srch-btn svg{width:18px;height:18px;display:block}@media (min-width:761px){.hdr .wrap{gap:16px}.hdr .msg{display:none}.srch-btn{width:38px;height:38px;background:none;border-color:transparent;color:var(--t2);margin-right:calc(4px - clamp(14px,2vw,40px))}.srch-btn svg{width:20px;height:20px}.srch-btn:hover{color:#fff;background:rgba(255,255,255,.07);border-color:rgba(255,255,255,.1);transform:none}}@media (min-width:761px) and (max-width:1440px){.hdr-right{gap:18px}.srch-btn{margin-right:-14px}}@media (min-width:761px) and (max-width:1000px){.hdr-right{gap:12px}.srch-btn{margin-right:-8px}}@media (max-width:900px){.logo-txt{display:flex;flex-direction:column;align-items:flex-start}.logo-sub{margin:0}}@media (max-width:760px){.hdr .wrap{gap:12px}.hdr-right{gap:8px}}@media (max-width:400px){.hdr .wrap{gap:10px}.srch-btn{width:40px;height:40px}}@media (max-width:360px){.hdr .wrap{gap:8px}.hdr-right{gap:6px}.srch-btn,.phone i,.burger{width:38px;height:38px}}@media (max-width:340px){.logo-mark{display:none}.logo-sub{display:block}}</style><script id="srch-js">/* поиск по сайту: движок и индекс загружаются по первому нажатию на лупу или «/» (tools/search) */(function(r,v){var d=document,ld=0,w=null;function go(o){if(window.PCSearch)return window.PCSearch.open(r,v,o);w=o;if(ld)return;ld=1;var s=d.createElement("script");s.src=r+"search.min.js?v="+v;s.async=true;s.onload=function(){window.PCSearch&&window.PCSearch.open(r,v,w)};s.onerror=function(){ld=0};d.head.appendChild(s)}d.addEventListener("click",function(e){var b=e.target.closest&&e.target.closest("[data-srch]");if(b){e.preventDefault();go({btn:b})}});d.addEventListener("keydown",function(e){if(e.key!=="/"||e.ctrlKey||e.metaKey||e.altKey)return;var t=e.target,n=t&&t.tagName;if(n==="INPUT"||n==="TEXTAREA"||n==="SELECT"||t.isContentEditable)return;e.preventDefault();go({})});if(/^#q\d+$/.test(location.hash)){var c=0,t=setInterval(function(){var b=d.getElementById(location.hash.slice(1));if(b&&d.documentElement.classList.contains("anim-ready")){clearInterval(t);if(b.getAttribute("aria-expanded")==="false")b.click()}else if(++c>60)clearInterval(t)},150)}})("../../","20261108");</script>
<style data-fx>
/* подсветка рамки карточек за курсором — как у .card на главной (tools/site/fx.py) */
:where(.d-card,.p-sec,.p-fcard,.p-duty-box,.p-dl-card,.pm-step-card,.pm-scen,.pm-link-card,.k-err,.w-sample,.d-doc-prev){position:relative}
:where(.d-card,.p-sec,.p-fcard,.p-duty-box,.p-dl-card,.pm-step-card,.pm-scen,.pm-link-card,.k-err,.w-sample,.d-doc-prev)::after{content:"";position:absolute;inset:0;border-radius:inherit;padding:1.4px;pointer-events:none;background:radial-gradient(360px circle at var(--mx,-999px) var(--my,-999px),rgba(124,134,255,.85),rgba(124,134,255,.15) 35%,transparent 60%);-webkit-mask:linear-gradient(#000 0 0) content-box,linear-gradient(#000 0 0);-webkit-mask-composite:xor;mask:linear-gradient(#000 0 0) content-box,linear-gradient(#000 0 0);mask-composite:exclude;opacity:0;transition:opacity .4s;z-index:2}
@media (hover:hover) and (pointer:fine){:where(.d-card,.p-sec,.p-fcard,.p-duty-box,.p-dl-card,.pm-step-card,.pm-scen,.pm-link-card,.k-err,.w-sample,.d-doc-prev):hover::after{opacity:1}}
/* «фонарь» на фото первого экрана — как на главной (tools/site/fx.py) */
.fx-lit{position:absolute;inset:0;opacity:0;pointer-events:none;-webkit-mask-image:radial-gradient(circle var(--sr,320px) at var(--sx,72%) var(--sy,46%),#000 0%,rgba(0,0,0,.55) 45%,transparent 72%);mask-image:radial-gradient(circle var(--sr,320px) at var(--sx,72%) var(--sy,46%),#000 0%,rgba(0,0,0,.55) 45%,transparent 72%);transition:opacity 1.8s cubic-bezier(.16,1,.3,1)}
#hero :is(.d-hero-media,.hero-media)>picture>img{transition:filter 1.8s cubic-bezier(.16,1,.3,1)}
#hero.fx-lit-on :is(.d-hero-media,.hero-media)>picture>img{filter:grayscale(.3) brightness(.56)}
#hero.fx-lit-on .fx-lit img{filter:brightness(1.08) contrast(1.06) saturate(1.06)}
#hero.fx-lit-on .fx-lit{opacity:1}
</style>
<style id="m-crumbs">/* крошки на телефоне не показываем: для SEO хватает BreadcrumbList и ссылок в HTML */@media (max-width:900px){.d-crumbs,.f-crumbs{display:none!important}}</style>
<style id="t-inset">/* таблицы: текст не прижимается к краю — отступ первой и последней колонки */@media (min-width:901px){.d-table tr>:first-child{padding-left:clamp(16px,1.5vw,24px)}.d-table tr>:last-child{padding-right:clamp(16px,1.5vw,24px)}}</style>
<style id="hero-fold">/* кнопки первого экрана видны целиком на любом экране (tools/site/hero_fold.py) */@media (max-width:760px){#hero.hero:not(.f-hero) .hero-copy{display:flex;flex-direction:column}#hero.hero:not(.f-hero) .hero-copy>*{order:6}#hero.hero:not(.f-hero) .hero-copy>.badge{order:1;align-self:flex-start}#hero.hero:not(.f-hero) .hero-copy>h1{order:2;margin-bottom:0}#hero.hero:not(.f-hero) .hero-copy>.hero-ctas{order:3;margin-top:22px}#hero.hero:not(.f-hero) .hero-copy>.lead{order:4;margin-top:24px}}@media (max-width:760px) and (max-height:620px){#hero.hero:not(.f-hero){padding-top:92px}#hero.hero:not(.f-hero) h1{margin-top:18px}}@media (max-width:900px){#hero.f-hero .hero-copy{display:flex;flex-direction:column}#hero.f-hero .hero-copy>*{order:6}#hero.f-hero .hero-copy>.f-crumbs{order:0}#hero.f-hero .hero-copy>.badge{order:1;align-self:flex-start}#hero.f-hero .hero-copy>h1{order:2;margin-bottom:0}#hero.f-hero .hero-copy>.hero-ctas{order:3;margin-top:22px}#hero.f-hero .hero-copy>.lead{order:4;margin-top:24px}#hero.f-hero .hero-media{aspect-ratio:auto;height:clamp(104px,calc(100vh - 440px),56.25vw);height:clamp(104px,calc(100svh - 440px),56.25vw)}}@media (max-width:760px){#hero.f-hero .hero-media{height:clamp(104px,calc(100vh - 440px),75vw);height:clamp(104px,calc(100svh - 440px),75vw)}.rp-page #hero.f-hero .hero-media,.lb-page #hero.f-hero .hero-media{height:clamp(104px,calc(100vh - 480px),75vw);height:clamp(104px,calc(100svh - 480px),75vw)}}@media (max-width:900px) and (max-height:620px){#hero.f-hero .hero-copy>.badge{display:none}#hero.f-hero .hero-media{height:clamp(96px,calc(100vh - 400px),75vw);height:clamp(96px,calc(100svh - 400px),75vw)}.rp-page #hero.f-hero .hero-copy>h1{font-size:clamp(26px,7.6vw,34px)}#hero.f-hero .hero-copy>h1{margin-top:30px}}@media (max-width:860px){#hero.d-hero .d-hero-media{aspect-ratio:auto;height:clamp(104px,calc(100vh - 380px),56.25vw);height:clamp(104px,calc(100svh - 380px),56.25vw)}}@media (max-width:860px) and (max-height:620px){#hero.d-hero{padding-top:84px}#hero.d-hero .d-hero-media{margin-top:14px}#hero.d-hero .d-btns{margin-top:16px}}@media (max-width:860px) and (max-height:520px){#hero.d-hero .d-hero-media{display:none}#hero.d-hero h1{margin-bottom:0}}@media (max-width:900px) and (max-height:520px){#hero.f-hero{padding-top:76px}#hero.f-hero .hero-media{display:none}#hero.f-hero .wrap{margin-top:0}#hero.f-hero .hero-copy>h1{margin-top:0}}@media (max-width:400px){#hero .hero-copy{min-width:0}#hero .hero-ctas .btn{min-width:0;max-width:100%;white-space:normal;padding:0 14px}#hero .hero-ctas .btn-t{white-space:normal;text-align:center}}@media (max-width:860px) and (max-height:620px){#hero.d-hero .d-hero-media{height:clamp(104px,calc(100vh - 410px),56.25vw);height:clamp(104px,calc(100svh - 410px),56.25vw)}}@media (max-height:520px){#hero.p-hero .p-hero-copy>.d-btns{order:3;margin-top:18px}#hero.p-hero .p-hero-copy>.p-def{order:4;margin-top:18px}}@media (max-width:760px) and (max-height:620px){#hero.p-hero .p-hero-copy>.d-btns{order:3;margin-top:18px}#hero.p-hero .p-hero-copy>.p-def{order:4;margin-top:18px}}@media (min-width:761px) and (max-height:520px){#hero.hero:not(.f-hero){padding-top:84px;min-height:0}#hero.hero:not(.f-hero) .hero-copy{display:flex;flex-direction:column}#hero.hero:not(.f-hero) .hero-copy>*{order:6}#hero.hero:not(.f-hero) .hero-copy>.badge{order:1;align-self:flex-start}#hero.hero:not(.f-hero) .hero-copy>h1{order:2;margin:14px 0 0}#hero.hero:not(.f-hero) .hero-copy>.hero-ctas{order:3;margin-top:18px}#hero.hero:not(.f-hero) .hero-copy>.lead{order:4;margin-top:18px}}@media (min-width:861px){#hero.d-hero .d-hero-copy{display:flex;flex-direction:column}#hero.d-hero .d-hero-copy>*{order:6}#hero.d-hero .d-hero-copy>.d-crumbs{order:0}#hero.d-hero .d-hero-copy>.eyebrow{order:1}#hero.d-hero .d-hero-copy>h1{order:2}#hero.d-hero .d-hero-copy>:is(.lead,.sub,.p-def):not(:is(.lead,.sub,.p-def)~*){order:3}#hero.d-hero .d-hero-copy>.d-btns:not(.d-btns~*){order:4}#hero.d-hero .d-hero-copy>.d-ticks{margin-bottom:0}}@media (min-width:901px){#hero.f-hero .hero-copy{display:flex;flex-direction:column}#hero.f-hero .hero-copy>*{order:6}#hero.f-hero .hero-copy>.f-crumbs{order:0}#hero.f-hero .hero-copy>.badge{order:1;align-self:flex-start}#hero.f-hero .hero-copy>h1{order:2}#hero.f-hero .hero-copy>.lead{order:3}#hero.f-hero .hero-copy>.hero-ctas{order:4}#hero.f-hero .hero-copy>.rp-hero-list{margin-top:26px}}@media (min-width:861px) and (max-height:820px){#hero.d-hero{padding-top:calc(clamp(68px,6vw,115px) + 8px)}#hero.d-hero .d-hero-copy>.d-crumbs{margin-bottom:0}#hero.d-hero .d-hero-copy>.eyebrow{margin:16px 0 0}#hero.d-hero .d-hero-copy>h1{margin-top:14px;line-height:1.02}#hero.d-hero .d-hero-copy>:is(.lead,.sub,.p-def){margin-top:16px}#hero.d-hero .d-btns{margin-top:20px}}@media (min-width:901px) and (max-height:820px){#hero.f-hero{padding-top:80px}#hero.f-hero .hero-copy>.f-crumbs{margin-bottom:10px}#hero.f-hero .hero-copy>h1{font-size:min(8.2vh,4.4vw);margin:16px 0 14px}.rp-page #hero.f-hero .hero-copy>h1,.lb-page #hero.f-hero .hero-copy>h1{font-size:min(8vh,3.4vw)}#hero.f-hero .hero-copy>.lead{line-height:1.5}#hero.f-hero .hero-copy>.hero-ctas{margin-top:26px}}@media (min-width:761px) and (max-height:820px){#hero.p-hero h1{font-size:min(8.4vh,4.4vw)}#hero.p-hero .p-hero-copy>.d-btns{margin-top:20px}}@media (min-width:761px) and (max-height:820px){#hero.hero:not(.f-hero) h1{font-size:min(8.4vh,4.4vw);margin:22px 0 18px}#hero.hero:not(.f-hero) .hero-ctas{margin-top:28px}}</style>
</head>
<body class="d-page lb-page lbs-page lbs-osveshchennost">
<a class="skip" href="#main">Перейти к содержанию</a>

<!-- ============ INTRO ============ -->
<div class="intro" id="intro" aria-hidden="true">
  <div class="intro-in">
    <svg class="intro-mark" viewBox="0 0 24 24" fill="none" stroke-width="1" stroke-linejoin="round"><path class="im-shield" pathLength="100" d="M12 2.5l7.5 3v6c0 5-3.2 8.6-7.5 10-4.3-1.4-7.5-5-7.5-10v-6z" stroke="#fff"/><circle class="im-c" pathLength="100" cx="12" cy="11.5" r="2.6" stroke="#7c86ff"/><path class="im-x" pathLength="100" d="M12 6.2v2.7M12 14.1v2.7M6.8 11.5h2.6M14.6 11.5h2.6" stroke="#7c86ff"/></svg>
    <div class="intro-word"><span>ПЕСТКОНТРОЛЬ</span><b>Центр</b></div>
    <div class="intro-bar"><i></i></div>
  </div>
</div>

<div class="progress" aria-hidden="true"><i id="progress"></i></div>
<div class="cursor" aria-hidden="true"><i class="cursor-dot"></i><i class="cursor-ring"></i></div>
<div class="grain" aria-hidden="true"></div>

<header class="hdr" id="hdr">
  <div class="wrap">
    <a href="../../" class="logo" aria-label="ПЕСТКОНТРОЛЬ Центр — на главную">
      <span class="logo-mark"><svg viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="1.6" stroke-linejoin="round" aria-hidden="true"><path d="M12 2.5l7.5 3v6c0 5-3.2 8.6-7.5 10-4.3-1.4-7.5-5-7.5-10v-6z"/><circle cx="12" cy="11.5" r="2.6" stroke="#7c86ff"/><path d="M12 6.2v2.7M12 14.1v2.7M6.8 11.5h2.6M14.6 11.5h2.6" stroke="#7c86ff"/></svg></span>
      <span class="logo-txt"><span class="logo-name">ПЕСТКОНТРОЛЬ</span> <span class="logo-sub">Центр</span></span>
    </a>
    <nav class="nav" aria-label="Основное меню">
      <div class="nav-dd"><button class="nav-dd-btn active" type="button" aria-expanded="false" aria-controls="nav-uslugi">Услуги<svg viewBox="0 0 12 12" aria-hidden="true"><path d="M2.5 4.5 6 8l3.5-3.5" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></button><div class="nav-dd-panel" id="nav-uslugi"><a href="../../dezinfektsiya/">Дезинфекция для организаций<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../../deratizatsiya/">Дератизация для организаций<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../../dezinsektsiya/">Дезинсекция для организаций<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../../deratizatsiya-i-dezinsektsiya/">Дератизация и дезинсекция<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../../sanitarnyy-audit/"><span>Санитарный аудит <span class="nw">(СЭС-аудит)</span></span><svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../../laboratornye-issledovaniya/">Лабораторные исследования<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../../razrabotka-ppk/">Разработка ППК<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../../normativnaya-baza/dokumenty-dlya-rospotrebnadzora/">Документы для Роспотребнадзора<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../../ochistka-dezinfektsiya-ventilyatsii/">Очистка и дезинфекция вентиляции<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../../dogovor-deratizatsiya-dezinsektsiya/">Договор на обслуживание<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../../#podhod" class="nav-dd-all"><span>Пест-контроль по системе IPM</span><svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a></div></div><div class="nav-dd"><button class="nav-dd-btn" type="button" aria-expanded="false" aria-controls="nav-otrasli">Отрасли<svg viewBox="0 0 12 12" aria-hidden="true"><path d="M2.5 4.5 6 8l3.5-3.5" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></button><div class="nav-dd-panel" id="nav-otrasli"><a href="../../pishchevoe-proizvodstvo/">Пищевые производства<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../../magaziny-i-torgovye-seti/">Магазины и торговые сети<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../../restorany-i-kafe/">Рестораны и кафе<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../../sklady-i-logistika/">Склады и логистика<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../../farmatsevticheskie-proizvodstva/">Фармацевтические производства<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../../gostinitsy/">Гостиницы и отели<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../../#otrasli" class="nav-dd-all">Все отрасли<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a></div></div><a href="../../dogovor-deratizatsiya-dezinsektsiya/">Договор</a><a href="../../#podhod">Метод IPM</a><a href="../../#usloviya">Цена</a><div class="nav-dd"><button class="nav-dd-btn" type="button" aria-expanded="false" aria-controls="nav-materialy">Материалы<svg viewBox="0 0 12 12" aria-hidden="true"><path d="M2.5 4.5 6 8l3.5-3.5" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></button><div class="nav-dd-panel" id="nav-materialy"><a href="../../normativnaya-baza/">Нормативная база<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../../normativnaya-baza/dokumenty-dlya-rospotrebnadzora/">Документы для Роспотребнадзора<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../../materialy/programma-pest-kontrolya/"><span>Программа <span class="nw">пест-контроля</span></span><svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../../materialy/zhurnal-pest-kontrolya/"><span>Журнал <span class="nw">пест-контроля</span></span><svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../../materialy/pest-menedzhment-ili-razovaya-obrabotka/"><span><span class="nw">Пест-менеджмент</span> или разовая обработка</span><svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../../materialy/programma-proizvodstvennogo-kontrolya-haccp/">Программа производственного контроля по ХАССП<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../../materialy/" class="nav-dd-all">Все материалы<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a></div></div>
    </nav>
    <div class="hdr-right">
      <button class="srch-btn" type="button" data-srch aria-label="Поиск по сайту" aria-haspopup="dialog"><svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="11" cy="11" r="7" fill="none" stroke="currentColor" stroke-width="2"/><path d="m20 20-3.6-3.6" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg></button>
      <a class="phone" href="tel:+74951043570" aria-label="Позвонить: +7 (495) 104-35-70"><i><svg viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2" aria-hidden="true"><path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1 1 .4 1.9.7 2.8a2 2 0 0 1-.5 2.1L8 9.9a16 16 0 0 0 6 6l1.3-1.3a2 2 0 0 1 2.1-.4c.9.3 1.8.6 2.8.7a2 2 0 0 1 1.7 2z"/></svg></i><span>+7 (495) 104-35-70</span></a>
      <div class="msg">
        <a href="https://max.ru/u/f9LHodD0cOIlIUXFkt4KMFP88lD8n4TArBiTcV7RI1XML5c4o39QfsDBXUc" class="max" aria-label="Написать в Max" target="_blank" rel="noopener noreferrer"><svg viewBox="0 0 24 24" fill="#fff" aria-hidden="true"><path d="M12 3a9 9 0 0 0-7.7 13.7L3 21l4.4-1.2A9 9 0 1 0 12 3zm-3.6 12.3V8.7h1.6l2 2.8 2-2.8h1.6v6.6h-1.7v-3.9L12 14l-1.9-2.6v3.9z"/></svg></a>
        <a href="https://t.me/Centr_Dezinfection?text=%D0%97%D0%B4%D1%80%D0%B0%D0%B2%D1%81%D1%82%D0%B2%D1%83%D0%B9%D1%82%D0%B5!%20%D0%9F%D0%B8%D1%88%D1%83%20%D1%81%20%D1%81%D0%B0%D0%B9%D1%82%D0%B0%20%D0%BF%D0%B5%D1%81%D1%82%D0%BA%D0%BE%D0%BD%D1%82%D1%80%D0%BE%D0%BB%D1%8C-%D1%86%D0%B5%D0%BD%D1%82%D1%80.%D1%80%D1%84" class="tg" aria-label="Написать в Telegram" target="_blank" rel="noopener noreferrer"><svg viewBox="0 0 24 24" fill="#fff" aria-hidden="true"><path d="M21.4 4.3 2.9 11.4c-1.3.5-1.2 1.2-.2 1.5l4.7 1.5 1.8 5.6c.2.6.4.8.9.8.4 0 .6-.2.9-.4l2.3-2.2 4.7 3.5c.9.5 1.5.2 1.7-.8l3.1-14.6c.3-1.3-.5-1.8-1.4-1.5zM9.6 14.1l8.6-5.4c.4-.3.8-.1.5.2l-7.1 6.4-.3 3.3z"/></svg></a>
      </div>
      <a href="#zayavka" class="btn btn-w btn-sm" data-magnet><span class="btn-t">Бесплатный выезд</span></a>
      <button class="burger" id="burger" aria-label="Открыть меню" aria-expanded="false" aria-controls="mmenu"><span></span></button>
    </div>
  </div>
</header>
<nav class="mmenu" id="mmenu" aria-label="Мобильное меню">
  <div class="mm-group open" data-open><button class="mm-toggle" type="button" aria-expanded="true" aria-controls="mm-uslugi">Услуги<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m6 9 6 6 6-6" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/></svg></button><div class="mm-sub" id="mm-uslugi"><div><a href="../../dezinfektsiya/">Дезинфекция для организаций</a><a href="../../deratizatsiya/">Дератизация для организаций</a><a href="../../dezinsektsiya/">Дезинсекция для организаций</a><a href="../../deratizatsiya-i-dezinsektsiya/">Дератизация и дезинсекция</a><a href="../../sanitarnyy-audit/"><span>Санитарный аудит <span class="nw">(СЭС-аудит)</span></span></a><a href="../../laboratornye-issledovaniya/">Лабораторные исследования</a><a href="../../razrabotka-ppk/">Разработка ППК</a><a href="../../normativnaya-baza/dokumenty-dlya-rospotrebnadzora/">Документы для Роспотребнадзора</a><a href="../../ochistka-dezinfektsiya-ventilyatsii/">Очистка и дезинфекция вентиляции</a><a href="../../dogovor-deratizatsiya-dezinsektsiya/">Договор на обслуживание</a><a href="../../#podhod"><span class="nw">Пест-контроль</span> по системе IPM</a></div></div></div><div class="mm-group"><button class="mm-toggle" type="button" aria-expanded="false" aria-controls="mm-otrasli">Отрасли<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m6 9 6 6 6-6" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/></svg></button><div class="mm-sub" id="mm-otrasli"><div><a href="../../pishchevoe-proizvodstvo/">Пищевые производства</a><a href="../../magaziny-i-torgovye-seti/">Магазины и торговые сети</a><a href="../../restorany-i-kafe/">Рестораны и кафе</a><a href="../../sklady-i-logistika/">Склады и логистика</a><a href="../../farmatsevticheskie-proizvodstva/">Фармацевтические производства</a><a href="../../gostinitsy/">Гостиницы и отели</a><a href="../../#otrasli">Все отрасли</a></div></div></div><a href="../../dogovor-deratizatsiya-dezinsektsiya/">Договор <small>на дератизацию и дезинсекцию</small></a><a href="../../#podhod">Метод IPM</a><a href="../../#usloviya">Цена</a><div class="mm-group"><button class="mm-toggle" type="button" aria-expanded="false" aria-controls="mm-materialy">Материалы<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m6 9 6 6 6-6" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/></svg></button><div class="mm-sub" id="mm-materialy"><div><a href="../../normativnaya-baza/">Нормативная база</a><a href="../../normativnaya-baza/dokumenty-dlya-rospotrebnadzora/">Документы для Роспотребнадзора</a><a href="../../materialy/programma-pest-kontrolya/"><span>Программа <span class="nw">пест-контроля</span></span></a><a href="../../materialy/zhurnal-pest-kontrolya/"><span>Журнал <span class="nw">пест-контроля</span></span></a><a href="../../materialy/pest-menedzhment-ili-razovaya-obrabotka/"><span><span class="nw">Пест-менеджмент</span> или разовая обработка</span></a><a href="../../materialy/programma-proizvodstvennogo-kontrolya-haccp/">Программа производственного контроля по ХАССП</a><a href="../../materialy/">Все материалы</a></div></div></div>
  <a href="#zayavka" class="btn btn-w btn-lg"><span class="btn-t">Заказать бесплатное обследование</span></a>
</nav>

<main id="main" tabindex="-1">
<section class="hero f-hero" id="hero">
  <div class="hero-media"><picture><source media="(max-width:760px)" srcset="../../img/lab-osveshchennost-hero-mob-760.webp 760w, ../../img/lab-osveshchennost-hero-mob.webp 1024w" sizes="100vw" width="1024" height="768"><img class="f-hero-img" src="../../img/lab-osveshchennost-hero.webp" srcset="../../img/lab-osveshchennost-hero-1440.webp 1440w, ../../img/lab-osveshchennost-hero.webp 1920w" sizes="100vw" width="1920" height="1072" alt="Специалист лаборатории измеряет освещённость рабочего стола люксметром в офисе в тёмное время суток" fetchpriority="high" decoding="async"></picture><div class="fx-lit" aria-hidden="true"><picture><source media="(max-width:760px)" srcset="../../img/lab-osveshchennost-hero-mob-760.webp 760w, ../../img/lab-osveshchennost-hero-mob.webp 1024w" sizes="100vw" width="1024" height="768"><img class="f-hero-img fx-lit-img" src="../../img/lab-osveshchennost-hero.webp" srcset="../../img/lab-osveshchennost-hero-1440.webp 1440w, ../../img/lab-osveshchennost-hero.webp 1920w" sizes="100vw" width="1920" height="1072" alt="" decoding="async"></picture></div></div>
  <div class="wrap">
    <div class="hero-copy">
      <nav class="f-crumbs" aria-label="Навигационная цепочка" data-h><a href="../../">Главная</a><span aria-hidden="true">→</span><a href="../../laboratornye-issledovaniya/">Лабораторные исследования</a><span aria-hidden="true">→</span><span aria-current="page">Замер освещённости</span></nav>
      <span class="badge" data-h><span class="dot"></span>Наша лаборатория · Москва и область</span>
      <h1><span class="ln"><span>Замер освещённости</span></span> <span class="ln"><span><em>на рабочих местах</em></span></span></h1>
      <p class="lead" data-h>Измеряем освещённость рабочих поверхностей поверенным люксметром по ГОСТ <span class="nw">24940-2016</span> и МУК <span class="nw">4.3.3975-24</span> и сравниваем с нормой СанПиН <span class="nw">1.2.3685-21</span> для каждого помещения. Протокол — для папки производственного контроля.</p>
      <ul class="lb-hero-list"><li>Замер освещённости — от 350&nbsp;₽ за точку</li><li>Офисы, цеха, склады, кухни, салоны красоты и медицинские кабинеты</li><li>Искусственное освещение измеряем в тёмное время суток</li></ul>
      <div class="hero-ctas" data-h><a href="#ceny" class="btn btn-w btn-lg" data-magnet><span class="btn-t">Рассчитать стоимость</span></a><a href="#zayavka" class="btn btn-o btn-lg" data-goal="Замеры на рабочих местах" data-magnet><span class="btn-t">Заказать замер</span></a></div>
    </div>
  </div>
</section>

<div class="strip" role="group" aria-label="Коротко о замере освещённости">
  <div class="strip-track" id="stripTrack">
    <div class="strip-set">
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-lightbulb" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M15 14c.2-1 .7-1.7 1.5-2.5 1-.9 1.5-2.2 1.5-3.5A6 6 0 0 0 6 8c0 1 .2 2.2 1.5 3.5.7.7 1.3 1.5 1.5 2.5" /> <path d="M9 18h6" /> <path d="M10 22h4" /> </svg><b>Освещённость</b> — от 350 ₽ за точку</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-file-badge" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M13 22h5a2 2 0 0 0 2-2V8a2.4 2.4 0 0 0-.706-1.706l-3.588-3.588A2.4 2.4 0 0 0 14 2H6a2 2 0 0 0-2 2v3.3" /> <path d="M14 2v5a1 1 0 0 0 1 1h5" /> <path d="m7.69 16.479 1.29 4.88a.5.5 0 0 1-.698.591l-1.843-.849a1 1 0 0 0-.879.001l-1.846.85a.5.5 0 0 1-.692-.593l1.29-4.88" /> <circle cx="6" cy="14" r="3" /> </svg><b>ГОСТ 24940-2016</b> — методы измерения</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-badge-check" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M3.85 8.62a4 4 0 0 1 4.78-4.77 4 4 0 0 1 6.74 0 4 4 0 0 1 4.78 4.78 4 4 0 0 1 0 6.74 4 4 0 0 1-4.77 4.78 4 4 0 0 1-6.75 0 4 4 0 0 1-4.78-4.77 4 4 0 0 1 0-6.76Z" /> <path d="m16 9-5.5 5.5L8 12" /> </svg><b>Поверенный люксметр</b> — погрешность до 10 %</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-clock" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg><b>Вечером</b> — или при зашторенных окнах</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-list-checks" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M13 5h8" /> <path d="M13 12h8" /> <path d="M13 19h8" /> <path d="m3 17 2 2 4-4" /> <path d="m3 7 2 2 4-4" /> </svg><b>300 лк в офисе</b> — при общем освещении</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-map-pinned" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M18 8c0 3.613-3.869 7.429-5.393 8.795a1 1 0 01-1.214 0C9.87 15.429 6 11.613 6 8a6 6 0 0112 0" /> <path d="M4.474 15h-.197a1 1 0 00-.969.753l-1.097 4.35a1.5 1.5 0 001.444 1.898L20.344 22a1.5 1.5 0 001.446-1.897l-1.098-4.35a1 1 0 00-.969-.753h-.197" /> <circle cx="12" cy="8" r="2" /> </svg><b>План точек</b> — под светильниками и между ними</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-clipboard-check" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <rect width="8" height="4" x="8" y="2" rx="1" ry="1" /> <path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2" /> <path d="m9 14 2 2 4-4" /> </svg><b>По плану ППК</b> — условия труда</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-notebook-pen" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M13.4 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-7.4" /> <path d="M2 6h4" /> <path d="M2 10h4" /> <path d="M2 14h4" /> <path d="M2 18h4" /> <path d="M21.378 5.626a1 1 0 1 0-3.004-3.004l-5.01 5.012a2 2 0 0 0-.506.854l-.837 2.87a.5.5 0 0 0 .62.62l2.87-.837a2 2 0 0 0 .854-.506z" /> </svg><b>Протоколы</b> — для папки к проверке</div>
    </div>
    <div class="strip-set" aria-hidden="true">
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-lightbulb" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M15 14c.2-1 .7-1.7 1.5-2.5 1-.9 1.5-2.2 1.5-3.5A6 6 0 0 0 6 8c0 1 .2 2.2 1.5 3.5.7.7 1.3 1.5 1.5 2.5" /> <path d="M9 18h6" /> <path d="M10 22h4" /> </svg><b>Освещённость</b> — от 350 ₽ за точку</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-file-badge" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M13 22h5a2 2 0 0 0 2-2V8a2.4 2.4 0 0 0-.706-1.706l-3.588-3.588A2.4 2.4 0 0 0 14 2H6a2 2 0 0 0-2 2v3.3" /> <path d="M14 2v5a1 1 0 0 0 1 1h5" /> <path d="m7.69 16.479 1.29 4.88a.5.5 0 0 1-.698.591l-1.843-.849a1 1 0 0 0-.879.001l-1.846.85a.5.5 0 0 1-.692-.593l1.29-4.88" /> <circle cx="6" cy="14" r="3" /> </svg><b>ГОСТ 24940-2016</b> — методы измерения</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-badge-check" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M3.85 8.62a4 4 0 0 1 4.78-4.77 4 4 0 0 1 6.74 0 4 4 0 0 1 4.78 4.78 4 4 0 0 1 0 6.74 4 4 0 0 1-4.77 4.78 4 4 0 0 1-6.75 0 4 4 0 0 1-4.78-4.77 4 4 0 0 1 0-6.76Z" /> <path d="m16 9-5.5 5.5L8 12" /> </svg><b>Поверенный люксметр</b> — погрешность до 10 %</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-clock" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg><b>Вечером</b> — или при зашторенных окнах</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-list-checks" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M13 5h8" /> <path d="M13 12h8" /> <path d="M13 19h8" /> <path d="m3 17 2 2 4-4" /> <path d="m3 7 2 2 4-4" /> </svg><b>300 лк в офисе</b> — при общем освещении</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-map-pinned" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M18 8c0 3.613-3.869 7.429-5.393 8.795a1 1 0 01-1.214 0C9.87 15.429 6 11.613 6 8a6 6 0 0112 0" /> <path d="M4.474 15h-.197a1 1 0 00-.969.753l-1.097 4.35a1.5 1.5 0 001.444 1.898L20.344 22a1.5 1.5 0 001.446-1.897l-1.098-4.35a1 1 0 00-.969-.753h-.197" /> <circle cx="12" cy="8" r="2" /> </svg><b>План точек</b> — под светильниками и между ними</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-clipboard-check" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <rect width="8" height="4" x="8" y="2" rx="1" ry="1" /> <path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2" /> <path d="m9 14 2 2 4-4" /> </svg><b>По плану ППК</b> — условия труда</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-notebook-pen" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M13.4 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-7.4" /> <path d="M2 6h4" /> <path d="M2 10h4" /> <path d="M2 14h4" /> <path d="M2 18h4" /> <path d="M21.378 5.626a1 1 0 1 0-3.004-3.004l-5.01 5.012a2 2 0 0 0-.506.854l-.837 2.87a.5.5 0 0 0 .62.62l2.87-.837a2 2 0 0 0 .854-.506z" /> </svg><b>Протоколы</b> — для папки к проверке</div>
    </div>
  </div>
</div>

<section class="s" id="korotko">
  <div class="wrap">
    <div class="head"><div class="eyebrow" data-eyebrow>Коротко</div><h2 data-split>Что такое <em>замер освещённости</em></h2></div>
    <p class="lb-def" data-fade><b>Замер освещённости</b> — измерение освещённости рабочих поверхностей люксметром в контрольных точках помещения и сравнение результата с нормой СанПиН <span class="nw">1.2.3685-21</span> для вида помещения и характера работы. Методы измерений установлены ГОСТ <span class="nw">24940-2016</span>, порядок оценки световой среды на рабочих местах — МУК <span class="nw">4.3.3975-24</span>. Результат нужен для производственного контроля условий труда.</p>
    <table class="d-table lb-short" data-fade>
      <caption class="sr-only">Что такое замер освещённости — коротко</caption>
      <tbody><tr><th scope="row">Что измеряем</th><td>освещённость рабочих поверхностей от общего и комбинированного искусственного освещения; другие показатели световой среды — по вашей программе производственного контроля</td></tr><tr><th scope="row">Как часто</th><td>по программе производственного контроля (п. 15 СП <span class="nw">2.2.4285-26</span>); в салонах красоты и парикмахерских — 1&nbsp;раз в год (п. 99.38 СП <span class="nw">2.1.4284-26</span>)</td></tr><tr><th scope="row">Когда измеряют</th><td>искусственное освещение — в тёмное время суток или при зашторенных окнах, чтобы дневной свет не искажал результат</td></tr><tr><th scope="row">Норма для офиса</th><td>кабинеты и рабочие комнаты — 300&nbsp;лк при общем освещении, залы персональных компьютеров — 400&nbsp;лк</td></tr><tr><th scope="row">Сколько стоит</th><td>от 350&nbsp;₽ за точку; итог зависит от числа помещений и рабочих мест — <a href="#ceny">соберите расчёт</a></td></tr><tr><th scope="row">Что вы получите</th><td>протокол измерений по каждой точке и вывод: где освещённость в норме, а где нужно исправить</td></tr></tbody>
    </table>
    <p class="lb-upd" data-fade>Обновлено 11.11.2026 · Автор: <a href="#avtor">Марианна Семерина, санитарный врач</a></p>
  </div>
</section>

<section class="s" id="ceny">
  <div class="wrap">
    <div class="head"><div class="eyebrow" data-eyebrow>Цены</div><h2 data-split>Цены на замер освещённости <em>и расчёт</em></h2><p class="sub" data-fade>Нажмите «+» и укажите число точек — сумма появится внизу экрана. Расчёт общий для всех страниц раздела: его можно отправить вместе с заявкой.</p></div>
    <div class="lb-price" data-fade>
      <details class="lb-grp" id="p-osveshchennost-1" open><summary><span class="lb-grp-ic"><svg aria-hidden="true" focusable="false" class="lucide lucide-thermometer" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M14 4v10.54a4 4 0 1 1-4 0V4a2 2 0 0 1 4 0Z" /> </svg></span><span class="lb-grp-n">Освещённость</span><span class="lb-grp-c">1 позиция · от 350 ₽</span><span class="pm" aria-hidden="true"></span></summary>
        <table class="d-table lb-tbl"><thead><tr><th scope="col">Услуга</th><th scope="col">Единица</th><th scope="col">Цена</th><th scope="col"><span class="sr-only">Расчёт</span></th></tr></thead><tbody><tr data-id="z-svet"><td data-l="Услуга" class="lb-tn">Измерение освещённости</td><td data-l="Единица" class="lb-tu">точка</td><td data-l="Цена" class="lb-tp">от 350 ₽</td><td class="lb-tc"><button type="button" class="lb-add" data-add="z-svet" aria-label="Добавить в расчёт: Измерение освещённости"><span aria-hidden="true">+</span></button></td></tr></tbody></table>
      </details>
      <details class="lb-grp" id="p-osveshchennost-2" open><summary><span class="lb-grp-ic"><svg aria-hidden="true" focusable="false" class="lucide lucide-thermometer" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M14 4v10.54a4 4 0 1 1-4 0V4a2 2 0 0 1 4 0Z" /> </svg></span><span class="lb-grp-n">Часто заказывают вместе</span><span class="lb-grp-c">3 позиции · от 350 ₽</span><span class="pm" aria-hidden="true"></span></summary>
        <table class="d-table lb-tbl"><thead><tr><th scope="col">Услуга</th><th scope="col">Единица</th><th scope="col">Цена</th><th scope="col"><span class="sr-only">Расчёт</span></th></tr></thead><tbody><tr data-id="z-mikroklimat"><td data-l="Услуга" class="lb-tn">Измерение микроклимата</td><td data-l="Единица" class="lb-tu">точка</td><td data-l="Цена" class="lb-tp">от 350 ₽</td><td class="lb-tc"><button type="button" class="lb-add" data-add="z-mikroklimat" aria-label="Добавить в расчёт: Измерение микроклимата"><span aria-hidden="true">+</span></button></td></tr><tr data-id="z-shum"><td data-l="Услуга" class="lb-tn">Измерение шума</td><td data-l="Единица" class="lb-tu">точка</td><td data-l="Цена" class="lb-tp">от 500 ₽</td><td class="lb-tc"><button type="button" class="lb-add" data-add="z-shum" aria-label="Добавить в расчёт: Измерение шума"><span aria-hidden="true">+</span></button></td></tr><tr data-id="rm"><td data-l="Услуга" class="lb-tn">Комплекс измерений на рабочих местах</td><td data-l="Единица" class="lb-tu">комплекс</td><td data-l="Цена" class="lb-tp">от 2 600 ₽</td><td class="lb-tc"><button type="button" class="lb-add" data-add="rm" aria-label="Добавить в расчёт: Комплекс измерений на рабочих местах"><span aria-hidden="true">+</span></button></td></tr></tbody></table>
      </details>
    </div>
    <p class="d-note" data-fade>Цена «от» — за одну точку измерения. Число точек зависит от площади помещений, расположения светильников и рабочих мест; точную сумму называем до выезда. Микроклимат удобно измерить в тот же выезд — см. <a href="../../laboratornye-issledovaniya/izmerenie-mikroklimata/">измерение микроклимата</a>.</p>
  </div>
</section>

<section class="s" id="kogda-nuzhno">
  <div class="wrap">
    <div class="head"><div class="eyebrow" data-eyebrow>Когда обязательно</div><h2 data-split>Когда нужен <em>замер освещённости</em></h2><p class="sub" data-fade>Освещённость — один из факторов производственного контроля условий труда. Объём и кратность замеров записывают в программу, а для некоторых видов деятельности их задают санитарные правила:</p></div>
    <table class="d-table lbs-t" data-fade>
      <thead><tr><th scope="col">Ситуация</th><th scope="col">Что требуется</th><th scope="col">Основание</th></tr></thead>
      <tbody>
        <tr><td data-l="Ситуация">Офис, цех, склад, магазин — освещённость не соответствовала нормам при спецоценке или прежних замерах</td><td data-l="Что требуется">замеры с кратностью из программы производственного контроля, пока условия не приведены в норму</td><td data-l="Основание">п. 15 СП <span class="nw">2.2.4285-26</span></td></tr>
        <tr><td data-l="Ситуация">Реконструкция, капитальный ремонт, замена освещения, новые рабочие места</td><td data-l="Что требуется">замер после работ — проверить, что новая схема освещения даёт норму</td><td data-l="Основание">п. 15 СП <span class="nw">2.2.4285-26</span></td></tr>
        <tr><td data-l="Ситуация">Парикмахерская, салон красоты, косметический кабинет</td><td data-l="Что требуется">контроль уровней искусственной освещённости 1&nbsp;раз в год; в маникюрных, педикюрных кабинетах и кабинетах декоративной косметики освещение должно быть комбинированным</td><td data-l="Основание">пп. 99.4 и 99.38 СП <span class="nw">2.1.4284-26</span></td></tr>
        <tr><td data-l="Ситуация">Аквапарк</td><td data-l="Что требуется">освещённость поверхности воды — перед открытием и после ремонта или замены осветительного и вентиляционного оборудования</td><td data-l="Основание">приложение № 6 к СП <span class="nw">2.1.4284-26</span></td></tr>
        <tr><td data-l="Ситуация">Недавно прошла специальная оценка условий труда</td><td data-l="Что требуется">её измерения можно зачесть в производственный контроль, если они сделаны не раньше чем за 6&nbsp;месяцев аккредитованной лабораторией</td><td data-l="Основание">п. 1.1 ст. 32 Федерального закона № <span class="nw">52-ФЗ</span></td></tr>
      </tbody>
    </table>
    <p class="d-note" data-fade>Если не знаете, какие замеры записаны в вашей программе производственного контроля, пришлите её — сверим. Нет программы — <a href="../../razrabotka-ppk/">разработаем</a>.</p>
  </div>
</section>

<section class="s" id="normy">
  <div class="wrap">
    <div class="head"><div class="eyebrow" data-eyebrow>Нормы</div><h2 data-split>Нормы освещённости <em>в офисе</em></h2><p class="sub" data-fade>Нормы зависят от вида помещения и точности зрительной работы. Для административных зданий СанПиН <span class="nw">1.2.3685-21</span> устанавливает, например, такие значения на рабочей поверхности (горизонтальная плоскость на высоте 0,8&nbsp;м):</p></div>
    <table class="d-table lbs-t" data-fade>
      <thead><tr><th scope="col">Помещение</th><th scope="col">Общее освещение</th><th scope="col">Комбинированное</th><th scope="col">UGR, не более</th><th scope="col">Кп, не более</th></tr></thead>
      <tbody>
        <tr><td data-l="Помещение">Кабинеты, рабочие комнаты, офисы, представительства</td><td data-l="Общее освещение" class="lbs-n">300&nbsp;лк</td><td data-l="Комбинированное" class="lbs-n">400&nbsp;лк</td><td data-l="UGR, не более" class="lbs-n">21</td><td data-l="Кп, не более" class="lbs-n">15&nbsp;%</td></tr>
        <tr><td data-l="Помещение">Залы персональных компьютеров</td><td data-l="Общее освещение" class="lbs-n">400&nbsp;лк</td><td data-l="Комбинированное" class="lbs-n">500&nbsp;лк</td><td data-l="UGR, не более" class="lbs-n">14</td><td data-l="Кп, не более" class="lbs-n">5&nbsp;%</td></tr>
        <tr><td data-l="Помещение">Проектные залы, конструкторские и чертёжные бюро</td><td data-l="Общее освещение" class="lbs-n">500&nbsp;лк</td><td data-l="Комбинированное" class="lbs-n">600&nbsp;лк</td><td data-l="UGR, не более" class="lbs-n">21</td><td data-l="Кп, не более" class="lbs-n">10&nbsp;%</td></tr>
      </tbody>
    </table>
    <p class="lbs-cap" data-fade>UGR — объединённый показатель дискомфортной блёскости, Кп — коэффициент пульсации освещённости. При комбинированном освещении часть нормы даёт общее освещение, остальное — местные светильники.</p>
    <p class="lbs-p" data-fade>Для производственных помещений норма зависит от разряда и подразряда зрительной работы — от размера объекта различения и контраста. Для торговых залов, кухонь, складов, медицинских и учебных помещений в СанПиН <span class="nw">1.2.3685-21</span> свои строки. В протоколе мы указываем норму для каждого помещения и рабочего места, чтобы было видно, с чем сравнивали.</p>
  </div>
</section>

<section class="s" id="kak-izmeryaem">
  <div class="wrap">
    <div class="head"><div class="eyebrow" data-eyebrow>Методика</div><h2 data-split>Как проходит замер <em>по ГОСТ <span class="nw">24940-2016</span></em></h2></div>
    <ul class="d-ticks lbs-ticks" data-group="ctalist">
      <li><b>Прибор.</b> Люксметр с погрешностью не более 10&nbsp;% и действующей поверкой (пп. 4.1–4.2).</li>
      <li><b>План точек.</b> Перед замером составляем план помещения с расположением светильников, оборудования и контрольных точек (п. 5.1).</li>
      <li><b>Подготовка.</b> По договорённости до замера меняют перегоревшие лампы и чистят светильники. Если подготовки не было, это отмечаем в протоколе (п. 5.2).</li>
      <li><b>Время.</b> Искусственное освещение измеряем в тёмное время суток, когда естественный свет не превышает 10&nbsp;% искусственного. Днём допускается занавесить окна (п. 6.1.1).</li>
      <li><b>Условия.</b> Включаем светильники заранее, чтобы световой поток стабилизировался; фиксируем напряжение сети в начале и в конце замера; следим, чтобы на датчик не падала тень от человека и оборудования (пп. 6.1.2–6.1.4).</li>
      <li><b>Точки.</b> Минимальную освещённость ищем под светильниками, между ними и у стен — на расстоянии 0,15–0,25 расстояния между рядами светильников, но не дальше 1&nbsp;м от стены (п. 5.5.1). Среднюю — по сетке точек, полосу 0,5&nbsp;м у стен не учитываем (п. 5.6.1).</li>
    </ul>
    <p class="d-note" data-fade>Подробнее о подготовке и типичных ошибках — в материале <a href="../../materialy/zamer-osveshchennosti-i-mikroklimata/">«Как проходит замер освещённости и микроклимата»</a>.</p>
  </div>
</section>

<section class="s" id="esli-ne-v-norme">
  <div class="wrap">
    <div class="head"><div class="eyebrow" data-eyebrow>Результат</div><h2 data-split>Если освещённость <em>не в норме</em></h2></div>
    <div class="lbs-split">
      <div data-fade>
        <p class="lbs-p">Чаще всего освещённость падает не <span class="nw">из-за</span> проекта, а <span class="nw">из-за</span> эксплуатации: перегоревшие и старые лампы, грязные рассеиватели, светильники, оставшиеся после перепланировки над проходом, а не над столами. Иногда норма по люксам выполняется, но светильники дают высокую пульсацию.</p>
        <p class="lbs-p">По протоколу видно, в какой точке недобор. После исправления повторяем замер в тех же точках и дополняем папку производственного контроля.</p>
      </div>
      <ul class="d-ticks lbs-ticks" data-group="ctalist">
        <li>Заменить перегоревшие и выработавшие ресурс лампы</li>
        <li>Очистить рассеиватели и плафоны светильников</li>
        <li>Передвинуть рабочие места или светильники</li>
        <li>Добавить местное освещение там, где нужна точная работа</li>
        <li>Повторный замер в тех же точках и отметка в журнале</li>
      </ul>
    </div>
  </div>
</section>

<section class="s" id="kak-rabotaem">
  <div class="wrap">
    <div class="head"><div class="eyebrow" data-eyebrow>Порядок работы</div><h2 data-split>Как заказать <em>замер освещённости</em></h2></div>
    <ol class="d-steps lb-steps" data-group="steps"><li><img class="lb-step-ic" src="../../img/lab-s1.webp" width="120" height="120" alt="" loading="lazy" decoding="async"><b>Заявка</b><span>Пришлите программу производственного контроля или план помещений. Назовём число точек и стоимость.</span></li><li><img class="lb-step-ic" src="../../img/lab-s2.webp" width="120" height="120" alt="" loading="lazy" decoding="async"><b>Выезд</b><span>Согласуем время после захода солнца или замер днём при зашторенных окнах — как удобнее объекту.</span></li><li><img class="lb-step-ic" src="../../img/lab-s3.webp" width="120" height="120" alt="" loading="lazy" decoding="async"><b>Замер</b><span>Измеряем освещённость в контрольных точках по плану, фиксируем напряжение сети и состояние светильников.</span></li><li><img class="lb-step-ic" src="../../img/lab-s4.webp" width="120" height="120" alt="" loading="lazy" decoding="async"><b>Оценка</b><span>Сравниваем результат с нормой СанПиН <span class="nw">1.2.3685-21</span> для каждого помещения и вида работы.</span></li><li><img class="lb-step-ic" src="../../img/lab-s5.webp" width="120" height="120" alt="" loading="lazy" decoding="async"><b>Протокол</b><span>Передаём протокол измерений и разбор: где норма, где нет и что исправить. Документ — для папки ППК.</span></li></ol>
  </div>
</section>

<section class="s" id="avtor">
  <div class="wrap">
    <div class="head"><div class="eyebrow" data-eyebrow>Автор</div><h2 data-split>Кто подготовил <em>материал</em></h2></div>
    <div class="lb-author-wrap" data-fade>
      <div class="card lb-author">
        <img class="lb-avatar" src="../../img/san-author-photo-240.webp" srcset="../../img/san-author-photo-240.webp 240w, ../../img/san-author-photo-480.webp 480w" sizes="(max-width:600px) 80px, 112px" width="240" height="240" loading="lazy" decoding="async" alt="Иллюстративное фото санитарного врача, изображение сгенерировано">
        <div><p class="lb-author-name">Марианна Семерина</p><p class="lb-author-role">Санитарный врач, автор материала</p><p class="lb-author-date">Дата обновления — 11.11.2026</p><p class="lb-author-note">Фото иллюстративное</p></div>
      </div>
      <ul class="lb-principles"><li><b>По вашей программе.</b> Точки, показатели и кратность берём из <span class="nw">плана-графика</span> ППК, а не из общего списка.</li><li><b>Понятный результат.</b> К протоколам — короткий разбор: что в норме, что нет и что сделать.</li><li><b>Вместе с санитарными работами.</b> Если показатель не в норме, поможем исправить причину: дезинфекция, <span class="nw">пест-контроль</span>, очистка вентиляции — и повторим исследование.</li></ul>
    </div>
  </div>
</section>

<section class="s" id="normativnaya-baza">
  <div class="wrap">
    <div class="head"><div class="eyebrow" data-eyebrow>Источники</div><h2 data-split>Нормативная база <em>(проверено 11.11.2026)</em></h2><p class="sub" data-fade>Документы о производственном контроле, дезинсекции и дератизации — в разделе <a href="../../normativnaya-baza/">«Нормативная база»</a>.</p></div>
    <ul class="lb-base" data-fade><li>ГОСТ <span class="nw">24940-2016</span> «Здания и сооружения. Методы измерения освещённости» — пп. 4.1–4.2, 5.1–5.2, 5.5.1, 5.6.1, 6.1.1–6.1.4 (<a href="https://base.garant.ru/71605300/" target="_blank" rel="noopener">Гарант</a>)</li><li>МУК <span class="nw">4.3.3975-24</span> «Измерение и оценка световой среды на рабочих местах» (утв. 19.02.2024, действуют с 19.05.2024 взамен МУК <span class="nw">4.3.2812-10</span> и МУ <span class="nw">2.2.4.706-98</span>) (<a href="https://base.garant.ru/408890461/" target="_blank" rel="noopener">Гарант</a>)</li><li>СанПиН <span class="nw">1.2.3685-21</span> «Гигиенические нормативы и требования к обеспечению безопасности и (или) безвредности для человека факторов среды обитания» — раздел V, требования к освещению помещений административных зданий (<a href="https://www.consultant.ru/document/cons_doc_LAW_375839/87fff7c296caa488a46d3a8f1ff07c0e0479864e/" target="_blank" rel="noopener">КонсультантПлюс</a>)</li><li>СП <span class="nw">2.2.4285-26</span> «<span class="nw">Санитарно-эпидемиологические</span> требования к условиям труда» (утв. постановлением Главного государственного санитарного врача РФ от 02.06.2026 № 15, действуют с 01.09.2026 взамен СП <span class="nw">2.2.3670-20</span>) — раздел II «Производственный контроль за условиями труда», пп. 9–15 (<a href="https://www.consultant.ru/document/cons_doc_LAW_535845/69252b917d81980eee80a287c3a241c76c90f105/" target="_blank" rel="noopener">КонсультантПлюс</a>)</li><li>Федеральный закон от 30.03.1999 № <span class="nw">52-ФЗ</span> «О <span class="nw">санитарно-эпидемиологическом</span> благополучии населения» — ст. 32, п. 1.1 (результаты измерений спецоценки условий труда в производственном контроле) (<a href="https://www.consultant.ru/document/cons_doc_LAW_22481/" target="_blank" rel="noopener">КонсультантПлюс</a>)</li><li>СП <span class="nw">2.1.4284-26</span> «<span class="nw">Санитарно-эпидемиологические</span> требования к эксплуатации помещений, зданий, сооружений, оборудования и транспорта, а также условиям деятельности хозяйствующих субъектов, осуществляющих продажу товаров, выполнение работ или оказание услуг» (утв. 02.06.2026 № 20, действуют с 01.09.2026 взамен СП <span class="nw">2.1.3678-20</span>) — пп. 99.4, 99.38 и приложение № 6 (<a href="http://publication.pravo.gov.ru/document/0001202606020088" target="_blank" rel="noopener">официальное опубликование</a>)</li><li>СП <span class="nw">1.1.1058-01</span> «Организация и проведение производственного контроля за соблюдением санитарных правил и выполнением <span class="nw">санитарно-противоэпидемических</span> (профилактических) мероприятий» — п. 2.5 (<a href="https://www.garant.ru/consult/work_law/1620091/" target="_blank" rel="noopener">Гарант</a>)</li></ul>
  </div>
</section>


<!-- ============ СМОТРИТЕ ТАКЖЕ (перелинковка) ============ -->
<section class="s s-rel" id="smotrite-takzhe">
  <div class="wrap">
    <div class="head">
      <div class="eyebrow" data-eyebrow>Смотрите также</div>
      <h2 data-split>Связанные услуги <em>и материалы</em></h2>
    </div>
    <div class="rel-grid" data-group="cards">
      <a class="card rel-card" href="../../materialy/zamer-osveshchennosti-i-mikroklimata/"><span class="rel-k">Материал</span><span class="rel-t">Как проходит замер освещённости и микроклимата</span><span class="rel-d">Периодичность по СП 2.2.4285-26, подготовка помещений, число точек и отличие от спецоценки.</span><span class="rel-a" aria-hidden="true"><svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></span></a>
      <a class="card rel-card" href="../../laboratornye-issledovaniya/izmerenie-mikroklimata/"><span class="rel-k">Услуга</span><span class="rel-t">Измерение микроклимата</span><span class="rel-d">Температура, влажность и скорость движения воздуха на рабочих местах по МУК 4.3.4120-25 — от 350 ₽ за точку.</span><span class="rel-a" aria-hidden="true"><svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></span></a>
      <a class="card rel-card" href="../../laboratornye-issledovaniya/"><span class="rel-k">Услуга</span><span class="rel-t">Лабораторные исследования</span><span class="rel-d">Смывы, воздух, вода, продукция и замеры по ППК — своя лаборатория, прайс и расчёт онлайн. От 2 600 ₽.</span><span class="rel-a" aria-hidden="true"><svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></span></a>
      <a class="card rel-card" href="../../razrabotka-ppk/"><span class="rel-k">Услуга</span><span class="rel-t">Разработка ППК</span><span class="rel-d">ППК под ваш объект — от 5 900 ₽ за 1 рабочий день, ППК по ХАССП для общепита и пищевых производств — от 19 900 ₽ за 3 рабочих дня.</span><span class="rel-a" aria-hidden="true"><svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></span></a>
    </div>
  </div>
</section>

<section class="s" id="voprosy">
  <div class="wrap">
    <div class="head"><div class="eyebrow" data-eyebrow>Вопросы</div><h2 data-split>Вопросы о <em>замере освещённости</em></h2></div>
    <div class="faq">
      <div class="faq-col" data-group="faq">
        <div class="card qa"><button aria-expanded="false" aria-controls="a1" id="q1"><span>Сколько стоит замер освещённости?</span><span class="pm"></span></button><div class="ans" id="a1" role="region" aria-labelledby="q1"><div><p>От 350&nbsp;₽ за точку. Итог зависит от числа помещений, рабочих мест и расположения светильников. Соберите <a href="#ceny">расчёт</a> или пришлите план помещений — назовём точную сумму до выезда.</p></div></div></div>
        <div class="card qa"><button aria-expanded="false" aria-controls="a2" id="q2"><span>Как часто нужно измерять освещённость на рабочих местах?</span><span class="pm"></span></button><div class="ans" id="a2" role="region" aria-labelledby="q2"><div><p>С кратностью из программы производственного контроля. По п. 15 СП <span class="nw">2.2.4285-26</span> её устанавливает работодатель — обязательно там, где освещённость не соответствовала нормам при спецоценке или прежних замерах, и после реконструкции или капремонта. В салонах красоты и парикмахерских — 1&nbsp;раз в год (п. 99.38 СП <span class="nw">2.1.4284-26</span>).</p></div></div></div>
        <div class="card qa"><button aria-expanded="false" aria-controls="a3" id="q3"><span>Какая норма освещённости в офисе?</span><span class="pm"></span></button><div class="ans" id="a3" role="region" aria-labelledby="q3"><div><p>Для кабинетов, рабочих комнат и офисов — 300&nbsp;лк при общем освещении и 400&nbsp;лк при комбинированном, коэффициент пульсации — не более 15&nbsp;%. Для залов персональных компьютеров — 400 и 500&nbsp;лк, пульсация — не более 5&nbsp;% (СанПиН <span class="nw">1.2.3685-21</span>).</p></div></div></div>
        <div class="card qa"><button aria-expanded="false" aria-controls="a4" id="q4"><span>Почему замер проводят вечером?</span><span class="pm"></span></button><div class="ans" id="a4" role="region" aria-labelledby="q4"><div><p>Искусственное освещение измеряют в тёмное время суток, когда естественный свет не превышает 10&nbsp;% искусственного (п. 6.1.1 ГОСТ <span class="nw">24940-2016</span>). Днём замер возможен, если плотно занавесить окна.</p></div></div></div>
      </div>
      <div class="faq-col" data-group="faq">
        <div class="card qa"><button aria-expanded="false" aria-controls="a5" id="q5"><span>Чем измеряют освещённость?</span><span class="pm"></span></button><div class="ans" id="a5" role="region" aria-labelledby="q5"><div><p>Люксметром с погрешностью не более 10&nbsp;% и действующей поверкой (пп. 4.1–4.2 ГОСТ <span class="nw">24940-2016</span>). Приложение в телефоне для протокола не подходит.</p></div></div></div>
        <div class="card qa"><button aria-expanded="false" aria-controls="a6" id="q6"><span>Что такое коэффициент пульсации освещённости?</span><span class="pm"></span></button><div class="ans" id="a6" role="region" aria-labelledby="q6"><div><p>Это показатель того, насколько сильно мерцает свет. Глаз пульсацию почти не замечает, но она утомляет при долгой работе. Для офисов норма — не более 15&nbsp;%, для залов персональных компьютеров — не более 5&nbsp;%. Нужен ли этот показатель в вашем протоколе, сверим с программой производственного контроля.</p></div></div></div>
        <div class="card qa"><button aria-expanded="false" aria-controls="a7" id="q7"><span>Сколько точек нужно для замера?</span><span class="pm"></span></button><div class="ans" id="a7" role="region" aria-labelledby="q7"><div><p>Точки выбирают по плану помещения: минимальную освещённость проверяют под светильниками, между ними и у стен, среднюю — по сетке точек. На каждом рабочем месте измеряют освещённость его рабочей поверхности. Пришлите план — посчитаем точки заранее.</p></div></div></div>
        <div class="card qa"><button aria-expanded="false" aria-controls="a8" id="q8"><span>Можно ли использовать результаты спецоценки условий труда?</span><span class="pm"></span></button><div class="ans" id="a8" role="region" aria-labelledby="q8"><div><p>Можно, если измерения спецоценки проведены аккредитованной лабораторией не раньше чем за 6&nbsp;месяцев до производственного контроля (п. 1.1 ст. 32 Федерального закона № <span class="nw">52-ФЗ</span>).</p></div></div></div>
      </div>
    </div>
  </div>
</section>

<section class="cta" id="zayavka"><div class="cta-bg f-lazy" aria-hidden="true" data-parallax-bg></div><div class="cta-orb" id="orb" aria-hidden="true"></div>
  <div class="wrap">
    <div>
      <div class="eyebrow" data-eyebrow>Заявка</div>
      <h2 data-split>Измерим освещённость <em>на вашем объекте</em></h2>
      <p class="sub" data-fade>Опишите объект или пришлите программу производственного контроля — перезвоним, посчитаем точки и назовём стоимость.</p>
      <ul class="cta-list" data-group="ctalist"><li><svg aria-hidden="true" focusable="false" class="lucide lucide-circle-check" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <circle cx="12" cy="12" r="10" /> <path d="m16 9-5.5 5.5L8 12" /> </svg><span>Замер освещённости — от 350&nbsp;₽ за точку</span></li><li><svg aria-hidden="true" focusable="false" class="lucide lucide-circle-check" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <circle cx="12" cy="12" r="10" /> <path d="m16 9-5.5 5.5L8 12" /> </svg><span>Измерения по ГОСТ <span class="nw">24940-2016</span></span></li><li><svg aria-hidden="true" focusable="false" class="lucide lucide-circle-check" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <circle cx="12" cy="12" r="10" /> <path d="m16 9-5.5 5.5L8 12" /> </svg><span>Москва и Московская область</span></li></ul>
      <div class="cta-contacts" data-fade>
        <a class="ph" href="tel:+74951043570">+7 (495) 104-35-70</a>
        <div class="msg">
          <a href="https://max.ru/u/f9LHodD0cOIlIUXFkt4KMFP88lD8n4TArBiTcV7RI1XML5c4o39QfsDBXUc" class="max" aria-label="Написать в Max" target="_blank" rel="noopener noreferrer"><svg viewBox="0 0 24 24" fill="#fff" aria-hidden="true"><path d="M12 3a9 9 0 0 0-7.7 13.7L3 21l4.4-1.2A9 9 0 1 0 12 3zm-3.6 12.3V8.7h1.6l2 2.8 2-2.8h1.6v6.6h-1.7v-3.9L12 14l-1.9-2.6v3.9z"/></svg></a>
          <a href="https://t.me/Centr_Dezinfection?text=%D0%97%D0%B4%D1%80%D0%B0%D0%B2%D1%81%D1%82%D0%B2%D1%83%D0%B9%D1%82%D0%B5!%20%D0%9F%D0%B8%D1%88%D1%83%20%D1%81%20%D1%81%D0%B0%D0%B9%D1%82%D0%B0%20%D0%BF%D0%B5%D1%81%D1%82%D0%BA%D0%BE%D0%BD%D1%82%D1%80%D0%BE%D0%BB%D1%8C-%D1%86%D0%B5%D0%BD%D1%82%D1%80.%D1%80%D1%84" class="tg" aria-label="Написать в Telegram" target="_blank" rel="noopener noreferrer"><svg viewBox="0 0 24 24" fill="#fff" aria-hidden="true"><path d="M21.4 4.3 2.9 11.4c-1.3.5-1.2 1.2-.2 1.5l4.7 1.5 1.8 5.6c.2.6.4.8.9.8.4 0 .6-.2.9-.4l2.3-2.2 4.7 3.5c.9.5 1.5.2 1.7-.8l3.1-14.6c.3-1.3-.5-1.8-1.4-1.5zM9.6 14.1l8.6-5.4c.4-.3.8-.1.5.2l-7.1 6.4-.3 3.3z"/></svg></a>
        </div>
      </div>
    </div>
    <form class="form" id="form" novalidate data-form>
      <div class="fbody">
        <h3>Расчёт исследований</h3>
        <p class="fs">Заполнение займёт меньше минуты</p>
        <div class="lb-fcalc" id="lb-fcalc" hidden><p class="lb-fcalc-h">Ваш расчёт</p><ul id="lb-fcalc-list"></ul><p class="lb-fcalc-t" id="lb-fcalc-t"></p></div>
        <div class="fg">
<div class="field"><label class="sr-only" for="f-name">Ваше имя</label><input id="f-name" name="name" placeholder="Ваше имя *" required autocomplete="name"><small class="ferr">Укажите имя</small></div>
<div class="field"><label class="sr-only" for="phone">Телефон</label><input name="phone" id="phone" type="tel" inputmode="tel" placeholder="+7 (___) ___-__-__ *" required autocomplete="tel"><small class="ferr">Укажите телефон полностью</small></div>
<div class="field full"><label class="sr-only" for="f-company">Компания</label><input id="f-company" name="company" placeholder="Компания (необязательно)" autocomplete="organization"></div>
<div class="field full"><label class="sr-only" for="f-type">Вид объекта</label><select id="f-type" name="type" required><option value="" selected>Вид объекта *</option><option>Ресторан или кафе</option><option>Магазин или торговая сеть</option><option>Пищевое производство</option><option>Склад, логистика</option><option>Гостиница</option><option value="Другое">Медицинская организация</option><option value="Другое">Салон красоты</option><option value="Другое">Бассейн, фитнес</option><option value="Другое">Школа, детский сад</option><option value="Другое">Офис, бизнес-центр</option><option>Фармацевтическое производство</option><option>Другое</option></select><small class="ferr">Выберите вид объекта</small></div>
<div class="field full"><label class="sr-only" for="f-goal">Что нужно</label><select id="f-goal" name="goal"><option value="">Что нужно</option><option>Лабораторный контроль по ППК</option><option>Смывы и пробы воздуха</option><option>Анализ воздуха рабочей зоны</option><option>Анализ воды</option><option>Анализ пищевых продуктов</option><option selected>Замеры на рабочих местах</option><option>Стерильность и стерилизаторы</option><option>Анализ почвы</option><option>Испытания продукции</option><option>Не знаю, какие исследования нужны</option></select></div>
<div class="field full"><label class="sr-only" for="f-addr">Адрес или район</label><input id="f-addr" name="address" placeholder="Адрес или район" autocomplete="street-address"></div>
<div class="field full"><label class="sr-only" for="f-msg">Комментарий</label><textarea id="f-msg" name="comment" placeholder="Комментарий: вид объекта, площадь, число помещений"></textarea></div>
<input type="hidden" name="msg" value="">
<div class="field" hidden><input type="hidden" name="email" value=""></div>
<input type="hidden" name="page" value="Замер освещённости">
</div>
        <button type="submit" class="btn btn-w btn-lg" id="submitBtn"><span class="btn-t">Рассчитать стоимость</span><svg class="btn-ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M5 12h14M13 6l6 6-6 6"/></svg><i class="spin" aria-hidden="true"></i></button>
        <p class="legal">Нажимая кнопку, вы даёте <a href="../../soglasie/" target="_blank" rel="noopener">согласие на обработку персональных данных</a> и подтверждаете, что ознакомились с <a href="../../privacy/" target="_blank" rel="noopener">политикой конфиденциальности</a>.</p>
      </div>
      <div class="ok" role="status" aria-live="polite">
        <svg class="ok-ic" viewBox="0 0 52 52" aria-hidden="true"><circle cx="26" cy="26" r="24" fill="none"/><path fill="none" d="M15 27l7 7 15-16"/></svg>
        <h3>Заявка отправлена</h3><p>Перезвоним в ближайшее рабочее время, уточним задачу и назовём стоимость.</p>
      </div>
    </form>
  </div>
</section>
</main>
<div class="lb-bar" id="lb-bar" hidden><div class="lb-bar-in"><p class="lb-bar-t"><span id="lb-bar-n">0 позиций</span><b id="lb-bar-s">от 0 ₽</b></p><button type="button" class="lb-bar-clear" id="lb-bar-clear">Очистить</button><a href="#zayavka" class="btn btn-w btn-sm lb-bar-go" id="lb-bar-go"><span class="btn-t">Отправить расчёт</span></a></div></div>


<footer>
  <div class="wrap">
    <div class="ft">
      <div>
        <a href="../../" class="logo" aria-label="ПЕСТКОНТРОЛЬ Центр — на главную"><span class="logo-mark"><svg viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="1.6" stroke-linejoin="round" aria-hidden="true"><path d="M12 2.5l7.5 3v6c0 5-3.2 8.6-7.5 10-4.3-1.4-7.5-5-7.5-10v-6z"/><circle cx="12" cy="11.5" r="2.6" stroke="#7c86ff"/><path d="M12 6.2v2.7M12 14.1v2.7M6.8 11.5h2.6M14.6 11.5h2.6" stroke="#7c86ff"/></svg></span><span class="logo-txt"><span class="logo-name">ПЕСТКОНТРОЛЬ</span> <span class="logo-sub">Центр</span></span></a>
        <p class="d"><span class="nw">Пест-контроль</span> и <span class="nw">пест-менеджмент</span> по системе IPM для бизнеса в Москве и Московской области: бесплатный аудит, оценка <span class="nw">пест-риска</span>, мониторинг вредителей и отчётность.</p>
      </div>
      <div><h4>Услуги</h4><ul><li><a href="../../dezinfektsiya/">Дезинфекция для организаций</a></li><li><a href="../../deratizatsiya/">Дератизация для организаций</a></li><li><a href="../../dezinsektsiya/">Дезинсекция для организаций</a></li><li><a href="../../deratizatsiya-i-dezinsektsiya/">Дератизация и дезинсекция</a></li><li><a href="../../sanitarnyy-audit/"><span>Санитарный аудит <span class="nw">(СЭС-аудит)</span></span></a></li><li><a href="../../laboratornye-issledovaniya/">Лабораторные исследования</a></li><li><a href="../../razrabotka-ppk/">Разработка ППК</a></li><li><a href="../../normativnaya-baza/dokumenty-dlya-rospotrebnadzora/">Документы для Роспотребнадзора</a></li><li><a href="../../ochistka-dezinfektsiya-ventilyatsii/">Очистка и дезинфекция вентиляции</a></li><li><a href="../../dogovor-deratizatsiya-dezinsektsiya/">Договор на дератизацию и дезинсекцию</a></li><li><a href="../../#podhod"><span><span class="nw">Пест-контроль</span> по системе IPM</span></a></li><li><a href="../../#etapy">Этапы работы</a></li><li><a href="../../#vrediteli">Вредители</a></li><li><a href="../../#usloviya">Цена</a></li><li><a href="../../#voprosy">Вопросы</a></li></ul></div>
      <div><h4>Отрасли</h4><ul><li><a href="../../pishchevoe-proizvodstvo/">Пищевые производства</a></li><li><a href="../../magaziny-i-torgovye-seti/">Магазины и торговые сети</a></li><li><a href="../../restorany-i-kafe/">Рестораны и кафе</a></li><li><a href="../../sklady-i-logistika/">Склады и логистика</a></li><li><a href="../../farmatsevticheskie-proizvodstva/">Фармацевтические производства</a></li><li><a href="../../gostinitsy/">Гостиницы и отели</a></li></ul></div>
      <div><h4>Материалы</h4><ul><li><a href="../../normativnaya-baza/">Нормативная база</a></li><li><a href="../../normativnaya-baza/proverochnye-listy/">Проверочные листы 2026</a></li><li><a href="../../normativnaya-baza/dokumenty-dlya-rospotrebnadzora/">Документы для Роспотребнадзора</a></li><li><a href="../../materialy/programma-pest-kontrolya/"><span>Программа <span class="nw">пест-контроля</span></span></a></li><li><a href="../../materialy/zhurnal-pest-kontrolya/"><span>Журнал <span class="nw">пест-контроля</span></span></a></li><li><a href="../../materialy/pest-menedzhment-ili-razovaya-obrabotka/"><span><span class="nw">Пест-менеджмент</span> или разовая обработка</span></a></li><li><a href="../../materialy/programma-proizvodstvennogo-kontrolya-haccp/">Программа производственного контроля по ХАССП</a></li><li><a href="../../materialy/">Все материалы</a></li></ul></div>
      <div><h4>Контакты</h4><ul><li><a href="tel:+74951043570">+7 (495) 104-35-70</a></li><li><a href="mailto:b2b@pestcontrol-center.ru">b2b@<wbr><span style="white-space:nowrap">pestcontrol-center.ru</span></a></li><li>Пн–Пт: 8:00–20:00</li><li>Срочные выезды: 24/7</li></ul>
        <div class="msg"><a href="https://max.ru/u/f9LHodD0cOIlIUXFkt4KMFP88lD8n4TArBiTcV7RI1XML5c4o39QfsDBXUc" class="max" aria-label="Написать в Max" target="_blank" rel="noopener noreferrer"><svg viewBox="0 0 24 24" fill="#fff" aria-hidden="true"><path d="M12 3a9 9 0 0 0-7.7 13.7L3 21l4.4-1.2A9 9 0 1 0 12 3zm-3.6 12.3V8.7h1.6l2 2.8 2-2.8h1.6v6.6h-1.7v-3.9L12 14l-1.9-2.6v3.9z"/></svg></a><a href="https://t.me/Centr_Dezinfection?text=%D0%97%D0%B4%D1%80%D0%B0%D0%B2%D1%81%D1%82%D0%B2%D1%83%D0%B9%D1%82%D0%B5!%20%D0%9F%D0%B8%D1%88%D1%83%20%D1%81%20%D1%81%D0%B0%D0%B9%D1%82%D0%B0%20%D0%BF%D0%B5%D1%81%D1%82%D0%BA%D0%BE%D0%BD%D1%82%D1%80%D0%BE%D0%BB%D1%8C-%D1%86%D0%B5%D0%BD%D1%82%D1%80.%D1%80%D1%84" class="tg" aria-label="Написать в Telegram" target="_blank" rel="noopener noreferrer"><svg viewBox="0 0 24 24" fill="#fff" aria-hidden="true"><path d="M21.4 4.3 2.9 11.4c-1.3.5-1.2 1.2-.2 1.5l4.7 1.5 1.8 5.6c.2.6.4.8.9.8.4 0 .6-.2.9-.4l2.3-2.2 4.7 3.5c.9.5 1.5.2 1.7-.8l3.1-14.6c.3-1.3-.5-1.8-1.4-1.5zM9.6 14.1l8.6-5.4c.4-.3.8-.1.5.2l-7.1 6.4-.3 3.3z"/></svg></a></div>
      </div>
    </div>
    <div class="fb"><span>© 2026 ПЕСТКОНТРОЛЬ Центр</span><a href="../../privacy/">Политика конфиденциальности</a><a href="../../soglasie/">Согласие на обработку данных</a><span>Информация на сайте не является публичной офертой</span></div>
  </div>
</footer>

<div class="mbar" id="mbar">
  <a href="tel:+74951043570" class="c1"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1 1 .4 1.9.7 2.8a2 2 0 0 1-.5 2.1L8 9.9a16 16 0 0 0 6 6l1.3-1.3a2 2 0 0 1 2.1-.4c.9.3 1.8.6 2.8.7a2 2 0 0 1 1.7 2z"/></svg>Позвонить</a>
  <a href="#zayavka" class="c2"><span>Обследование</span></a>
</div>
<div class="fab" role="group" aria-label="Написать в мессенджер">
  <a href="https://max.ru/u/f9LHodD0cOIlIUXFkt4KMFP88lD8n4TArBiTcV7RI1XML5c4o39QfsDBXUc" class="max" aria-label="Написать в Max" target="_blank" rel="noopener noreferrer"><svg viewBox="0 0 24 24" fill="#fff" aria-hidden="true"><path d="M12 3a9 9 0 0 0-7.7 13.7L3 21l4.4-1.2A9 9 0 1 0 12 3zm-3.6 12.3V8.7h1.6l2 2.8 2-2.8h1.6v6.6h-1.7v-3.9L12 14l-1.9-2.6v3.9z"/></svg></a>
  <a href="https://t.me/Centr_Dezinfection?text=%D0%97%D0%B4%D1%80%D0%B0%D0%B2%D1%81%D1%82%D0%B2%D1%83%D0%B9%D1%82%D0%B5!%20%D0%9F%D0%B8%D1%88%D1%83%20%D1%81%20%D1%81%D0%B0%D0%B9%D1%82%D0%B0%20%D0%BF%D0%B5%D1%81%D1%82%D0%BA%D0%BE%D0%BD%D1%82%D1%80%D0%BE%D0%BB%D1%8C-%D1%86%D0%B5%D0%BD%D1%82%D1%80.%D1%80%D1%84" class="tg" aria-label="Написать в Telegram" target="_blank" rel="noopener noreferrer"><svg viewBox="0 0 24 24" fill="#fff" aria-hidden="true"><path d="M21.4 4.3 2.9 11.4c-1.3.5-1.2 1.2-.2 1.5l4.7 1.5 1.8 5.6c.2.6.4.8.9.8.4 0 .6-.2.9-.4l2.3-2.2 4.7 3.5c.9.5 1.5.2 1.7-.8l3.1-14.6c.3-1.3-.5-1.8-1.4-1.5zM9.6 14.1l8.6-5.4c.4-.3.8-.1.5.2l-7.1 6.4-.3 3.3z"/></svg></a>
</div>

<script>
/* Предпросмотр: вне рабочего домена заявка не отправляется (на пестконтроль-центр.рф этот блок не срабатывает) */
(function(){if(/^(www\.)?xn----itbbsflddbfpfdodg9d0f\.xn--p1ai$/i.test(location.hostname))return;var f=window.fetch;window.fetch=function(u){if(typeof u==='string'&&u.indexOf('send.php')>-1)return new Promise(function(r){setTimeout(function(){r(new Response('{"success":true}',{status:200,headers:{'Content-Type':'application/json'}}))},500)});return f.apply(this,arguments)};document.addEventListener('DOMContentLoaded',function(){var p=document.querySelector('.form .fs');if(p)p.textContent='Предпросмотр: заявка никуда не отправляется'})})();
</script>
<script data-fx>
/* Эффекты под курсором, как на главной (tools/site/fx.py) */
(function(){
  var mm=window.matchMedia;if(!mm)return;
  var fine=mm('(hover: hover) and (pointer: fine)').matches;
  /* «фонарь»: следует за мышью, без движения мыши плавно ходит сам; на сенсорных экранах ходит сам (30 кадров в секунду).
     Не считаем, пока первый экран не виден или вкладка скрыта. Старт — вместе со входом первого экрана */
  var hero=document.getElementById('hero'),lit=hero&&hero.querySelector('.fx-lit');
  if(lit&&!mm('(prefers-reduced-motion: reduce)').matches){
    var media=lit.parentNode,small=mm('(max-width:860px)').matches,full=hero.classList.contains('f-hero');
    lit.style.setProperty('--sr',small?'150px':'clamp(240px, 21vw, 400px)');
    var cx=small?.5:(full?.68:.74),ax=small?.24:(full?.16:.13),cy=small?.5:.47,ay=small?.2:.17;
    var sx=cx,sy=cy,tx=cx,ty=cy,last=-1e9,vis=true,on=false,raf=0,lt=0;
    var frame=function(now){
      raf=0;if(!on||!vis||document.hidden)return;
      var dt=now-lt;if(!fine&&dt<30){raf=requestAnimationFrame(frame);return;}
      lt=now;if(now-last>2600){var t=now/1000;tx=cx+ax*Math.sin(t*.33);ty=cy+ay*Math.sin(t*.47+1.3);}
      var k=1-Math.pow(.94,Math.min(dt,100)/16.67);sx+=(tx-sx)*k;sy+=(ty-sy)*k;
      lit.style.setProperty('--sx',(sx*100).toFixed(2)+'%');lit.style.setProperty('--sy',(sy*100).toFixed(2)+'%');
      raf=requestAnimationFrame(frame);
    };
    var kick=function(){if(!raf&&on&&vis&&!document.hidden){lt=performance.now();raf=requestAnimationFrame(frame);}};
    hero.addEventListener('pointermove',function(e){
      if(e.pointerType!=='mouse')return;var r=media.getBoundingClientRect();if(!r.width||!r.height)return;
      tx=(e.clientX-r.left)/r.width;ty=(e.clientY-r.top)/r.height;last=performance.now();kick();
    },{passive:true});
    if('IntersectionObserver' in window)new IntersectionObserver(function(es){vis=es[0].isIntersecting;kick();}).observe(hero);
    document.addEventListener('visibilitychange',kick);
    var start=function(){if(on)return;on=true;hero.classList.add('fx-lit-on');kick();};
    var eb=hero.querySelector('.eyebrow');
    if(eb&&'MutationObserver' in window){
      if(eb.classList.contains('in'))start();
      else{var mo=new MutationObserver(function(){if(eb.classList.contains('in')){mo.disconnect();start();}});mo.observe(eb,{attributes:true,attributeFilter:['class']});}
    }
    setTimeout(start,eb?5000:2500);
  }
  /* подсветка рамки карточек за курсором — как у .card на главной */
  if(fine)document.addEventListener('pointermove',function(e){
    var c=e.target.closest&&e.target.closest('.d-card,.p-sec,.p-fcard,.p-duty-box,.p-dl-card,.pm-step-card,.pm-scen,.pm-link-card,.k-err,.w-sample,.d-doc-prev');if(!c)return;
    var r=c.getBoundingClientRect();c.style.setProperty('--mx',(e.clientX-r.left)+'px');c.style.setProperty('--my',(e.clientY-r.top)+'px');
  },{passive:true});
})();
</script>
<script>
  /* скрипты анимаций подключаются сразу после первой отрисовки: фото и заголовок первого экрана не ждут их загрузки */
  (function (r, l) {
    var go = function () { l.forEach(function (u) { var e = document.createElement('script'); e.src = r + u; e.async = false; document.body.appendChild(e); }); };
    if (document.visibilityState === 'hidden' || !window.requestAnimationFrame) setTimeout(go, 0);
    else requestAnimationFrame(function () { setTimeout(go, 0); });
  })('../../', ['vendor/gsap.min.js', 'vendor/ScrollTrigger.min.js', 'vendor/lenis.min.js', 'app.min.js?v=20261106s2']);
</script>
<script>window.LB={"ppk":["Лабораторный контроль по ППК","комплекс",2600,1],"smyv":["Анализ смывов","точка",310,1],"v-mikro":["Микробиологический анализ воздуха","комплекс",300,1],"v-him":["Химический анализ воздуха","элемент",600,1],"v-aero":["Аэроионный состав воздуха","точка",600,1],"w-vodoprovod":["Анализ водопроводной воды","комплекс",4330,1],"w-mikro":["Микробиологический анализ воды","комплекс",2350,1],"w-him":["Химический анализ воды","элемент",737,1],"w-parazit":["Паразитологический анализ воды","комплекс",4708,1],"w-bassein":["Анализ воды из бассейна","комплекс",4582,1],"w-butyl":["Анализ бутилированной воды","комплекс",5813,1],"w-skvazhina":["Анализ воды из скважины","комплекс",5500,1],"w-vodoem":["Анализ воды из водоёма","комплекс",2080,1],"w-stok":["Анализ сточных вод","комплекс",5600,1],"w-radiac":["Анализ воды на радиацию","комплекс",8236,1],"w-ryb":["Анализ воды для рыбных хозяйств","комплекс",12124,1],"f-mikro":["Микробиологический анализ пищевых продуктов и готовых блюд","элемент",690,1],"f-him":["Химический анализ пищевых продуктов и готовых блюд","элемент",194,1],"f-cennost":["Анализ пищевой ценности","точка",980,1],"z-mikroklimat":["Измерение микроклимата","точка",350,1],"z-svet":["Измерение освещённости","точка",350,1],"z-shum":["Измерение шума","точка",500,1],"z-vibr":["Измерение вибрации","точка",500,1],"z-emi":["Измерение электромагнитных излучений","точка",1090,1],"rm":["Комплекс измерений на рабочих местах","комплекс",2600,1],"rad":["Измерение радиации","точка",400,1],"st":["Анализ на стерильность","точка",1003,1],"sz":["Контроль работы стерилизаторов","услуга",1600,1],"bu":["Анализ эффективности работы бактерицидной установки","услуга",1600,1],"p-mikro":["Микробиологический анализ почвы","элемент",690,1],"p-him":["Химический анализ почвы","элемент",925,1],"p-radio":["Радиологический анализ почвы","комплекс",5920,0],"p-plodorodie":["Анализ почвы на плодородие","комплекс",3520,1],"p-granulo":["Гранулометрический анализ почвы","комплекс",3200,1],"p-rasteniya":["Анализ почвы на совместимость с растением","документ",3080,0],"i-pishch":["Испытания пищевой продукции","элемент",194,1],"i-kosmetika":["Испытания косметики","комплекс",9100,1],"i-deti":["Испытания детских товаров","комплекс",10100,1],"i-odezhda":["Испытания одежды и текстиля","комплекс",10100,1],"i-upakovka":["Испытания упаковки","комплекс",10100,1],"i-mebel":["Испытания мебели","комплекс",11100,1],"i-siz":["Испытания СИЗ","комплекс",15100,1],"i-tehnika":["Испытания бытовой техники","комплекс",50100,1],"i-oborud":["Испытания оборудования","комплекс",50100,1],"i-med":["Испытания медицинских изделий","комплекс",100100,1],"e":["Измерение сопротивления электросетей","услуга",1600,1]};window.LBP={"n":"Замер освещённости","p":"/laboratornye-issledovaniya/zamer-osveshchennosti/"};
/* Расчёт «Лабораторные исследования»: позиции из прайса (+, количество), наборы по видам объектов,
   панель внизу экрана, список в заявке и в поле msg для send.php. window.LB = {код: [название, единица, цена, «от»]},
   window.LBP = {n: название страницы, p: адрес} — для строки «Страница:» в заявке (страницы направлений, с 11.11.2026).
   Расчёт общий для всех страниц раздела (sessionStorage 'lb-calc'). */
(function(){
var L=window.LB||{},S={},K='lb-calc',sent={},P=window.LBP||{n:'Лабораторные исследования',p:'/laboratornye-issledovaniya/'};
try{S=JSON.parse(sessionStorage.getItem(K))||{};}catch(_){S={};}
for(var k in S){if(!L[k]||!(S[k]>0))delete S[k];}
function goal(g){if(sent[g])return;sent[g]=1;try{if(window.ym)ym(113675622,'reachGoal',g)}catch(_){}}
function rub(n){return String(n).replace(/\B(?=(\d{3})+(?!\d))/g,'\u00a0')+'\u00a0₽';}
function plural(n,a,b,c){var m=n%10,h=n%100;return n+' '+(m==1&&h!=11?a:m>=2&&m<=4&&(h<12||h>14)?b:c);}
function total(){var s=0,n=0;for(var k in S){s+=L[k][2]*S[k];n++;}return {s:s,n:n};}
function save(){try{sessionStorage.setItem(K,JSON.stringify(S));}catch(_){}}
function cell(id){
  var q=S[id],nm=L[id][0];
  if(!q)return '<button type="button" class="lb-add" data-add="'+id+'" aria-label="Добавить в расчёт: '+nm+'"><span aria-hidden="true">+</span></button>';
  return '<span class="lb-qty"><button type="button" data-dec="'+id+'" aria-label="Меньше: '+nm+'">−</button>'+
    '<input type="number" inputmode="numeric" min="0" max="999" value="'+q+'" data-q="'+id+'" aria-label="Количество, '+L[id][1]+': '+nm+'">'+
    '<button type="button" data-inc="'+id+'" aria-label="Больше: '+nm+'">+</button></span>';
}
function render(focus){
  var rows=document.querySelectorAll('.lb-tbl tr[data-id]');
  for(var i=0;i<rows.length;i++){
    var r=rows[i],id=r.getAttribute('data-id'),td=r.querySelector('.lb-tc'),want=S[id]?'q':'a';
    r.classList.toggle('lb-on',!!S[id]);
    if(td.getAttribute('data-st')!==want){td.innerHTML=cell(id);td.setAttribute('data-st',want);}
    else if(S[id]){var inp=td.querySelector('input');if(inp&&document.activeElement!==inp)inp.value=S[id];}
  }
  var t=total(),bar=document.getElementById('lb-bar');
  if(bar){bar.hidden=!t.n;document.body.classList.toggle('lb-has-bar',!!t.n);
    document.getElementById('lb-bar-n').textContent=plural(t.n,'позиция','позиции','позиций');
    document.getElementById('lb-bar-s').textContent='от '+rub(t.s);}
  var fc=document.getElementById('lb-fcalc');
  if(fc){fc.hidden=!t.n;var ul=document.getElementById('lb-fcalc-list'),h='';
    for(var k in S){h+='<li><span>'+L[k][0]+'</span><span>'+S[k]+' × '+rub(L[k][2])+'</span></li>';}
    ul.innerHTML=h;document.getElementById('lb-fcalc-t').textContent='Итого: от '+rub(t.s);}
  if(focus){var el=document.querySelector(focus);if(el)el.focus();}
  save();
}
function set(id,q,focus){q=Math.max(0,Math.min(999,parseInt(q,10)||0));if(q)S[id]=q;else delete S[id];if(q)goal('lab_pozitsiya');render(focus);}
document.addEventListener('click',function(e){
  var t=e.target.closest&&e.target.closest('[data-add],[data-inc],[data-dec],[data-set],[data-open],#lb-bar-clear,#lb-bar-go');
  if(!t)return;var id;
  if((id=t.getAttribute('data-add'))){set(id,1,'input[data-q="'+id+'"]');}
  else if((id=t.getAttribute('data-inc'))){set(id,(S[id]||0)+1,'[data-inc="'+id+'"]');}
  else if((id=t.getAttribute('data-dec'))){var q=(S[id]||0)-1;set(id,q,q>0?'[data-dec="'+id+'"]':'[data-add="'+id+'"]');}
  else if(t.hasAttribute('data-set')){
    try{JSON.parse(t.getAttribute('data-set')).forEach(function(p){if(L[p[0]])S[p[0]]=(S[p[0]]||0)+p[1];});}catch(_){}
    goal('lab_nabor');render();
    var ok=t.parentNode.querySelector('.lb-set-ok');if(ok){ok.textContent='Добавлено ✓';clearTimeout(ok._t);ok._t=setTimeout(function(){ok.textContent='';},2500);}
  }
  else if((id=t.getAttribute('data-open'))){var d=document.getElementById('g-'+id);if(d)d.open=true;}
  else if(t.id==='lb-bar-clear'){S={};render();}
  else if(t.id==='lb-bar-go'){goal('lab_raschet');}
});
document.addEventListener('change',function(e){var id=e.target.getAttribute&&e.target.getAttribute('data-q');if(id)set(id,e.target.value);});
document.addEventListener('keydown',function(e){var id=e.target.getAttribute&&e.target.getAttribute('data-q');if(id&&e.key==='Enter'){e.preventDefault();set(id,e.target.value);}});
function openHash(){var h=location.hash;if(h&&h.indexOf('#g-')===0){var d=document.getElementById(h.slice(1));if(d)d.open=true;}}
window.addEventListener('hashchange',openHash);openHash();
/* Заявка: вид объекта, что нужно, адрес, комментарий, расчёт и страница — в поле msg (send.php, до 3000 знаков) */
document.addEventListener('submit',function(ev){var f=ev.target;if(!f||f.id!=='form')return;var e=f.elements,
  g=e.goal.value||'не выбрано',a=e.address.value.trim()||'не указан',c=e.comment.value.trim(),
  o=e.type.options[e.type.selectedIndex],k=o&&o.value&&o.text!==o.value?'Вид объекта: '+o.text+'\n':'',r='',t=total();
  if(t.n){r='\nРасчёт:';for(var id in S){r+='\n— '+L[id][0]+': '+S[id]+' ('+L[id][1]+') × '+(L[id][3]?'от ':'')+L[id][2]+' ₽';}r+='\nИтого: от '+t.s+' ₽';}
  var m=k+'Что нужно: '+g+'\nАдрес: '+a+(c?'\nКомментарий: '+c:'')+r+'\nСтраница: '+P.n+' ('+P.p+')';
  e.msg.value=m.length>3000?m.slice(0,2990)+'…':m;},true);
document.addEventListener('click',function(e){var b=e.target.closest&&e.target.closest('[data-goal]');if(!b)return;
  var g=document.getElementById('f-goal');if(g)g.value=b.getAttribute('data-goal');});
render();
})();</script>
<!-- Yandex.Metrika counter + UIS + Radist: загружаются после первого действия посетителя (касание, прокрутка, мышь, клавиатура) или через 5 с после загрузки страницы -->
<script type="text/javascript">
    (function (w, d) {
        w.ym = w.ym || function () { (w.ym.a = w.ym.a || []).push(arguments); };
        w.ym.l = 1 * new Date();
        ym(113675622, 'init', {ssr:true, webvisor:true, clickmap:true, ecommerce:"dataLayer", referrer: document.referrer, url: location.href, accurateTrackBounce:true, trackLinks:true});
        var done = false, ready = false, wait = null, ev = ['pointerdown', 'touchstart', 'keydown', 'scroll', 'wheel', 'mousemove'];
        w.__cs = w.__cs || [];
        w.__cs.push(['waitForTrackViewAndRun', function () { ready = true; }]);
        // Radist: код заявки в ссылках Telegram и MAX — сразу, скрипт Radist загрузится вместе со счётчиками
        var rmsg = 'Здравствуйте! Пишу с сайта пестконтроль-центр.рф. Номер заявки: {radist_tracker}';
        w.radist_tracker = w.radist_tracker || function () { (w.radist_tracker.a = w.radist_tracker.a || []).push(arguments); };
        w.radist_tracker.l = 1 * new Date();
        w.radist_tracker({ message: rmsg, whatsapp_enabled: true, tgbot_enabled: true, tg_enabled: true, max_enabled: true, vk_enabled: true });
        (function () {
            var id = null, abc = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789', s = 'ro', i, txt;
            try {
                id = sessionStorage.getItem('radistVisit');
                if (!id || id.length !== 12) {
                    for (i = 0; i < 10; i++) s += abc.charAt(Math.floor(Math.random() * abc.length));
                    sessionStorage.setItem('radistVisit', s);
                    id = sessionStorage.getItem('radistVisit');
                }
            } catch (e) { id = null; }
            if (!id || id.length !== 12) return;
            txt = encodeURIComponent(rmsg.replace(/{radist_tracker}/g, id));
            [].forEach.call(d.querySelectorAll('a[href*="//t.me/"], a[href*="//max.ru/"]'), function (a) {
                try {
                    var u = new URL(a.href), n = u.pathname.split('/')[1] || '';
                    if (u.host === 'max.ru') a.href = 'https://max.ru/' + u.pathname.substring(1) + '?start=' + id;
                    else if (u.host === 't.me' && !/bot$/i.test(n)) a.href = 'https://t.me' + u.pathname + '?text=' + txt;
                } catch (e) {}
            });
        })();
        function add(src) { var k = d.createElement('script'); k.async = true; k.src = src; d.head.appendChild(k); return k; }
        function load() {
            if (done) return; done = true;
            ev.forEach(function (e) { w.removeEventListener(e, load, true); });
            add('https://mc.yandex.ru/metrika/tag.js?id=113675622');
            var p = d.createElement('link'); p.rel = 'preconnect'; p.href = 'https://tracker.comagic.ru'; d.head.appendChild(p);
            add('https://app.uiscom.ru/static/cs.min.js?k=ICWycQx6m3NSBe3WlCeDAdAKMTmNhMHC').onerror = function () { ready = true; };
            add('https://track.radist.me/tracker.min.js');
        }
        ev.forEach(function (e) { w.addEventListener(e, load, { capture: true, passive: true }); });
        function later() { setTimeout(load, 5000); }
        if (d.readyState === 'complete') later(); else w.addEventListener('load', later);
        // Ожидание подмены номера при первом касании: набор откладывается до ответа UIS, максимум 0,8–1 с
        d.addEventListener('click', function (e) {
            if (ready) return;
            var a = e.target && e.target.closest ? e.target.closest('a[href^="tel:"]') : null;
            if (!a || e.button || e.ctrlKey || e.metaKey || e.shiftKey || e.altKey) return;
            e.preventDefault();
            if (wait) return;
            load();
            var href = a.getAttribute('href'), op = a.style.opacity, max = 'GestureEvent' in w ? 800 : 1000, t;
            function go() {
                for (var i = 0; i < wait.length; i++) clearTimeout(wait[i]);
                wait = null; ready = true; a.style.opacity = op;
                w.location.href = a.href;
            }
            function check(last) { return function () { if (wait && (last || ready || a.getAttribute('href') !== href)) go(); }; }
            wait = [];
            a.style.opacity = '.6';
            for (t = 50; t <= max; t += 50) wait.push(setTimeout(check(t === max), t));
        }, true);
    })(window, document);
</script>
<noscript><div><img src="https://mc.yandex.ru/watch/113675622" style="position:absolute; left:-9999px;" alt="" /></div></noscript>
<!-- /Yandex.Metrika counter -->
</body>
</html>
