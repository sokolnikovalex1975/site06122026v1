<!doctype html>
<html lang="ru">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>Дератизация и дезинсекция в Москве — цены для юридических лиц — ПЕСТКОНТРОЛЬ Центр</title>
<meta name="description" content="Дезинсекция и дератизация для организаций в Москве и области: комплекс от 4 900 ₽/мес, общий график визитов, акты и журнал. Цены для юрлиц, документы для закупок.">
<link rel="canonical" href="https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/deratizatsiya-i-dezinsektsiya/">
<meta name="theme-color" content="#000000">
<meta property="og:type" content="website">
<meta property="og:locale" content="ru_RU">
<meta property="og:site_name" content="ПЕСТКОНТРОЛЬ Центр">
<meta property="og:url" content="https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/deratizatsiya-i-dezinsektsiya/">
<meta property="og:title" content="Дератизация и дезинсекция для организаций — комплекс от 4 900 ₽/мес">
<meta property="og:description" content="Дезинсекция и дератизация для организаций в Москве и области: комплекс от 4 900 ₽/мес, общий график визитов, акты и журнал. Цены для юрлиц, документы для закупок.">
<meta property="og:image" content="https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/img/dd-og.jpg">
<meta property="og:image:type" content="image/jpeg">
<meta property="og:image:width" content="1200">
<meta property="og:image:height" content="630">
<meta property="og:image:alt" content="Специалист проверяет контейнер для грызунов в складском помещении ресторана, рядом ловушка для насекомых">
<meta name="twitter:card" content="summary_large_image">
<link rel="icon" href="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 32 32'%3E%3Ccircle cx='16' cy='16' r='15' fill='%2309090b' stroke='%237c86ff' stroke-width='2'/%3E%3Cpath d='M16 7l7 3v5c0 5-3 8.5-7 10-4-1.5-7-5-7-10v-5z' fill='none' stroke='%23fff' stroke-width='2'/%3E%3C/svg%3E">
<link rel="preload" href="../fonts/inter-ru-wght-normal.woff2" as="font" type="font/woff2" crossorigin>
<link rel="preload" as="image" media="(min-width:761px)" imagesrcset="../img/dd-hero-1440.webp 1440w, ../img/dd-hero.webp 1920w" imagesizes="100vw" fetchpriority="high">
<link rel="preload" as="image" media="(max-width:760px)" imagesrcset="../img/dd-hero-mob-760.webp 760w, ../img/dd-hero-mob.webp 1024w" imagesizes="100vw" fetchpriority="high">
<script>
  /* начальные состояния анимаций — только при работающем JS; страховка — через 4 с всё показывается.
     Заставка — один раз за посещение: при переходе по ссылке с якорем и между страницами сайта её нет */
  (function (d) {
    d.classList.add('js');
    try { if (location.hash || sessionStorage.getItem('pc-intro')) d.classList.add('no-intro'); else sessionStorage.setItem('pc-intro', '1'); }
    catch (e) { if (location.hash) d.classList.add('no-intro'); }
    setTimeout(function () { if (!d.classList.contains('anim-ready')) d.classList.add('anim-fail'); }, 4000);
  })(document.documentElement);
</script>
<link rel="stylesheet" href="../style.css?v=20261106s2">
<style>.d-page .s{padding:clamp(64px,7vw,128px) 0;border-top:1px solid var(--line)}.d-crumbs{padding-top:calc(clamp(68px,6vw,115px) + 20px);font-size:14px;color:var(--t3);display:flex;flex-wrap:wrap;gap:8px}.d-crumbs a{color:var(--t2)}.d-crumbs a:hover{color:var(--t1)}.d-hero{padding:clamp(28px,3vw,56px) 0 clamp(64px,7vw,128px)}.d-hero .wrap{display:grid;grid-template-columns:minmax(0,1.15fr) minmax(0,.85fr);gap:clamp(28px,4vw,80px);align-items:center}.d-hero h1{font-size:clamp(34px,4.2vw,80px);line-height:1.05;letter-spacing:-.045em;font-weight:300;margin:18px 0 0}.d-ticks{list-style:none;padding:0;margin:28px 0 34px;display:grid;gap:12px}.d-ticks li{position:relative;padding-left:30px;line-height:1.5}.d-ticks li::before{content:"";position:absolute;left:2px;top:.42em;width:13px;height:7px;border-left:2px solid var(--acc);border-bottom:2px solid var(--acc);transform:rotate(-45deg)}.d-btns{display:flex;flex-wrap:wrap;gap:12px}.ph-img{aspect-ratio:4/3;border:1.5px dashed var(--line2);border-radius:var(--r);display:flex;align-items:center;justify-content:center;text-align:center;padding:28px;color:var(--t3);font-size:14px;line-height:1.5;background:rgba(255,255,255,.02)}.ph-doc{aspect-ratio:3/4;max-width:340px}.d-cards{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:16px}.d-card{background:var(--card);border:1px solid var(--line2);border-radius:var(--r);padding:clamp(22px,2vw,34px)}.d-card h3{font-size:clamp(20px,1.5vw,26px);font-weight:400;letter-spacing:-.02em;margin:0 0 12px}.d-card p{color:var(--t2);line-height:1.6;margin:0}.d-note{color:var(--t2);margin:24px 0 0;line-height:1.6}.d-strong{color:var(--t1);font-size:clamp(18px,1.3vw,22px)}.d-split{display:grid;grid-template-columns:minmax(0,1fr) minmax(0,340px);gap:clamp(28px,4vw,80px);align-items:start}.d-two{display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1fr);gap:clamp(28px,4vw,80px);align-items:start}.d-two .head{margin-bottom:0}.d-two .d-ticks{margin:0}.d-terms{list-style:none;counter-reset:t;padding:0;margin:0;border-top:1px solid var(--line2)}.d-terms li{display:grid;grid-template-columns:44px minmax(0,.42fr) minmax(0,1fr);gap:16px;padding:18px 0;border-bottom:1px solid var(--line2);line-height:1.55}.d-terms li::before{counter-increment:t;content:counter(t,decimal-leading-zero);color:var(--t3)}.d-terms b{font-weight:500}.d-terms span{color:var(--t2)}.d-doc{display:grid;gap:16px;justify-items:start}.d-small{font-size:14px;color:var(--t3);margin:0}.d-steps{list-style:none;counter-reset:st;padding:0;margin:0;display:grid;grid-template-columns:repeat(5,minmax(0,1fr));gap:18px}.d-steps li{border-top:2px solid var(--line2);padding-top:18px;line-height:1.55}.d-steps li::before{counter-increment:st;content:"0" counter(st);display:block;color:var(--acc);font-size:14px;margin-bottom:12px}.d-steps b{display:block;font-weight:500;margin-bottom:8px}.d-steps span{color:var(--t2)}.d-table{width:100%;border-collapse:collapse;line-height:1.5}.d-table th,.d-table td{text-align:left;vertical-align:top;padding:16px 20px 16px 0;border-bottom:1px solid var(--line2)}.d-table th{color:var(--t3);font-weight:400;font-size:14px}.d-table td{color:var(--t2)}.d-table td:first-child{color:var(--t1)}.d-vs td:first-child{color:var(--t2)}.d-vs th:last-child,.d-vs td:last-child{color:var(--t1);background:rgba(124,134,255,.07);padding-left:20px}.d-cols2{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:16px;margin-top:28px}.d-chips{list-style:none;padding:0;margin:0;display:flex;flex-wrap:wrap;gap:10px}.d-chips a{display:inline-block;padding:12px 18px;border:1px solid var(--line2);border-radius:999px;color:var(--t1);transition:border-color .2s}.d-chips a:hover{border-color:var(--acc)}.tbd{background:rgba(255,209,102,.14);color:#ffd166;border-radius:4px;padding:0 .2em}.d-page .cta .sub{margin-bottom:30px}@media (max-width:1100px){.d-steps{grid-template-columns:repeat(2,minmax(0,1fr))}}@media (max-width:860px){.d-hero .wrap,.d-split,.d-two,.d-cols2,.d-cards{grid-template-columns:minmax(0,1fr)}.d-terms li{grid-template-columns:36px minmax(0,1fr);gap:6px 12px}.d-terms span{grid-column:2}.ph-doc{display:none}}@media (max-width:600px){.d-steps{grid-template-columns:minmax(0,1fr)}.d-table thead{display:none}.d-table,.d-table tbody,.d-table tr,.d-table td{display:block;width:100%}.d-table tr{border:1px solid var(--line2);border-radius:var(--r);padding:6px 16px;margin-bottom:12px}.d-table td{border:0;padding:10px 0}.d-table td+td{border-top:1px solid var(--line)}.d-table td::before{content:attr(data-l);display:block;font-size:13px;color:var(--t3);margin-bottom:4px}.d-vs td:last-child{background:none;padding-left:0}.d-page .form .btn-lg{padding:0 16px}}.hdr .nav a{white-space:nowrap}.f-lazy:not(.bg-in){background-image:none!important}
.f-hero .hero-media{overflow:hidden}.f-hero .hero-media::after{content:"";position:absolute;inset:0 0 auto;height:200px;background:linear-gradient(180deg,rgba(9,9,11,.72),rgba(9,9,11,0));pointer-events:none}.f-hero .f-hero-img{position:absolute;inset:0;width:100%;height:100%;object-fit:cover;object-position:64% 50%;filter:saturate(.95)}.f-hero::before{background:linear-gradient(90deg,rgba(9,9,11,.92) 0%,rgba(9,9,11,.84) 40%,rgba(9,9,11,.32) 58%,rgba(9,9,11,0) 74%)}.f-hero::after{height:22%}.f-hero p.lead{max-width:600px}.f-crumbs{display:flex;flex-wrap:wrap;gap:8px;font-size:14px;color:var(--t3);margin:0 0 26px}.f-crumbs a{color:var(--t2)}.f-crumbs a:hover{color:var(--t1)}.f-urgent{margin:22px 0 0;color:var(--t2);font-size:15px}.f-urgent::before{content:"";display:inline-block;width:8px;height:8px;border-radius:50%;background:var(--grn);margin-right:10px;vertical-align:middle}
.f-checks{position:relative;padding:clamp(28px,3vw,56px) 0 clamp(56px,6vw,110px)}.f-check.panel{max-width:none}.f-check-in{position:relative;z-index:1;display:grid;grid-template-columns:minmax(0,.9fr) minmax(0,1.1fr);gap:clamp(24px,4vw,80px);padding:clamp(24px,3vw,52px)}.f-check-t{font-size:clamp(28px,2.6vw,48px);line-height:1.08;letter-spacing:-.04em;font-weight:300;margin:0}.f-check-res{margin:22px 0 10px;color:var(--t2);font-size:15px}.f-check-res b{font-size:clamp(40px,3.4vw,64px);font-weight:300;letter-spacing:-.04em;color:var(--acc);margin-right:6px;line-height:1;transition:color .3s}.f-check-res.full b{color:var(--grn)}.f-check-note{color:var(--t2);line-height:1.6;margin:0 0 28px;max-width:440px}.f-check-list{list-style:none;margin:0;padding:0;display:grid;align-content:center;border-top:1px solid var(--line)}.f-check-list li{border-bottom:1px solid var(--line)}.f-check-list label{display:flex;gap:18px;align-items:center;padding:18px 4px;cursor:pointer;font-size:clamp(16px,1.15vw,20px);line-height:1.4;color:var(--t2);transition:color .25s}.f-check-list label:hover{color:var(--t1)}.f-check-list input{appearance:none;-webkit-appearance:none;flex:none;width:26px;height:26px;margin:0;border-radius:8px;border:1.4px solid var(--line2);background:rgba(255,255,255,.03) center/14px no-repeat;cursor:pointer;transition:background-color .25s,border-color .25s}.f-check-list input:checked{background-color:var(--acc2);border-color:var(--acc);background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 14 14'%3E%3Cpath d='M2.5 7.5l3 3 6-7' fill='none' stroke='%23fff' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'/%3E%3C/svg%3E")}.f-check-list input:focus-visible{outline:2px solid var(--acc);outline-offset:3px}.f-check-list input:checked+span{color:var(--t1)}
.d-card .f-num{font-size:clamp(28px,2.4vw,44px);line-height:1.05;letter-spacing:-.035em;font-weight:300;color:var(--acc);margin:0 0 16px}.f-req .d-card{border-top:2px solid rgba(124,134,255,.45)}
.f-zmap{display:grid;grid-template-columns:minmax(0,1.4fr) minmax(0,1fr);gap:clamp(20px,2.4vw,44px);align-items:start}.f-plan{margin:0;padding:clamp(14px,1.4vw,26px)}.f-plan svg{display:block;width:100%;height:auto}.f-plan svg *{pointer-events:none}.f-plan .zf,.f-plan .bdg{pointer-events:all}.f-plan .zf{fill:transparent;transition:fill .3s,stroke .3s}.f-plan .z.on .zf{fill:rgba(124,134,255,.14)}.f-plan .z6.on .zf{fill:rgba(124,134,255,.05);stroke:#7c86ff}.f-plan .bdg circle{fill:#09090b;stroke:#7c86ff;stroke-width:2;transition:fill .3s}.f-plan .bdg text{fill:#7c86ff;font:500 22px Inter,system-ui,sans-serif;text-anchor:middle;dominant-baseline:central;transition:fill .3s}.f-plan .bdg.on circle{fill:#7c86ff}.f-plan .bdg.on text{fill:#fff}.f-plan .lbl text{fill:#84848e;font:400 15px Inter,system-ui,sans-serif}.f-legend{display:flex;flex-wrap:wrap;gap:10px 22px;margin:16px 4px 2px;font-size:13px;color:var(--t3)}.f-legend span{display:inline-flex;align-items:center;gap:9px}.f-legend i{flex:none;display:inline-block}.lg-st{width:11px;height:11px;border-radius:2px;background:var(--yel)}.lg-tr{width:11px;height:11px;border-radius:50%;background:var(--acc)}.lg-uv{width:20px;height:7px;border-radius:4px;background:#c4b5fd;box-shadow:0 0 8px rgba(167,139,250,.9)}.lg-fl{width:24px;border-top:2px dashed var(--acc)}.f-zlist{list-style:none;padding:0;margin:0;display:grid;gap:10px;counter-reset:zl}.f-zlist li{display:grid;grid-template-columns:40px minmax(0,1fr);gap:2px 14px;align-items:start;padding:15px 18px;border:1.4px solid var(--line);border-radius:var(--r);background:var(--card);transition:border-color .3s,background .3s;outline:none;cursor:default}.f-zlist li::before{counter-increment:zl;content:counter(zl);grid-row:1/span 2;width:34px;height:34px;border-radius:50%;border:1.4px solid var(--acc);color:var(--acc);display:flex;align-items:center;justify-content:center;font-size:15px;transition:background .3s,color .3s}.f-zlist b{font-weight:500;font-size:clamp(16px,1.05vw,19px);line-height:1.3}.f-zlist span{color:var(--t2);font-size:clamp(14px,.9vw,16px);line-height:1.5}.f-zlist li.on,.f-zlist li:hover,.f-zlist li:focus-visible{border-color:rgba(124,134,255,.6);background:rgba(124,134,255,.08)}.f-zlist li.on::before{background:var(--acc);color:#fff}
.f-steps4{grid-template-columns:repeat(4,minmax(0,1fr))}.d-steps li.f-alert{border-top-color:var(--yel)}.d-steps li.f-alert::before{color:var(--yel)}
.inds.f-inds{grid-template-columns:repeat(6,minmax(0,1fr))}.inds.f-inds>*{grid-column:span 2}.inds.f-inds>:nth-child(n+4){grid-column:span 3}.inds.f-inds>:nth-child(n+4) .ind-img{aspect-ratio:834/275}
.f-lbl{display:block;font-size:12px;letter-spacing:.08em;text-transform:uppercase;color:var(--acc);margin:4px 0 8px}.f-mb{margin:0 0 4px}.f-pricecard .f-price{margin:22px 0 26px;color:var(--t2);line-height:1.6}.f-pricecard .f-price b{display:block;color:var(--t1);font-weight:400;font-size:clamp(20px,1.6vw,28px);letter-spacing:-.02em;line-height:1.25;margin-bottom:6px}.d-card .btn{max-width:100%;white-space:normal;text-align:center;line-height:1.25}
@media (max-width:1100px){.f-steps4{grid-template-columns:repeat(2,minmax(0,1fr))}.f-zmap,.f-check-in{grid-template-columns:minmax(0,1fr)}.inds.f-inds{grid-template-columns:repeat(2,minmax(0,1fr))}.inds.f-inds>*,.inds.f-inds>:nth-child(n+4){grid-column:auto}.inds.f-inds>:nth-child(n+4) .ind-img{aspect-ratio:556/275}.inds.f-inds>:last-child{grid-column:1/-1}.inds.f-inds>:last-child .ind-img{aspect-ratio:834/275}}
@media (max-width:900px){.hdr{background:rgba(0,0,0,.72);backdrop-filter:blur(18px);-webkit-backdrop-filter:blur(18px);border-color:var(--line)}.f-hero{display:block;min-height:0;padding:68px 0 clamp(44px,8vw,72px)}.f-hero::before,.f-hero::after{display:none}.f-hero .hero-media{position:relative;inset:auto;width:100%;aspect-ratio:16/9}.f-hero .hero-media::after{height:100%;background:linear-gradient(180deg,rgba(0,0,0,0) 62%,#000 100%)}.f-hero .f-hero-img{object-position:70% 50%;filter:none}.f-hero .wrap{margin-top:-24px}.f-hero p.lead{max-width:760px}}@media (max-width:760px){.f-hero .hero-media{aspect-ratio:4/3}.f-hero .f-hero-img{object-position:50% 50%}.f-crumbs{font-size:13px;margin-bottom:18px}.inds.f-inds{grid-template-columns:minmax(0,1fr)}.inds.f-inds>:last-child{grid-column:auto}.inds.f-inds>:last-child .ind-img{aspect-ratio:556/275}}
@media (max-width:600px){.f-steps4{grid-template-columns:minmax(0,1fr)}.d-btns .btn,.d-card .btn,.f-check .btn{width:100%;white-space:normal;text-align:center;line-height:1.25}.d-page .btn-lg{padding:0 16px}.f-plan .lbl{display:none}.f-check-in{padding:24px 20px}.f-check-list label{padding:15px 2px;gap:14px}.f-zlist li{padding:14px}}
@media (max-width:400px){.hdr .wrap{gap:10px}.hdr-right{gap:8px}.logo{gap:8px}.logo-mark{width:34px;height:34px}.logo-name{font-size:15px}.phone i,.burger{width:40px;height:40px}}@media (max-width:340px){.logo-sub{display:none}}
/* ===== Страница «Дератизация и дезинсекция для организаций» (/deratizatsiya-i-dezinsektsiya/): дополнения к стилям отраслевой страницы ===== */
.dd-page .f-hero .f-hero-img{object-position:62% 50%}
@media (min-width:761px){.dd-page .hero h1{font-size:clamp(40px,3.9vw,74px)}}
.dd-hero-list{list-style:none;padding:0;margin:26px 0 0;display:grid;gap:10px;max-width:620px}
.dd-hero-list li{position:relative;padding-left:28px;color:#c4c4cc;line-height:1.5;font-size:clamp(15px,.95vw,18px)}
.dd-hero-list li::before{content:"";position:absolute;left:2px;top:.45em;width:12px;height:6px;border-left:2px solid var(--acc);border-bottom:2px solid var(--acc);transform:rotate(-45deg)}
.dd-arr{width:16px;height:16px;flex:none;transition:transform .3s var(--ease)}
.dd-page #korotko a:not(.card),.dd-choose a,#tseny .d-note a,.dd-buy-n a,#voprosy .ans a{color:var(--t1);border-bottom:1px solid rgba(124,134,255,.45);transition:border-color .25s}
.dd-page #korotko a:not(.card):hover,.dd-choose a:hover,.dd-buy-n a:hover,#voprosy .ans a:hover{border-color:var(--t1)}

/* коротко: определение и «формула» комплекса */
.dd-def{margin:0 0 clamp(24px,2.6vw,40px);padding:clamp(18px,1.6vw,26px) clamp(20px,2vw,30px);border:1px solid var(--line2);border-left:2px solid var(--acc);border-radius:var(--r);background:var(--card);color:var(--t2);line-height:1.65;max-width:1100px;font-size:clamp(16px,1.05vw,19px)}
.dd-def b{color:var(--t1);font-weight:500}
.dd-vs{display:grid;grid-template-columns:minmax(0,1fr) 40px minmax(0,1fr) 40px minmax(0,1fr);align-items:stretch;gap:0}
.dd-vs-c{display:flex;flex-direction:column;gap:8px;padding:clamp(20px,1.8vw,28px);color:var(--t1)}
.dd-vs-c:hover{border-color:rgba(124,134,255,.6)}
.dd-vs-k{font-size:13px;letter-spacing:.12em;text-transform:uppercase;color:var(--acc)}
.dd-vs-c b{font-weight:500;font-size:clamp(20px,1.5vw,26px);letter-spacing:-.02em;line-height:1.2}
.dd-vs-d{color:var(--t2);font-size:15px;line-height:1.55}
.dd-go{margin-top:auto;padding-top:10px;display:inline-flex;align-items:center;gap:8px;color:var(--t2);font-size:14px}
.dd-vs-c:hover .dd-go{color:var(--t1)}
.dd-vs-c:hover .dd-arr{transform:translateX(3px)}
.dd-vs-all{border-color:rgba(124,134,255,.45);background:linear-gradient(160deg,rgba(124,134,255,.12),rgba(24,24,27,.4) 60%)}
.dd-vs-op{display:grid;place-items:center;font-size:26px;font-weight:300;color:var(--t3)}
.dd-law{margin:clamp(22px,2.2vw,32px) 0 0;color:var(--t2);line-height:1.6;max-width:1100px}
.dd-upd{margin:12px 0 0;font-size:14px;color:var(--t3)}

/* что выбрать */
.d-table.dd-choose{max-width:1200px}
@media (min-width:601px){.dd-choose th:nth-child(2),.dd-choose td:nth-child(2){width:30%}.dd-choose th:nth-child(3),.dd-choose td:nth-child(3){width:24%}}
.d-table.dd-choose td:nth-child(2){color:var(--t1)}
.dd-choose tr.dd-on td{background:rgba(124,134,255,.07)}
.dd-choose tr.dd-on td:nth-child(2){color:var(--acc)}

/* цены */
.dd-price{display:grid;grid-template-columns:minmax(0,1fr) minmax(0,400px);gap:clamp(20px,2.4vw,44px);align-items:start}
.d-table.dd-ptbl td{vertical-align:middle}
.dd-obj{display:flex;align-items:center;gap:12px;color:var(--t1)}
.dd-oi{flex:none;display:inline-grid;place-items:center;width:38px;height:38px;border-radius:10px;border:1px solid var(--line2);background:rgba(255,255,255,.03);color:var(--acc)}
.dd-oi svg{width:19px;height:19px}
.d-table.dd-ptbl td.dd-p{white-space:nowrap;color:var(--t1);font-size:clamp(16px,1.05vw,19px);text-align:right}
.dd-ptbl th:last-child{text-align:right}
.dd-cmp{padding:clamp(22px,2vw,32px);border-color:rgba(124,134,255,.45)}
.dd-cmp p{margin:0}
.dd-cmp-h{font-size:13px;letter-spacing:.12em;text-transform:uppercase;color:var(--t3)}
.dd-cmp-ex{margin-top:4px!important;font-size:13px;color:var(--t3)}
.dd-cmp-l{list-style:none;padding:0;margin:12px 0 0;border-top:1px solid var(--line2)}
.dd-cmp-l li{display:flex;justify-content:space-between;gap:12px;padding:10px 0;border-bottom:1px solid var(--line);color:var(--t2);font-size:15px}
.dd-cmp-l li>span:last-child{white-space:nowrap;color:var(--t1)}
.dd-cmp-l li.dd-cmp-sum{border-bottom-color:var(--line2)}
.dd-cmp-l li.dd-cmp-sum>span:last-child{font-size:17px}
.dd-cmp-k{margin-top:24px!important;color:var(--acc)!important}
.dd-cmp-big{margin-top:6px!important;font-size:clamp(34px,3vw,52px);font-weight:300;letter-spacing:-.035em;line-height:1.05;color:var(--t1)}
.dd-cmp-big small{font-size:.42em;letter-spacing:0;color:var(--t2);margin-left:4px}
.dd-cmp-n{margin-top:8px!important;color:var(--t2);font-size:15px;line-height:1.5}
.dd-cmp .btn.dd-cmp-b{margin-top:22px;width:100%;white-space:normal;text-align:center;line-height:1.25}
.dd-facts{margin:clamp(16px,1.6vw,24px) 0 0;display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:16px}
.dd-facts>div{padding:18px clamp(20px,1.8vw,28px);border:1px solid var(--line2);border-radius:var(--r)}
.dd-facts dt{font-size:13px;letter-spacing:.12em;text-transform:uppercase;color:var(--t3);margin-bottom:8px}
.dd-facts dd{margin:0;color:var(--t1);line-height:1.55}

/* график на год */
.dd-month{margin:0 0 clamp(18px,1.8vw,26px);color:var(--t2);line-height:1.6;max-width:1100px}
.dd-month b{color:var(--t1);font-weight:500}
.dd-year{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:12px}
.dd-ssn{padding:clamp(16px,1.4vw,22px);display:flex;flex-direction:column;gap:12px}
.dd-ssn p{margin:0}
.dd-ssn-h b{font-weight:500;font-size:clamp(18px,1.3vw,22px);letter-spacing:-.02em}
.dd-ssn{border-top:2px solid rgba(124,134,255,.35)}
.dd-ssn-t{width:100%;border-collapse:collapse;table-layout:fixed}
.dd-ssn-t th,.dd-ssn-t td{padding:8px 4px;text-align:center;border-top:1px solid var(--line)}
.dd-ssn-t thead td,.dd-ssn-t thead th{border-top:0;padding-top:0}
.dd-ssn-t thead th{font-size:13px;font-weight:400;color:var(--t3)}
.dd-ssn-t abbr{text-decoration:none;border:0}
.dd-ssn-t tbody th{text-align:left;font-size:13px;font-weight:400;color:var(--t2);width:84px;padding-left:0}
.dd-ssn-t thead td{width:84px}
.dd-ssn-n{color:var(--t2);font-size:14px;line-height:1.5}
.dd-dot{display:inline-block;width:10px;height:10px;border-radius:50%;margin:0 2px;vertical-align:middle}
.dd-dot.dd-r{background:rgba(124,134,255,.55)}
.dd-dot.dd-i{background:rgba(255,137,4,.55)}
.dd-dot.on{box-shadow:0 0 0 3px rgba(255,255,255,.12)}
.dd-dot.dd-r.on{background:#7c86ff;box-shadow:0 0 0 3px rgba(124,134,255,.28)}
.dd-dot.dd-i.on{background:#ff8904;box-shadow:0 0 0 3px rgba(255,137,4,.28)}
.dd-leg{margin:16px 0 0;display:flex;flex-wrap:wrap;gap:10px 28px;color:var(--t2);font-size:14px}
.dd-leg>span{display:inline-flex;align-items:center;gap:4px}
.dd-leg .dd-dot:last-of-type{margin-right:8px}

/* документы */
.dd-docs{display:grid;grid-template-columns:minmax(0,.75fr) minmax(0,1.25fr);gap:clamp(24px,3vw,56px);align-items:start}
.dd-doclist{list-style:none;counter-reset:dl;padding:0;margin:0;border-top:1px solid var(--line2)}
.dd-doclist li{position:relative;padding:16px 0 16px 46px;border-bottom:1px solid var(--line2);line-height:1.45}
.dd-doclist li::before{counter-increment:dl;content:"0" counter(dl);position:absolute;left:0;top:17px;color:var(--acc);font-size:14px}
.dd-doclist b{display:block;font-weight:500;color:var(--t1)}
.dd-doclist li>span{display:block;margin-top:4px;color:var(--t2);font-size:15px}
.dd-smps{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px}
.dd-smp{display:grid;grid-template-columns:96px minmax(0,1fr);gap:16px;align-items:center;padding:14px;color:var(--t1)}
.dd-smp:hover{border-color:rgba(124,134,255,.6)}
.dd-smp img{display:block;width:96px;height:auto;aspect-ratio:240/339;object-fit:cover;object-position:top;border-radius:6px;background:#fff;box-shadow:0 8px 24px rgba(0,0,0,.35)}
.dd-smp-t{min-width:0;overflow-wrap:break-word}
.dd-smp-t b{display:block;font-weight:500;line-height:1.3}
.dd-smp-t>span{display:block;margin-top:6px;color:var(--t3);font-size:14px;line-height:1.45}

/* закупки */
.dd-buy{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:14px}
.dd-buy-c{display:flex;flex-direction:column;gap:10px;padding:clamp(20px,1.8vw,28px)}
.dd-buy-i{display:inline-grid;place-items:center;width:44px;height:44px;border-radius:12px;border:1px solid rgba(124,134,255,.35);color:var(--acc);margin-bottom:6px}
.dd-buy-i svg{width:22px;height:22px}
.dd-buy-c b{font-weight:500;font-size:clamp(17px,1.15vw,20px);line-height:1.3}
.dd-buy-c>span:last-child{color:var(--t2);font-size:15px;line-height:1.55}
.dd-buy-f{margin-top:clamp(22px,2.2vw,32px);display:flex;flex-wrap:wrap;align-items:center;gap:14px 28px}
.dd-buy-f .btn{margin:0}
.dd-buy-n{margin:0;color:var(--t2);font-size:15px}

/* дезинфекция — полоса */
.dd-band-s.s{padding-top:clamp(40px,4vw,72px);padding-bottom:clamp(40px,4vw,72px)}
.dd-band{display:flex;align-items:center;justify-content:space-between;gap:20px 40px;padding:clamp(24px,2.4vw,40px);border-color:rgba(124,134,255,.35)}
.dd-band-t h2{margin:0 0 10px;font-size:clamp(26px,2.2vw,40px);font-weight:400;letter-spacing:-.03em;line-height:1.15}
.dd-band-t p{margin:0;color:var(--t2);line-height:1.6;max-width:720px}
.dd-band .btn{flex:none;margin:0}

@media (max-width:1279px){
.dd-docs{grid-template-columns:minmax(0,1fr)}
}
@media (max-width:1180px){
.dd-vs{grid-template-columns:minmax(0,1fr) 32px minmax(0,1fr)}
.dd-vs-op:nth-of-type(2){display:none}
.dd-vs-all{grid-column:1/-1;margin-top:12px}
.dd-price{grid-template-columns:minmax(0,1fr)}
.dd-cmp{max-width:560px}
.dd-year{grid-template-columns:repeat(2,minmax(0,1fr))}
.dd-buy{grid-template-columns:repeat(2,minmax(0,1fr))}
}
@media (max-width:900px){
.dd-band{flex-direction:column;align-items:flex-start}
}
@media (max-width:760px){
.dd-page .hero-ctas .dd-tel{display:none}
.dd-page #hero.f-hero .hero-copy>.dd-hero-list{order:4;margin-top:22px}
.dd-page #hero.f-hero .hero-copy>.lead{order:5;margin-top:18px}
.dd-page #hero.f-hero .hero-media{height:clamp(104px,calc(100vh - 470px),75vw);height:clamp(104px,calc(100svh - 470px),75vw)}
.dd-vs{grid-template-columns:minmax(0,1fr)}
.dd-vs-op{height:30px}
.dd-vs-op:nth-of-type(2){display:grid}
.dd-vs-all{grid-column:auto;margin-top:0}
.dd-facts{grid-template-columns:minmax(0,1fr)}
.dd-smps{grid-template-columns:minmax(0,1fr)}
.dd-smp{grid-template-columns:72px minmax(0,1fr)}
.dd-smp img{width:72px}
}
@media (max-width:600px){
.dd-year{grid-template-columns:minmax(0,1fr)}
.dd-buy{grid-template-columns:minmax(0,1fr)}
.d-table.dd-ptbl td.dd-p{text-align:left;font-size:17px}
.d-table.dd-ptbl td:first-child::before{display:none}
.dd-choose tr.dd-on{border-color:rgba(124,134,255,.45)}
.dd-choose tr.dd-on td{background:none}
.dd-buy-f .btn{width:100%;white-space:normal;text-align:center;line-height:1.25}
.dd-band .btn{width:100%;white-space:normal;text-align:center}
}
@media (max-width:900px) and (max-height:620px){
.dd-page #hero.f-hero .hero-copy>.dd-hero-list{display:none}
}</style>
<script type="application/ld+json">{"@context": "https://schema.org", "@graph": [{"@type": "BreadcrumbList", "itemListElement": [{"@type": "ListItem", "position": 1, "name": "Главная", "item": "https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/"}, {"@type": "ListItem", "position": 2, "name": "Дератизация и дезинсекция", "item": "https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/deratizatsiya-i-dezinsektsiya/"}]}, {"@type": "Service", "@id": "https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/deratizatsiya-i-dezinsektsiya/#service", "name": "Дератизация и дезинсекция для организаций", "alternateName": ["Дезинсекция и дератизация для организаций", "Комплекс дератизации и дезинсекции", "Оказание услуг по дератизации и дезинсекции"], "serviceType": "Дератизация и дезинсекция", "description": "Дезинсекция и дератизация для организаций в Москве и области: комплекс от 4 900 ₽/мес, общий график визитов, акты и журнал. Цены для юрлиц, документы для закупок.", "url": "https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/deratizatsiya-i-dezinsektsiya/", "provider": {"@type": "Organization", "@id": "https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/#org", "name": "ПЕСТКОНТРОЛЬ Центр", "legalName": "ООО «Центр дезинфекционных услуг»", "url": "https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/", "telephone": "+7 495 104-35-70", "email": "b2b@pestcontrol-center.ru"}, "areaServed": [{"@type": "City", "name": "Москва"}, {"@type": "AdministrativeArea", "name": "Московская область"}], "audience": {"@type": "BusinessAudience", "audienceType": "Организации и предприятия"}, "offers": {"@type": "Offer", "name": "Комплекс дератизации и дезинсекции", "priceCurrency": "RUB", "price": 4900, "priceSpecification": {"@type": "UnitPriceSpecification", "minPrice": 4900, "priceCurrency": "RUB", "unitText": "в месяц", "unitCode": "MON"}}, "hasOfferCatalog": {"@type": "OfferCatalog", "name": "Цены на комплекс дератизации и дезинсекции", "itemListElement": [{"@type": "Offer", "name": "Кафе, ресторан, столовая: дератизация и дезинсекция", "priceCurrency": "RUB", "price": 4900, "priceSpecification": {"@type": "UnitPriceSpecification", "minPrice": 4900, "priceCurrency": "RUB", "unitText": "в месяц", "unitCode": "MON"}}, {"@type": "Offer", "name": "Магазин, торговая сеть: дератизация и дезинсекция", "priceCurrency": "RUB", "price": 4900, "priceSpecification": {"@type": "UnitPriceSpecification", "minPrice": 4900, "priceCurrency": "RUB", "unitText": "в месяц", "unitCode": "MON"}}, {"@type": "Offer", "name": "Склад и логистика: дератизация и дезинсекция", "priceCurrency": "RUB", "price": 4900, "priceSpecification": {"@type": "UnitPriceSpecification", "minPrice": 4900, "priceCurrency": "RUB", "unitText": "в месяц", "unitCode": "MON"}}, {"@type": "Offer", "name": "Пищевое и фармацевтическое производство: дератизация и дезинсекция", "priceCurrency": "RUB", "price": 4900, "priceSpecification": {"@type": "UnitPriceSpecification", "minPrice": 4900, "priceCurrency": "RUB", "unitText": "в месяц", "unitCode": "MON"}}]}}, {"@type": "WebPage", "@id": "https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/deratizatsiya-i-dezinsektsiya/#webpage", "url": "https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/deratizatsiya-i-dezinsektsiya/", "name": "Дератизация и дезинсекция в Москве — цены для юридических лиц — ПЕСТКОНТРОЛЬ Центр", "description": "Дезинсекция и дератизация для организаций в Москве и области: комплекс от 4 900 ₽/мес, общий график визитов, акты и журнал. Цены для юрлиц, документы для закупок.", "inLanguage": "ru", "datePublished": "2026-11-11", "dateModified": "2026-11-11", "about": [{"@id": "https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/deratizatsiya-i-dezinsektsiya/#service"}, {"@id": "https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/deratizatsiya-i-dezinsektsiya/#derat"}, {"@id": "https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/deratizatsiya-i-dezinsektsiya/#dezins"}], "primaryImageOfPage": {"@type": "ImageObject", "url": "https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/img/dd-hero.webp", "width": 1920, "height": 1072}}, {"@type": "DefinedTerm", "@id": "https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/deratizatsiya-i-dezinsektsiya/#derat", "name": "Дератизация", "description": "Защита от грызунов: крыс и мышей."}, {"@type": "DefinedTerm", "@id": "https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/deratizatsiya-i-dezinsektsiya/#dezins", "name": "Дезинсекция", "description": "Защита от насекомых: тараканов, мух, муравьёв, моли и других."}, {"@type": "FAQPage", "@id": "https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/deratizatsiya-i-dezinsektsiya/#faq", "mainEntity": [{"@type": "Question", "name": "Чем дератизация отличается от дезинсекции?", "acceptedAnswer": {"@type": "Answer", "text": "Дератизация — меры против грызунов, дезинсекция — против насекомых и других членистоногих. У них разные методы и оборудование, но на одном объекте обе услуги можно вести по одному договору и графику."}}, {"@type": "Question", "name": "Как часто нужно проводить дератизацию и дезинсекцию?", "acceptedAnswer": {"@type": "Answer", "text": "На объектах особого эпидемиологического значения — пищевых производствах, в общепите, торговле продуктами, гостиницах — обследования на насекомых проводят не реже 2 раз в месяц, а дератизацию — по результатам ежемесячной оценки (пп. 101 и 110 СанПиН 3.3686-21). Для остальных объектов кратность определяем после обследования и закрепляем в графике."}}, {"@type": "Question", "name": "Можно ли заключить один договор на дератизацию и дезинсекцию?", "acceptedAnswer": {"@type": "Answer", "text": "Да. В договоре обе услуги, общий график и одна ежемесячная оплата. Образец договора — на странице договора на дератизацию и дезинсекцию."}}, {"@type": "Question", "name": "Сколько стоит дератизация и дезинсекция для юридических лиц?", "acceptedAnswer": {"@type": "Answer", "text": "Комплекс — от 4 900 ₽ в месяц. Точную цену называем после бесплатного выезда: она зависит от площади, числа зон и точек контроля, кратности визитов."}}, {"@type": "Question", "name": "Какие организации проводят дератизацию и дезинсекцию?", "acceptedAnswer": {"@type": "Answer", "text": "С 1 марта 2025 года эти услуги оказывают только по лицензии. Наша лицензия — № Л064-00111-77/01942445, её можно проверить в реестре Роспотребнадзора."}}, {"@type": "Question", "name": "Работаете ли вы в Московской области?", "acceptedAnswer": {"@type": "Answer", "text": "Да. Выезд и расчёт по Москве и Московской области бесплатны."}}, {"@type": "Question", "name": "Какой код ОКПД 2 указать в закупке?", "acceptedAnswer": {"@type": "Answer", "text": "81.29.11.000 «Услуги по дезинфекции, дезинсекции и дератизации»."}}]}]}</script>
<style id="srch-st">/* лупа поиска в шапке и раскладка шапки с ней (tools/menu/apply_menu.py) */.srch-btn{flex:none;width:44px;height:44px;padding:0;border-radius:50%;display:grid;place-items:center;background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.1);color:#fff;cursor:pointer;transition:color .25s,border-color .3s,background .3s,transform .35s cubic-bezier(.16,1,.3,1)}.srch-btn:hover{border-color:#7c86ff;background:rgba(97,95,255,.2);transform:translateY(-2px)}.srch-btn:focus-visible{outline:2px solid #7c86ff;outline-offset:2px}.srch-btn svg{width:18px;height:18px;display:block}@media (min-width:761px){.hdr .wrap{gap:16px}.hdr .msg{display:none}.srch-btn{width:38px;height:38px;background:none;border-color:transparent;color:var(--t2);margin-right:calc(4px - clamp(14px,2vw,40px))}.srch-btn svg{width:20px;height:20px}.srch-btn:hover{color:#fff;background:rgba(255,255,255,.07);border-color:rgba(255,255,255,.1);transform:none}}@media (min-width:761px) and (max-width:1440px){.hdr-right{gap:18px}.srch-btn{margin-right:-14px}}@media (min-width:761px) and (max-width:1000px){.hdr-right{gap:12px}.srch-btn{margin-right:-8px}}@media (max-width:900px){.logo-txt{display:flex;flex-direction:column;align-items:flex-start}.logo-sub{margin:0}}@media (max-width:760px){.hdr .wrap{gap:12px}.hdr-right{gap:8px}}@media (max-width:400px){.hdr .wrap{gap:10px}.srch-btn{width:40px;height:40px}}@media (max-width:360px){.hdr .wrap{gap:8px}.hdr-right{gap:6px}.srch-btn,.phone i,.burger{width:38px;height:38px}}@media (max-width:340px){.logo-mark{display:none}.logo-sub{display:block}}</style><script id="srch-js">/* поиск по сайту: движок и индекс загружаются по первому нажатию на лупу или «/» (tools/search) */(function(r,v){var d=document,ld=0,w=null;function go(o){if(window.PCSearch)return window.PCSearch.open(r,v,o);w=o;if(ld)return;ld=1;var s=d.createElement("script");s.src=r+"search.min.js?v="+v;s.async=true;s.onload=function(){window.PCSearch&&window.PCSearch.open(r,v,w)};s.onerror=function(){ld=0};d.head.appendChild(s)}d.addEventListener("click",function(e){var b=e.target.closest&&e.target.closest("[data-srch]");if(b){e.preventDefault();go({btn:b})}});d.addEventListener("keydown",function(e){if(e.key!=="/"||e.ctrlKey||e.metaKey||e.altKey)return;var t=e.target,n=t&&t.tagName;if(n==="INPUT"||n==="TEXTAREA"||n==="SELECT"||t.isContentEditable)return;e.preventDefault();go({})});if(/^#q\d+$/.test(location.hash)){var c=0,t=setInterval(function(){var b=d.getElementById(location.hash.slice(1));if(b&&d.documentElement.classList.contains("anim-ready")){clearInterval(t);if(b.getAttribute("aria-expanded")==="false")b.click()}else if(++c>60)clearInterval(t)},150)}})("../","20261108");</script>
<style data-fx>
/* подсветка рамки карточек за курсором — как у .card на главной (tools/site/fx.py) */
:where(.d-card,.p-sec,.p-fcard,.p-duty-box,.p-dl-card,.pm-step-card,.pm-scen,.pm-link-card,.k-err,.w-sample,.d-doc-prev){position:relative}
:where(.d-card,.p-sec,.p-fcard,.p-duty-box,.p-dl-card,.pm-step-card,.pm-scen,.pm-link-card,.k-err,.w-sample,.d-doc-prev)::after{content:"";position:absolute;inset:0;border-radius:inherit;padding:1.4px;pointer-events:none;background:radial-gradient(360px circle at var(--mx,-999px) var(--my,-999px),rgba(124,134,255,.85),rgba(124,134,255,.15) 35%,transparent 60%);-webkit-mask:linear-gradient(#000 0 0) content-box,linear-gradient(#000 0 0);-webkit-mask-composite:xor;mask:linear-gradient(#000 0 0) content-box,linear-gradient(#000 0 0);mask-composite:exclude;opacity:0;transition:opacity .4s;z-index:2}
@media (hover:hover) and (pointer:fine){:where(.d-card,.p-sec,.p-fcard,.p-duty-box,.p-dl-card,.pm-step-card,.pm-scen,.pm-link-card,.k-err,.w-sample,.d-doc-prev):hover::after{opacity:1}}
/* «фонарь» на фото первого экрана — как на главной (tools/site/fx.py) */
.fx-lit{position:absolute;inset:0;opacity:0;pointer-events:none;-webkit-mask-image:radial-gradient(circle var(--sr,320px) at var(--sx,72%) var(--sy,46%),#000 0%,rgba(0,0,0,.55) 45%,transparent 72%);mask-image:radial-gradient(circle var(--sr,320px) at var(--sx,72%) var(--sy,46%),#000 0%,rgba(0,0,0,.55) 45%,transparent 72%);transition:opacity 1.8s cubic-bezier(.16,1,.3,1)}
#hero :is(.d-hero-media,.hero-media)>picture>img{transition:filter 1.8s cubic-bezier(.16,1,.3,1)}
#hero.fx-lit-on :is(.d-hero-media,.hero-media)>picture>img{filter:grayscale(.3) brightness(.56)}
#hero.fx-lit-on .fx-lit img{filter:brightness(1.08) contrast(1.06) saturate(1.06)}
#hero.fx-lit-on .fx-lit{opacity:1}
</style>
<style id="m-crumbs">/* крошки на телефоне не показываем: для SEO хватает BreadcrumbList и ссылок в HTML */@media (max-width:900px){.d-crumbs,.f-crumbs{display:none!important}}</style>
<style id="t-inset">/* таблицы: текст не прижимается к краю — отступ первой и последней колонки */@media (min-width:901px){.d-table tr>:first-child{padding-left:clamp(16px,1.5vw,24px)}.d-table tr>:last-child{padding-right:clamp(16px,1.5vw,24px)}}</style>
<style id="hero-fold">/* кнопки первого экрана видны целиком на любом экране (tools/site/hero_fold.py) */@media (max-width:760px){#hero.hero:not(.f-hero) .hero-copy{display:flex;flex-direction:column}#hero.hero:not(.f-hero) .hero-copy>*{order:6}#hero.hero:not(.f-hero) .hero-copy>.badge{order:1;align-self:flex-start}#hero.hero:not(.f-hero) .hero-copy>h1{order:2;margin-bottom:0}#hero.hero:not(.f-hero) .hero-copy>.hero-ctas{order:3;margin-top:22px}#hero.hero:not(.f-hero) .hero-copy>.lead{order:4;margin-top:24px}}@media (max-width:760px) and (max-height:620px){#hero.hero:not(.f-hero){padding-top:92px}#hero.hero:not(.f-hero) h1{margin-top:18px}}@media (max-width:900px){#hero.f-hero .hero-copy{display:flex;flex-direction:column}#hero.f-hero .hero-copy>*{order:6}#hero.f-hero .hero-copy>.f-crumbs{order:0}#hero.f-hero .hero-copy>.badge{order:1;align-self:flex-start}#hero.f-hero .hero-copy>h1{order:2;margin-bottom:0}#hero.f-hero .hero-copy>.hero-ctas{order:3;margin-top:22px}#hero.f-hero .hero-copy>.lead{order:4;margin-top:24px}#hero.f-hero .hero-media{aspect-ratio:auto;height:clamp(104px,calc(100vh - 440px),56.25vw);height:clamp(104px,calc(100svh - 440px),56.25vw)}}@media (max-width:760px){#hero.f-hero .hero-media{height:clamp(104px,calc(100vh - 440px),75vw);height:clamp(104px,calc(100svh - 440px),75vw)}.rp-page #hero.f-hero .hero-media,.lb-page #hero.f-hero .hero-media{height:clamp(104px,calc(100vh - 480px),75vw);height:clamp(104px,calc(100svh - 480px),75vw)}}@media (max-width:900px) and (max-height:620px){#hero.f-hero .hero-copy>.badge{display:none}#hero.f-hero .hero-media{height:clamp(96px,calc(100vh - 400px),75vw);height:clamp(96px,calc(100svh - 400px),75vw)}.rp-page #hero.f-hero .hero-copy>h1{font-size:clamp(26px,7.6vw,34px)}#hero.f-hero .hero-copy>h1{margin-top:30px}}@media (max-width:860px){#hero.d-hero .d-hero-media{aspect-ratio:auto;height:clamp(104px,calc(100vh - 380px),56.25vw);height:clamp(104px,calc(100svh - 380px),56.25vw)}}@media (max-width:860px) and (max-height:620px){#hero.d-hero{padding-top:84px}#hero.d-hero .d-hero-media{margin-top:14px}#hero.d-hero .d-btns{margin-top:16px}}@media (max-width:860px) and (max-height:520px){#hero.d-hero .d-hero-media{display:none}#hero.d-hero h1{margin-bottom:0}}@media (max-width:900px) and (max-height:520px){#hero.f-hero{padding-top:76px}#hero.f-hero .hero-media{display:none}#hero.f-hero .wrap{margin-top:0}#hero.f-hero .hero-copy>h1{margin-top:0}}@media (max-width:400px){#hero .hero-copy{min-width:0}#hero .hero-ctas .btn{min-width:0;max-width:100%;white-space:normal;padding:0 14px}#hero .hero-ctas .btn-t{white-space:normal;text-align:center}}@media (max-width:860px) and (max-height:620px){#hero.d-hero .d-hero-media{height:clamp(104px,calc(100vh - 410px),56.25vw);height:clamp(104px,calc(100svh - 410px),56.25vw)}}@media (max-height:520px){#hero.p-hero .p-hero-copy>.d-btns{order:3;margin-top:18px}#hero.p-hero .p-hero-copy>.p-def{order:4;margin-top:18px}}@media (max-width:760px) and (max-height:620px){#hero.p-hero .p-hero-copy>.d-btns{order:3;margin-top:18px}#hero.p-hero .p-hero-copy>.p-def{order:4;margin-top:18px}}@media (min-width:761px) and (max-height:520px){#hero.hero:not(.f-hero){padding-top:84px;min-height:0}#hero.hero:not(.f-hero) .hero-copy{display:flex;flex-direction:column}#hero.hero:not(.f-hero) .hero-copy>*{order:6}#hero.hero:not(.f-hero) .hero-copy>.badge{order:1;align-self:flex-start}#hero.hero:not(.f-hero) .hero-copy>h1{order:2;margin:14px 0 0}#hero.hero:not(.f-hero) .hero-copy>.hero-ctas{order:3;margin-top:18px}#hero.hero:not(.f-hero) .hero-copy>.lead{order:4;margin-top:18px}}@media (min-width:861px){#hero.d-hero .d-hero-copy{display:flex;flex-direction:column}#hero.d-hero .d-hero-copy>*{order:6}#hero.d-hero .d-hero-copy>.d-crumbs{order:0}#hero.d-hero .d-hero-copy>.eyebrow{order:1}#hero.d-hero .d-hero-copy>h1{order:2}#hero.d-hero .d-hero-copy>:is(.lead,.sub,.p-def):not(:is(.lead,.sub,.p-def)~*){order:3}#hero.d-hero .d-hero-copy>.d-btns:not(.d-btns~*){order:4}#hero.d-hero .d-hero-copy>.d-ticks{margin-bottom:0}}@media (min-width:901px){#hero.f-hero .hero-copy{display:flex;flex-direction:column}#hero.f-hero .hero-copy>*{order:6}#hero.f-hero .hero-copy>.f-crumbs{order:0}#hero.f-hero .hero-copy>.badge{order:1;align-self:flex-start}#hero.f-hero .hero-copy>h1{order:2}#hero.f-hero .hero-copy>.lead{order:3}#hero.f-hero .hero-copy>.hero-ctas{order:4}#hero.f-hero .hero-copy>.rp-hero-list{margin-top:26px}}@media (min-width:861px) and (max-height:820px){#hero.d-hero{padding-top:calc(clamp(68px,6vw,115px) + 8px)}#hero.d-hero .d-hero-copy>.d-crumbs{margin-bottom:0}#hero.d-hero .d-hero-copy>.eyebrow{margin:16px 0 0}#hero.d-hero .d-hero-copy>h1{margin-top:14px;line-height:1.02}#hero.d-hero .d-hero-copy>:is(.lead,.sub,.p-def){margin-top:16px}#hero.d-hero .d-btns{margin-top:20px}}@media (min-width:901px) and (max-height:820px){#hero.f-hero{padding-top:80px}#hero.f-hero .hero-copy>.f-crumbs{margin-bottom:10px}#hero.f-hero .hero-copy>h1{font-size:min(8.2vh,4.4vw);margin:16px 0 14px}.rp-page #hero.f-hero .hero-copy>h1,.lb-page #hero.f-hero .hero-copy>h1{font-size:min(8vh,3.4vw)}#hero.f-hero .hero-copy>.lead{line-height:1.5}#hero.f-hero .hero-copy>.hero-ctas{margin-top:26px}}@media (min-width:761px) and (max-height:820px){#hero.p-hero h1{font-size:min(8.4vh,4.4vw)}#hero.p-hero .p-hero-copy>.d-btns{margin-top:20px}}@media (min-width:761px) and (max-height:820px){#hero.hero:not(.f-hero) h1{font-size:min(8.4vh,4.4vw);margin:22px 0 18px}#hero.hero:not(.f-hero) .hero-ctas{margin-top:28px}}</style>
</head>
<body class="d-page dd-page">
<a class="skip" href="#main">Перейти к содержанию</a>

<!-- ============ INTRO ============ -->
<div class="intro" id="intro" aria-hidden="true">
  <div class="intro-in">
    <svg class="intro-mark" viewBox="0 0 24 24" fill="none" stroke-width="1" stroke-linejoin="round"><path class="im-shield" pathLength="100" d="M12 2.5l7.5 3v6c0 5-3.2 8.6-7.5 10-4.3-1.4-7.5-5-7.5-10v-6z" stroke="#fff"/><circle class="im-c" pathLength="100" cx="12" cy="11.5" r="2.6" stroke="#7c86ff"/><path class="im-x" pathLength="100" d="M12 6.2v2.7M12 14.1v2.7M6.8 11.5h2.6M14.6 11.5h2.6" stroke="#7c86ff"/></svg>
    <div class="intro-word"><span>ПЕСТКОНТРОЛЬ</span><b>Центр</b></div>
    <div class="intro-bar"><i></i></div>
  </div>
</div>

<div class="progress" aria-hidden="true"><i id="progress"></i></div>
<div class="cursor" aria-hidden="true"><i class="cursor-dot"></i><i class="cursor-ring"></i></div>
<div class="grain" aria-hidden="true"></div>

<header class="hdr" id="hdr">
  <div class="wrap">
    <a href="../" class="logo" aria-label="ПЕСТКОНТРОЛЬ Центр — на главную">
      <span class="logo-mark"><svg viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="1.6" stroke-linejoin="round" aria-hidden="true"><path d="M12 2.5l7.5 3v6c0 5-3.2 8.6-7.5 10-4.3-1.4-7.5-5-7.5-10v-6z"/><circle cx="12" cy="11.5" r="2.6" stroke="#7c86ff"/><path d="M12 6.2v2.7M12 14.1v2.7M6.8 11.5h2.6M14.6 11.5h2.6" stroke="#7c86ff"/></svg></span>
      <span class="logo-txt"><span class="logo-name">ПЕСТКОНТРОЛЬ</span> <span class="logo-sub">Центр</span></span>
    </a>
    <nav class="nav" aria-label="Основное меню">
      <div class="nav-dd"><button class="nav-dd-btn active" type="button" aria-expanded="false" aria-controls="nav-uslugi">Услуги<svg viewBox="0 0 12 12" aria-hidden="true"><path d="M2.5 4.5 6 8l3.5-3.5" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></button><div class="nav-dd-panel" id="nav-uslugi"><a href="../dezinfektsiya/">Дезинфекция для организаций<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../deratizatsiya/">Дератизация для организаций<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../dezinsektsiya/">Дезинсекция для организаций<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="./" aria-current="page">Дератизация и дезинсекция<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../sanitarnyy-audit/"><span>Санитарный аудит <span class="nw">(СЭС-аудит)</span></span><svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../laboratornye-issledovaniya/">Лабораторные исследования<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../razrabotka-ppk/">Разработка ППК<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../normativnaya-baza/dokumenty-dlya-rospotrebnadzora/">Документы для Роспотребнадзора<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../ochistka-dezinfektsiya-ventilyatsii/">Очистка и дезинфекция вентиляции<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../dogovor-deratizatsiya-dezinsektsiya/">Договор на обслуживание<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../#podhod" class="nav-dd-all"><span>Пест-контроль по системе IPM</span><svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a></div></div><div class="nav-dd"><button class="nav-dd-btn" type="button" aria-expanded="false" aria-controls="nav-otrasli">Отрасли<svg viewBox="0 0 12 12" aria-hidden="true"><path d="M2.5 4.5 6 8l3.5-3.5" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></button><div class="nav-dd-panel" id="nav-otrasli"><a href="../pishchevoe-proizvodstvo/">Пищевые производства<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../magaziny-i-torgovye-seti/">Магазины и торговые сети<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../restorany-i-kafe/">Рестораны и кафе<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../sklady-i-logistika/">Склады и логистика<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../farmatsevticheskie-proizvodstva/">Фармацевтические производства<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../gostinitsy/">Гостиницы и отели<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../#otrasli" class="nav-dd-all">Все отрасли<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a></div></div><a href="../dogovor-deratizatsiya-dezinsektsiya/">Договор</a><a href="../#podhod">Метод IPM</a><a href="../#usloviya">Цена</a><div class="nav-dd"><button class="nav-dd-btn" type="button" aria-expanded="false" aria-controls="nav-materialy">Материалы<svg viewBox="0 0 12 12" aria-hidden="true"><path d="M2.5 4.5 6 8l3.5-3.5" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></button><div class="nav-dd-panel" id="nav-materialy"><a href="../normativnaya-baza/">Нормативная база<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../normativnaya-baza/dokumenty-dlya-rospotrebnadzora/">Документы для Роспотребнадзора<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../materialy/programma-pest-kontrolya/"><span>Программа <span class="nw">пест-контроля</span></span><svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../materialy/zhurnal-pest-kontrolya/"><span>Журнал <span class="nw">пест-контроля</span></span><svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../materialy/pest-menedzhment-ili-razovaya-obrabotka/"><span><span class="nw">Пест-менеджмент</span> или разовая обработка</span><svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../materialy/programma-proizvodstvennogo-kontrolya-haccp/">Программа производственного контроля по ХАССП<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../materialy/" class="nav-dd-all">Все материалы<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a></div></div>
    </nav>
    <div class="hdr-right">
      <button class="srch-btn" type="button" data-srch aria-label="Поиск по сайту" aria-haspopup="dialog"><svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="11" cy="11" r="7" fill="none" stroke="currentColor" stroke-width="2"/><path d="m20 20-3.6-3.6" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg></button>
      <a class="phone" href="tel:+74951043570" aria-label="Позвонить: +7 (495) 104-35-70"><i><svg viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2" aria-hidden="true"><path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1 1 .4 1.9.7 2.8a2 2 0 0 1-.5 2.1L8 9.9a16 16 0 0 0 6 6l1.3-1.3a2 2 0 0 1 2.1-.4c.9.3 1.8.6 2.8.7a2 2 0 0 1 1.7 2z"/></svg></i><span>+7 (495) 104-35-70</span></a>
      <div class="msg">
        <a href="https://max.ru/u/f9LHodD0cOIlIUXFkt4KMFP88lD8n4TArBiTcV7RI1XML5c4o39QfsDBXUc" class="max" aria-label="Написать в Max" target="_blank" rel="noopener noreferrer"><svg viewBox="0 0 24 24" fill="#fff" aria-hidden="true"><path d="M12 3a9 9 0 0 0-7.7 13.7L3 21l4.4-1.2A9 9 0 1 0 12 3zm-3.6 12.3V8.7h1.6l2 2.8 2-2.8h1.6v6.6h-1.7v-3.9L12 14l-1.9-2.6v3.9z"/></svg></a>
        <a href="https://t.me/Centr_Dezinfection?text=%D0%97%D0%B4%D1%80%D0%B0%D0%B2%D1%81%D1%82%D0%B2%D1%83%D0%B9%D1%82%D0%B5!%20%D0%9F%D0%B8%D1%88%D1%83%20%D1%81%20%D1%81%D0%B0%D0%B9%D1%82%D0%B0%20%D0%BF%D0%B5%D1%81%D1%82%D0%BA%D0%BE%D0%BD%D1%82%D1%80%D0%BE%D0%BB%D1%8C-%D1%86%D0%B5%D0%BD%D1%82%D1%80.%D1%80%D1%84" class="tg" aria-label="Написать в Telegram" target="_blank" rel="noopener noreferrer"><svg viewBox="0 0 24 24" fill="#fff" aria-hidden="true"><path d="M21.4 4.3 2.9 11.4c-1.3.5-1.2 1.2-.2 1.5l4.7 1.5 1.8 5.6c.2.6.4.8.9.8.4 0 .6-.2.9-.4l2.3-2.2 4.7 3.5c.9.5 1.5.2 1.7-.8l3.1-14.6c.3-1.3-.5-1.8-1.4-1.5zM9.6 14.1l8.6-5.4c.4-.3.8-.1.5.2l-7.1 6.4-.3 3.3z"/></svg></a>
      </div>
      <a href="#zayavka" class="btn btn-w btn-sm" data-magnet><span class="btn-t">Бесплатный выезд</span></a>
      <button class="burger" id="burger" aria-label="Открыть меню" aria-expanded="false" aria-controls="mmenu"><span></span></button>
    </div>
  </div>
</header>
<nav class="mmenu" id="mmenu" aria-label="Мобильное меню">
  <div class="mm-group open" data-open><button class="mm-toggle" type="button" aria-expanded="true" aria-controls="mm-uslugi">Услуги<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m6 9 6 6 6-6" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/></svg></button><div class="mm-sub" id="mm-uslugi"><div><a href="../dezinfektsiya/">Дезинфекция для организаций</a><a href="../deratizatsiya/">Дератизация для организаций</a><a href="../dezinsektsiya/">Дезинсекция для организаций</a><a href="./" aria-current="page">Дератизация и дезинсекция</a><a href="../sanitarnyy-audit/"><span>Санитарный аудит <span class="nw">(СЭС-аудит)</span></span></a><a href="../laboratornye-issledovaniya/">Лабораторные исследования</a><a href="../razrabotka-ppk/">Разработка ППК</a><a href="../normativnaya-baza/dokumenty-dlya-rospotrebnadzora/">Документы для Роспотребнадзора</a><a href="../ochistka-dezinfektsiya-ventilyatsii/">Очистка и дезинфекция вентиляции</a><a href="../dogovor-deratizatsiya-dezinsektsiya/">Договор на обслуживание</a><a href="../#podhod"><span class="nw">Пест-контроль</span> по системе IPM</a></div></div></div><div class="mm-group"><button class="mm-toggle" type="button" aria-expanded="false" aria-controls="mm-otrasli">Отрасли<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m6 9 6 6 6-6" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/></svg></button><div class="mm-sub" id="mm-otrasli"><div><a href="../pishchevoe-proizvodstvo/">Пищевые производства</a><a href="../magaziny-i-torgovye-seti/">Магазины и торговые сети</a><a href="../restorany-i-kafe/">Рестораны и кафе</a><a href="../sklady-i-logistika/">Склады и логистика</a><a href="../farmatsevticheskie-proizvodstva/">Фармацевтические производства</a><a href="../gostinitsy/">Гостиницы и отели</a><a href="../#otrasli">Все отрасли</a></div></div></div><a href="../dogovor-deratizatsiya-dezinsektsiya/">Договор <small>на дератизацию и дезинсекцию</small></a><a href="../#podhod">Метод IPM</a><a href="../#usloviya">Цена</a><div class="mm-group"><button class="mm-toggle" type="button" aria-expanded="false" aria-controls="mm-materialy">Материалы<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m6 9 6 6 6-6" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/></svg></button><div class="mm-sub" id="mm-materialy"><div><a href="../normativnaya-baza/">Нормативная база</a><a href="../normativnaya-baza/dokumenty-dlya-rospotrebnadzora/">Документы для Роспотребнадзора</a><a href="../materialy/programma-pest-kontrolya/"><span>Программа <span class="nw">пест-контроля</span></span></a><a href="../materialy/zhurnal-pest-kontrolya/"><span>Журнал <span class="nw">пест-контроля</span></span></a><a href="../materialy/pest-menedzhment-ili-razovaya-obrabotka/"><span><span class="nw">Пест-менеджмент</span> или разовая обработка</span></a><a href="../materialy/programma-proizvodstvennogo-kontrolya-haccp/">Программа производственного контроля по ХАССП</a><a href="../materialy/">Все материалы</a></div></div></div>
  <a href="#zayavka" class="btn btn-w btn-lg"><span class="btn-t">Заказать бесплатное обследование</span></a>
</nav>

<main id="main" tabindex="-1">
<section class="hero f-hero" id="hero">
  <div class="hero-media"><picture><source media="(max-width:760px)" srcset="../img/dd-hero-mob-760.webp 760w, ../img/dd-hero-mob.webp 1024w" sizes="100vw" width="1024" height="768"><img class="f-hero-img" src="../img/dd-hero.webp" srcset="../img/dd-hero-1440.webp 1440w, ../img/dd-hero.webp 1920w" sizes="100vw" width="1920" height="1072" alt="Специалист в тёмно-синей рабочей форме проверяет контейнер для грызунов у стены складского помещения ресторана; рядом ловушка для ползающих насекомых, на стене — ультрафиолетовая ловушка для летающих" fetchpriority="high" decoding="async"></picture><div class="fx-lit" aria-hidden="true"><picture><source media="(max-width:760px)" srcset="../img/dd-hero-mob-760.webp 760w, ../img/dd-hero-mob.webp 1024w" sizes="100vw" width="1024" height="768"><img class="f-hero-img fx-lit-img" src="../img/dd-hero.webp" srcset="../img/dd-hero-1440.webp 1440w, ../img/dd-hero.webp 1920w" sizes="100vw" width="1920" height="1072" alt="" decoding="async"></picture></div></div>
  <div class="wrap">
    <div class="hero-copy">
      <nav class="f-crumbs" aria-label="Навигационная цепочка" data-h><a href="../">Главная</a><span aria-hidden="true">→</span><span aria-current="page">Дератизация и дезинсекция</span></nav>
      <span class="badge" data-h><span class="dot"></span>Услуги для организаций · Москва и Московская область</span>
      <h1><span class="ln"><span>Дератизация и дезинсекция</span></span> <span class="ln"><span><em>для организаций</em></span></span></h1>
      <p class="lead" data-h>Защищаем объект от грызунов и насекомых по одному договору: общий график визитов, один комплект документов и одна цена — от <span class="nw">4&nbsp;900&nbsp;₽</span> в месяц.</p>
      <ul class="dd-hero-list">
        <li>Комплекс дешевле двух отдельных договоров</li>
        <li>Бесплатный выезд и расчёт по Москве и области</li>
        <li>Документы для отдела закупок</li>
      </ul>
      <div class="hero-ctas" data-h>
        <a href="#zayavka" class="btn btn-w btn-lg" data-magnet><span class="btn-t">Рассчитать комплекс</span></a>
        <a href="tel:+74951043570" class="btn btn-o btn-lg dd-tel" data-magnet><span class="btn-t">+7 (495) <span class="nw">104-35-70</span></span></a>
      </div>
    </div>
  </div>
</section>

<div class="strip" role="group" aria-label="Коротко о дератизации и дезинсекции">
  <div class="strip-track" id="stripTrack">
    <div class="strip-set">
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-file-signature" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M14.364 13.634a2 2 0 0 0-.506.854l-.837 2.87a.5.5 0 0 0 .62.62l2.87-.837a2 2 0 0 0 .854-.506l4.013-4.009a1 1 0 0 0-3.004-3.004z" /> <path d="M14.487 7.858A1 1 0 0 1 14 7V2" /> <path d="M20 19.645V20a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.704.706l2.516 2.516" /> <path d="M8 18h1" /> </svg><b>Один договор</b> — грызуны и насекомые</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-calculator" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <rect width="16" height="20" x="4" y="2" rx="2" /> <line x1="8" x2="16" y1="6" y2="6" /> <line x1="16" x2="16" y1="14" y2="18" /> <path d="M16 10h.01" /> <path d="M12 10h.01" /> <path d="M8 10h.01" /> <path d="M12 14h.01" /> <path d="M8 14h.01" /> <path d="M12 18h.01" /> <path d="M8 18h.01" /> </svg><b>Комплекс</b> — от 4 900 ₽/мес</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-scan-search" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M3 7V5a2 2 0 0 1 2-2h2" /> <path d="M17 3h2a2 2 0 0 1 2 2v2" /> <path d="M21 17v2a2 2 0 0 1-2 2h-2" /> <path d="M7 21H5a2 2 0 0 1-2-2v-2" /> <circle cx="12" cy="12" r="3" /> <path d="m16 16-1.9-1.9" /> </svg><b>Бесплатный выезд</b> и расчёт</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-activity" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M22 12h-2.48a2 2 0 0 0-1.93 1.46l-2.35 8.36a.25.25 0 0 1-.48 0L9.24 2.18a.25.25 0 0 0-.48 0l-2.35 8.36A2 2 0 0 1 4.49 12H2" /> </svg><b>Общий график</b> визитов на год</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-notebook-pen" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M13.4 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-7.4" /> <path d="M2 6h4" /> <path d="M2 10h4" /> <path d="M2 14h4" /> <path d="M2 18h4" /> <path d="M21.378 5.626a1 1 0 1 0-3.004-3.004l-5.01 5.012a2 2 0 0 0-.506.854l-.837 2.87a.5.5 0 0 0 .62.62l2.87-.837a2 2 0 0 0 .854-.506z" /> </svg><b>Журнал и акт</b> после каждого визита</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-file-badge" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M13 22h5a2 2 0 0 0 2-2V8a2.4 2.4 0 0 0-.706-1.706l-3.588-3.588A2.4 2.4 0 0 0 14 2H6a2 2 0 0 0-2 2v3.3" /> <path d="M14 2v5a1 1 0 0 0 1 1h5" /> <path d="m7.69 16.479 1.29 4.88a.5.5 0 0 1-.698.591l-1.843-.849a1 1 0 0 0-.879.001l-1.846.85a.5.5 0 0 1-.692-.593l1.29-4.88" /> <circle cx="6" cy="14" r="3" /> </svg><b>СанПиН 3.3686-21</b> — пп. 101 и 110</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-shield-check" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z" /> <path d="m9 12 2 2 4-4" /> </svg><b>Лицензия</b> Роспотребнадзора</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-list-checks" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M13 5h8" /> <path d="M13 12h8" /> <path d="M13 19h8" /> <path d="m3 17 2 2 4-4" /> <path d="m3 7 2 2 4-4" /> </svg><b>Документы</b> для отдела закупок</div>
    </div>
    <div class="strip-set" aria-hidden="true">
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-file-signature" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M14.364 13.634a2 2 0 0 0-.506.854l-.837 2.87a.5.5 0 0 0 .62.62l2.87-.837a2 2 0 0 0 .854-.506l4.013-4.009a1 1 0 0 0-3.004-3.004z" /> <path d="M14.487 7.858A1 1 0 0 1 14 7V2" /> <path d="M20 19.645V20a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.704.706l2.516 2.516" /> <path d="M8 18h1" /> </svg><b>Один договор</b> — грызуны и насекомые</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-calculator" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <rect width="16" height="20" x="4" y="2" rx="2" /> <line x1="8" x2="16" y1="6" y2="6" /> <line x1="16" x2="16" y1="14" y2="18" /> <path d="M16 10h.01" /> <path d="M12 10h.01" /> <path d="M8 10h.01" /> <path d="M12 14h.01" /> <path d="M8 14h.01" /> <path d="M12 18h.01" /> <path d="M8 18h.01" /> </svg><b>Комплекс</b> — от 4 900 ₽/мес</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-scan-search" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M3 7V5a2 2 0 0 1 2-2h2" /> <path d="M17 3h2a2 2 0 0 1 2 2v2" /> <path d="M21 17v2a2 2 0 0 1-2 2h-2" /> <path d="M7 21H5a2 2 0 0 1-2-2v-2" /> <circle cx="12" cy="12" r="3" /> <path d="m16 16-1.9-1.9" /> </svg><b>Бесплатный выезд</b> и расчёт</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-activity" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M22 12h-2.48a2 2 0 0 0-1.93 1.46l-2.35 8.36a.25.25 0 0 1-.48 0L9.24 2.18a.25.25 0 0 0-.48 0l-2.35 8.36A2 2 0 0 1 4.49 12H2" /> </svg><b>Общий график</b> визитов на год</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-notebook-pen" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M13.4 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-7.4" /> <path d="M2 6h4" /> <path d="M2 10h4" /> <path d="M2 14h4" /> <path d="M2 18h4" /> <path d="M21.378 5.626a1 1 0 1 0-3.004-3.004l-5.01 5.012a2 2 0 0 0-.506.854l-.837 2.87a.5.5 0 0 0 .62.62l2.87-.837a2 2 0 0 0 .854-.506z" /> </svg><b>Журнал и акт</b> после каждого визита</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-file-badge" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M13 22h5a2 2 0 0 0 2-2V8a2.4 2.4 0 0 0-.706-1.706l-3.588-3.588A2.4 2.4 0 0 0 14 2H6a2 2 0 0 0-2 2v3.3" /> <path d="M14 2v5a1 1 0 0 0 1 1h5" /> <path d="m7.69 16.479 1.29 4.88a.5.5 0 0 1-.698.591l-1.843-.849a1 1 0 0 0-.879.001l-1.846.85a.5.5 0 0 1-.692-.593l1.29-4.88" /> <circle cx="6" cy="14" r="3" /> </svg><b>СанПиН 3.3686-21</b> — пп. 101 и 110</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-shield-check" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z" /> <path d="m9 12 2 2 4-4" /> </svg><b>Лицензия</b> Роспотребнадзора</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-list-checks" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M13 5h8" /> <path d="M13 12h8" /> <path d="M13 19h8" /> <path d="m3 17 2 2 4-4" /> <path d="m3 7 2 2 4-4" /> </svg><b>Документы</b> для отдела закупок</div>
    </div>
  </div>
</div>

<section class="s" id="korotko">
  <div class="wrap">
    <div class="head"><div class="eyebrow" data-eyebrow>Коротко</div><h2 data-split>Чем отличаются <em>дератизация и дезинсекция</em></h2></div>
    <p class="dd-def" data-fade><b>Дератизация</b> — защита от грызунов: крыс и мышей. <b>Дезинсекция</b> — защита от насекомых: тараканов, мух, муравьёв, моли и других. На кухне, в цехе, на складе и в магазине риск обычно есть по обоим направлениям, поэтому организации заказывают их вместе — по одному договору и графику.</p>
    <div class="dd-vs" data-fade>
      <a class="card dd-vs-c" href="../deratizatsiya/"><span class="dd-vs-k">Грызуны</span><b>Дератизация</b><span class="dd-vs-d">Крысы и мыши: контейнеры и ловушки по периметру, снаружи и внутри здания.</span><span class="dd-go">Подробно о дератизации<svg class="dd-arr" viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></span></a>
      <span class="dd-vs-op" aria-hidden="true">+</span>
      <a class="card dd-vs-c" href="../dezinsektsiya/"><span class="dd-vs-k">Насекомые</span><b>Дезинсекция</b><span class="dd-vs-d">Тараканы, мухи, муравьи, моль, складские вредители: <span class="nw">ловушки-мониторы</span> и лампы для летающих насекомых.</span><span class="dd-go">Подробно о дезинсекции<svg class="dd-arr" viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></span></a>
      <span class="dd-vs-op" aria-hidden="true">=</span>
      <a class="card dd-vs-c dd-vs-all" href="#tseny"><span class="dd-vs-k">Комплекс</span><b>Один договор и график</b><span class="dd-vs-d">Грызуны и насекомые под контролем по общему графику, один комплект документов — от <span class="nw">4&nbsp;900&nbsp;₽/мес</span>.</span><span class="dd-go">Цены комплекса<svg class="dd-arr" viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></span></a>
    </div>
    <p class="dd-law" data-fade>Обеспечивать эти меры на своих объектах обязаны сами организации и ИП — своими силами или через специализированную организацию (п. 88 СанПиН <span class="nw">3.3686-21</span>).</p>
    <p class="dd-upd" data-fade>Обновлено 11.11.2026</p>
  </div>
</section>

<section class="s" id="chto-vybrat">
  <div class="wrap">
    <div class="head"><div class="eyebrow" data-eyebrow>Выбор услуги</div><h2 data-split>Что выбрать: <em>комплекс или одну услугу</em></h2></div>
    <table class="d-table dd-choose" data-fade>
      <caption class="sr-only">Что выбрать: комплекс или одну услугу</caption>
      <thead><tr><th scope="col">Ваша ситуация</th><th scope="col">Что подойдёт</th><th scope="col">Подробнее</th></tr></thead>
      <tbody>
        <tr><td data-l="Ваша ситуация">Грызуны или риск по периметру и на складе, насекомых нет</td><td data-l="Что подойдёт">Дератизация</td><td data-l="Подробнее"><a href="../deratizatsiya/">Дератизация для организаций</a></td></tr>
        <tr><td data-l="Ваша ситуация">Тараканы, мухи или моль, грызунов нет</td><td data-l="Что подойдёт">Дезинсекция</td><td data-l="Подробнее"><a href="../dezinsektsiya/">Дезинсекция для организаций</a></td></tr>
        <tr class="dd-on"><td data-l="Ваша ситуация">Кухня, пищевой цех, магазин или склад продуктов — риск по обоим направлениям</td><td data-l="Что подойдёт">Комплекс дератизации и дезинсекции</td><td data-l="Подробнее"><a href="#tseny">Цены комплекса</a></td></tr>
        <tr><td data-l="Ваша ситуация">Нужен договор с графиком и образцом для проверки</td><td data-l="Что подойдёт">Договор на обслуживание</td><td data-l="Подробнее"><a href="../dogovor-deratizatsiya-dezinsektsiya/">Договор и его образец</a></td></tr>
        <tr><td data-l="Ваша ситуация">Нужно ещё обеззараживание помещений</td><td data-l="Что подойдёт">Дезинфекция</td><td data-l="Подробнее"><a href="../dezinfektsiya/">Дезинфекция для организаций</a></td></tr>
      </tbody>
    </table>
    <p class="d-note" data-fade>Можно начать с одной услуги и добавить вторую дополнительным соглашением.</p>
  </div>
</section>

<section class="s" id="tseny">
  <div class="wrap">
    <div class="head"><div class="eyebrow" data-eyebrow>Цены</div><h2 data-split>Сколько стоят дератизация и дезинсекция <em>для юридических лиц</em></h2><p class="sub" data-fade>Комплекс — от <span class="nw">4&nbsp;900&nbsp;₽</span> в месяц для любого типа объекта. Точную цену называем после бесплатного выезда и закрепляем в договоре.</p></div>
    <div class="dd-price" data-fade>
      <table class="d-table dd-ptbl">
        <caption class="sr-only">Цены на комплекс дератизации и дезинсекции для организаций, в месяц</caption>
        <thead><tr><th scope="col">Объект</th><th scope="col">Что под контролем</th><th scope="col">Цена комплекса</th></tr></thead>
        <tbody>
          <tr><td data-l="Объект"><span class="dd-obj"><span class="dd-oi"><svg aria-hidden="true" focusable="false" class="lucide lucide-utensils" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M3 2v7c0 1.1.9 2 2 2h4a2 2 0 0 0 2-2V2" /> <path d="M7 2v20" /> <path d="M21 15V2a5 5 0 0 0-5 5v6c0 1.1.9 2 2 2h3Zm0 0v7" /> </svg></span><span>Кафе, ресторан, столовая</span></span></td><td data-l="Что под контролем">кухня, мойка, склад продуктов, зал</td><td data-l="Цена комплекса" class="dd-p">от 4&nbsp;900&nbsp;₽/мес</td></tr>
          <tr><td data-l="Объект"><span class="dd-obj"><span class="dd-oi"><svg aria-hidden="true" focusable="false" class="lucide lucide-shopping-cart" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="m2.05 2.05 1.099-.028a1 1 0 0 1 1.008.815l2.69 14.347A1 1 0 0 0 7.83 18H18" /> <path d="M4.563 5h16.435a1 1 0 0 1 .981 1.204l-1.026 6.226A2 2 0 0 1 18.962 14H6.25" /> <circle cx="18" cy="20" r="2" /> <circle cx="8" cy="20" r="2" /> </svg></span><span>Магазин, торговая сеть</span></span></td><td data-l="Что под контролем">торговый зал, склад, зона разгрузки</td><td data-l="Цена комплекса" class="dd-p">от 4&nbsp;900&nbsp;₽/мес</td></tr>
          <tr><td data-l="Объект"><span class="dd-obj"><span class="dd-oi"><svg aria-hidden="true" focusable="false" class="lucide lucide-warehouse" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M18 21V10a1 1 0 0 0-1-1H7a1 1 0 0 0-1 1v11" /> <path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V8a2 2 0 0 1 1.132-1.803l7.95-3.974a2 2 0 0 1 1.837 0l7.948 3.974A2 2 0 0 1 22 8z" /> <path d="M6 13h12" /> <path d="M6 17h12" /> </svg></span><span>Склад и логистика</span></span></td><td data-l="Что под контролем">периметр, рампы, ворота, зоны хранения</td><td data-l="Цена комплекса" class="dd-p">от 4&nbsp;900&nbsp;₽/мес</td></tr>
          <tr><td data-l="Объект"><span class="dd-obj"><span class="dd-oi"><svg aria-hidden="true" focusable="false" class="lucide lucide-factory" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M12 16h.01" /> <path d="M16 16h.01" /> <path d="M3 19a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V8.5a.5.5 0 0 0-.769-.422l-4.462 2.844A.5.5 0 0 1 15 10.5v-2a.5.5 0 0 0-.769-.422L9.77 10.922A.5.5 0 0 1 9 10.5V5a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2z" /> <path d="M8 16h.01" /> </svg></span><span>Пищевое и фармацевтическое производство</span></span></td><td data-l="Что под контролем">зоны по программе <span class="nw">пест-контроля</span> и ХАССП</td><td data-l="Цена комплекса" class="dd-p">от 4&nbsp;900&nbsp;₽/мес</td></tr>
        </tbody>
      </table>
      <aside class="card dd-cmp" aria-label="Сравнение: по отдельности и комплексом">
        <p class="dd-cmp-h">По отдельности</p><p class="dd-cmp-ex">на примере кафе или магазина</p>
        <ul class="dd-cmp-l">
          <li><span>Дератизация</span><span>от 3&nbsp;500&nbsp;₽/мес</span></li>
          <li><span>Дезинсекция</span><span>от 3&nbsp;500&nbsp;₽/мес</span></li>
          <li class="dd-cmp-sum"><span>Два договора</span><span>от 7&nbsp;000&nbsp;₽/мес</span></li>
        </ul>
        <p class="dd-cmp-h dd-cmp-k">Комплексом</p>
        <p class="dd-cmp-big">от 4&nbsp;900&nbsp;₽<small>/мес</small></p>
        <p class="dd-cmp-n">Грызуны и насекомые — в одном договоре и графике</p>
        <a href="#zayavka" class="btn btn-w btn-lg dd-cmp-b"><span class="btn-t">Рассчитать комплекс для объекта</span></a>
      </aside>
    </div>
    <div class="d-cols2" data-group="cards">
      <div class="d-card"><h3>Входит в цену</h3><p>Визиты по графику, обслуживание точек контроля по грызунам и насекомым, записи в журнале, акты и ежемесячный отчёт.</p></div>
      <div class="d-card"><h3>Оплачивается отдельно</h3><p>Обработки по результатам мониторинга и выезды вне графика — порядок прописываем в договоре.</p></div>
    </div>
    <dl class="dd-facts" data-fade>
      <div><dt>От чего зависит цена</dt><dd>площадь и число зон, количество точек контроля, кратность визитов, число адресов</dd></div>
      <div><dt>Оплата</dt><dd>ежемесячно по договору, с НДС и без НДС; документы — через ЭДО или на бумаге</dd></div>
    </dl>
  </div>
</section>

<section class="s" id="grafik">
  <div class="wrap">
    <div class="head"><div class="eyebrow" data-eyebrow>График на год</div><h2 data-split>Как часто проводят дератизацию и дезинсекцию: <em>график на год</em></h2><p class="sub" data-fade>Кратность визитов определяем после выезда и закрепляем в графике — приложении к договору. Для пищевых производств, общепита, торговли продуктами, гостиниц и других объектов особого эпидемиологического значения СанПиН <span class="nw">3.3686-21</span> требует обследовать объект на насекомых не реже 2 раз в месяц (п. 101), а дератизацию проводить по результатам ежемесячной оценки (п. 110).</p></div>
    <p class="dd-month" data-fade><b>Каждый месяц:</b> оценка по грызунам, обследования по насекомым по графику, акт после визита и отчёт за месяц.</p>
    <div class="dd-year" data-group="cards">
      <div class="card dd-ssn dd-ssn-vesna"><p class="dd-ssn-h"><b>Весна</b></p><table class="dd-ssn-t"><caption class="sr-only">Весна: пример графика визитов</caption><thead><tr><td></td><th scope="col"><abbr title="март">Мар</abbr></th><th scope="col"><abbr title="апрель">Апр</abbr></th><th scope="col"><abbr title="май">Май</abbr></th></tr></thead><tbody><tr><th scope="row">Грызуны</th><td><i class="dd-dot dd-r on"></i><span class="sr-only">март: оценка, усиленный контроль</span></td><td><i class="dd-dot dd-r"></i><span class="sr-only">апрель: оценка</span></td><td><i class="dd-dot dd-r"></i><span class="sr-only">май: оценка</span></td></tr><tr><th scope="row">Насекомые</th><td><i class="dd-dot dd-i"></i><i class="dd-dot dd-i"></i><span class="sr-only">март: 2 обследования</span></td><td><i class="dd-dot dd-i"></i><i class="dd-dot dd-i"></i><span class="sr-only">апрель: 2 обследования</span></td><td><i class="dd-dot dd-i on"></i><i class="dd-dot dd-i on"></i><span class="sr-only">май: 2 обследования, усиленный контроль</span></td></tr></tbody></table><p class="dd-ssn-n">Осмотр периметра после зимы, подготовка к сезону летающих насекомых.</p></div>
      <div class="card dd-ssn dd-ssn-leto"><p class="dd-ssn-h"><b>Лето</b></p><table class="dd-ssn-t"><caption class="sr-only">Лето: пример графика визитов</caption><thead><tr><td></td><th scope="col"><abbr title="июнь">Июн</abbr></th><th scope="col"><abbr title="июль">Июл</abbr></th><th scope="col"><abbr title="август">Авг</abbr></th></tr></thead><tbody><tr><th scope="row">Грызуны</th><td><i class="dd-dot dd-r"></i><span class="sr-only">июнь: оценка</span></td><td><i class="dd-dot dd-r"></i><span class="sr-only">июль: оценка</span></td><td><i class="dd-dot dd-r"></i><span class="sr-only">август: оценка</span></td></tr><tr><th scope="row">Насекомые</th><td><i class="dd-dot dd-i on"></i><i class="dd-dot dd-i on"></i><span class="sr-only">июнь: 2 обследования, усиленный контроль</span></td><td><i class="dd-dot dd-i on"></i><i class="dd-dot dd-i on"></i><span class="sr-only">июль: 2 обследования, усиленный контроль</span></td><td><i class="dd-dot dd-i on"></i><i class="dd-dot dd-i on"></i><span class="sr-only">август: 2 обследования, усиленный контроль</span></td></tr></tbody></table><p class="dd-ssn-n">Больше мух и муравьёв — усиливаем контроль у входов, площадок для отходов и в зонах приёмки.</p></div>
      <div class="card dd-ssn dd-ssn-osen"><p class="dd-ssn-h"><b>Осень</b></p><table class="dd-ssn-t"><caption class="sr-only">Осень: пример графика визитов</caption><thead><tr><td></td><th scope="col"><abbr title="сентябрь">Сен</abbr></th><th scope="col"><abbr title="октябрь">Окт</abbr></th><th scope="col"><abbr title="ноябрь">Ноя</abbr></th></tr></thead><tbody><tr><th scope="row">Грызуны</th><td><i class="dd-dot dd-r on"></i><span class="sr-only">сентябрь: оценка, усиленный контроль</span></td><td><i class="dd-dot dd-r on"></i><span class="sr-only">октябрь: оценка, усиленный контроль</span></td><td><i class="dd-dot dd-r on"></i><span class="sr-only">ноябрь: оценка, усиленный контроль</span></td></tr><tr><th scope="row">Насекомые</th><td><i class="dd-dot dd-i"></i><i class="dd-dot dd-i"></i><span class="sr-only">сентябрь: 2 обследования</span></td><td><i class="dd-dot dd-i"></i><i class="dd-dot dd-i"></i><span class="sr-only">октябрь: 2 обследования</span></td><td><i class="dd-dot dd-i"></i><i class="dd-dot dd-i"></i><span class="sr-only">ноябрь: 2 обследования</span></td></tr></tbody></table><p class="dd-ssn-n">Грызуны ищут укрытие в зданиях — проверяем ворота, рампы и проходы коммуникаций.</p></div>
      <div class="card dd-ssn dd-ssn-zima"><p class="dd-ssn-h"><b>Зима</b></p><table class="dd-ssn-t"><caption class="sr-only">Зима: пример графика визитов</caption><thead><tr><td></td><th scope="col"><abbr title="декабрь">Дек</abbr></th><th scope="col"><abbr title="январь">Янв</abbr></th><th scope="col"><abbr title="февраль">Фев</abbr></th></tr></thead><tbody><tr><th scope="row">Грызуны</th><td><i class="dd-dot dd-r"></i><span class="sr-only">декабрь: оценка</span></td><td><i class="dd-dot dd-r"></i><span class="sr-only">январь: оценка</span></td><td><i class="dd-dot dd-r"></i><span class="sr-only">февраль: оценка</span></td></tr><tr><th scope="row">Насекомые</th><td><i class="dd-dot dd-i"></i><i class="dd-dot dd-i"></i><span class="sr-only">декабрь: 2 обследования</span></td><td><i class="dd-dot dd-i"></i><i class="dd-dot dd-i"></i><span class="sr-only">январь: 2 обследования</span></td><td><i class="dd-dot dd-i"></i><i class="dd-dot dd-i"></i><span class="sr-only">февраль: 2 обследования</span></td></tr></tbody></table><p class="dd-ssn-n">Контроль внутренних зон, складов и подвальных помещений.</p></div>
    </div>
    <p class="dd-leg" data-fade><span><i class="dd-dot dd-r"></i>Грызуны — оценка раз в месяц</span><span><i class="dd-dot dd-i"></i><i class="dd-dot dd-i"></i>Насекомые — обследования не реже 2 раз в месяц</span><span><i class="dd-dot dd-r on"></i><i class="dd-dot dd-i on"></i>Усиленный контроль в сезон</span></p>
    <p class="d-note" data-fade>Схема — ориентир для кафе, магазина продуктов или пищевого цеха. Реальный график зависит от объекта и результатов мониторинга.</p>
  </div>
</section>

<section class="s" id="dokumenty">
  <div class="wrap">
    <div class="head"><div class="eyebrow" data-eyebrow>Документы</div><h2 data-split>Документы по дератизации и дезинсекции — <em>один комплект</em></h2><p class="sub" data-fade>По комплексу ведём одну папку документов на объект: её показывают инспектору Роспотребнадзора, аудитору и отделу качества.</p></div>
    <div class="dd-docs">
      <ol class="dd-doclist" data-fade>
        <li><b>Договор с приложениями</b><span>перечень работ, график, стоимость</span></li>
        <li><b>Программа <span class="nw">пест-контроля</span> и схема точек контроля</b><span>по грызунам и насекомым</span></li>
        <li><b>Журнал учёта и акт после каждого визита</b><span>что проверили, что нашли и что сделали</span></li>
        <li><b>Отчёт за месяц</b><span>активность грызунов и насекомых по точкам контроля</span></li>
        <li><b>Копия лицензии и документы на применяемые средства</b><span>для папки к проверке</span></li>
      </ol>
      <div class="dd-smps" data-group="cards">
        <a class="card dd-smp" href="../dogovor-deratizatsiya-dezinsektsiya/"><img src="../img/dogovor-sample-p1-240.webp" srcset="../img/dogovor-sample-p1-240.webp 240w, ../img/dogovor-sample-p1-360.webp 360w" sizes="120px" width="240" height="339" alt="" loading="lazy" decoding="async"><span class="dd-smp-t"><b>Образец договора</b><span>на дератизацию и дезинсекцию, PDF</span></span></a>
        <a class="card dd-smp" href="../materialy/programma-pest-kontrolya/"><img src="../img/programma-sample-p1-240.webp" srcset="../img/programma-sample-p1-240.webp 240w, ../img/programma-sample-p1-360.webp 360w" sizes="120px" width="240" height="339" alt="" loading="lazy" decoding="async"><span class="dd-smp-t"><b>Образец программы <span class="nw">пест-контроля</span></b><span>разделы, <span class="nw">пест-риск</span> по зонам, план</span></span></a>
        <a class="card dd-smp" href="../materialy/zhurnal-pest-kontrolya/"><img src="../img/zhurnal-obrazets-p1-360.webp" sizes="120px" width="360" height="509" alt="" loading="lazy" decoding="async"><span class="dd-smp-t"><b>Образец журнала</b><span>точки контроля, ловушки, предписания</span></span></a>
        <a class="card dd-smp" href="../normativnaya-baza/dokumenty-dlya-rospotrebnadzora/"><img src="../img/dok-cover-240.webp" srcset="../img/dok-cover-240.webp 240w, ../img/dok-cover-360.webp 360w" sizes="120px" width="240" height="339" alt="" loading="lazy" decoding="async"><span class="dd-smp-t"><b>Документы для Роспотребнадзора</b><span>что положить в папку к проверке</span></span></a>
      </div>
    </div>
  </div>
</section>

<section class="s" id="zakupki">
  <div class="wrap">
    <div class="head"><div class="eyebrow" data-eyebrow>Для закупок</div><h2 data-split>Оказание услуг по дератизации и дезинсекции: <em>для закупок</em></h2><p class="sub" data-fade>Участвуем в закупках на дератизацию и дезинсекцию. Для отдела закупок подготовим:</p></div>
    <div class="dd-buy" data-group="cards">
      <div class="card dd-buy-c"><span class="dd-buy-i"><svg aria-hidden="true" focusable="false" class="lucide lucide-calculator" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <rect width="16" height="20" x="4" y="2" rx="2" /> <line x1="8" x2="16" y1="6" y2="6" /> <line x1="16" x2="16" y1="14" y2="18" /> <path d="M16 10h.01" /> <path d="M12 10h.01" /> <path d="M8 10h.01" /> <path d="M12 14h.01" /> <path d="M8 14h.01" /> <path d="M12 18h.01" /> <path d="M8 18h.01" /> </svg></span><b>Коммерческое предложение</b><span>для расчёта начальной цены закупки — по запросу</span></div>
      <div class="card dd-buy-c"><span class="dd-buy-i"><svg aria-hidden="true" focusable="false" class="lucide lucide-file-signature" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M14.364 13.634a2 2 0 0 0-.506.854l-.837 2.87a.5.5 0 0 0 .62.62l2.87-.837a2 2 0 0 0 .854-.506l4.013-4.009a1 1 0 0 0-3.004-3.004z" /> <path d="M14.487 7.858A1 1 0 0 1 14 7V2" /> <path d="M20 19.645V20a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.704.706l2.516 2.516" /> <path d="M8 18h1" /> </svg></span><b>Проект договора</b><span>с перечнем объектов, кратностью визитов, точками контроля и отчётностью</span></div>
      <div class="card dd-buy-c"><span class="dd-buy-i"><svg aria-hidden="true" focusable="false" class="lucide lucide-list-checks" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M13 5h8" /> <path d="M13 12h8" /> <path d="M13 19h8" /> <path d="m3 17 2 2 4-4" /> <path d="m3 7 2 2 4-4" /> </svg></span><b>Код ОКПД 2</b><span>81.29.11.000 «Услуги по дезинфекции, дезинсекции и дератизации»</span></div>
      <div class="card dd-buy-c"><span class="dd-buy-i"><svg aria-hidden="true" focusable="false" class="lucide lucide-shield-check" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z" /> <path d="m9 12 2 2 4-4" /> </svg></span><b>Документы исполнителя</b><span>лицензия Роспотребнадзора № Л064-00111-77/01942445, закрывающие документы через ЭДО, с НДС и без НДС</span></div>
    </div>
    <div class="dd-buy-f" data-fade>
      <a href="#zayavka" class="btn btn-w btn-lg" data-goal="КП для закупки"><span class="btn-t">Запросить коммерческое предложение</span></a>
      <p class="dd-buy-n">Лицензию можно проверить в <a href="https://fp.rospotrebnadzor.ru/licen/?oper=search&amp;numb_history=&amp;numb=&amp;firmget_name=&amp;ogrn_inn_nza=7714462211" target="_blank" rel="noopener">реестре Роспотребнадзора</a>.</p>
    </div>
  </div>
</section>

<section class="s dd-band-s" id="dezinfektsiya">
  <div class="wrap">
    <div class="card dd-band" data-fade>
      <div class="dd-band-t"><h2>Нужна ещё и <em>дезинфекция?</em></h2><p>Проводим плановую и внеплановую дезинфекцию помещений для организаций. Периодичность, состав работ и цены — на отдельной странице.</p></div>
      <a href="../dezinfektsiya/" class="btn btn-o btn-lg"><span class="btn-t">О дезинфекции для организаций</span></a>
    </div>
  </div>
</section>


<!-- ============ СМОТРИТЕ ТАКЖЕ (перелинковка) ============ -->
<section class="s s-rel" id="smotrite-takzhe">
  <div class="wrap">
    <div class="head">
      <div class="eyebrow" data-eyebrow>Смотрите также</div>
      <h2 data-split>Связанные услуги <em>и материалы</em></h2>
    </div>
    <div class="rel-grid" data-group="cards">
      <a class="card rel-card" href="../deratizatsiya/"><span class="rel-k">Услуга</span><span class="rel-t">Дератизация для организаций</span><span class="rel-d">Три контура защиты от крыс и мышей, контейнеры КИК и ловушки без яда в цехах, схема точек и акты.</span><span class="rel-a" aria-hidden="true"><svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></span></a>
      <a class="card rel-card" href="../dezinsektsiya/"><span class="rel-k">Услуга</span><span class="rel-t">Дезинсекция для организаций</span><span class="rel-d">Контроль насекомых по IPM без остановки работы, ротация средств, журнал и акты по СанПиН.</span><span class="rel-a" aria-hidden="true"><svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></span></a>
      <a class="card rel-card" href="../dogovor-deratizatsiya-dezinsektsiya/"><span class="rel-k">Обслуживание</span><span class="rel-t">Договор на дератизацию и дезинсекцию</span><span class="rel-d">Одно или оба направления в одном договоре: график визитов, акт после выезда, цена до подписания.</span><span class="rel-a" aria-hidden="true"><svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></span></a>
      <a class="card rel-card" href="../sanitarnyy-audit/"><span class="rel-k">Услуга</span><span class="rel-t">Санитарный аудит (<span class="nw">СЭС-аудит</span>)</span><span class="rel-d">Проверка по проверочным листам и СанПиН 2026 года, смывы и пробы воздуха, акт с реестром нарушений.</span><span class="rel-a" aria-hidden="true"><svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></span></a>
    </div>
  </div>
</section>

<section class="s" id="voprosy">
  <div class="wrap">
    <div class="head"><div class="eyebrow" data-eyebrow>Вопросы</div><h2 data-split>Вопросы о <em>дератизации и дезинсекции</em></h2></div>
    <div class="faq">
      <div class="faq-col" data-group="faq">
        <div class="card qa open"><button aria-expanded="true" aria-controls="a1" id="q1"><span>Чем дератизация отличается от дезинсекции?</span><span class="pm"></span></button><div class="ans" id="a1" role="region" aria-labelledby="q1"><div><p>Дератизация — меры против грызунов, дезинсекция — против насекомых и других членистоногих. У них разные методы и оборудование, но на одном объекте обе услуги можно вести по одному договору и графику.</p></div></div></div>
        <div class="card qa open"><button aria-expanded="true" aria-controls="a2" id="q2"><span>Как часто нужно проводить дератизацию и дезинсекцию?</span><span class="pm"></span></button><div class="ans" id="a2" role="region" aria-labelledby="q2"><div><p>На объектах особого эпидемиологического значения — пищевых производствах, в общепите, торговле продуктами, гостиницах — обследования на насекомых проводят не реже 2 раз в месяц, а дератизацию — по результатам ежемесячной оценки (пп. 101 и 110 СанПиН <span class="nw">3.3686-21</span>). Для остальных объектов кратность определяем после обследования и закрепляем в графике.</p></div></div></div>
        <div class="card qa open"><button aria-expanded="true" aria-controls="a3" id="q3"><span>Можно ли заключить один договор на дератизацию и дезинсекцию?</span><span class="pm"></span></button><div class="ans" id="a3" role="region" aria-labelledby="q3"><div><p>Да. В договоре обе услуги, общий график и одна ежемесячная оплата. Образец договора — на странице <a href="../dogovor-deratizatsiya-dezinsektsiya/">договора на дератизацию и дезинсекцию</a>.</p></div></div></div>
        <div class="card qa open"><button aria-expanded="true" aria-controls="a4" id="q4"><span>Сколько стоит дератизация и дезинсекция для юридических лиц?</span><span class="pm"></span></button><div class="ans" id="a4" role="region" aria-labelledby="q4"><div><p>Комплекс — от 4&nbsp;900&nbsp;₽ в месяц. Точную цену называем после бесплатного выезда: она зависит от площади, числа зон и точек контроля, кратности визитов.</p></div></div></div>
      </div>
      <div class="faq-col" data-group="faq">
        <div class="card qa open"><button aria-expanded="true" aria-controls="a5" id="q5"><span>Какие организации проводят дератизацию и дезинсекцию?</span><span class="pm"></span></button><div class="ans" id="a5" role="region" aria-labelledby="q5"><div><p>С 1 марта 2025 года эти услуги оказывают только по лицензии. Наша лицензия — № Л064-00111-77/01942445, её можно проверить в <a href="https://fp.rospotrebnadzor.ru/licen/?oper=search&amp;numb_history=&amp;numb=&amp;firmget_name=&amp;ogrn_inn_nza=7714462211" target="_blank" rel="noopener">реестре Роспотребнадзора</a>.</p></div></div></div>
        <div class="card qa open"><button aria-expanded="true" aria-controls="a6" id="q6"><span>Работаете ли вы в Московской области?</span><span class="pm"></span></button><div class="ans" id="a6" role="region" aria-labelledby="q6"><div><p>Да. Выезд и расчёт по Москве и Московской области бесплатны.</p></div></div></div>
        <div class="card qa open"><button aria-expanded="true" aria-controls="a7" id="q7"><span>Какой код ОКПД 2 указать в закупке?</span><span class="pm"></span></button><div class="ans" id="a7" role="region" aria-labelledby="q7"><div><p>81.29.11.000 «Услуги по дезинфекции, дезинсекции и дератизации».</p></div></div></div>
      </div>
    </div>
  </div>
</section>

<section class="cta" id="zayavka"><div class="cta-bg f-lazy" aria-hidden="true" data-parallax-bg></div><div class="cta-orb" id="orb" aria-hidden="true"></div>
  <div class="wrap">
    <div>
      <div class="eyebrow" data-eyebrow>Заявка</div>
      <h2 data-split>Рассчитайте комплекс <em>для вашего объекта</em></h2>
      <p class="sub" data-fade>Бесплатно приедем, осмотрим объект и пришлём расчёт и проект договора.</p>
      <ul class="cta-list" data-group="ctalist">
        <li><svg aria-hidden="true" focusable="false" class="lucide lucide-circle-check" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <circle cx="12" cy="12" r="10" /> <path d="m16 9-5.5 5.5L8 12" /> </svg>Выезд по Москве и Московской области</li>
        <li><svg aria-hidden="true" focusable="false" class="lucide lucide-circle-check" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <circle cx="12" cy="12" r="10" /> <path d="m16 9-5.5 5.5L8 12" /> </svg>Осмотр и расчёт — бесплатно</li>
        <li><svg aria-hidden="true" focusable="false" class="lucide lucide-circle-check" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <circle cx="12" cy="12" r="10" /> <path d="m16 9-5.5 5.5L8 12" /> </svg>Проект договора — в течение 1 часа после осмотра</li>
      </ul>
      <div class="cta-contacts" data-fade>
        <a class="ph" href="tel:+74951043570">+7 (495) 104-35-70</a>
        <div class="msg">
          <a href="https://max.ru/u/f9LHodD0cOIlIUXFkt4KMFP88lD8n4TArBiTcV7RI1XML5c4o39QfsDBXUc" class="max" aria-label="Написать в Max" target="_blank" rel="noopener noreferrer"><svg viewBox="0 0 24 24" fill="#fff" aria-hidden="true"><path d="M12 3a9 9 0 0 0-7.7 13.7L3 21l4.4-1.2A9 9 0 1 0 12 3zm-3.6 12.3V8.7h1.6l2 2.8 2-2.8h1.6v6.6h-1.7v-3.9L12 14l-1.9-2.6v3.9z"/></svg></a>
          <a href="https://t.me/Centr_Dezinfection?text=%D0%97%D0%B4%D1%80%D0%B0%D0%B2%D1%81%D1%82%D0%B2%D1%83%D0%B9%D1%82%D0%B5!%20%D0%9F%D0%B8%D1%88%D1%83%20%D1%81%20%D1%81%D0%B0%D0%B9%D1%82%D0%B0%20%D0%BF%D0%B5%D1%81%D1%82%D0%BA%D0%BE%D0%BD%D1%82%D1%80%D0%BE%D0%BB%D1%8C-%D1%86%D0%B5%D0%BD%D1%82%D1%80.%D1%80%D1%84" class="tg" aria-label="Написать в Telegram" target="_blank" rel="noopener noreferrer"><svg viewBox="0 0 24 24" fill="#fff" aria-hidden="true"><path d="M21.4 4.3 2.9 11.4c-1.3.5-1.2 1.2-.2 1.5l4.7 1.5 1.8 5.6c.2.6.4.8.9.8.4 0 .6-.2.9-.4l2.3-2.2 4.7 3.5c.9.5 1.5.2 1.7-.8l3.1-14.6c.3-1.3-.5-1.8-1.4-1.5zM9.6 14.1l8.6-5.4c.4-.3.8-.1.5.2l-7.1 6.4-.3 3.3z"/></svg></a>
        </div>
      </div>
    </div>
    <form class="form" id="form" novalidate data-form>
      <div class="fbody">
        <h3>Расчёт комплекса</h3>
        <p class="fs">Заполнение займёт меньше минуты</p>
        <div class="fg">
<div class="field"><label class="sr-only" for="f-name">Ваше имя</label><input id="f-name" name="name" placeholder="Ваше имя *" required autocomplete="name"><small class="ferr">Укажите имя</small></div>
<div class="field"><label class="sr-only" for="phone">Телефон</label><input name="phone" id="phone" type="tel" inputmode="tel" placeholder="+7 (___) ___-__-__ *" required autocomplete="tel"><small class="ferr">Укажите телефон полностью</small></div>
<div class="field full"><label class="sr-only" for="f-type">Тип объекта</label><select id="f-type" name="type" required><option value="" selected>Тип объекта *</option><option>Ресторан или кафе</option><option>Магазин или торговая сеть</option><option>Склад, логистика</option><option>Пищевое производство</option><option>Фармацевтическое производство</option><option>Гостиница</option><option>Другое</option></select><small class="ferr">Выберите тип объекта</small></div>
<div class="field full"><label class="sr-only" for="f-area">Площадь, м²</label><input id="f-area" name="area" inputmode="numeric" placeholder="Площадь, м²" maxlength="40" autocomplete="off"></div>
<div class="field full"><label class="sr-only" for="f-goal">Что нужно</label><select id="f-goal" name="goal"><option value="" selected>Что нужно</option><option>Комплекс: дератизация и дезинсекция</option><option>Только дератизация</option><option>Только дезинсекция</option><option>КП для закупки</option></select></div>
<input type="hidden" name="msg" value="">
<div class="field" hidden><input type="hidden" name="email" value=""></div>
<input type="hidden" name="page" value="Дератизация и дезинсекция">
</div>
        <button type="submit" class="btn btn-w btn-lg" id="submitBtn"><span class="btn-t">Рассчитать комплекс</span><svg class="btn-ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M5 12h14M13 6l6 6-6 6"/></svg><i class="spin" aria-hidden="true"></i></button>
        <p class="legal">Нажимая кнопку, вы даёте <a href="../soglasie/" target="_blank" rel="noopener">согласие на обработку персональных данных</a> и подтверждаете, что ознакомились с <a href="../privacy/" target="_blank" rel="noopener">политикой конфиденциальности</a>.</p>
      </div>
      <div class="ok" role="status" aria-live="polite">
        <svg class="ok-ic" viewBox="0 0 52 52" aria-hidden="true"><circle cx="26" cy="26" r="24" fill="none"/><path fill="none" d="M15 27l7 7 15-16"/></svg>
        <h3>Заявка отправлена</h3><p>Перезвоним в ближайшее рабочее время, уточним объект и договоримся о бесплатном выезде.</p>
      </div>
    </form>
  </div>
</section>
</main>


<footer>
  <div class="wrap">
    <div class="ft">
      <div>
        <a href="../" class="logo" aria-label="ПЕСТКОНТРОЛЬ Центр — на главную"><span class="logo-mark"><svg viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="1.6" stroke-linejoin="round" aria-hidden="true"><path d="M12 2.5l7.5 3v6c0 5-3.2 8.6-7.5 10-4.3-1.4-7.5-5-7.5-10v-6z"/><circle cx="12" cy="11.5" r="2.6" stroke="#7c86ff"/><path d="M12 6.2v2.7M12 14.1v2.7M6.8 11.5h2.6M14.6 11.5h2.6" stroke="#7c86ff"/></svg></span><span class="logo-txt"><span class="logo-name">ПЕСТКОНТРОЛЬ</span> <span class="logo-sub">Центр</span></span></a>
        <p class="d"><span class="nw">Пест-контроль</span> и <span class="nw">пест-менеджмент</span> по системе IPM для бизнеса в Москве и Московской области: бесплатный аудит, оценка <span class="nw">пест-риска</span>, мониторинг вредителей и отчётность.</p>
      </div>
      <div><h4>Услуги</h4><ul><li><a href="../dezinfektsiya/">Дезинфекция для организаций</a></li><li><a href="../deratizatsiya/">Дератизация для организаций</a></li><li><a href="../dezinsektsiya/">Дезинсекция для организаций</a></li><li><a href="./" aria-current="page">Дератизация и дезинсекция</a></li><li><a href="../sanitarnyy-audit/"><span>Санитарный аудит <span class="nw">(СЭС-аудит)</span></span></a></li><li><a href="../laboratornye-issledovaniya/">Лабораторные исследования</a></li><li><a href="../razrabotka-ppk/">Разработка ППК</a></li><li><a href="../normativnaya-baza/dokumenty-dlya-rospotrebnadzora/">Документы для Роспотребнадзора</a></li><li><a href="../ochistka-dezinfektsiya-ventilyatsii/">Очистка и дезинфекция вентиляции</a></li><li><a href="../dogovor-deratizatsiya-dezinsektsiya/">Договор на дератизацию и дезинсекцию</a></li><li><a href="../#podhod"><span><span class="nw">Пест-контроль</span> по системе IPM</span></a></li><li><a href="../#etapy">Этапы работы</a></li><li><a href="../#vrediteli">Вредители</a></li><li><a href="../#usloviya">Цена</a></li><li><a href="../#voprosy">Вопросы</a></li></ul></div>
      <div><h4>Отрасли</h4><ul><li><a href="../pishchevoe-proizvodstvo/">Пищевые производства</a></li><li><a href="../magaziny-i-torgovye-seti/">Магазины и торговые сети</a></li><li><a href="../restorany-i-kafe/">Рестораны и кафе</a></li><li><a href="../sklady-i-logistika/">Склады и логистика</a></li><li><a href="../farmatsevticheskie-proizvodstva/">Фармацевтические производства</a></li><li><a href="../gostinitsy/">Гостиницы и отели</a></li></ul></div>
      <div><h4>Материалы</h4><ul><li><a href="../normativnaya-baza/">Нормативная база</a></li><li><a href="../normativnaya-baza/proverochnye-listy/">Проверочные листы 2026</a></li><li><a href="../normativnaya-baza/dokumenty-dlya-rospotrebnadzora/">Документы для Роспотребнадзора</a></li><li><a href="../materialy/programma-pest-kontrolya/"><span>Программа <span class="nw">пест-контроля</span></span></a></li><li><a href="../materialy/zhurnal-pest-kontrolya/"><span>Журнал <span class="nw">пест-контроля</span></span></a></li><li><a href="../materialy/pest-menedzhment-ili-razovaya-obrabotka/"><span><span class="nw">Пест-менеджмент</span> или разовая обработка</span></a></li><li><a href="../materialy/programma-proizvodstvennogo-kontrolya-haccp/">Программа производственного контроля по ХАССП</a></li><li><a href="../materialy/">Все материалы</a></li></ul></div>
      <div><h4>Контакты</h4><ul><li><a href="tel:+74951043570">+7 (495) 104-35-70</a></li><li><a href="mailto:b2b@pestcontrol-center.ru">b2b@<wbr><span style="white-space:nowrap">pestcontrol-center.ru</span></a></li><li>Пн–Пт: 8:00–20:00</li><li>Срочные выезды: 24/7</li></ul>
        <div class="msg"><a href="https://max.ru/u/f9LHodD0cOIlIUXFkt4KMFP88lD8n4TArBiTcV7RI1XML5c4o39QfsDBXUc" class="max" aria-label="Написать в Max" target="_blank" rel="noopener noreferrer"><svg viewBox="0 0 24 24" fill="#fff" aria-hidden="true"><path d="M12 3a9 9 0 0 0-7.7 13.7L3 21l4.4-1.2A9 9 0 1 0 12 3zm-3.6 12.3V8.7h1.6l2 2.8 2-2.8h1.6v6.6h-1.7v-3.9L12 14l-1.9-2.6v3.9z"/></svg></a><a href="https://t.me/Centr_Dezinfection?text=%D0%97%D0%B4%D1%80%D0%B0%D0%B2%D1%81%D1%82%D0%B2%D1%83%D0%B9%D1%82%D0%B5!%20%D0%9F%D0%B8%D1%88%D1%83%20%D1%81%20%D1%81%D0%B0%D0%B9%D1%82%D0%B0%20%D0%BF%D0%B5%D1%81%D1%82%D0%BA%D0%BE%D0%BD%D1%82%D1%80%D0%BE%D0%BB%D1%8C-%D1%86%D0%B5%D0%BD%D1%82%D1%80.%D1%80%D1%84" class="tg" aria-label="Написать в Telegram" target="_blank" rel="noopener noreferrer"><svg viewBox="0 0 24 24" fill="#fff" aria-hidden="true"><path d="M21.4 4.3 2.9 11.4c-1.3.5-1.2 1.2-.2 1.5l4.7 1.5 1.8 5.6c.2.6.4.8.9.8.4 0 .6-.2.9-.4l2.3-2.2 4.7 3.5c.9.5 1.5.2 1.7-.8l3.1-14.6c.3-1.3-.5-1.8-1.4-1.5zM9.6 14.1l8.6-5.4c.4-.3.8-.1.5.2l-7.1 6.4-.3 3.3z"/></svg></a></div>
      </div>
    </div>
    <div class="fb"><span>© 2026 ПЕСТКОНТРОЛЬ Центр</span><a href="../privacy/">Политика конфиденциальности</a><a href="../soglasie/">Согласие на обработку данных</a><span>Информация на сайте не является публичной офертой</span></div>
  </div>
</footer>

<div class="mbar" id="mbar">
  <a href="tel:+74951043570" class="c1"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1 1 .4 1.9.7 2.8a2 2 0 0 1-.5 2.1L8 9.9a16 16 0 0 0 6 6l1.3-1.3a2 2 0 0 1 2.1-.4c.9.3 1.8.6 2.8.7a2 2 0 0 1 1.7 2z"/></svg>Позвонить</a>
  <a href="#zayavka" class="c2"><span>Обследование</span></a>
</div>
<div class="fab" role="group" aria-label="Написать в мессенджер">
  <a href="https://max.ru/u/f9LHodD0cOIlIUXFkt4KMFP88lD8n4TArBiTcV7RI1XML5c4o39QfsDBXUc" class="max" aria-label="Написать в Max" target="_blank" rel="noopener noreferrer"><svg viewBox="0 0 24 24" fill="#fff" aria-hidden="true"><path d="M12 3a9 9 0 0 0-7.7 13.7L3 21l4.4-1.2A9 9 0 1 0 12 3zm-3.6 12.3V8.7h1.6l2 2.8 2-2.8h1.6v6.6h-1.7v-3.9L12 14l-1.9-2.6v3.9z"/></svg></a>
  <a href="https://t.me/Centr_Dezinfection?text=%D0%97%D0%B4%D1%80%D0%B0%D0%B2%D1%81%D1%82%D0%B2%D1%83%D0%B9%D1%82%D0%B5!%20%D0%9F%D0%B8%D1%88%D1%83%20%D1%81%20%D1%81%D0%B0%D0%B9%D1%82%D0%B0%20%D0%BF%D0%B5%D1%81%D1%82%D0%BA%D0%BE%D0%BD%D1%82%D1%80%D0%BE%D0%BB%D1%8C-%D1%86%D0%B5%D0%BD%D1%82%D1%80.%D1%80%D1%84" class="tg" aria-label="Написать в Telegram" target="_blank" rel="noopener noreferrer"><svg viewBox="0 0 24 24" fill="#fff" aria-hidden="true"><path d="M21.4 4.3 2.9 11.4c-1.3.5-1.2 1.2-.2 1.5l4.7 1.5 1.8 5.6c.2.6.4.8.9.8.4 0 .6-.2.9-.4l2.3-2.2 4.7 3.5c.9.5 1.5.2 1.7-.8l3.1-14.6c.3-1.3-.5-1.8-1.4-1.5zM9.6 14.1l8.6-5.4c.4-.3.8-.1.5.2l-7.1 6.4-.3 3.3z"/></svg></a>
</div>

<script>
/* Предпросмотр: вне рабочего домена заявка не отправляется (на пестконтроль-центр.рф этот блок не срабатывает) */
(function(){if(/^(www\.)?xn----itbbsflddbfpfdodg9d0f\.xn--p1ai$/i.test(location.hostname))return;var f=window.fetch;window.fetch=function(u){if(typeof u==='string'&&u.indexOf('send.php')>-1)return new Promise(function(r){setTimeout(function(){r(new Response('{"success":true}',{status:200,headers:{'Content-Type':'application/json'}}))},500)});return f.apply(this,arguments)};document.addEventListener('DOMContentLoaded',function(){var p=document.querySelector('.form .fs');if(p)p.textContent='Предпросмотр: заявка никуда не отправляется'})})();
</script>
<script data-fx>
/* Эффекты под курсором, как на главной (tools/site/fx.py) */
(function(){
  var mm=window.matchMedia;if(!mm)return;
  var fine=mm('(hover: hover) and (pointer: fine)').matches;
  /* «фонарь»: следует за мышью, без движения мыши плавно ходит сам; на сенсорных экранах ходит сам (30 кадров в секунду).
     Не считаем, пока первый экран не виден или вкладка скрыта. Старт — вместе со входом первого экрана */
  var hero=document.getElementById('hero'),lit=hero&&hero.querySelector('.fx-lit');
  if(lit&&!mm('(prefers-reduced-motion: reduce)').matches){
    var media=lit.parentNode,small=mm('(max-width:860px)').matches,full=hero.classList.contains('f-hero');
    lit.style.setProperty('--sr',small?'150px':'clamp(240px, 21vw, 400px)');
    var cx=small?.5:(full?.68:.74),ax=small?.24:(full?.16:.13),cy=small?.5:.47,ay=small?.2:.17;
    var sx=cx,sy=cy,tx=cx,ty=cy,last=-1e9,vis=true,on=false,raf=0,lt=0;
    var frame=function(now){
      raf=0;if(!on||!vis||document.hidden)return;
      var dt=now-lt;if(!fine&&dt<30){raf=requestAnimationFrame(frame);return;}
      lt=now;if(now-last>2600){var t=now/1000;tx=cx+ax*Math.sin(t*.33);ty=cy+ay*Math.sin(t*.47+1.3);}
      var k=1-Math.pow(.94,Math.min(dt,100)/16.67);sx+=(tx-sx)*k;sy+=(ty-sy)*k;
      lit.style.setProperty('--sx',(sx*100).toFixed(2)+'%');lit.style.setProperty('--sy',(sy*100).toFixed(2)+'%');
      raf=requestAnimationFrame(frame);
    };
    var kick=function(){if(!raf&&on&&vis&&!document.hidden){lt=performance.now();raf=requestAnimationFrame(frame);}};
    hero.addEventListener('pointermove',function(e){
      if(e.pointerType!=='mouse')return;var r=media.getBoundingClientRect();if(!r.width||!r.height)return;
      tx=(e.clientX-r.left)/r.width;ty=(e.clientY-r.top)/r.height;last=performance.now();kick();
    },{passive:true});
    if('IntersectionObserver' in window)new IntersectionObserver(function(es){vis=es[0].isIntersecting;kick();}).observe(hero);
    document.addEventListener('visibilitychange',kick);
    var start=function(){if(on)return;on=true;hero.classList.add('fx-lit-on');kick();};
    var eb=hero.querySelector('.eyebrow');
    if(eb&&'MutationObserver' in window){
      if(eb.classList.contains('in'))start();
      else{var mo=new MutationObserver(function(){if(eb.classList.contains('in')){mo.disconnect();start();}});mo.observe(eb,{attributes:true,attributeFilter:['class']});}
    }
    setTimeout(start,eb?5000:2500);
  }
  /* подсветка рамки карточек за курсором — как у .card на главной */
  if(fine)document.addEventListener('pointermove',function(e){
    var c=e.target.closest&&e.target.closest('.d-card,.p-sec,.p-fcard,.p-duty-box,.p-dl-card,.pm-step-card,.pm-scen,.pm-link-card,.k-err,.w-sample,.d-doc-prev');if(!c)return;
    var r=c.getBoundingClientRect();c.style.setProperty('--mx',(e.clientX-r.left)+'px');c.style.setProperty('--my',(e.clientY-r.top)+'px');
  },{passive:true});
})();
</script>
<script>
  /* скрипты анимаций подключаются сразу после первой отрисовки: фото и заголовок первого экрана не ждут их загрузки */
  (function (r, l) {
    var go = function () { l.forEach(function (u) { var e = document.createElement('script'); e.src = r + u; e.async = false; document.body.appendChild(e); }); };
    if (document.visibilityState === 'hidden' || !window.requestAnimationFrame) setTimeout(go, 0);
    else requestAnimationFrame(function () { setTimeout(go, 0); });
  })('../', ['vendor/gsap.min.js', 'vendor/ScrollTrigger.min.js', 'vendor/lenis.min.js', 'app.min.js?v=20261106s2']);
</script>
<script>/* Форма: площадь, «Что нужно» и страница — в поле msg, которое читает send.php; кнопка «Запросить коммерческое предложение» выбирает в форме «КП для закупки» */
(function(d){var f=d.getElementById('form');if(!f)return;d.addEventListener('click',function(e){var a=e.target.closest&&e.target.closest('[data-goal]');if(a&&f.elements.goal)f.elements.goal.value=a.getAttribute('data-goal');});d.addEventListener('submit',function(ev){if(ev.target!==f)return;var e=f.elements,a=e.area.value.trim(),g=e.goal.value;e.msg.value='Тип объекта: '+(e.type.value||'не выбран')+(a?'\nПлощадь: '+a+' м²':'')+'\nЧто нужно: '+(g||'не выбрано')+'\nСтраница: Дератизация и дезинсекция (/deratizatsiya-i-dezinsektsiya/)';},true);})(document);</script>
<!-- Yandex.Metrika counter + UIS + Radist: загружаются после первого действия посетителя (касание, прокрутка, мышь, клавиатура) или через 5 с после загрузки страницы -->
<script type="text/javascript">
    (function (w, d) {
        w.ym = w.ym || function () { (w.ym.a = w.ym.a || []).push(arguments); };
        w.ym.l = 1 * new Date();
        ym(113675622, 'init', {ssr:true, webvisor:true, clickmap:true, ecommerce:"dataLayer", referrer: document.referrer, url: location.href, accurateTrackBounce:true, trackLinks:true});
        var done = false, ready = false, wait = null, ev = ['pointerdown', 'touchstart', 'keydown', 'scroll', 'wheel', 'mousemove'];
        w.__cs = w.__cs || [];
        w.__cs.push(['waitForTrackViewAndRun', function () { ready = true; }]);
        // Radist: код заявки в ссылках Telegram и MAX — сразу, скрипт Radist загрузится вместе со счётчиками
        var rmsg = 'Здравствуйте! Пишу с сайта пестконтроль-центр.рф. Номер заявки: {radist_tracker}';
        w.radist_tracker = w.radist_tracker || function () { (w.radist_tracker.a = w.radist_tracker.a || []).push(arguments); };
        w.radist_tracker.l = 1 * new Date();
        w.radist_tracker({ message: rmsg, whatsapp_enabled: true, tgbot_enabled: true, tg_enabled: true, max_enabled: true, vk_enabled: true });
        (function () {
            var id = null, abc = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789', s = 'ro', i, txt;
            try {
                id = sessionStorage.getItem('radistVisit');
                if (!id || id.length !== 12) {
                    for (i = 0; i < 10; i++) s += abc.charAt(Math.floor(Math.random() * abc.length));
                    sessionStorage.setItem('radistVisit', s);
                    id = sessionStorage.getItem('radistVisit');
                }
            } catch (e) { id = null; }
            if (!id || id.length !== 12) return;
            txt = encodeURIComponent(rmsg.replace(/{radist_tracker}/g, id));
            [].forEach.call(d.querySelectorAll('a[href*="//t.me/"], a[href*="//max.ru/"]'), function (a) {
                try {
                    var u = new URL(a.href), n = u.pathname.split('/')[1] || '';
                    if (u.host === 'max.ru') a.href = 'https://max.ru/' + u.pathname.substring(1) + '?start=' + id;
                    else if (u.host === 't.me' && !/bot$/i.test(n)) a.href = 'https://t.me' + u.pathname + '?text=' + txt;
                } catch (e) {}
            });
        })();
        function add(src) { var k = d.createElement('script'); k.async = true; k.src = src; d.head.appendChild(k); return k; }
        function load() {
            if (done) return; done = true;
            ev.forEach(function (e) { w.removeEventListener(e, load, true); });
            add('https://mc.yandex.ru/metrika/tag.js?id=113675622');
            var p = d.createElement('link'); p.rel = 'preconnect'; p.href = 'https://tracker.comagic.ru'; d.head.appendChild(p);
            add('https://app.uiscom.ru/static/cs.min.js?k=ICWycQx6m3NSBe3WlCeDAdAKMTmNhMHC').onerror = function () { ready = true; };
            add('https://track.radist.me/tracker.min.js');
        }
        ev.forEach(function (e) { w.addEventListener(e, load, { capture: true, passive: true }); });
        function later() { setTimeout(load, 5000); }
        if (d.readyState === 'complete') later(); else w.addEventListener('load', later);
        // Ожидание подмены номера при первом касании: набор откладывается до ответа UIS, максимум 0,8–1 с
        d.addEventListener('click', function (e) {
            if (ready) return;
            var a = e.target && e.target.closest ? e.target.closest('a[href^="tel:"]') : null;
            if (!a || e.button || e.ctrlKey || e.metaKey || e.shiftKey || e.altKey) return;
            e.preventDefault();
            if (wait) return;
            load();
            var href = a.getAttribute('href'), op = a.style.opacity, max = 'GestureEvent' in w ? 800 : 1000, t;
            function go() {
                for (var i = 0; i < wait.length; i++) clearTimeout(wait[i]);
                wait = null; ready = true; a.style.opacity = op;
                w.location.href = a.href;
            }
            function check(last) { return function () { if (wait && (last || ready || a.getAttribute('href') !== href)) go(); }; }
            wait = [];
            a.style.opacity = '.6';
            for (t = 50; t <= max; t += 50) wait.push(setTimeout(check(t === max), t));
        }, true);
    })(window, document);
</script>
<noscript><div><img src="https://mc.yandex.ru/watch/113675622" style="position:absolute; left:-9999px;" alt="" /></div></noscript>
<!-- /Yandex.Metrika counter -->
</body>
</html>
