<!doctype html>
<html lang="ru">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>Пест-менеджмент или разовая обработка: разница — ПЕСТКОНТРОЛЬ Центр</title>
<meta name="description" content="Чем системный пест-менеджмент по IPM отличается от разовой дезинсекции и дератизации на предприятии: таблица сравнения, требования СанПиН 3.3686-21 и ХАССП, цены.">
<link rel="canonical" href="https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/materialy/pest-menedzhment-ili-razovaya-obrabotka/">
<meta name="theme-color" content="#000000">
<meta property="og:type" content="article">
<meta property="og:locale" content="ru_RU">
<meta property="og:site_name" content="ПЕСТКОНТРОЛЬ Центр">
<meta property="og:url" content="https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/materialy/pest-menedzhment-ili-razovaya-obrabotka/">
<meta property="og:title" content="Пест-менеджмент или разовая обработка на предприятии: что выбрать">
<meta property="og:description" content="Чем системный пест-менеджмент по IPM отличается от разовой дезинсекции и дератизации на предприятии: таблица сравнения, требования СанПиН 3.3686-21 и ХАССП, цены.">
<link rel="icon" href="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 32 32'%3E%3Ccircle cx='16' cy='16' r='15' fill='%2309090b' stroke='%237c86ff' stroke-width='2'/%3E%3Cpath d='M16 7l7 3v5c0 5-3 8.5-7 10-4-1.5-7-5-7-10v-5z' fill='none' stroke='%23fff' stroke-width='2'/%3E%3C/svg%3E">
<link rel="preload" href="../../fonts/inter-ru-wght-normal.woff2" as="font" type="font/woff2" crossorigin>
<link rel="preload" href="../../img/pm-hero.webp" as="image" media="(min-width:861px)">
<link rel="preload" href="../../img/pm-hero-mob.webp" as="image" media="(max-width:860px)">
<script>
  /* начальные состояния анимаций — только при работающем JS; страховка — через 4 с всё показывается.
     Заставка — один раз за посещение: при переходе по ссылке с якорем и между страницами сайта её нет */
  (function (d) {
    d.classList.add('js');
    try { if (location.hash || sessionStorage.getItem('pc-intro')) d.classList.add('no-intro'); else sessionStorage.setItem('pc-intro', '1'); }
    catch (e) { if (location.hash) d.classList.add('no-intro'); }
    setTimeout(function () { if (!d.classList.contains('anim-ready')) d.classList.add('anim-fail'); }, 4000);
  })(document.documentElement);
</script>
<link rel="stylesheet" href="../../style.css?v=20261106s2">
<style>html{scroll-behavior:auto}.d-page .s{padding:clamp(64px,7vw,128px) 0;border-top:1px solid var(--line)}.d-crumbs{font-size:14px;color:var(--t3);display:flex;flex-wrap:wrap;gap:8px;margin:0 0 clamp(28px,3vw,48px)}.d-crumbs a{color:var(--t2)}.d-crumbs a:hover{color:var(--t1)}.d-hero{position:relative;overflow:hidden;padding:calc(clamp(68px,6vw,115px) + 20px) 0 clamp(64px,7vw,116px);min-height:clamp(680px,56vw,900px);display:flex;align-items:center}.d-hero .wrap{width:100%;display:grid;grid-template-columns:minmax(0,.92fr) minmax(0,1.08fr);gap:clamp(28px,4vw,80px);align-items:center}.d-hero-copy>*:not(.d-hero-media){position:relative;z-index:1}.d-hero-media{position:absolute;inset:0;z-index:0;pointer-events:none;overflow:hidden}.d-hero-media::before{content:"";position:absolute;inset:0;z-index:1;background:linear-gradient(90deg,rgba(0,0,0,.92) 0%,rgba(0,0,0,.82) 36%,rgba(0,0,0,.25) 52%,rgba(0,0,0,0) 62%),linear-gradient(180deg,#000 0,rgba(0,0,0,.55) 90px,rgba(0,0,0,0) 260px),linear-gradient(0deg,#000 0,rgba(0,0,0,0) 20%)}.d-hero-img{position:absolute;inset:0;width:100%;height:100%;object-fit:cover;object-position:100% 50%}.d-hero h1{font-size:clamp(42px,4.4vw,84px);line-height:1.1;letter-spacing:-.055em;font-weight:300;margin:18px 0 0}.d-hero h1 .ln{display:block;padding:0 .08em .08em 0;margin-bottom:-.08em}.d-hero h1 .ln>span{display:inline-block}.d-ticks{list-style:none;padding:0;margin:28px 0 0;display:grid;gap:12px}.d-ticks li{position:relative;padding-left:30px;line-height:1.5}.d-ticks li::before{content:"";position:absolute;left:2px;top:.42em;width:13px;height:7px;border-left:2px solid var(--acc);border-bottom:2px solid var(--acc);transform:rotate(-45deg)}.d-hero .sub{margin:22px 0 0}.d-btns{display:flex;flex-wrap:wrap;gap:12px;margin-top:28px}.ph-img{aspect-ratio:4/3;border:1.5px dashed var(--line2);border-radius:var(--r);display:flex;align-items:center;justify-content:center;text-align:center;padding:28px;color:var(--t3);font-size:14px;line-height:1.5;background:rgba(255,255,255,.02)}.ph-doc{aspect-ratio:3/4;max-width:340px}.d-doc-prev{display:block;max-width:300px;border-radius:14px;overflow:hidden;border:1px solid var(--line2);background:#fff;box-shadow:0 18px 44px rgba(0,0,0,.45);transition:border-color .2s,transform .2s}.d-doc-prev:hover{border-color:var(--acc);transform:translateY(-2px)}.d-doc-prev img{display:block;width:100%;height:auto}.d-cards{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:16px}.d-card{background:var(--card);border:1px solid var(--line2);border-radius:var(--r);padding:clamp(22px,2vw,34px)}.d-card h3{font-size:clamp(20px,1.5vw,26px);font-weight:400;letter-spacing:-.02em;margin:0 0 12px}.d-card p{color:var(--t2);line-height:1.6;margin:0}.d-note{color:var(--t2);margin:24px 0 0;line-height:1.6}.d-strong{color:var(--t1);font-size:clamp(18px,1.3vw,22px)}.d-split{display:grid;grid-template-columns:minmax(0,1fr) minmax(0,340px);gap:clamp(28px,4vw,80px);align-items:start}.d-two{display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1fr);gap:clamp(28px,4vw,80px);align-items:start}.d-two .head{margin-bottom:0}.d-two .d-ticks{margin:0}.d-terms{list-style:none;counter-reset:t;padding:0;margin:0;border-top:1px solid var(--line2)}.d-terms li{display:grid;grid-template-columns:44px minmax(0,.42fr) minmax(0,1fr);gap:16px;padding:18px 0;border-bottom:1px solid var(--line2);line-height:1.55}.d-terms li::before{counter-increment:t;content:counter(t,decimal-leading-zero);color:var(--t3)}.d-terms b{font-weight:500}.d-terms span{color:var(--t2)}.d-doc{display:grid;gap:16px;justify-items:start}.d-small{font-size:14px;color:var(--t3);margin:0}.d-steps{list-style:none;counter-reset:st;padding:0;margin:0;display:grid;grid-template-columns:repeat(5,minmax(0,1fr));gap:18px}.d-steps li{border-top:2px solid var(--line2);padding-top:18px;line-height:1.55}.d-steps li::before{counter-increment:st;content:"0" counter(st);display:block;color:var(--acc);font-size:14px;margin-bottom:12px}.d-steps b{display:block;font-weight:500;margin-bottom:8px}.d-steps span{color:var(--t2)}.d-table{width:100%;border-collapse:collapse;line-height:1.5}.d-table th,.d-table td{text-align:left;vertical-align:top;padding:16px 20px 16px 0;border-bottom:1px solid var(--line2)}.d-table th{color:var(--t3);font-weight:400;font-size:14px}.d-table td{color:var(--t2)}.d-table td:first-child{color:var(--t1)}.d-vs td:first-child{color:var(--t2)}.d-vs th:last-child,.d-vs td:last-child{color:var(--t1);background:rgba(124,134,255,.07);padding-left:20px}.d-cols2{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:16px;margin-top:28px}.d-chips{list-style:none;padding:0;margin:0;display:flex;flex-wrap:wrap;gap:10px}.d-chips a{display:inline-block;padding:12px 18px;border:1px solid var(--line2);border-radius:999px;color:var(--t1);transition:border-color .2s}.d-chips a:hover{border-color:var(--acc)}.tbd{background:rgba(255,209,102,.14);color:#ffd166;border-radius:4px;padding:0 .2em}.d-page .cta .sub{margin-bottom:30px}@media (max-width:1180px){.d-hero{min-height:0}.d-hero .wrap{grid-template-columns:minmax(0,.82fr) minmax(0,1.18fr)}.d-hero .btn-lg{height:52px;padding:0 22px;font-size:15px}}@media (max-width:1100px){.d-steps{grid-template-columns:repeat(2,minmax(0,1fr))}}@media (max-width:860px){.hdr{background:rgba(0,0,0,.72);backdrop-filter:blur(18px);-webkit-backdrop-filter:blur(18px);border-color:var(--line)}.d-hero{display:block;min-height:0;padding:calc(clamp(68px,6vw,115px) + 20px) 0 clamp(44px,7vw,64px)}.d-hero .wrap,.d-split,.d-two,.d-cols2,.d-cards{grid-template-columns:minmax(0,1fr)}.d-hero-copy{display:flex;flex-direction:column}.d-hero .eyebrow{display:none}.d-hero h1{order:1;font-size:clamp(26px,7.6vw,31px);line-height:1.1;letter-spacing:-.055em;margin:0}.d-hero h1 .d-ln1,.d-hero h1 .d-ln2{display:inline}.d-hero-media{order:2;position:relative;inset:auto;aspect-ratio:16/9;margin:18px calc(var(--pad) * -1) 0}.d-hero-media::before{display:none}.d-hero-img{height:100%;min-height:0}.d-btns{order:3;margin-top:22px;gap:10px}.d-btns .btn{height:52px}.d-btns .d-tel-btn{display:none}.d-ticks{order:4;margin:26px 0 0}.d-hero .sub{order:5;margin:20px 0 0;font-size:16px;line-height:1.45}.d-crumbs{order:6;margin:18px 0 0;padding:0;font-size:clamp(10px,2.8vw,11px);line-height:1.2;gap:6px;flex-wrap:nowrap;white-space:nowrap;opacity:.42;letter-spacing:0}.d-terms li{grid-template-columns:36px minmax(0,1fr);gap:6px 12px}.d-terms span{grid-column:2}.ph-doc{display:none}.d-doc-prev{max-width:220px}}@media (max-width:600px){.d-steps{grid-template-columns:minmax(0,1fr)}.d-table thead{display:none}.d-table,.d-table tbody,.d-table tr,.d-table td{display:block;width:100%}.d-table tr{border:1px solid var(--line2);border-radius:var(--r);padding:6px 16px;margin-bottom:12px}.d-table td{border:0;padding:10px 0}.d-table td+td{border-top:1px solid var(--line)}.d-table td::before{content:attr(data-l);display:block;font-size:13px;color:var(--t3);margin-bottom:4px}.d-vs td:last-child{background:none;padding-left:0}.d-page .form .btn-lg{padding:0 16px}}@media (max-width:360px){.d-doc .btn-lg{max-width:100%;padding:0 18px;font-size:15px}}
.hdr .nav a{white-space:nowrap}
.d-hero-media::before{background:linear-gradient(90deg,rgba(0,0,0,.95) 0%,rgba(0,0,0,.86) 40%,rgba(0,0,0,.32) 56%,rgba(0,0,0,0) 68%),linear-gradient(180deg,#000 0,rgba(0,0,0,.55) 90px,rgba(0,0,0,0) 260px),linear-gradient(0deg,#000 0,rgba(0,0,0,0) 20%)}
.d-hero h1{font-size:clamp(38px,4.1vw,76px)}
.f-checks{position:relative;padding:clamp(28px,3vw,56px) 0 clamp(56px,6vw,110px);border-top:1px solid var(--line)}
.f-check.panel{max-width:none}
.f-check-in{position:relative;z-index:1;display:grid;grid-template-columns:minmax(0,.9fr) minmax(0,1.1fr);gap:clamp(24px,4vw,80px);padding:clamp(24px,3vw,52px)}
.f-check-t{font-size:clamp(28px,2.6vw,46px);line-height:1.08;letter-spacing:-.04em;font-weight:300;margin:14px 0 0}
.f-check-res{margin:22px 0 10px;color:var(--t2);font-size:15px}
.f-check-res b{font-size:clamp(40px,3.4vw,64px);font-weight:300;letter-spacing:-.04em;color:var(--acc);margin-right:6px;line-height:1;transition:color .3s}
.f-check-res.warn b{color:var(--yel)}
.f-check-note{color:var(--t2);line-height:1.6;margin:0 0 28px;max-width:460px}
.f-check-list{list-style:none;margin:0;padding:0;display:grid;align-content:center;border-top:1px solid var(--line)}
.f-check-list li{border-bottom:1px solid var(--line)}
.f-check-list label{display:flex;gap:18px;align-items:center;padding:18px 4px;cursor:pointer;font-size:clamp(15px,1.08vw,19px);line-height:1.45;color:var(--t2);transition:color .25s}
.f-check-list label:hover{color:var(--t1)}
.f-check-list input{appearance:none;-webkit-appearance:none;flex:none;width:26px;height:26px;margin:0;border-radius:8px;border:1.4px solid var(--line2);background:rgba(255,255,255,.03) center/14px no-repeat;cursor:pointer;transition:background-color .25s,border-color .25s}
.f-check-list input:checked{background-color:var(--acc2);border-color:var(--acc);background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 14 14'%3E%3Cpath d='M2.5 7.5l3 3 6-7' fill='none' stroke='%23fff' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'/%3E%3C/svg%3E")}
.f-check-list input:focus-visible{outline:2px solid var(--acc);outline-offset:3px}
.f-check-list input:checked+span{color:var(--t1)}
.pm-chain{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:16px;margin-bottom:24px}
.pm-step-card{background:var(--card);border:1px solid var(--line2);border-radius:var(--r);padding:clamp(22px,2vw,32px);position:relative;display:flex;flex-direction:column;gap:10px}
.pm-step-tag{display:inline-flex;align-self:flex-start;font-size:12px;letter-spacing:.08em;text-transform:uppercase;color:var(--acc);padding:4px 10px;border-radius:999px;background:rgba(124,134,255,.1);border:1px solid rgba(124,134,255,.24)}
.pm-step-card h3{font-size:clamp(19px,1.4vw,24px);font-weight:400;letter-spacing:-.02em;margin:4px 0 0}
.pm-step-card p{color:var(--t2);line-height:1.6;margin:0;font-size:15px}
.pm-callout{background:rgba(124,134,255,.06);border:1px solid rgba(124,134,255,.28);border-radius:var(--r);padding:clamp(20px,2vw,28px);color:var(--t2);line-height:1.6}
.pm-callout b{color:var(--t1);font-weight:500}
.d-table.pm-vs3 th:first-child,.d-table.pm-vs3 td:first-child{width:22%;color:var(--t1);font-weight:500}
.d-table.pm-vs3 th:nth-child(2),.d-table.pm-vs3 td:nth-child(2){width:36%;color:var(--t2)}
.d-table.pm-vs3 th:nth-child(3),.d-table.pm-vs3 td:nth-child(3){width:42%;background:rgba(124,134,255,.07);border-left:1px solid rgba(124,134,255,.32);color:var(--t1)}
.d-table.pm-vs3 th:nth-child(3){color:var(--acc)}
.pm-scen-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:20px}
.pm-scen{background:var(--card);border:1px solid var(--line2);border-radius:var(--r);padding:clamp(24px,2.4vw,38px)}
.pm-scen.pm-scen-ipm{border-color:rgba(124,134,255,.42);background:linear-gradient(180deg,rgba(124,134,255,.07),rgba(24,24,27,.45))}
.pm-scen-lbl{display:inline-block;font-size:12px;letter-spacing:.08em;text-transform:uppercase;padding:4px 10px;border-radius:999px;margin-bottom:14px}
.pm-scen-bad .pm-scen-lbl{color:var(--yel);background:rgba(253,199,0,.1);border:1px solid rgba(253,199,0,.25)}
.pm-scen-ipm .pm-scen-lbl{color:var(--acc);background:rgba(124,134,255,.12);border:1px solid rgba(124,134,255,.3)}
.pm-scen h3{font-size:clamp(21px,1.6vw,28px);font-weight:400;letter-spacing:-.025em;margin:0 0 20px}
.pm-tl{list-style:none;padding:0;margin:0;display:grid;gap:16px}
.pm-tl li{padding-top:16px;border-top:1px solid var(--line);display:grid;gap:4px}
.pm-tl li:first-child{padding-top:0;border-top:0}
.pm-tl-time{font-size:13px;letter-spacing:.06em;text-transform:uppercase;color:var(--t3)}
.pm-scen-ipm .pm-tl-time{color:var(--acc)}
.pm-tl b{font-weight:500;color:var(--t1);font-size:16px}
.pm-tl span{color:var(--t2);line-height:1.55;font-size:15px}
.d-card .f-num{font-size:clamp(26px,2.2vw,42px);line-height:1.08;letter-spacing:-.035em;font-weight:300;color:var(--acc);margin:0 0 14px}
.f-req .d-card{border-top:2px solid rgba(124,134,255,.45)}
.pm-choice-card h3{font-size:clamp(21px,1.6vw,28px);margin-bottom:16px}
.pm-choice-ipm{border-color:rgba(124,134,255,.42);background:rgba(124,134,255,.05)}
.pm-links-grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:16px;margin-top:20px}
.pm-link-card{display:flex;flex-direction:column;justify-content:space-between;gap:14px;background:var(--card);border:1px solid var(--line2);border-radius:var(--r);padding:clamp(20px,1.8vw,28px);transition:border-color .25s,background .25s}
.pm-link-card:hover{border-color:var(--acc);background:rgba(124,134,255,.06)}
.pm-link-card h3{font-size:clamp(18px,1.3vw,22px);font-weight:400;margin:0 0 8px;color:var(--t1)}
.pm-link-card p{color:var(--t2);font-size:15px;line-height:1.55;margin:0}
.pm-link-more{display:inline-flex;align-items:center;gap:8px;font-size:14px;color:var(--acc)}
@media (max-width:1100px){
  .pm-chain{grid-template-columns:repeat(2,minmax(0,1fr))}
  .f-check-in,.pm-scen-grid{grid-template-columns:minmax(0,1fr)}
  .pm-links-grid{grid-template-columns:repeat(2,minmax(0,1fr))}
}
@media (max-width:760px){
  .pm-chain,.pm-links-grid{grid-template-columns:minmax(0,1fr)}
  .d-table.pm-vs3 th,.d-table.pm-vs3 td{width:auto!important}
  .d-table.pm-vs3 td:nth-child(3){border-left:0;border-top:1px solid rgba(124,134,255,.28)}
}
@media (max-width:600px){
  .f-check-in{padding:24px 20px}
  .f-check-list label{padding:15px 2px;gap:14px}
}
</style>
<script type="application/ld+json">{"@context":"https://schema.org","@graph":[{"@type":"BreadcrumbList","itemListElement":[{"@type":"ListItem","position":1,"name":"Главная","item":"https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/"},{"@type":"ListItem","position":2,"name":"Материалы","item":"https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/materialy/"},{"@type":"ListItem","position":3,"name":"Пест-менеджмент или разовая обработка","item":"https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/materialy/pest-menedzhment-ili-razovaya-obrabotka/"}]},{"@type":"TechArticle","headline":"Пест-менеджмент или разовая обработка на предприятии: в чём разница и что выбрать","description":"Сравнение системного пест-менеджмента по методу IPM и разовой дезинсекции или дератизации для юридических лиц по СанПиН 3.3686-21 и ХАССП.","mainEntityOfPage":"https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/materialy/pest-menedzhment-ili-razovaya-obrabotka/","publisher":{"@type":"Organization","name":"ПЕСТКОНТРОЛЬ Центр","url":"https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/","telephone":"+7-495-104-35-70","areaServed":["Москва","Московская область"]}},{"@type":"FAQPage","mainEntity":[{"@type":"Question","name":"Чем пест-менеджмент отличается от пест-контроля?","acceptedAnswer":{"@type":"Answer","text":"Пест-контроль — общее название мер по сдерживанию численности вредителей. Пест-менеджмент делает акцент на управлении пест-риском как системой: обследовании, оценке опасности по зонам, мониторинге точек контроля, анализе трендов, прогнозе численности и ведении документации для проверок."}},{"@type":"Question","name":"Чем постоянный пест-контроль отличается от разовой обработки?","acceptedAnswer":{"@type":"Answer","text":"Разовая обработка уничтожает только тех особей, которые попали под препарат в день выезда. Постоянный пест-контроль по системе IPM закрывает пути проникновения вредителей, поддерживает контуры пронумерованных точек контроля, отслеживает динамику и применяет химию только по показаниям."}},{"@type":"Question","name":"Что такое IPM в пест-контроле простыми словами?","acceptedAnswer":{"@type":"Answer","text":"IPM (Integrated Pest Management) — интегрированный пест-менеджмент, при котором основу защиты составляют инженерные барьеры, санитария и регулярный мониторинг ловушек, а пестициды применяются точечно только при превышении порогового уровня численности."}},{"@type":"Question","name":"Как часто по закону нужно проводить обследования на предприятии?","acceptedAnswer":{"@type":"Answer","text":"По пп. 98, 101 и 110 СанПиН 3.3686-21 на объектах особого эпидемиологического значения (пищевые производства, общепит, продуктовые магазины, продовольственные склады, гостиницы) обследования на насекомых проводятся не реже 2 раз в месяц, а дератизация — по результатам ежемесячной оценки."}}]}]}</script>
<style id="m-crumbs">/* крошки на телефоне не показываем: для SEO хватает BreadcrumbList и ссылок в HTML */@media (max-width:900px){.d-crumbs,.f-crumbs{display:none!important}}</style>
<style id="t-inset">/* таблицы: текст не прижимается к краю — отступ первой и последней колонки */@media (min-width:901px){.d-table tr>:first-child{padding-left:clamp(16px,1.5vw,24px)}.d-table tr>:last-child{padding-right:clamp(16px,1.5vw,24px)}}</style>
<style id="srch-st">/* лупа поиска в шапке и раскладка шапки с ней (tools/menu/apply_menu.py) */.srch-btn{flex:none;width:44px;height:44px;padding:0;border-radius:50%;display:grid;place-items:center;background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.1);color:#fff;cursor:pointer;transition:color .25s,border-color .3s,background .3s,transform .35s cubic-bezier(.16,1,.3,1)}.srch-btn:hover{border-color:#7c86ff;background:rgba(97,95,255,.2);transform:translateY(-2px)}.srch-btn:focus-visible{outline:2px solid #7c86ff;outline-offset:2px}.srch-btn svg{width:18px;height:18px;display:block}@media (min-width:761px){.hdr .wrap{gap:16px}.hdr .msg{display:none}.srch-btn{width:38px;height:38px;background:none;border-color:transparent;color:var(--t2);margin-right:calc(4px - clamp(14px,2vw,40px))}.srch-btn svg{width:20px;height:20px}.srch-btn:hover{color:#fff;background:rgba(255,255,255,.07);border-color:rgba(255,255,255,.1);transform:none}}@media (min-width:761px) and (max-width:1440px){.hdr-right{gap:18px}.srch-btn{margin-right:-14px}}@media (min-width:761px) and (max-width:1000px){.hdr-right{gap:12px}.srch-btn{margin-right:-8px}}@media (max-width:900px){.logo-txt{display:flex;flex-direction:column;align-items:flex-start}.logo-sub{margin:0}}@media (max-width:760px){.hdr .wrap{gap:12px}.hdr-right{gap:8px}}@media (max-width:400px){.hdr .wrap{gap:10px}.srch-btn{width:40px;height:40px}}@media (max-width:360px){.hdr .wrap{gap:8px}.hdr-right{gap:6px}.srch-btn,.phone i,.burger{width:38px;height:38px}}@media (max-width:340px){.logo-mark{display:none}.logo-sub{display:block}}</style><script id="srch-js">/* поиск по сайту: движок и индекс загружаются по первому нажатию на лупу или «/» (tools/search) */(function(r,v){var d=document,ld=0,w=null;function go(o){if(window.PCSearch)return window.PCSearch.open(r,v,o);w=o;if(ld)return;ld=1;var s=d.createElement("script");s.src=r+"search.min.js?v="+v;s.async=true;s.onload=function(){window.PCSearch&&window.PCSearch.open(r,v,w)};s.onerror=function(){ld=0};d.head.appendChild(s)}d.addEventListener("click",function(e){var b=e.target.closest&&e.target.closest("[data-srch]");if(b){e.preventDefault();go({btn:b})}});d.addEventListener("keydown",function(e){if(e.key!=="/"||e.ctrlKey||e.metaKey||e.altKey)return;var t=e.target,n=t&&t.tagName;if(n==="INPUT"||n==="TEXTAREA"||n==="SELECT"||t.isContentEditable)return;e.preventDefault();go({})});if(/^#q\d+$/.test(location.hash)){var c=0,t=setInterval(function(){var b=d.getElementById(location.hash.slice(1));if(b&&d.documentElement.classList.contains("anim-ready")){clearInterval(t);if(b.getAttribute("aria-expanded")==="false")b.click()}else if(++c>60)clearInterval(t)},150)}})("../../","20261108");</script>
<style data-fx>
/* подсветка рамки карточек за курсором — как у .card на главной (tools/site/fx.py) */
:where(.d-card,.p-sec,.p-fcard,.p-duty-box,.p-dl-card,.pm-step-card,.pm-scen,.pm-link-card,.k-err,.w-sample,.d-doc-prev){position:relative}
:where(.d-card,.p-sec,.p-fcard,.p-duty-box,.p-dl-card,.pm-step-card,.pm-scen,.pm-link-card,.k-err,.w-sample,.d-doc-prev)::after{content:"";position:absolute;inset:0;border-radius:inherit;padding:1.4px;pointer-events:none;background:radial-gradient(360px circle at var(--mx,-999px) var(--my,-999px),rgba(124,134,255,.85),rgba(124,134,255,.15) 35%,transparent 60%);-webkit-mask:linear-gradient(#000 0 0) content-box,linear-gradient(#000 0 0);-webkit-mask-composite:xor;mask:linear-gradient(#000 0 0) content-box,linear-gradient(#000 0 0);mask-composite:exclude;opacity:0;transition:opacity .4s;z-index:2}
@media (hover:hover) and (pointer:fine){:where(.d-card,.p-sec,.p-fcard,.p-duty-box,.p-dl-card,.pm-step-card,.pm-scen,.pm-link-card,.k-err,.w-sample,.d-doc-prev):hover::after{opacity:1}}
/* «фонарь» на фото первого экрана — как на главной (tools/site/fx.py) */
.fx-lit{position:absolute;inset:0;opacity:0;pointer-events:none;-webkit-mask-image:radial-gradient(circle var(--sr,320px) at var(--sx,72%) var(--sy,46%),#000 0%,rgba(0,0,0,.55) 45%,transparent 72%);mask-image:radial-gradient(circle var(--sr,320px) at var(--sx,72%) var(--sy,46%),#000 0%,rgba(0,0,0,.55) 45%,transparent 72%);transition:opacity 1.8s cubic-bezier(.16,1,.3,1)}
#hero :is(.d-hero-media,.hero-media)>picture>img{transition:filter 1.8s cubic-bezier(.16,1,.3,1)}
#hero.fx-lit-on :is(.d-hero-media,.hero-media)>picture>img{filter:grayscale(.3) brightness(.56)}
#hero.fx-lit-on .fx-lit img{filter:brightness(1.08) contrast(1.06) saturate(1.06)}
#hero.fx-lit-on .fx-lit{opacity:1}
</style>
<style id="hero-fold">/* кнопки первого экрана видны целиком на любом экране (tools/site/hero_fold.py) */@media (max-width:760px){#hero.hero:not(.f-hero) .hero-copy{display:flex;flex-direction:column}#hero.hero:not(.f-hero) .hero-copy>*{order:6}#hero.hero:not(.f-hero) .hero-copy>.badge{order:1;align-self:flex-start}#hero.hero:not(.f-hero) .hero-copy>h1{order:2;margin-bottom:0}#hero.hero:not(.f-hero) .hero-copy>.hero-ctas{order:3;margin-top:22px}#hero.hero:not(.f-hero) .hero-copy>.lead{order:4;margin-top:24px}}@media (max-width:760px) and (max-height:620px){#hero.hero:not(.f-hero){padding-top:92px}#hero.hero:not(.f-hero) h1{margin-top:18px}}@media (max-width:900px){#hero.f-hero .hero-copy{display:flex;flex-direction:column}#hero.f-hero .hero-copy>*{order:6}#hero.f-hero .hero-copy>.f-crumbs{order:0}#hero.f-hero .hero-copy>.badge{order:1;align-self:flex-start}#hero.f-hero .hero-copy>h1{order:2;margin-bottom:0}#hero.f-hero .hero-copy>.hero-ctas{order:3;margin-top:22px}#hero.f-hero .hero-copy>.lead{order:4;margin-top:24px}#hero.f-hero .hero-media{aspect-ratio:auto;height:clamp(104px,calc(100vh - 440px),56.25vw);height:clamp(104px,calc(100svh - 440px),56.25vw)}}@media (max-width:760px){#hero.f-hero .hero-media{height:clamp(104px,calc(100vh - 440px),75vw);height:clamp(104px,calc(100svh - 440px),75vw)}.rp-page #hero.f-hero .hero-media,.lb-page #hero.f-hero .hero-media{height:clamp(104px,calc(100vh - 480px),75vw);height:clamp(104px,calc(100svh - 480px),75vw)}}@media (max-width:900px) and (max-height:620px){#hero.f-hero .hero-copy>.badge{display:none}#hero.f-hero .hero-media{height:clamp(96px,calc(100vh - 400px),75vw);height:clamp(96px,calc(100svh - 400px),75vw)}.rp-page #hero.f-hero .hero-copy>h1{font-size:clamp(26px,7.6vw,34px)}#hero.f-hero .hero-copy>h1{margin-top:30px}}@media (max-width:860px){#hero.d-hero .d-hero-media{aspect-ratio:auto;height:clamp(104px,calc(100vh - 380px),56.25vw);height:clamp(104px,calc(100svh - 380px),56.25vw)}}@media (max-width:860px) and (max-height:620px){#hero.d-hero{padding-top:84px}#hero.d-hero .d-hero-media{margin-top:14px}#hero.d-hero .d-btns{margin-top:16px}}@media (max-width:860px) and (max-height:520px){#hero.d-hero .d-hero-media{display:none}#hero.d-hero h1{margin-bottom:0}}@media (max-width:900px) and (max-height:520px){#hero.f-hero{padding-top:76px}#hero.f-hero .hero-media{display:none}#hero.f-hero .wrap{margin-top:0}#hero.f-hero .hero-copy>h1{margin-top:0}}@media (max-width:400px){#hero .hero-copy{min-width:0}#hero .hero-ctas .btn{min-width:0;max-width:100%;white-space:normal;padding:0 14px}#hero .hero-ctas .btn-t{white-space:normal;text-align:center}}@media (max-width:860px) and (max-height:620px){#hero.d-hero .d-hero-media{height:clamp(104px,calc(100vh - 410px),56.25vw);height:clamp(104px,calc(100svh - 410px),56.25vw)}}@media (max-height:520px){#hero.p-hero .p-hero-copy>.d-btns{order:3;margin-top:18px}#hero.p-hero .p-hero-copy>.p-def{order:4;margin-top:18px}}@media (max-width:760px) and (max-height:620px){#hero.p-hero .p-hero-copy>.d-btns{order:3;margin-top:18px}#hero.p-hero .p-hero-copy>.p-def{order:4;margin-top:18px}}@media (min-width:761px) and (max-height:520px){#hero.hero:not(.f-hero){padding-top:84px;min-height:0}#hero.hero:not(.f-hero) .hero-copy{display:flex;flex-direction:column}#hero.hero:not(.f-hero) .hero-copy>*{order:6}#hero.hero:not(.f-hero) .hero-copy>.badge{order:1;align-self:flex-start}#hero.hero:not(.f-hero) .hero-copy>h1{order:2;margin:14px 0 0}#hero.hero:not(.f-hero) .hero-copy>.hero-ctas{order:3;margin-top:18px}#hero.hero:not(.f-hero) .hero-copy>.lead{order:4;margin-top:18px}}@media (min-width:861px){#hero.d-hero .d-hero-copy{display:flex;flex-direction:column}#hero.d-hero .d-hero-copy>*{order:6}#hero.d-hero .d-hero-copy>.d-crumbs{order:0}#hero.d-hero .d-hero-copy>.eyebrow{order:1}#hero.d-hero .d-hero-copy>h1{order:2}#hero.d-hero .d-hero-copy>:is(.lead,.sub,.p-def):not(:is(.lead,.sub,.p-def)~*){order:3}#hero.d-hero .d-hero-copy>.d-btns:not(.d-btns~*){order:4}#hero.d-hero .d-hero-copy>.d-ticks{margin-bottom:0}}@media (min-width:901px){#hero.f-hero .hero-copy{display:flex;flex-direction:column}#hero.f-hero .hero-copy>*{order:6}#hero.f-hero .hero-copy>.f-crumbs{order:0}#hero.f-hero .hero-copy>.badge{order:1;align-self:flex-start}#hero.f-hero .hero-copy>h1{order:2}#hero.f-hero .hero-copy>.lead{order:3}#hero.f-hero .hero-copy>.hero-ctas{order:4}#hero.f-hero .hero-copy>.rp-hero-list{margin-top:26px}}@media (min-width:861px) and (max-height:820px){#hero.d-hero{padding-top:calc(clamp(68px,6vw,115px) + 8px)}#hero.d-hero .d-hero-copy>.d-crumbs{margin-bottom:0}#hero.d-hero .d-hero-copy>.eyebrow{margin:16px 0 0}#hero.d-hero .d-hero-copy>h1{margin-top:14px;line-height:1.02}#hero.d-hero .d-hero-copy>:is(.lead,.sub,.p-def){margin-top:16px}#hero.d-hero .d-btns{margin-top:20px}}@media (min-width:901px) and (max-height:820px){#hero.f-hero{padding-top:80px}#hero.f-hero .hero-copy>.f-crumbs{margin-bottom:10px}#hero.f-hero .hero-copy>h1{font-size:min(8.2vh,4.4vw);margin:16px 0 14px}.rp-page #hero.f-hero .hero-copy>h1,.lb-page #hero.f-hero .hero-copy>h1{font-size:min(8vh,3.4vw)}#hero.f-hero .hero-copy>.lead{line-height:1.5}#hero.f-hero .hero-copy>.hero-ctas{margin-top:26px}}@media (min-width:761px) and (max-height:820px){#hero.p-hero h1{font-size:min(8.4vh,4.4vw)}#hero.p-hero .p-hero-copy>.d-btns{margin-top:20px}}@media (min-width:761px) and (max-height:820px){#hero.hero:not(.f-hero) h1{font-size:min(8.4vh,4.4vw);margin:22px 0 18px}#hero.hero:not(.f-hero) .hero-ctas{margin-top:28px}}</style>
<style id="ind-links">.ind-xlist{color:var(--t2);margin:24px 0 0;line-height:1.7;font-size:clamp(14px,.9vw,16px)}.ind-xlist a{color:var(--t1);border-bottom:1px solid var(--line2);transition:color .25s,border-color .25s}.ind-xlist a:hover,.ind-xlist a:focus-visible{color:var(--acc);border-color:var(--acc)}.d-card .ind-x{display:inline-block;margin-top:14px;color:var(--t1);font-weight:500;border-bottom:1px solid var(--line2);transition:color .25s,border-color .25s}.d-card .ind-x:hover,.d-card .ind-x:focus-visible{color:var(--acc);border-color:var(--acc)}</style>
</head>
<body class="d-page">
<a class="skip" href="#main">Перейти к содержанию</a>

<!-- ============ INTRO ============ -->
<div class="intro" id="intro" aria-hidden="true">
  <div class="intro-in">
    <svg class="intro-mark" viewBox="0 0 24 24" fill="none" stroke-width="1" stroke-linejoin="round"><path class="im-shield" pathLength="100" d="M12 2.5l7.5 3v6c0 5-3.2 8.6-7.5 10-4.3-1.4-7.5-5-7.5-10v-6z" stroke="#fff"/><circle class="im-c" pathLength="100" cx="12" cy="11.5" r="2.6" stroke="#7c86ff"/><path class="im-x" pathLength="100" d="M12 6.2v2.7M12 14.1v2.7M6.8 11.5h2.6M14.6 11.5h2.6" stroke="#7c86ff"/></svg>
    <div class="intro-word"><span>ПЕСТКОНТРОЛЬ</span><b>Центр</b></div>
    <div class="intro-bar"><i></i></div>
  </div>
</div>

<div class="progress" aria-hidden="true"><i id="progress"></i></div>
<div class="cursor" aria-hidden="true"><i class="cursor-dot"></i><i class="cursor-ring"></i></div>
<div class="grain" aria-hidden="true"></div>

<header class="hdr" id="hdr">
  <div class="wrap">
    <a href="../../" class="logo" aria-label="ПЕСТКОНТРОЛЬ Центр — на главную">
      <span class="logo-mark"><svg viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="1.6" stroke-linejoin="round" aria-hidden="true"><path d="M12 2.5l7.5 3v6c0 5-3.2 8.6-7.5 10-4.3-1.4-7.5-5-7.5-10v-6z"/><circle cx="12" cy="11.5" r="2.6" stroke="#7c86ff"/><path d="M12 6.2v2.7M12 14.1v2.7M6.8 11.5h2.6M14.6 11.5h2.6" stroke="#7c86ff"/></svg></span>
      <span class="logo-txt"><span class="logo-name">ПЕСТКОНТРОЛЬ</span> <span class="logo-sub">Центр</span></span>
    </a>
    <nav class="nav" aria-label="Основное меню">
      <div class="nav-dd"><button class="nav-dd-btn" type="button" aria-expanded="false" aria-controls="nav-uslugi">Услуги<svg viewBox="0 0 12 12" aria-hidden="true"><path d="M2.5 4.5 6 8l3.5-3.5" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></button><div class="nav-dd-panel" id="nav-uslugi"><a href="../../dezinfektsiya/">Дезинфекция для организаций<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../../deratizatsiya/">Дератизация для организаций<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../../dezinsektsiya/">Дезинсекция для организаций<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../../deratizatsiya-i-dezinsektsiya/">Дератизация и дезинсекция<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../../sanitarnyy-audit/"><span>Санитарный аудит <span class="nw">(СЭС-аудит)</span></span><svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../../laboratornye-issledovaniya/">Лабораторные исследования<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../../razrabotka-ppk/">Разработка ППК<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../../normativnaya-baza/dokumenty-dlya-rospotrebnadzora/">Документы для Роспотребнадзора<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../../ochistka-dezinfektsiya-ventilyatsii/">Очистка и дезинфекция вентиляции<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../../dogovor-deratizatsiya-dezinsektsiya/">Договор на обслуживание<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../../#podhod" class="nav-dd-all"><span>Пест-контроль по системе IPM</span><svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a></div></div><div class="nav-dd"><button class="nav-dd-btn" type="button" aria-expanded="false" aria-controls="nav-otrasli">Отрасли<svg viewBox="0 0 12 12" aria-hidden="true"><path d="M2.5 4.5 6 8l3.5-3.5" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></button><div class="nav-dd-panel" id="nav-otrasli"><a href="../../pishchevoe-proizvodstvo/">Пищевые производства<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../../magaziny-i-torgovye-seti/">Магазины и торговые сети<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../../restorany-i-kafe/">Рестораны и кафе<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../../sklady-i-logistika/">Склады и логистика<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../../farmatsevticheskie-proizvodstva/">Фармацевтические производства<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../../gostinitsy/">Гостиницы и отели<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../../#otrasli" class="nav-dd-all">Все отрасли<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a></div></div><a href="../../dogovor-deratizatsiya-dezinsektsiya/">Договор</a><a href="../../#podhod">Метод IPM</a><a href="../../#usloviya">Цена</a><div class="nav-dd"><button class="nav-dd-btn active" type="button" aria-expanded="false" aria-controls="nav-materialy">Материалы<svg viewBox="0 0 12 12" aria-hidden="true"><path d="M2.5 4.5 6 8l3.5-3.5" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></button><div class="nav-dd-panel" id="nav-materialy"><a href="../../normativnaya-baza/">Нормативная база<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../../normativnaya-baza/dokumenty-dlya-rospotrebnadzora/">Документы для Роспотребнадзора<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../../materialy/programma-pest-kontrolya/"><span>Программа <span class="nw">пест-контроля</span></span><svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../../materialy/zhurnal-pest-kontrolya/"><span>Журнал <span class="nw">пест-контроля</span></span><svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="./" aria-current="page"><span><span class="nw">Пест-менеджмент</span> или разовая обработка</span><svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../../materialy/programma-proizvodstvennogo-kontrolya-haccp/">Программа производственного контроля по ХАССП<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../../materialy/" class="nav-dd-all">Все материалы<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a></div></div>
    </nav>
    <div class="hdr-right">
      <button class="srch-btn" type="button" data-srch aria-label="Поиск по сайту" aria-haspopup="dialog"><svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="11" cy="11" r="7" fill="none" stroke="currentColor" stroke-width="2"/><path d="m20 20-3.6-3.6" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg></button>
      <a class="phone" href="tel:+74951043570" aria-label="Позвонить: +7 (495) 104-35-70"><i><svg viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2" aria-hidden="true"><path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1 1 .4 1.9.7 2.8a2 2 0 0 1-.5 2.1L8 9.9a16 16 0 0 0 6 6l1.3-1.3a2 2 0 0 1 2.1-.4c.9.3 1.8.6 2.8.7a2 2 0 0 1 1.7 2z"/></svg></i><span>+7 (495) 104-35-70</span></a>
      <div class="msg">
        <a href="https://max.ru/u/f9LHodD0cOIlIUXFkt4KMFP88lD8n4TArBiTcV7RI1XML5c4o39QfsDBXUc" class="max" aria-label="Написать в Max" target="_blank" rel="noopener noreferrer"><svg viewBox="0 0 24 24" fill="#fff" aria-hidden="true"><path d="M12 3a9 9 0 0 0-7.7 13.7L3 21l4.4-1.2A9 9 0 1 0 12 3zm-3.6 12.3V8.7h1.6l2 2.8 2-2.8h1.6v6.6h-1.7v-3.9L12 14l-1.9-2.6v3.9z"/></svg></a>
        <a href="https://t.me/Centr_Dezinfection?text=%D0%97%D0%B4%D1%80%D0%B0%D0%B2%D1%81%D1%82%D0%B2%D1%83%D0%B9%D1%82%D0%B5!%20%D0%9F%D0%B8%D1%88%D1%83%20%D1%81%20%D1%81%D0%B0%D0%B9%D1%82%D0%B0%20%D0%BF%D0%B5%D1%81%D1%82%D0%BA%D0%BE%D0%BD%D1%82%D1%80%D0%BE%D0%BB%D1%8C-%D1%86%D0%B5%D0%BD%D1%82%D1%80.%D1%80%D1%84" class="tg" aria-label="Написать в Telegram" target="_blank" rel="noopener noreferrer"><svg viewBox="0 0 24 24" fill="#fff" aria-hidden="true"><path d="M21.4 4.3 2.9 11.4c-1.3.5-1.2 1.2-.2 1.5l4.7 1.5 1.8 5.6c.2.6.4.8.9.8.4 0 .6-.2.9-.4l2.3-2.2 4.7 3.5c.9.5 1.5.2 1.7-.8l3.1-14.6c.3-1.3-.5-1.8-1.4-1.5zM9.6 14.1l8.6-5.4c.4-.3.8-.1.5.2l-7.1 6.4-.3 3.3z"/></svg></a>
      </div>
      <a href="#zayavka" class="btn btn-w btn-sm" data-magnet><span class="btn-t">Бесплатный выезд</span></a>
      <button class="burger" id="burger" aria-label="Открыть меню" aria-expanded="false" aria-controls="mmenu"><span></span></button>
    </div>
  </div>
</header>
<nav class="mmenu" id="mmenu" aria-label="Мобильное меню">
  <div class="mm-group"><button class="mm-toggle" type="button" aria-expanded="false" aria-controls="mm-uslugi">Услуги<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m6 9 6 6 6-6" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/></svg></button><div class="mm-sub" id="mm-uslugi"><div><a href="../../dezinfektsiya/">Дезинфекция для организаций</a><a href="../../deratizatsiya/">Дератизация для организаций</a><a href="../../dezinsektsiya/">Дезинсекция для организаций</a><a href="../../deratizatsiya-i-dezinsektsiya/">Дератизация и дезинсекция</a><a href="../../sanitarnyy-audit/"><span>Санитарный аудит <span class="nw">(СЭС-аудит)</span></span></a><a href="../../laboratornye-issledovaniya/">Лабораторные исследования</a><a href="../../razrabotka-ppk/">Разработка ППК</a><a href="../../normativnaya-baza/dokumenty-dlya-rospotrebnadzora/">Документы для Роспотребнадзора</a><a href="../../ochistka-dezinfektsiya-ventilyatsii/">Очистка и дезинфекция вентиляции</a><a href="../../dogovor-deratizatsiya-dezinsektsiya/">Договор на обслуживание</a><a href="../../#podhod"><span class="nw">Пест-контроль</span> по системе IPM</a></div></div></div><div class="mm-group"><button class="mm-toggle" type="button" aria-expanded="false" aria-controls="mm-otrasli">Отрасли<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m6 9 6 6 6-6" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/></svg></button><div class="mm-sub" id="mm-otrasli"><div><a href="../../pishchevoe-proizvodstvo/">Пищевые производства</a><a href="../../magaziny-i-torgovye-seti/">Магазины и торговые сети</a><a href="../../restorany-i-kafe/">Рестораны и кафе</a><a href="../../sklady-i-logistika/">Склады и логистика</a><a href="../../farmatsevticheskie-proizvodstva/">Фармацевтические производства</a><a href="../../gostinitsy/">Гостиницы и отели</a><a href="../../#otrasli">Все отрасли</a></div></div></div><a href="../../dogovor-deratizatsiya-dezinsektsiya/">Договор <small>на дератизацию и дезинсекцию</small></a><a href="../../#podhod">Метод IPM</a><a href="../../#usloviya">Цена</a><div class="mm-group open" data-open><button class="mm-toggle" type="button" aria-expanded="true" aria-controls="mm-materialy">Материалы<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m6 9 6 6 6-6" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/></svg></button><div class="mm-sub" id="mm-materialy"><div><a href="../../normativnaya-baza/">Нормативная база</a><a href="../../normativnaya-baza/dokumenty-dlya-rospotrebnadzora/">Документы для Роспотребнадзора</a><a href="../../materialy/programma-pest-kontrolya/"><span>Программа <span class="nw">пест-контроля</span></span></a><a href="../../materialy/zhurnal-pest-kontrolya/"><span>Журнал <span class="nw">пест-контроля</span></span></a><a href="./" aria-current="page"><span><span class="nw">Пест-менеджмент</span> или разовая обработка</span></a><a href="../../materialy/programma-proizvodstvennogo-kontrolya-haccp/">Программа производственного контроля по ХАССП</a><a href="../../materialy/">Все материалы</a></div></div></div>
  <a href="#zayavka" class="btn btn-w btn-lg"><span class="btn-t">Заказать бесплатное обследование</span></a>
</nav>

<main id="main" tabindex="-1">
<section class="d-hero" id="hero">
  <div class="wrap">
    <div class="d-hero-copy">
      <nav class="d-crumbs" aria-label="Навигационная цепочка" data-h><a href="../../">Главная</a><span aria-hidden="true">→</span><a href="../../materialy/">Материалы</a><span aria-hidden="true">→</span><span aria-current="page"><span class="nw">Пест-менеджмент</span> или разовая обработка</span></nav>
      <div class="eyebrow">Материалы для бизнеса · Сравнение подходов</div>
      <h1><span class="ln d-ln1"><span><span class="nw">Пест-менеджмент</span></span></span> <span class="ln d-ln2"><span>или разовая</span></span> <span class="ln"><span><em>обработка</em></span></span></h1>
      <div class="d-hero-media"><picture><source media="(max-width:860px)" srcset="../../img/pm-hero-mob.webp" width="1024" height="576"><img class="d-hero-img" src="../../img/pm-hero.webp" width="1920" height="1072" alt="Пест-менеджер и инженер предприятия сверяют схему точек контроля на складе" fetchpriority="high" decoding="async"></picture><div class="fx-lit" aria-hidden="true"><picture><source media="(max-width:860px)" srcset="../../img/pm-hero-mob.webp" width="1024" height="576"><img class="d-hero-img fx-lit-img" src="../../img/pm-hero.webp" width="1920" height="1072" alt="" decoding="async"></picture></div></div>
      <ul class="d-ticks">
        <li data-h>Чем системный <span class="nw">пест-контроль</span> по IPM отличается от дезинсекции и дератизации по вызову</li>
        <li data-h>Почему после разового распыления вредители возвращаются через <span class="nw">2–4 недели</span></li>
        <li data-h>Когда предприятию хватит одного выезда, а когда закон и аудиторы требуют систему</li>
      </ul>
      <p class="sub" data-h>Разовая обработка убирает только тех особей, которые попали под препарат в день выезда. <span class="nw">Пест-менеджмент</span> по системе IPM закрывает пути проникновения вредителей, ведёт учёт по пронумерованным точкам и формирует папку документов для Роспотребнадзора и ХАССП.</p>
      <div class="d-btns" data-h>
        <a href="#zayavka" class="btn btn-w btn-lg" data-magnet><span class="btn-t">Бесплатное обследование</span></a>
        <a href="#sravnenie" class="btn btn-o btn-lg d-tel-btn" data-magnet><span class="btn-t">Таблица сравнения</span></a>
      </div>
    </div>
    <div aria-hidden="true"></div>
  </div>
</section>

<div class="strip" aria-label="Коротко о пест-менеджменте">
  <div class="strip-track" id="stripTrack">
    <div class="strip-set">
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-crosshair" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <circle cx="12" cy="12" r="10" /> <line x1="22" x2="18" y1="12" y2="12" /> <line x1="6" x2="2" y1="12" y2="12" /> <line x1="12" x2="12" y1="6" y2="2" /> <line x1="12" x2="12" y1="22" y2="18" /> </svg><b>IPM</b> вместо разовых обработок</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-activity" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M22 12h-2.48a2 2 0 0 0-1.93 1.46l-2.35 8.36a.25.25 0 0 1-.48 0L9.24 2.18a.25.25 0 0 0-.48 0l-2.35 8.36A2 2 0 0 1 4.49 12H2" /> </svg><b>Мониторинг</b> по пронумерованным точкам</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-lock" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><rect width="18" height="11" x="3" y="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg><b>Пути проникновения</b> закрываем, а не травим</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-ban" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="m4.9 4.9 14.2 14.2"/></svg><b>Химия</b> — по показаниям</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-notebook-pen" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M13.4 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-7.4" /> <path d="M2 6h4" /> <path d="M2 10h4" /> <path d="M2 14h4" /> <path d="M2 18h4" /> <path d="M21.378 5.626a1 1 0 1 0-3.004-3.004l-5.01 5.012a2 2 0 0 0-.506.854l-.837 2.87a.5.5 0 0 0 .62.62l2.87-.837a2 2 0 0 0 .854-.506z" /> </svg><b>Журнал и акты</b> для проверок</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-scan-search" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M3 7V5a2 2 0 0 1 2-2h2" /> <path d="M17 3h2a2 2 0 0 1 2 2v2" /> <path d="M21 17v2a2 2 0 0 1-2 2h-2" /> <path d="M7 21H5a2 2 0 0 1-2-2v-2" /> <circle cx="12" cy="12" r="3" /> <path d="m16 16-1.9-1.9" /> </svg><b>Бесплатное обследование</b> объекта</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-file-badge" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M13 22h5a2 2 0 0 0 2-2V8a2.4 2.4 0 0 0-.706-1.706l-3.588-3.588A2.4 2.4 0 0 0 14 2H6a2 2 0 0 0-2 2v3.3" /> <path d="M14 2v5a1 1 0 0 0 1 1h5" /> <path d="m7.69 16.479 1.29 4.88a.5.5 0 0 1-.698.591l-1.843-.849a1 1 0 0 0-.879.001l-1.846.85a.5.5 0 0 1-.692-.593l1.29-4.88" /> <circle cx="6" cy="14" r="3" /> </svg><b>СанПиН 3.3686-21</b> и ХАССП</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-map-pinned" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M18 8c0 3.613-3.869 7.429-5.393 8.795a1 1 0 01-1.214 0C9.87 15.429 6 11.613 6 8a6 6 0 0112 0" /> <path d="M4.474 15h-.197a1 1 0 00-.969.753l-1.097 4.35a1.5 1.5 0 001.444 1.898L20.344 22a1.5 1.5 0 001.446-1.897l-1.098-4.35a1 1 0 00-.969-.753h-.197" /> <circle cx="12" cy="8" r="2" /> </svg><b>Схема точек</b> на плане объекта</div>
    </div>
    <div class="strip-set" aria-hidden="true">
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-crosshair" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <circle cx="12" cy="12" r="10" /> <line x1="22" x2="18" y1="12" y2="12" /> <line x1="6" x2="2" y1="12" y2="12" /> <line x1="12" x2="12" y1="6" y2="2" /> <line x1="12" x2="12" y1="22" y2="18" /> </svg><b>IPM</b> вместо разовых обработок</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-activity" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M22 12h-2.48a2 2 0 0 0-1.93 1.46l-2.35 8.36a.25.25 0 0 1-.48 0L9.24 2.18a.25.25 0 0 0-.48 0l-2.35 8.36A2 2 0 0 1 4.49 12H2" /> </svg><b>Мониторинг</b> по пронумерованным точкам</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-lock" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><rect width="18" height="11" x="3" y="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg><b>Пути проникновения</b> закрываем, а не травим</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-ban" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="m4.9 4.9 14.2 14.2"/></svg><b>Химия</b> — по показаниям</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-notebook-pen" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M13.4 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-7.4" /> <path d="M2 6h4" /> <path d="M2 10h4" /> <path d="M2 14h4" /> <path d="M2 18h4" /> <path d="M21.378 5.626a1 1 0 1 0-3.004-3.004l-5.01 5.012a2 2 0 0 0-.506.854l-.837 2.87a.5.5 0 0 0 .62.62l2.87-.837a2 2 0 0 0 .854-.506z" /> </svg><b>Журнал и акты</b> для проверок</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-scan-search" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M3 7V5a2 2 0 0 1 2-2h2" /> <path d="M17 3h2a2 2 0 0 1 2 2v2" /> <path d="M21 17v2a2 2 0 0 1-2 2h-2" /> <path d="M7 21H5a2 2 0 0 1-2-2v-2" /> <circle cx="12" cy="12" r="3" /> <path d="m16 16-1.9-1.9" /> </svg><b>Бесплатное обследование</b> объекта</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-file-badge" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M13 22h5a2 2 0 0 0 2-2V8a2.4 2.4 0 0 0-.706-1.706l-3.588-3.588A2.4 2.4 0 0 0 14 2H6a2 2 0 0 0-2 2v3.3" /> <path d="M14 2v5a1 1 0 0 0 1 1h5" /> <path d="m7.69 16.479 1.29 4.88a.5.5 0 0 1-.698.591l-1.843-.849a1 1 0 0 0-.879.001l-1.846.85a.5.5 0 0 1-.692-.593l1.29-4.88" /> <circle cx="6" cy="14" r="3" /> </svg><b>СанПиН 3.3686-21</b> и ХАССП</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-map-pinned" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M18 8c0 3.613-3.869 7.429-5.393 8.795a1 1 0 01-1.214 0C9.87 15.429 6 11.613 6 8a6 6 0 0112 0" /> <path d="M4.474 15h-.197a1 1 0 00-.969.753l-1.097 4.35a1.5 1.5 0 001.444 1.898L20.344 22a1.5 1.5 0 001.446-1.897l-1.098-4.35a1 1 0 00-.969-.753h-.197" /> <circle cx="12" cy="8" r="2" /> </svg><b>Схема точек</b> на плане объекта</div>
    </div>
  </div>
</div>

<section class="f-checks" id="samoproverka" aria-labelledby="chk-t">
  <div class="wrap">
    <div class="panel f-check" data-fade>
      <div class="panel-scan" aria-hidden="true"></div>
      <div class="f-check-in">
        <div class="f-check-l">
          <div class="eyebrow" data-eyebrow>Быстрый тест объекта</div>
          <h2 id="chk-t" class="f-check-t" data-split>Хватит ли вашему объекту <em>разовой обработки</em></h2>
          <p class="f-check-res"><b id="chk-n">0</b> из 5 признаков риска</p>
          <p class="f-check-note" id="chk-note" aria-live="polite">Отметьте пункты, которые относятся к вашему предприятию, чтобы понять, закроет ли задачу разовый выезд дезинфектора.</p>
          <a href="#zayavka" class="btn btn-w btn-lg"><span class="btn-t">Рассчитать формат для объекта</span></a>
        </div>
        <ul class="f-check-list">
          <li><label><input type="checkbox"><span>Работаем с продуктами, напитками, сырьём, общепитом, торговлей или размещением гостей (п. 98 <span class="nw">СанПиН 3.3686-21</span>)</span></label></li>
          <li><label><input type="checkbox"><span>Проходим проверки Роспотребнадзора, сертификацию ХАССП / <span class="nw">FSSC 22000</span> или аудиты торговых сетей</span></label></li>
          <li><label><input type="checkbox"><span>Уже вызывали обработку, но через <span class="nw">2–4 недели</span> тараканы, мухи или грызуны появляются снова</span></label></li>
          <li><label><input type="checkbox"><span>Здание соседствует с другими арендаторами, площадкой ТКО или ежедневно принимает паллеты от поставщиков</span></label></li>
          <li><label><input type="checkbox"><span>В цехах, на кухне или складе продукции нельзя распылять химию сплошным методом и раскладывать яды</span></label></li>
        </ul>
      </div>
    </div>
  </div>
</section>

<section class="s" id="terminy">
  <div class="wrap">
    <div class="head">
      <div class="eyebrow" data-eyebrow>Термины без путаницы</div>
      <h2 data-split>Чем <span class="nw">пест-менеджмент</span> отличается от <span class="nw">пест-контроля</span>, <em>IPM и дезинсекции</em></h2>
      <p class="sub" data-fade>В коммерческих предложениях эти понятия часто используют как синонимы. На практике они описывают разные уровни работы — от системы управления рисками до отдельной технической операции.</p>
    </div>
    <div class="pm-chain" data-group="cards">
      <article class="pm-step-card">
        <span class="pm-step-tag">Уровень 1 · Цель</span>
        <h3><span class="nw">Пест-контроль</span></h3>
        <p>Общее название комплекса мер по сдерживанию численности проблемных биологических видов (грызунов, насекомых, птиц) на территории и в зданиях предприятия. Объединяет профилактику, мониторинг и истребительные процедуры.</p>
      </article>
      <article class="pm-step-card">
        <span class="pm-step-tag">Уровень 2 · Управление</span>
        <h3><span class="nw">Пест-менеджмент</span></h3>
        <p>Системное управление <span class="nw">пест-риском</span> под руководством профильного специалиста (<span class="nw">пест-менеджера</span>): обследование, оценка <span class="nw">пест-опасности</span> по зонам, программа, схема точек, анализ статистики, прогноз численности и отчётность.</p>
      </article>
      <article class="pm-step-card">
        <span class="pm-step-tag">Уровень 3 · Метод</span>
        <h3>Система IPM</h3>
        <p>Интегрированный подход (Integrated Pest Management): сначала перекрываем пути захода вредителей, налаживаем санитарию и ставим ловушки-мониторы. Пестициды применяем только точечно при превышении порогового уровня.</p>
      </article>
      <article class="pm-step-card">
        <span class="pm-step-tag">Уровень 4 · Инструмент</span>
        <h3>Дератизация и дезинсекция</h3>
        <p>Исполнительные операции по уничтожению грызунов и насекомых. В системе IPM они работают по данным мониторинга, а при разовом заказе проводятся изолированно — без программы, учёта и устранения причин.</p>
      </article>
    </div>
    <div class="pm-callout" data-fade>
      <b>Как это связано с ХАССП:</b> ХАССП (HACCP) — это система безопасности пищевой продукции в целом, а не название обработки. Программа <span class="nw">пест-контроля</span>, выстроенная по методу IPM, входит в обязательные базовые программы предварительных условий (ПОПМ / PRP), на которых держатся ХАССП, <span class="nw">ISO 22000</span> и <span class="nw">FSSC 22000</span> (раздел 12 <span class="nw">ГОСТ Р 54762-2011</span>).
    </div>
  </div>
</section>

<section class="s" id="sravnenie">
  <div class="wrap">
    <div class="head">
      <div class="eyebrow" data-eyebrow>Детальное сравнение</div>
      <h2 data-split><span class="nw">Пест-менеджмент</span> по системе IPM и разовая обработка: <em>8 отличий</em></h2>
      <p class="sub" data-fade>Главное различие — в объекте работы: разовая обработка борется со следствием (видимыми особями), а <span class="nw">пест-менеджмент</span> управляет причинами захода и документально подтверждает защиту предприятия.</p>
    </div>
    <table class="d-table pm-vs3" data-fade>
      <thead>
        <tr>
          <th scope="col">Критерий</th>
          <th scope="col">Разовая обработка (по вызову)</th>
          <th scope="col"><span class="nw">Пест-менеджмент</span> по системе IPM (по договору)</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td data-l="Критерий">1. Момент вмешательства</td>
          <td data-l="Разовая обработка">Реактивно: бригаду вызывают, когда вредителей уже заметил персонал, клиент или инспектор</td>
          <td data-l="Пест-менеджмент (IPM)">Превентивно: плановые осмотры перехватывают единичных особей на периметре до появления очага</td>
        </tr>
        <tr>
          <td data-l="Критерий">2. Главная задача</td>
          <td data-l="Разовая обработка">Нанести инсектицид или разложить приманку на доступной площади за один выезд</td>
          <td data-l="Пест-менеджмент (IPM)">Выявить пути проникновения, проверить пронумерованные точки контроля и удержать численность ниже порога</td>
        </tr>
        <tr>
          <td data-l="Критерий">3. Инженерная защита</td>
          <td data-l="Разовая обработка">Не входит в вызов или ограничивается устным комментарием мастера</td>
          <td data-l="Пест-менеджмент (IPM)">Письменные рекомендации с фото для техслужбы: какие щели, ворота, сетки и вводы труб нужно герметизировать</td>
        </tr>
        <tr>
          <td data-l="Критерий">4. Применение химии</td>
          <td data-l="Разовая обработка">Сплошное распыление, туман или открытая раскладка приманок по помещениям</td>
          <td data-l="Пест-менеджмент (IPM)">Химия — только по данным мониторинга. В цехах и на складах продукции работают ловушки без токсичных приманок</td>
        </tr>
        <tr>
          <td data-l="Критерий">5. Кто ведёт объект</td>
          <td data-l="Разовая обработка">Выездной дезинфектор по разовому наряду</td>
          <td data-l="Пест-менеджмент (IPM)">Закреплённый <span class="nw">пест-менеджер</span> (оценка <span class="nw">пест-риска</span>, программа, аналитика) и техники по чек-листу объекта</td>
        </tr>
        <tr>
          <td data-l="Критерий">6. Учёт и прогноз</td>
          <td data-l="Разовая обработка">После отъезда никто не отслеживает выжившие кладки и новый занос с поставками</td>
          <td data-l="Пест-менеджмент (IPM)">Учёт по каждой точке контроля, анализ сезонных трендов и расчёт прогноза численности вредителей</td>
        </tr>
        <tr>
          <td data-l="Критерий">7. Папка документов</td>
          <td data-l="Разовая обработка">Только разовый акт выполненных работ и бухгалтерский счёт</td>
          <td data-l="Пест-менеджмент (IPM)">Договор, лицензия, программа <span class="nw">пест-контроля</span>, оценка <span class="nw">пест-риска</span>, план-схема точек, журнал, акты, СГР и ежемесячные отчёты</td>
        </tr>
        <tr>
          <td data-l="Критерий">8. Выезд при инциденте</td>
          <td data-l="Разовая обработка">Новый платный заказ, согласование сметы и ожидание свободной бригады</td>
          <td data-l="Пест-менеджмент (IPM)">Внеплановый выезд специалиста в течение 3 часов по условиям действующего договора</td>
        </tr>
      </tbody>
    </table>
  </div>
</section>

<section class="s" id="stsenarii">
  <div class="wrap">
    <div class="head">
      <div class="eyebrow" data-eyebrow>Динамика за 90 дней</div>
      <h2 data-split>Почему разовая обработка даёт эффект <em>только на <span class="nw">2–3 недели</span></em></h2>
      <p class="sub" data-fade>На коммерческом объекте вредители постоянно поступают извне — с прилегающей территории, из общих коммуникаций и с паллетами поставщиков. Сравните, как развивается ситуация за один квартал.</p>
    </div>
    <div class="pm-scen-grid" data-group="cards">
      <article class="pm-scen pm-scen-bad">
        <span class="pm-scen-lbl">Сценарий А · Вызовы по факту</span>
        <h3>Только разовые обработки</h3>
        <ol class="pm-tl">
          <li>
            <span class="pm-tl-time">День 1</span>
            <b>Распыление препарата или раскладка приманок</b>
            <span>Взрослые насекомые или часть грызунов, попавшие под обработку, погибают. Видимая активность временно стихает.</span>
          </li>
          <li>
            <span class="pm-tl-time">Неделя 2–3</span>
            <b>Выход молодняка и новый занос</b>
            <span>Из защищённых оотек (капсул с яйцами тараканов) выходят нимфы, а препарат уже смыт влажными уборками. Через открытые рампы и щели заходят новые мыши.</span>
          </li>
          <li>
            <span class="pm-tl-time">Месяц 2</span>
            <b>Восстановление популяции и привыкание</b>
            <span>Численность возвращается к прежнему уровню. Повторное применение той же группы инсектицидов формирует резистентность, цех снова приходится останавливать.</span>
          </li>
          <li>
            <span class="pm-tl-time">Месяц 3 · Проверка</span>
            <b>Замечание Роспотребнадзора или аудитора сети</b>
            <span>На руках <span class="nw">1–2 разрозненных</span> акта. Нет ни программы <span class="nw">пест-контроля</span>, ни схемы пронумерованных точек, ни ежемесячной оценки по <span class="nw">СанПиН 3.3686-21</span>.</span>
          </li>
        </ol>
      </article>
      <article class="pm-scen pm-scen-ipm">
        <span class="pm-scen-lbl">Сценарий Б · Система IPM</span>
        <h3>Постоянный <span class="nw">пест-менеджмент</span> по договору</h3>
        <ol class="pm-tl">
          <li>
            <span class="pm-tl-time">День 1</span>
            <b>Обследование, оценка риска и установка контуров</b>
            <span><span class="nw">Пест-менеджер</span> находит пути захода, при наличии очага проводит первичную обработку, расставляет и нумерует станции контроля, заводит схему и журнал.</span>
          </li>
          <li>
            <span class="pm-tl-time">Неделя 2–3</span>
            <b>Герметизация и перехват на периметре</b>
            <span>Техслужба по фотоотчёту закрывает щели и ставит щёточные уплотнители. На плановом визите специалист проверяет ловушки и отсекает единичный занос у ворот и рамп.</span>
          </li>
          <li>
            <span class="pm-tl-time">Месяц 2</span>
            <b>Анализ трендов и сезонный прогноз</b>
            <span>По статистике точек контроля специалист видит уязвимые зоны, чередует действующие вещества во внешнем контуре и усиливает защиту перед сезонной миграцией.</span>
          </li>
          <li>
            <span class="pm-tl-time">Месяц 3 · Проверка</span>
            <b>Готовая папка и чистый обход инспектора</b>
            <span>Производство работает без внеплановых остановок. Станции на местах совпадают с план-схемой, в папке — непрерывный журнал, акты, СГР и ежемесячные отчёты.</span>
          </li>
        </ol>
      </article>
    </div>
  </div>
</section>

<section class="s" id="vybor">
  <div class="wrap">
    <div class="head">
      <div class="eyebrow" data-eyebrow>Правило выбора</div>
      <h2 data-split>Когда достаточно разового выезда, а когда <em>нужна система</em></h2>
    </div>
    <div class="d-cols2" data-group="cards">
      <article class="d-card pm-choice-card">
        <h3>Когда подходит разовая обработка</h3>
        <ul class="d-ticks">
          <li><b>Закрытые непищевые помещения с единичным заносом:</b> офис, архив или склад стройматериалов, куда насекомые попали однократно с мебелью или возвратной тарой.</li>
          <li><b>Подготовка пустующего объекта:</b> разовая дезинсекция или дератизация после ремонта, перед въездом арендатора или перед консервацией здания.</li>
          <li><b>Экстренный старт («нулевой визит»):</b> подавление острого очага в первые сутки перед установкой точек мониторинга и переходом на плановый договор.</li>
        </ul>
      </article>
      <article class="d-card pm-choice-card pm-choice-ipm">
        <h3>Когда обязателен постоянный <span class="nw">пест-менеджмент</span></h3>
        <ul class="d-ticks">
          <li><b>По закону (п. 98 <span class="nw">СанПиН 3.3686-21</span>):</b> пищевые производства, рестораны, кафе, столовые, продуктовые магазины, продовольственные склады и гостиницы.</li>
          <li><b>По стандартам ХАССП, <span class="nw">ISO 22000</span>, <span class="nw">FSSC 22000</span>, IFS, GMP:</b> где требуются программа <span class="nw">пест-контроля</span>, карта точек, запрет ядов в цехах и анализ трендов.</li>
          <li><b>По конструктиву здания:</b> склады с ежедневной отгрузкой фур, первые этажи ТЦ и БЦ с общими подвалами и объекты рядом с площадками ТКО.</li>
        </ul>
      </article>
    </div>
  </div>
</section>

<section class="s" id="normativy">
  <div class="wrap">
    <div class="head">
      <div class="eyebrow" data-eyebrow>Нормативные требования</div>
      <h2 data-split>Почему на проверке недостаточно показать <em>акты разовых обработок</em></h2>
      <p class="sub" data-fade>Инспектор Роспотребнадзора и аудитор торговой сети проверяют не факт распыления препарата в прошлом месяце, а непрерывность обследований и управляемость объекта.</p>
    </div>
    <div class="d-cards f-req" data-group="cards">
      <article class="d-card">
        <p class="f-num">2 раза в месяц</p>
        <p>Минимальная кратность плановых обследований на заселённость насекомыми для пищевых, торговых, складских и гостиничных объектов (п. 101 <span class="nw">СанПиН 3.3686-21</span>); для прочих объектов — не реже 1 раза в месяц.</p>
      </article>
      <article class="d-card">
        <p class="f-num">Каждый месяц</p>
        <p>Дератизация на объектах особого эпидемиологического значения проводится по результатам ежемесячной оценки заселённости (п. 110 <span class="nw">СанПиН 3.3686-21</span>, <span class="nw">МР 2.1.0247-21</span>), а не по разовым заявкам.</p>
      </article>
      <article class="d-card">
        <p class="f-num">Лицензия РПН</p>
        <p>С 1 марта 2025 года (<span class="nw">ФЗ № 99-ФЗ</span>) работы по дезинсекции и дератизации законны только при наличии лицензии. Выполняем работы по лицензии <span class="nw">№ Л064-00111-77/01942445</span>.</p>
      </article>
    </div>
    <table class="d-table d-vs" style="margin-top:24px" data-fade>
      <thead>
        <tr>
          <th scope="col">При проверке с разовыми актами</th>
          <th scope="col">При договоре <span class="nw">пест-менеджмента</span> ПЕСТКОНТРОЛЬ Центра</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td data-l="Разовые акты">Разрывы между вызовами нарушают кратность обследований по пп. 101 и 110 <span class="nw">СанПиН 3.3686-21</span></td>
          <td data-l="Договор IPM">График визитов закреплён в договоре, каждый осмотр подтверждён записью в журнале и актом</td>
        </tr>
        <tr>
          <td data-l="Разовые акты">Нет программы <span class="nw">пест-контроля</span>, оценки риска и схемы точек по разделу 12 <span class="nw">ГОСТ Р 54762-2011</span></td>
          <td data-l="Договор IPM">Утверждённая программа, оценка <span class="nw">пест-риска</span> по зонам и план-схема с пронумерованными станциями</td>
        </tr>
        <tr>
          <td data-l="Разовые акты">В цехах или на складе находят открытые приманки без маркировки и СГР</td>
          <td data-l="Договор IPM">Закрытые станции с инвентарными номерами, ловушки без яда внутри цехов и полный комплект СГР</td>
        </tr>
        <tr>
          <td data-l="Разовые акты">Нет данных о динамике численности и выполненных санитарно-технических мерах</td>
          <td data-l="Договор IPM">Ежемесячный отчёт с трендами отлова, прогнозом и фотофиксацией нарушений герметичности</td>
        </tr>
      </tbody>
    </table>
  </div>
</section>

<section class="s" id="stoimost">
  <div class="wrap">
    <div class="head">
      <div class="eyebrow" data-eyebrow>Стоимость и условия</div>
      <h2 data-split>Сколько стоит системный <span class="nw">пест-менеджмент</span> <em>по договору</em></h2>
      <p class="sub" data-fade>Повторные аварийные вызовы с остановкой смены и порчей товара за год обходятся дороже планового абонентского обслуживания. Точную сумму фиксируем в договоре после бесплатного осмотра объекта.</p>
    </div>
    <table class="d-table" data-fade>
      <thead>
        <tr>
          <th scope="col">Объект</th>
          <th scope="col">Что обычно входит в программу</th>
          <th scope="col">Ориентир</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td data-l="Объект">Кафе, ресторан</td>
          <td data-l="Что обычно входит">Грызуны и насекомые: кухня, склад и зона ТКО, <span class="nw">1–2 визита</span> в месяц</td>
          <td data-l="Ориентир">от 3 500 ₽/мес</td>
        </tr>
        <tr>
          <td data-l="Объект">Магазин</td>
          <td data-l="Что обычно входит">Грызуны и насекомые: торговый зал, подсобный склад, приёмка, <span class="nw">1–2 визита</span> в месяц</td>
          <td data-l="Ориентир">от 3 500 ₽/мес</td>
        </tr>
        <tr>
          <td data-l="Объект">Склад до 1 000 м²</td>
          <td data-l="Что обычно входит">Грызуны: внешний периметр, погрузочные ворота и внутренние зоны хранения</td>
          <td data-l="Ориентир">от 4 500 ₽/мес</td>
        </tr>
        <tr>
          <td data-l="Объект">Пищевое производство</td>
          <td data-l="Что обычно входит">Комплекс по зонам ХАССП / <span class="nw">FSSC 22000</span>, ежемесячная оценка и отчёт с трендами</td>
          <td data-l="Ориентир">после выезда</td>
        </tr>
      </tbody>
    </table>
    <div class="d-cols2" data-group="cards">
      <div class="d-card">
        <h3>Входит в ежемесячную оплату</h3>
        <p>Визиты по графику, осмотр и обслуживание точек контроля, родентицидные блоки и клеевые пластины, ведение журнала, акты после каждого выезда и ежемесячный отчёт с прогнозом численности.</p>
      </div>
      <div class="d-card">
        <h3>Сроки и условия договора</h3>
        <p>Бесплатный выезд и оценка <span class="nw">пест-риска</span> — 0 ₽. Проект договора с расчётом — в течение 1 часа после осмотра. От заявки до первого визита или внепланового выезда — от 3 часов. Работаем с НДС и без НДС, по ЭДО.</p>
      </div>
    </div>
    <p class="d-note" data-fade>Подробные условия и PDF-образец договора с приложениями — на странице <a href="../../dogovor-deratizatsiya-dezinsektsiya/" style="color:var(--acc);text-decoration:underline;text-underline-offset:4px">Договор на дератизацию и дезинсекцию</a>.</p>
  </div>
</section>

<section class="s" id="otrasli-i-materialy">
  <div class="wrap">
    <div class="head">
      <div class="eyebrow" data-eyebrow>Отрасли и документы</div>
      <h2 data-split>Как устроен <span class="nw">пест-менеджмент</span> <em>на вашем типе объекта</em></h2>
    </div>
    <div class="pm-links-grid" data-group="cards">
      <a href="../../dogovor-deratizatsiya-dezinsektsiya/" class="pm-link-card">
        <div>
          <h3>Договор на дератизацию и дезинсекцию</h3>
          <p>Что прописываем в договоре, как переходим от прежнего подрядчика без разрыва в журнале и образец договора в PDF.</p>
        </div>
        <span class="pm-link-more">Перейти к договору →</span>
      </a>
      <a href="../../pishchevoe-proizvodstvo/" class="pm-link-card">
        <div>
          <h3><span class="nw">Пест-контроль</span> на пищевом производстве</h3>
          <p>Шесть зон риска завода, четыре правила IPM без ядов в цехах и папка документов для ХАССП, <span class="nw">FSSC 22000</span> и аудитов сетей.</p>
        </div>
        <span class="pm-link-more">Перейти к странице отрасли →</span>
      </a>
      <a href="../../#dokumenty" class="pm-link-card">
        <div>
          <h3>Папка документов для проверок</h3>
          <p>Программа <span class="nw">пест-контроля</span>, схема точек, объектовый журнал учёта, копии СГР и ежемесячные отчёты с рекомендациями.</p>
        </div>
        <span class="pm-link-more">Смотреть состав папки →</span>
      </a>
    </div>
    <p class="ind-xlist" data-fade><span class="nw">Пест-менеджмент</span> на&nbsp;других объектах: <a href="../../restorany-i-kafe/">рестораны и&nbsp;кафе</a>, <a href="../../magaziny-i-torgovye-seti/">магазины и&nbsp;торговые сети</a>, <a href="../../sklady-i-logistika/">склады и&nbsp;логистика</a>, <a href="../../farmatsevticheskie-proizvodstva/">фармацевтические производства</a>, <a href="../../gostinitsy/">гостиницы</a>.</p>
  </div>
</section>


<!-- ============ СМОТРИТЕ ТАКЖЕ (перелинковка) ============ -->
<section class="s s-rel" id="smotrite-takzhe">
  <div class="wrap">
    <div class="head">
      <div class="eyebrow" data-eyebrow>Смотрите также</div>
      <h2 data-split>Связанные услуги <em>и материалы</em></h2>
    </div>
    <div class="rel-grid" data-group="cards">
      <a class="card rel-card" href="../../materialy/programma-pest-kontrolya/"><span class="rel-k">Материал</span><span class="rel-t">Программа <span class="nw">пест-контроля</span></span><span class="rel-d">Образец и шаблон в PDF: 7 разделов, оценка <span class="nw">пест-риска</span> по зонам и план мероприятий.</span><span class="rel-a" aria-hidden="true"><svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></span></a>
      <a class="card rel-card" href="../../materialy/zhurnal-pest-kontrolya/"><span class="rel-k">Материал</span><span class="rel-t">Журнал <span class="nw">пест-контроля</span></span><span class="rel-d">Образец заполнения и шаблон в PDF: 9 разделов на 10 листах — точки контроля, ловушки, предписания.</span><span class="rel-a" aria-hidden="true"><svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></span></a>
      <a class="card rel-card" href="../../deratizatsiya/"><span class="rel-k">Услуга</span><span class="rel-t">Дератизация для организаций</span><span class="rel-d">Три контура защиты от крыс и мышей, контейнеры КИК и ловушки без яда в цехах, схема точек и акты.</span><span class="rel-a" aria-hidden="true"><svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></span></a>
      <a class="card rel-card" href="../../dezinsektsiya/"><span class="rel-k">Услуга</span><span class="rel-t">Дезинсекция для организаций</span><span class="rel-d">Контроль насекомых по IPM без остановки работы, ротация средств, журнал и акты по СанПиН.</span><span class="rel-a" aria-hidden="true"><svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></span></a>
    </div>
  </div>
</section>

<section class="s" id="voprosy">
  <div class="wrap">
    <div class="head">
      <div class="eyebrow" data-eyebrow>Вопросы</div>
      <h2 data-split>Частые вопросы о <span class="nw">пест-менеджменте</span> <em>и разовых обработках</em></h2>
    </div>
    <div class="faq">
      <div class="faq-col" data-group="faq">
        <div class="card qa"><button aria-expanded="false" aria-controls="a1" id="q1">Чем пест‑менеджмент отличается от пест‑контроля?<span class="pm"></span></button><div class="ans" id="a1" role="region" aria-labelledby="q1"><div><p><span class="nw">Пест-контроль</span> — общее название деятельности по сдерживанию численности вредителей (профилактика, мониторинг, дератизация, дезинсекция). <span class="nw">Пест-менеджмент</span> делает акцент на управлении <span class="nw">пест-риском</span> как системой: обследовании объекта, оценке опасности по зонам, постановке точек мониторинга, анализе статистики, прогнозе численности и ведении документации для аудитов.</p></div></div></div>
        <div class="card qa"><button aria-expanded="false" aria-controls="a2" id="q2">Чем постоянный пест‑контроль отличается от разовой обработки?<span class="pm"></span></button><div class="ans" id="a2" role="region" aria-labelledby="q2"><div><p>Разовая обработка направлена на быстрое уничтожение уже размножившихся насекомых или грызунов в день выезда. Постоянный <span class="nw">пест-контроль</span> по договору работает на опережение: объект защищён контурами пронумерованных станций и ловушек, специалист проверяет их по графику, выдаёт рекомендации по герметизации щелей и применяет препараты только там, где мониторинг зафиксировал активность.</p></div></div></div>
        <div class="card qa"><button aria-expanded="false" aria-controls="a3" id="q3">Что такое IPM в пест‑контроле простыми словами?<span class="pm"></span></button><div class="ans" id="a3" role="region" aria-labelledby="q3"><div><p>IPM (Integrated Pest Management, интегрированный <span class="nw">пест-менеджмент</span>) — это подход, при котором сначала убирают причины появления вредителей (перекрывают щели и ворота, налаживают санитарию и хранение), ведут постоянный подсчёт по ловушкам, а химические средства используют точечно и только при превышении допустимого порога численности.</p></div></div></div>
        <div class="card qa"><button aria-expanded="false" aria-controls="a4" id="q4">Что такое оценка пест‑риска и зачем прогнозировать численность вредителей?<span class="pm"></span></button><div class="ans" id="a4" role="region" aria-labelledby="q4"><div><p>Оценка <span class="nw">пест-риска</span> определяет вероятность появления вредителей в каждой зоне предприятия и тяжесть возможного ущерба для сырья, продукции и репутации. Прогноз численности строится по данным регулярных осмотров точек контроля и сезонным факторам: он позволяет усилить внешний барьер до того, как осенняя миграция грызунов или летний выплод насекомых приведут к заражению цеха.</p></div></div></div>
      </div>
      <div class="faq-col" data-group="faq">
        <div class="card qa"><button aria-expanded="false" aria-controls="a5" id="q5">Можно ли начать с разовой обработки, если вредители уже есть на объекте?<span class="pm"></span></button><div class="ans" id="a5" role="region" aria-labelledby="q5"><div><p>Да. Если на складе, кухне или производстве уже есть активный очаг, работа начинается с первичной истребительной обработки. Сразу после неё мы расставляем точки контроля, передаём инженерной службе перечень уязвимых мест и переводим объект на плановый мониторинг, чтобы вредители не вернулись через <span class="nw">2–3 недели</span>.</p></div></div></div>
        <div class="card qa"><button aria-expanded="false" aria-controls="a6" id="q6">Как часто по закону нужно проводить обследования на предприятии?<span class="pm"></span></button><div class="ans" id="a6" role="region" aria-labelledby="q6"><div><p>По пп. 101 и 110 <span class="nw">СанПиН 3.3686-21</span> на объектах особого эпидемиологического значения (пищевые производства, общепит, продуктовые магазины, продовольственные склады, гостиницы) плановые обследования на насекомых проводятся не реже 2 раз в месяц, а дератизационные мероприятия — по результатам ежемесячной оценки. Для остальных коммерческих зданий — не реже 1 раза в месяц.</p></div></div></div>
        <div class="card qa"><button aria-expanded="false" aria-controls="a7" id="q7">Что делать, если вредители появились между плановыми визитами?<span class="pm"></span></button><div class="ans" id="a7" role="region" aria-labelledby="q7"><div><p>Позвоните нам или напишите в Telegram / MAX. По условиям договора специалист приедет на внеплановый выезд в течение 3 часов, обследует зону, выяснит источник заноса, проведёт локальную обработку или уплотнит точки контроля и внесёт запись в журнал.</p></div></div></div>
      </div>
    </div>
  </div>
</section>

<section class="cta" id="zayavka"><div class="cta-bg f-lazy" aria-hidden="true" data-parallax-bg></div><div class="cta-orb" id="orb" aria-hidden="true"></div>
  <div class="wrap">
    <div>
      <div class="eyebrow" data-eyebrow>Бесплатный выезд</div>
      <h2 data-split>Поможем перейти от разовых обработок <em>к системному контролю</em></h2>
      <p class="sub" data-fade>Бесплатно приедем на ваш объект в Москве или Московской области, оценим <span class="nw">пест-риск</span>, покажем причины возврата вредителей и в течение 1 часа после осмотра пришлём проект договора с расчётом.</p>
      <div class="cta-contacts" data-fade>
        <a class="ph" href="tel:+74951043570">+7 (495) 104-35-70</a>
        <div class="msg">
          <a href="https://max.ru/u/f9LHodD0cOIlIUXFkt4KMFP88lD8n4TArBiTcV7RI1XML5c4o39QfsDBXUc" class="max" aria-label="Написать в Max" target="_blank" rel="noopener noreferrer"><svg viewBox="0 0 24 24" fill="#fff" aria-hidden="true"><path d="M12 3a9 9 0 0 0-7.7 13.7L3 21l4.4-1.2A9 9 0 1 0 12 3zm-3.6 12.3V8.7h1.6l2 2.8 2-2.8h1.6v6.6h-1.7v-3.9L12 14l-1.9-2.6v3.9z"/></svg></a>
          <a href="https://t.me/Centr_Dezinfection?text=%D0%97%D0%B4%D1%80%D0%B0%D0%B2%D1%81%D1%82%D0%B2%D1%83%D0%B9%D1%82%D0%B5!%20%D0%9F%D0%B8%D1%88%D1%83%20%D1%81%20%D1%81%D0%B0%D0%B9%D1%82%D0%B0%20%D0%BF%D0%B5%D1%81%D1%82%D0%BA%D0%BE%D0%BD%D1%82%D1%80%D0%BE%D0%BB%D1%8C-%D1%86%D0%B5%D0%BD%D1%82%D1%80.%D1%80%D1%84" class="tg" aria-label="Написать в Telegram" target="_blank" rel="noopener noreferrer"><svg viewBox="0 0 24 24" fill="#fff" aria-hidden="true"><path d="M21.4 4.3 2.9 11.4c-1.3.5-1.2 1.2-.2 1.5l4.7 1.5 1.8 5.6c.2.6.4.8.9.8.4 0 .6-.2.9-.4l2.3-2.2 4.7 3.5c.9.5 1.5.2 1.7-.8l3.1-14.6c.3-1.3-.5-1.8-1.4-1.5zM9.6 14.1l8.6-5.4c.4-.3.8-.1.5.2l-7.1 6.4-.3 3.3z"/></svg></a>
        </div>
      </div>
    </div>
    <form class="form" id="form" novalidate data-form>
      <div class="fbody">
        <h3>Заявка на бесплатное обследование</h3>
        <p class="fs">Заполнение займёт меньше минуты</p>
        <div class="fg">
          <div class="field"><label class="sr-only" for="f-name">Ваше имя</label><input id="f-name" name="name" placeholder="Ваше имя *" required autocomplete="name"><small class="ferr">Укажите имя</small></div>
          <div class="field"><label class="sr-only" for="phone">Телефон</label><input name="phone" id="phone" type="tel" inputmode="tel" placeholder="+7 (___) ___-__-__ *" required autocomplete="tel"><small class="ferr">Укажите телефон полностью</small></div>
          <div class="field full"><label class="sr-only" for="f-type">Тип объекта</label><select id="f-type" name="type" required><option value="" disabled selected>Тип объекта *</option><option>Пищевое производство</option><option>Магазин или торговая сеть</option><option>Ресторан или кафе</option><option>Склад, логистика</option><option>Фармацевтическое производство</option><option>Гостиница</option><option>Другое</option></select><small class="ferr">Выберите тип объекта</small></div>
          <div class="field full"><label class="sr-only" for="f-address">Адрес или район объекта</label><input id="f-address" name="address" placeholder="Адрес или район объекта" autocomplete="street-address" maxlength="200"></div>
          <div class="field full"><label class="sr-only" for="f-service">Текущая ситуация</label><select id="f-service" name="service"><option value="" selected>Текущая ситуация на объекте</option><option>Вызываем разово — вредители возвращаются</option><option>Нужен договор и документы для проверки РПН / ХАССП</option><option>Есть активный очаг — нужен срочный выезд и программа</option><option>Меняем подрядчика по пест-контролю</option></select></div>
          <div class="field" hidden><input type="hidden" name="email" value=""></div>
          <input type="hidden" name="msg" value="">
        </div>
        <button type="submit" class="btn btn-w btn-lg" id="submitBtn"><span class="btn-t">Заказать бесплатное обследование</span><svg class="btn-ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M5 12h14M13 6l6 6-6 6"/></svg><i class="spin" aria-hidden="true"></i></button>
        <p class="legal">Нажимая кнопку, вы даёте <a href="../../soglasie/" target="_blank" rel="noopener">согласие на обработку персональных данных</a> и подтверждаете, что ознакомились с <a href="../../privacy/" target="_blank" rel="noopener">политикой конфиденциальности</a>.</p>
      </div>
      <div class="ok" role="status" aria-live="polite">
        <svg class="ok-ic" viewBox="0 0 52 52" aria-hidden="true"><circle cx="26" cy="26" r="24" fill="none"/><path fill="none" d="M15 27l7 7 15-16"/></svg>
        <h3>Заявка отправлена</h3><p>Перезвоним в ближайшее рабочее время, чтобы согласовать день выезда.</p>
      </div>
    </form>
  </div>
</section>
</main>

<footer>
  <div class="wrap">
    <div class="ft">
      <div>
        <a href="../../" class="logo" aria-label="ПЕСТКОНТРОЛЬ Центр — на главную"><span class="logo-mark"><svg viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="1.6" stroke-linejoin="round" aria-hidden="true"><path d="M12 2.5l7.5 3v6c0 5-3.2 8.6-7.5 10-4.3-1.4-7.5-5-7.5-10v-6z"/><circle cx="12" cy="11.5" r="2.6" stroke="#7c86ff"/><path d="M12 6.2v2.7M12 14.1v2.7M6.8 11.5h2.6M14.6 11.5h2.6" stroke="#7c86ff"/></svg></span><span class="logo-txt"><span class="logo-name">ПЕСТКОНТРОЛЬ</span> <span class="logo-sub">Центр</span></span></a>
        <p class="d"><span class="nw">Пест-контроль</span> и <span class="nw">пест-менеджмент</span> по системе IPM для бизнеса в Москве и Московской области: бесплатный аудит, оценка <span class="nw">пест-риска</span>, мониторинг вредителей и отчётность.</p>
      </div>
      <div><h4>Услуги</h4><ul><li><a href="../../dezinfektsiya/">Дезинфекция для организаций</a></li><li><a href="../../deratizatsiya/">Дератизация для организаций</a></li><li><a href="../../dezinsektsiya/">Дезинсекция для организаций</a></li><li><a href="../../deratizatsiya-i-dezinsektsiya/">Дератизация и дезинсекция</a></li><li><a href="../../sanitarnyy-audit/"><span>Санитарный аудит <span class="nw">(СЭС-аудит)</span></span></a></li><li><a href="../../laboratornye-issledovaniya/">Лабораторные исследования</a></li><li><a href="../../razrabotka-ppk/">Разработка ППК</a></li><li><a href="../../normativnaya-baza/dokumenty-dlya-rospotrebnadzora/">Документы для Роспотребнадзора</a></li><li><a href="../../ochistka-dezinfektsiya-ventilyatsii/">Очистка и дезинфекция вентиляции</a></li><li><a href="../../dogovor-deratizatsiya-dezinsektsiya/">Договор на дератизацию и дезинсекцию</a></li><li><a href="../../#podhod"><span><span class="nw">Пест-контроль</span> по системе IPM</span></a></li><li><a href="../../#etapy">Этапы работы</a></li><li><a href="../../#vrediteli">Вредители</a></li><li><a href="../../#usloviya">Цена</a></li><li><a href="../../#voprosy">Вопросы</a></li></ul></div>
      <div><h4>Отрасли</h4><ul><li><a href="../../pishchevoe-proizvodstvo/">Пищевые производства</a></li><li><a href="../../magaziny-i-torgovye-seti/">Магазины и торговые сети</a></li><li><a href="../../restorany-i-kafe/">Рестораны и кафе</a></li><li><a href="../../sklady-i-logistika/">Склады и логистика</a></li><li><a href="../../farmatsevticheskie-proizvodstva/">Фармацевтические производства</a></li><li><a href="../../gostinitsy/">Гостиницы и отели</a></li></ul></div>
      <div><h4>Материалы</h4><ul><li><a href="../../normativnaya-baza/">Нормативная база</a></li><li><a href="../../normativnaya-baza/proverochnye-listy/">Проверочные листы 2026</a></li><li><a href="../../normativnaya-baza/dokumenty-dlya-rospotrebnadzora/">Документы для Роспотребнадзора</a></li><li><a href="../../materialy/programma-pest-kontrolya/"><span>Программа <span class="nw">пест-контроля</span></span></a></li><li><a href="../../materialy/zhurnal-pest-kontrolya/"><span>Журнал <span class="nw">пест-контроля</span></span></a></li><li><a href="./" aria-current="page"><span><span class="nw">Пест-менеджмент</span> или разовая обработка</span></a></li><li><a href="../../materialy/programma-proizvodstvennogo-kontrolya-haccp/">Программа производственного контроля по ХАССП</a></li><li><a href="../../materialy/">Все материалы</a></li></ul></div>
      <div><h4>Контакты</h4><ul><li><a href="tel:+74951043570">+7 (495) 104-35-70</a></li><li><a href="mailto:b2b@pestcontrol-center.ru">b2b@<wbr><span style="white-space:nowrap">pestcontrol-center.ru</span></a></li><li>Пн–Пт: 8:00–20:00</li><li>Срочные выезды: 24/7</li></ul>
        <div class="msg"><a href="https://max.ru/u/f9LHodD0cOIlIUXFkt4KMFP88lD8n4TArBiTcV7RI1XML5c4o39QfsDBXUc" class="max" aria-label="Написать в Max" target="_blank" rel="noopener noreferrer"><svg viewBox="0 0 24 24" fill="#fff" aria-hidden="true"><path d="M12 3a9 9 0 0 0-7.7 13.7L3 21l4.4-1.2A9 9 0 1 0 12 3zm-3.6 12.3V8.7h1.6l2 2.8 2-2.8h1.6v6.6h-1.7v-3.9L12 14l-1.9-2.6v3.9z"/></svg></a><a href="https://t.me/Centr_Dezinfection?text=%D0%97%D0%B4%D1%80%D0%B0%D0%B2%D1%81%D1%82%D0%B2%D1%83%D0%B9%D1%82%D0%B5!%20%D0%9F%D0%B8%D1%88%D1%83%20%D1%81%20%D1%81%D0%B0%D0%B9%D1%82%D0%B0%20%D0%BF%D0%B5%D1%81%D1%82%D0%BA%D0%BE%D0%BD%D1%82%D1%80%D0%BE%D0%BB%D1%8C-%D1%86%D0%B5%D0%BD%D1%82%D1%80.%D1%80%D1%84" class="tg" aria-label="Написать в Telegram" target="_blank" rel="noopener noreferrer"><svg viewBox="0 0 24 24" fill="#fff" aria-hidden="true"><path d="M21.4 4.3 2.9 11.4c-1.3.5-1.2 1.2-.2 1.5l4.7 1.5 1.8 5.6c.2.6.4.8.9.8.4 0 .6-.2.9-.4l2.3-2.2 4.7 3.5c.9.5 1.5.2 1.7-.8l3.1-14.6c.3-1.3-.5-1.8-1.4-1.5zM9.6 14.1l8.6-5.4c.4-.3.8-.1.5.2l-7.1 6.4-.3 3.3z"/></svg></a></div>
      </div>
    </div>
    <div class="fb"><span>© 2026 ПЕСТКОНТРОЛЬ Центр</span><a href="../../privacy/">Политика конфиденциальности</a><a href="../../soglasie/">Согласие на обработку данных</a><span>Информация на сайте не является публичной офертой</span></div>
  </div>
</footer>

<div class="mbar" id="mbar">
  <a href="tel:+74951043570" class="c1"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1 1 .4 1.9.7 2.8a2 2 0 0 1-.5 2.1L8 9.9a16 16 0 0 0 6 6l1.3-1.3a2 2 0 0 1 2.1-.4c.9.3 1.8.6 2.8.7a2 2 0 0 1 1.7 2z"/></svg>Позвонить</a>
  <a href="#zayavka" class="c2"><span>Обследование</span></a>
</div>
<div class="fab" role="group" aria-label="Написать в мессенджер">
  <a href="https://max.ru/u/f9LHodD0cOIlIUXFkt4KMFP88lD8n4TArBiTcV7RI1XML5c4o39QfsDBXUc" class="max" aria-label="Написать в Max" target="_blank" rel="noopener noreferrer"><svg viewBox="0 0 24 24" fill="#fff" aria-hidden="true"><path d="M12 3a9 9 0 0 0-7.7 13.7L3 21l4.4-1.2A9 9 0 1 0 12 3zm-3.6 12.3V8.7h1.6l2 2.8 2-2.8h1.6v6.6h-1.7v-3.9L12 14l-1.9-2.6v3.9z"/></svg></a>
  <a href="https://t.me/Centr_Dezinfection?text=%D0%97%D0%B4%D1%80%D0%B0%D0%B2%D1%81%D1%82%D0%B2%D1%83%D0%B9%D1%82%D0%B5!%20%D0%9F%D0%B8%D1%88%D1%83%20%D1%81%20%D1%81%D0%B0%D0%B9%D1%82%D0%B0%20%D0%BF%D0%B5%D1%81%D1%82%D0%BA%D0%BE%D0%BD%D1%82%D1%80%D0%BE%D0%BB%D1%8C-%D1%86%D0%B5%D0%BD%D1%82%D1%80.%D1%80%D1%84" class="tg" aria-label="Написать в Telegram" target="_blank" rel="noopener noreferrer"><svg viewBox="0 0 24 24" fill="#fff" aria-hidden="true"><path d="M21.4 4.3 2.9 11.4c-1.3.5-1.2 1.2-.2 1.5l4.7 1.5 1.8 5.6c.2.6.4.8.9.8.4 0 .6-.2.9-.4l2.3-2.2 4.7 3.5c.9.5 1.5.2 1.7-.8l3.1-14.6c.3-1.3-.5-1.8-1.4-1.5zM9.6 14.1l8.6-5.4c.4-.3.8-.1.5.2l-7.1 6.4-.3 3.3z"/></svg></a>
</div>

<script>
/* Предпросмотр: вне рабочего домена заявка не отправляется */
(function(){if(/^(www\.)?xn----itbbsflddbfpfdodg9d0f\.xn--p1ai$/i.test(location.hostname))return;var f=window.fetch;window.fetch=function(u){if(typeof u==='string'&&u.indexOf('send.php')>-1)return new Promise(function(r){setTimeout(function(){r(new Response('{"success":true}',{status:200,headers:{'Content-Type':'application/json'}}))},500)});return f.apply(this,arguments)};document.addEventListener('DOMContentLoaded',function(){var p=document.querySelector('.form .fs');if(p)p.textContent='Предпросмотр: заявка никуда не отправляется'})})();
/* самопроверка: счётчик отмеченных признаков риска */
document.addEventListener('change',function(e){
  if(!e.target.closest('.f-check-list'))return;
  var n=0;
  document.querySelectorAll('.f-check-list input').forEach(function(i){n+=i.checked?1:0});
  document.getElementById('chk-n').textContent=n;
  var res=document.querySelector('.f-check-res');
  res.classList.toggle('warn',n>=1);
  document.getElementById('chk-note').textContent=n===0
    ?'Для закрытого непищевого помещения с единичным заносом может хватить разовой обработки. На бесплатном осмотре подтвердим, нужна ли постоянная схема.'
    :'Отмечено признаков: '+n+'. Разовый выезд даст только временную передышку и не закроет требования проверяющих — такому объекту нужен постоянный пест-менеджмент с точками контроля и журналом.';
});
(function(){var f=document.getElementById('form');if(!f)return;f.addEventListener('submit',function(){var e=f.elements,s=e.service.value||'не выбрано',a=e.address.value.trim()||'не указан';e.msg.value='Ситуация: '+s+'\nАдрес объекта: '+a+'\nСтраница: пест-менеджмент или разовая обработка (/materialy/pest-menedzhment-ili-razovaya-obrabotka/)';});})();
</script>
<script data-fx>
/* Эффекты под курсором, как на главной (tools/site/fx.py) */
(function(){
  var mm=window.matchMedia;if(!mm)return;
  var fine=mm('(hover: hover) and (pointer: fine)').matches;
  /* «фонарь»: следует за мышью, без движения мыши плавно ходит сам; на сенсорных экранах ходит сам (30 кадров в секунду).
     Не считаем, пока первый экран не виден или вкладка скрыта. Старт — вместе со входом первого экрана */
  var hero=document.getElementById('hero'),lit=hero&&hero.querySelector('.fx-lit');
  if(lit&&!mm('(prefers-reduced-motion: reduce)').matches){
    var media=lit.parentNode,small=mm('(max-width:860px)').matches,full=hero.classList.contains('f-hero');
    lit.style.setProperty('--sr',small?'150px':'clamp(240px, 21vw, 400px)');
    var cx=small?.5:(full?.68:.74),ax=small?.24:(full?.16:.13),cy=small?.5:.47,ay=small?.2:.17;
    var sx=cx,sy=cy,tx=cx,ty=cy,last=-1e9,vis=true,on=false,raf=0,lt=0;
    var frame=function(now){
      raf=0;if(!on||!vis||document.hidden)return;
      var dt=now-lt;if(!fine&&dt<30){raf=requestAnimationFrame(frame);return;}
      lt=now;if(now-last>2600){var t=now/1000;tx=cx+ax*Math.sin(t*.33);ty=cy+ay*Math.sin(t*.47+1.3);}
      var k=1-Math.pow(.94,Math.min(dt,100)/16.67);sx+=(tx-sx)*k;sy+=(ty-sy)*k;
      lit.style.setProperty('--sx',(sx*100).toFixed(2)+'%');lit.style.setProperty('--sy',(sy*100).toFixed(2)+'%');
      raf=requestAnimationFrame(frame);
    };
    var kick=function(){if(!raf&&on&&vis&&!document.hidden){lt=performance.now();raf=requestAnimationFrame(frame);}};
    hero.addEventListener('pointermove',function(e){
      if(e.pointerType!=='mouse')return;var r=media.getBoundingClientRect();if(!r.width||!r.height)return;
      tx=(e.clientX-r.left)/r.width;ty=(e.clientY-r.top)/r.height;last=performance.now();kick();
    },{passive:true});
    if('IntersectionObserver' in window)new IntersectionObserver(function(es){vis=es[0].isIntersecting;kick();}).observe(hero);
    document.addEventListener('visibilitychange',kick);
    var start=function(){if(on)return;on=true;hero.classList.add('fx-lit-on');kick();};
    var eb=hero.querySelector('.eyebrow');
    if(eb&&'MutationObserver' in window){
      if(eb.classList.contains('in'))start();
      else{var mo=new MutationObserver(function(){if(eb.classList.contains('in')){mo.disconnect();start();}});mo.observe(eb,{attributes:true,attributeFilter:['class']});}
    }
    setTimeout(start,eb?5000:2500);
  }
  /* подсветка рамки карточек за курсором — как у .card на главной */
  if(fine)document.addEventListener('pointermove',function(e){
    var c=e.target.closest&&e.target.closest('.d-card,.p-sec,.p-fcard,.p-duty-box,.p-dl-card,.pm-step-card,.pm-scen,.pm-link-card,.k-err,.w-sample,.d-doc-prev');if(!c)return;
    var r=c.getBoundingClientRect();c.style.setProperty('--mx',(e.clientX-r.left)+'px');c.style.setProperty('--my',(e.clientY-r.top)+'px');
  },{passive:true});
})();
</script>
<script>
  /* скрипты анимаций подключаются сразу после первой отрисовки: фото и заголовок первого экрана не ждут их загрузки */
  (function (r, l) {
    var go = function () { l.forEach(function (u) { var e = document.createElement('script'); e.src = r + u; e.async = false; document.body.appendChild(e); }); };
    if (document.visibilityState === 'hidden' || !window.requestAnimationFrame) setTimeout(go, 0);
    else requestAnimationFrame(function () { setTimeout(go, 0); });
  })('../../', ['vendor/gsap.min.js', 'vendor/ScrollTrigger.min.js', 'vendor/lenis.min.js', 'app.min.js?v=20261106s2']);
</script>
<!-- Yandex.Metrika counter + UIS + Radist: загружаются после первого действия посетителя (касание, прокрутка, мышь, клавиатура) или через 5 с после загрузки страницы -->
<script type="text/javascript">
    (function (w, d) {
        w.ym = w.ym || function () { (w.ym.a = w.ym.a || []).push(arguments); };
        w.ym.l = 1 * new Date();
        ym(113675622, 'init', {ssr:true, webvisor:true, clickmap:true, ecommerce:"dataLayer", referrer: document.referrer, url: location.href, accurateTrackBounce:true, trackLinks:true});
        var done = false, ready = false, wait = null, ev = ['pointerdown', 'touchstart', 'keydown', 'scroll', 'wheel', 'mousemove'];
        w.__cs = w.__cs || [];
        w.__cs.push(['waitForTrackViewAndRun', function () { ready = true; }]);
        // Radist: код заявки в ссылках Telegram и MAX — сразу, скрипт Radist загрузится вместе со счётчиками
        var rmsg = 'Здравствуйте! Пишу с сайта пестконтроль-центр.рф. Номер заявки: {radist_tracker}';
        w.radist_tracker = w.radist_tracker || function () { (w.radist_tracker.a = w.radist_tracker.a || []).push(arguments); };
        w.radist_tracker.l = 1 * new Date();
        w.radist_tracker({ message: rmsg, whatsapp_enabled: true, tgbot_enabled: true, tg_enabled: true, max_enabled: true, vk_enabled: true });
        (function () {
            var id = null, abc = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789', s = 'ro', i, txt;
            try {
                id = sessionStorage.getItem('radistVisit');
                if (!id || id.length !== 12) {
                    for (i = 0; i < 10; i++) s += abc.charAt(Math.floor(Math.random() * abc.length));
                    sessionStorage.setItem('radistVisit', s);
                    id = sessionStorage.getItem('radistVisit');
                }
            } catch (e) { id = null; }
            if (!id || id.length !== 12) return;
            txt = encodeURIComponent(rmsg.replace(/{radist_tracker}/g, id));
            [].forEach.call(d.querySelectorAll('a[href*="//t.me/"], a[href*="//max.ru/"]'), function (a) {
                try {
                    var u = new URL(a.href), n = u.pathname.split('/')[1] || '';
                    if (u.host === 'max.ru') a.href = 'https://max.ru/' + u.pathname.substring(1) + '?start=' + id;
                    else if (u.host === 't.me' && !/bot$/i.test(n)) a.href = 'https://t.me' + u.pathname + '?text=' + txt;
                } catch (e) {}
            });
        })();
        function add(src) { var k = d.createElement('script'); k.async = true; k.src = src; d.head.appendChild(k); return k; }
        function load() {
            if (done) return; done = true;
            ev.forEach(function (e) { w.removeEventListener(e, load, true); });
            add('https://mc.yandex.ru/metrika/tag.js?id=113675622');
            var p = d.createElement('link'); p.rel = 'preconnect'; p.href = 'https://tracker.comagic.ru'; d.head.appendChild(p);
            add('https://app.uiscom.ru/static/cs.min.js?k=ICWycQx6m3NSBe3WlCeDAdAKMTmNhMHC').onerror = function () { ready = true; };
            add('https://track.radist.me/tracker.min.js');
        }
        ev.forEach(function (e) { w.addEventListener(e, load, { capture: true, passive: true }); });
        function later() { setTimeout(load, 5000); }
        if (d.readyState === 'complete') later(); else w.addEventListener('load', later);
        // Ожидание подмены номера при первом касании: набор откладывается до ответа UIS, максимум 0,8–1 с
        d.addEventListener('click', function (e) {
            if (ready) return;
            var a = e.target && e.target.closest ? e.target.closest('a[href^="tel:"]') : null;
            if (!a || e.button || e.ctrlKey || e.metaKey || e.shiftKey || e.altKey) return;
            e.preventDefault();
            if (wait) return;
            load();
            var href = a.getAttribute('href'), op = a.style.opacity, max = 'GestureEvent' in w ? 800 : 1000, t;
            function go() {
                for (var i = 0; i < wait.length; i++) clearTimeout(wait[i]);
                wait = null; ready = true; a.style.opacity = op;
                w.location.href = a.href;
            }
            function check(last) { return function () { if (wait && (last || ready || a.getAttribute('href') !== href)) go(); }; }
            wait = [];
            a.style.opacity = '.6';
            for (t = 50; t <= max; t += 50) wait.push(setTimeout(check(t === max), t));
        }, true);
    })(window, document);
</script>
<noscript><div><img src="https://mc.yandex.ru/watch/113675622" style="position:absolute; left:-9999px;" alt="" /></div></noscript>
<!-- /Yandex.Metrika counter -->
</body>
</html>
