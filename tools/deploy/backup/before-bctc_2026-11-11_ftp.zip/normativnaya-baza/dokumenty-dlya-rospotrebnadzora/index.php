<!doctype html>
<html lang="ru" class="anim-fail">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>Документы для Роспотребнадзора: перечень для проверки в 2026 году</title>
<meta name="description" content="Какие документы нужны для проверки Роспотребнадзора: договоры, акты, протоколы лабораторных исследований, журналы и ППК. Перечень по объектам и чек-лист PDF.">
<link rel="canonical" href="https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/normativnaya-baza/dokumenty-dlya-rospotrebnadzora/">
<meta name="theme-color" content="#000000">
<meta property="og:type" content="article">
<meta property="og:locale" content="ru_RU">
<meta property="og:site_name" content="ПЕСТКОНТРОЛЬ Центр">
<meta property="og:url" content="https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/normativnaya-baza/dokumenty-dlya-rospotrebnadzora/">
<meta property="og:title" content="Документы для Роспотребнадзора: перечень для проверки в 2026 году">
<meta property="og:description" content="Какие документы нужны для проверки Роспотребнадзора: договоры, акты, протоколы лабораторных исследований, журналы и ППК. Перечень по объектам и чек-лист PDF.">
<meta property="og:image" content="https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/img/dok-og.jpg">
<meta property="og:image:type" content="image/jpeg">
<meta property="og:image:width" content="1200">
<meta property="og:image:height" content="630">
<meta property="og:image:alt" content="Чек-лист «Документы для Роспотребнадзора»: перечень для проверки в 2026 году">
<meta name="twitter:card" content="summary_large_image">
<link rel="icon" href="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 32 32'%3E%3Ccircle cx='16' cy='16' r='15' fill='%2309090b' stroke='%237c86ff' stroke-width='2'/%3E%3Cpath d='M16 7l7 3v5c0 5-3 8.5-7 10-4-1.5-7-5-7-10v-5z' fill='none' stroke='%23fff' stroke-width='2'/%3E%3C/svg%3E">
<link rel="preload" href="../../fonts/inter-ru-wght-normal.woff2" as="font" type="font/woff2" crossorigin>
<link rel="preload" as="image" media="(min-width:861px)" imagesrcset="../../img/dok-hero-1440.webp 1440w, ../../img/dok-hero.webp 1920w" imagesizes="100vw" fetchpriority="high">
<link rel="preload" as="image" media="(max-width:860px)" imagesrcset="../../img/dok-hero-mob-760.webp 760w, ../../img/dok-hero-mob.webp 1024w" imagesizes="100vw" fetchpriority="high">
<script>
  /* начальные состояния анимаций — только при работающем JS; страховка — через 4 с всё показывается.
     Заставка — один раз за посещение: при переходе по ссылке с якорем и между страницами сайта её нет */
  (function (d) {
    d.classList.add('js');
    try { if (location.hash || sessionStorage.getItem('pc-intro')) d.classList.add('no-intro'); else sessionStorage.setItem('pc-intro', '1'); }
    catch (e) { if (location.hash) d.classList.add('no-intro'); }
    setTimeout(function () { if (!d.classList.contains('anim-ready')) d.classList.add('anim-fail'); }, 4000);
  })(document.documentElement);
</script>
<link rel="stylesheet" href="../../style.css?v=20261106s2">
<style>.d-page .s{padding:clamp(64px,7vw,128px) 0;border-top:1px solid var(--line)}.d-crumbs{padding-top:calc(clamp(68px,6vw,115px) + 20px);font-size:14px;color:var(--t3);display:flex;flex-wrap:wrap;gap:8px}.d-crumbs a{color:var(--t2)}.d-crumbs a:hover{color:var(--t1)}.d-hero{padding:clamp(28px,3vw,56px) 0 clamp(64px,7vw,128px)}.d-hero .wrap{display:grid;grid-template-columns:minmax(0,1.15fr) minmax(0,.85fr);gap:clamp(28px,4vw,80px);align-items:center}.d-hero h1{font-size:clamp(34px,4.2vw,80px);line-height:1.05;letter-spacing:-.045em;font-weight:300;margin:18px 0 0}.d-ticks{list-style:none;padding:0;margin:28px 0 34px;display:grid;gap:12px}.d-ticks li{position:relative;padding-left:30px;line-height:1.5}.d-ticks li::before{content:"";position:absolute;left:2px;top:.42em;width:13px;height:7px;border-left:2px solid var(--acc);border-bottom:2px solid var(--acc);transform:rotate(-45deg)}.d-btns{display:flex;flex-wrap:wrap;gap:12px}.ph-img{aspect-ratio:4/3;border:1.5px dashed var(--line2);border-radius:var(--r);display:flex;align-items:center;justify-content:center;text-align:center;padding:28px;color:var(--t3);font-size:14px;line-height:1.5;background:rgba(255,255,255,.02)}.ph-doc{aspect-ratio:3/4;max-width:340px}.d-cards{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:16px}.d-card{background:var(--card);border:1px solid var(--line2);border-radius:var(--r);padding:clamp(22px,2vw,34px)}.d-card h3{font-size:clamp(20px,1.5vw,26px);font-weight:400;letter-spacing:-.02em;margin:0 0 12px}.d-card p{color:var(--t2);line-height:1.6;margin:0}.d-note{color:var(--t2);margin:24px 0 0;line-height:1.6}.d-strong{color:var(--t1);font-size:clamp(18px,1.3vw,22px)}.d-split{display:grid;grid-template-columns:minmax(0,1fr) minmax(0,340px);gap:clamp(28px,4vw,80px);align-items:start}.d-two{display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1fr);gap:clamp(28px,4vw,80px);align-items:start}.d-two .head{margin-bottom:0}.d-two .d-ticks{margin:0}.d-terms{list-style:none;counter-reset:t;padding:0;margin:0;border-top:1px solid var(--line2)}.d-terms li{display:grid;grid-template-columns:44px minmax(0,.42fr) minmax(0,1fr);gap:16px;padding:18px 0;border-bottom:1px solid var(--line2);line-height:1.55}.d-terms li::before{counter-increment:t;content:counter(t,decimal-leading-zero);color:var(--t3)}.d-terms b{font-weight:500}.d-terms span{color:var(--t2)}.d-doc{display:grid;gap:16px;justify-items:start}.d-small{font-size:14px;color:var(--t3);margin:0}.d-steps{list-style:none;counter-reset:st;padding:0;margin:0;display:grid;grid-template-columns:repeat(5,minmax(0,1fr));gap:18px}.d-steps li{border-top:2px solid var(--line2);padding-top:18px;line-height:1.55}.d-steps li::before{counter-increment:st;content:"0" counter(st);display:block;color:var(--acc);font-size:14px;margin-bottom:12px}.d-steps b{display:block;font-weight:500;margin-bottom:8px}.d-steps span{color:var(--t2)}.d-table{width:100%;border-collapse:collapse;line-height:1.5}.d-table th,.d-table td{text-align:left;vertical-align:top;padding:16px 20px 16px 0;border-bottom:1px solid var(--line2)}.d-table th{color:var(--t3);font-weight:400;font-size:14px}.d-table td{color:var(--t2)}.d-table td:first-child{color:var(--t1)}.d-vs td:first-child{color:var(--t2)}.d-vs th:last-child,.d-vs td:last-child{color:var(--t1);background:rgba(124,134,255,.07);padding-left:20px}.d-cols2{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:16px;margin-top:28px}.d-chips{list-style:none;padding:0;margin:0;display:flex;flex-wrap:wrap;gap:10px}.d-chips a{display:inline-block;padding:12px 18px;border:1px solid var(--line2);border-radius:999px;color:var(--t1);transition:border-color .2s}.d-chips a:hover{border-color:var(--acc)}.tbd{background:rgba(255,209,102,.14);color:#ffd166;border-radius:4px;padding:0 .2em}.d-page .cta .sub{margin-bottom:30px}@media (max-width:1100px){.d-steps{grid-template-columns:repeat(2,minmax(0,1fr))}}@media (max-width:860px){.d-hero .wrap,.d-split,.d-two,.d-cols2,.d-cards{grid-template-columns:minmax(0,1fr)}.d-terms li{grid-template-columns:36px minmax(0,1fr);gap:6px 12px}.d-terms span{grid-column:2}.ph-doc{display:none}}@media (max-width:600px){.d-steps{grid-template-columns:minmax(0,1fr)}.d-table thead{display:none}.d-table,.d-table tbody,.d-table tr,.d-table td{display:block;width:100%}.d-table tr{border:1px solid var(--line2);border-radius:var(--r);padding:6px 16px;margin-bottom:12px}.d-table td{border:0;padding:10px 0}.d-table td+td{border-top:1px solid var(--line)}.d-table td::before{content:attr(data-l);display:block;font-size:13px;color:var(--t3);margin-bottom:4px}.d-vs td:last-child{background:none;padding-left:0}.d-page .form .btn-lg{padding:0 16px}}.hdr .nav a{white-space:nowrap}.f-lazy:not(.bg-in){background-image:none!important}
.f-hero .hero-media{overflow:hidden}.f-hero .hero-media::after{content:"";position:absolute;inset:0 0 auto;height:200px;background:linear-gradient(180deg,rgba(9,9,11,.72),rgba(9,9,11,0));pointer-events:none}.f-hero .f-hero-img{position:absolute;inset:0;width:100%;height:100%;object-fit:cover;object-position:64% 50%;filter:saturate(.95)}.f-hero::before{background:linear-gradient(90deg,rgba(9,9,11,.92) 0%,rgba(9,9,11,.84) 40%,rgba(9,9,11,.32) 58%,rgba(9,9,11,0) 74%)}.f-hero::after{height:22%}.f-hero p.lead{max-width:600px}.f-crumbs{display:flex;flex-wrap:wrap;gap:8px;font-size:14px;color:var(--t3);margin:0 0 26px}.f-crumbs a{color:var(--t2)}.f-crumbs a:hover{color:var(--t1)}.f-urgent{margin:22px 0 0;color:var(--t2);font-size:15px}.f-urgent::before{content:"";display:inline-block;width:8px;height:8px;border-radius:50%;background:var(--grn);margin-right:10px;vertical-align:middle}
.f-checks{position:relative;padding:clamp(28px,3vw,56px) 0 clamp(56px,6vw,110px)}.f-check.panel{max-width:none}.f-check-in{position:relative;z-index:1;display:grid;grid-template-columns:minmax(0,.9fr) minmax(0,1.1fr);gap:clamp(24px,4vw,80px);padding:clamp(24px,3vw,52px)}.f-check-t{font-size:clamp(28px,2.6vw,48px);line-height:1.08;letter-spacing:-.04em;font-weight:300;margin:0}.f-check-res{margin:22px 0 10px;color:var(--t2);font-size:15px}.f-check-res b{font-size:clamp(40px,3.4vw,64px);font-weight:300;letter-spacing:-.04em;color:var(--acc);margin-right:6px;line-height:1;transition:color .3s}.f-check-res.full b{color:var(--grn)}.f-check-note{color:var(--t2);line-height:1.6;margin:0 0 28px;max-width:440px}.f-check-list{list-style:none;margin:0;padding:0;display:grid;align-content:center;border-top:1px solid var(--line)}.f-check-list li{border-bottom:1px solid var(--line)}.f-check-list label{display:flex;gap:18px;align-items:center;padding:18px 4px;cursor:pointer;font-size:clamp(16px,1.15vw,20px);line-height:1.4;color:var(--t2);transition:color .25s}.f-check-list label:hover{color:var(--t1)}.f-check-list input{appearance:none;-webkit-appearance:none;flex:none;width:26px;height:26px;margin:0;border-radius:8px;border:1.4px solid var(--line2);background:rgba(255,255,255,.03) center/14px no-repeat;cursor:pointer;transition:background-color .25s,border-color .25s}.f-check-list input:checked{background-color:var(--acc2);border-color:var(--acc);background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 14 14'%3E%3Cpath d='M2.5 7.5l3 3 6-7' fill='none' stroke='%23fff' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'/%3E%3C/svg%3E")}.f-check-list input:focus-visible{outline:2px solid var(--acc);outline-offset:3px}.f-check-list input:checked+span{color:var(--t1)}
.d-card .f-num{font-size:clamp(28px,2.4vw,44px);line-height:1.05;letter-spacing:-.035em;font-weight:300;color:var(--acc);margin:0 0 16px}.f-req .d-card{border-top:2px solid rgba(124,134,255,.45)}
.f-zmap{display:grid;grid-template-columns:minmax(0,1.4fr) minmax(0,1fr);gap:clamp(20px,2.4vw,44px);align-items:start}.f-plan{margin:0;padding:clamp(14px,1.4vw,26px)}.f-plan svg{display:block;width:100%;height:auto}.f-plan svg *{pointer-events:none}.f-plan .zf,.f-plan .bdg{pointer-events:all}.f-plan .zf{fill:transparent;transition:fill .3s,stroke .3s}.f-plan .z.on .zf{fill:rgba(124,134,255,.14)}.f-plan .z6.on .zf{fill:rgba(124,134,255,.05);stroke:#7c86ff}.f-plan .bdg circle{fill:#09090b;stroke:#7c86ff;stroke-width:2;transition:fill .3s}.f-plan .bdg text{fill:#7c86ff;font:500 22px Inter,system-ui,sans-serif;text-anchor:middle;dominant-baseline:central;transition:fill .3s}.f-plan .bdg.on circle{fill:#7c86ff}.f-plan .bdg.on text{fill:#fff}.f-plan .lbl text{fill:#84848e;font:400 15px Inter,system-ui,sans-serif}.f-legend{display:flex;flex-wrap:wrap;gap:10px 22px;margin:16px 4px 2px;font-size:13px;color:var(--t3)}.f-legend span{display:inline-flex;align-items:center;gap:9px}.f-legend i{flex:none;display:inline-block}.lg-st{width:11px;height:11px;border-radius:2px;background:var(--yel)}.lg-tr{width:11px;height:11px;border-radius:50%;background:var(--acc)}.lg-uv{width:20px;height:7px;border-radius:4px;background:#c4b5fd;box-shadow:0 0 8px rgba(167,139,250,.9)}.lg-fl{width:24px;border-top:2px dashed var(--acc)}.f-zlist{list-style:none;padding:0;margin:0;display:grid;gap:10px;counter-reset:zl}.f-zlist li{display:grid;grid-template-columns:40px minmax(0,1fr);gap:2px 14px;align-items:start;padding:15px 18px;border:1.4px solid var(--line);border-radius:var(--r);background:var(--card);transition:border-color .3s,background .3s;outline:none;cursor:default}.f-zlist li::before{counter-increment:zl;content:counter(zl);grid-row:1/span 2;width:34px;height:34px;border-radius:50%;border:1.4px solid var(--acc);color:var(--acc);display:flex;align-items:center;justify-content:center;font-size:15px;transition:background .3s,color .3s}.f-zlist b{font-weight:500;font-size:clamp(16px,1.05vw,19px);line-height:1.3}.f-zlist span{color:var(--t2);font-size:clamp(14px,.9vw,16px);line-height:1.5}.f-zlist li.on,.f-zlist li:hover,.f-zlist li:focus-visible{border-color:rgba(124,134,255,.6);background:rgba(124,134,255,.08)}.f-zlist li.on::before{background:var(--acc);color:#fff}
.f-steps4{grid-template-columns:repeat(4,minmax(0,1fr))}.d-steps li.f-alert{border-top-color:var(--yel)}.d-steps li.f-alert::before{color:var(--yel)}
.inds.f-inds{grid-template-columns:repeat(6,minmax(0,1fr))}.inds.f-inds>*{grid-column:span 2}.inds.f-inds>:nth-child(n+4){grid-column:span 3}.inds.f-inds>:nth-child(n+4) .ind-img{aspect-ratio:834/275}
.f-lbl{display:block;font-size:12px;letter-spacing:.08em;text-transform:uppercase;color:var(--acc);margin:4px 0 8px}.f-mb{margin:0 0 4px}.f-pricecard .f-price{margin:22px 0 26px;color:var(--t2);line-height:1.6}.f-pricecard .f-price b{display:block;color:var(--t1);font-weight:400;font-size:clamp(20px,1.6vw,28px);letter-spacing:-.02em;line-height:1.25;margin-bottom:6px}.d-card .btn{max-width:100%;white-space:normal;text-align:center;line-height:1.25}
@media (max-width:1100px){.f-steps4{grid-template-columns:repeat(2,minmax(0,1fr))}.f-zmap,.f-check-in{grid-template-columns:minmax(0,1fr)}.inds.f-inds{grid-template-columns:repeat(2,minmax(0,1fr))}.inds.f-inds>*,.inds.f-inds>:nth-child(n+4){grid-column:auto}.inds.f-inds>:nth-child(n+4) .ind-img{aspect-ratio:556/275}.inds.f-inds>:last-child{grid-column:1/-1}.inds.f-inds>:last-child .ind-img{aspect-ratio:834/275}}
@media (max-width:900px){.hdr{background:rgba(0,0,0,.72);backdrop-filter:blur(18px);-webkit-backdrop-filter:blur(18px);border-color:var(--line)}.f-hero{display:block;min-height:0;padding:68px 0 clamp(44px,8vw,72px)}.f-hero::before,.f-hero::after{display:none}.f-hero .hero-media{position:relative;inset:auto;width:100%;aspect-ratio:16/9}.f-hero .hero-media::after{height:100%;background:linear-gradient(180deg,rgba(0,0,0,0) 62%,#000 100%)}.f-hero .f-hero-img{object-position:70% 50%;filter:none}.f-hero .wrap{margin-top:-24px}.f-hero p.lead{max-width:760px}}@media (max-width:760px){.f-hero .hero-media{aspect-ratio:4/3}.f-hero .f-hero-img{object-position:50% 50%}.f-crumbs{font-size:13px;margin-bottom:18px}.inds.f-inds{grid-template-columns:minmax(0,1fr)}.inds.f-inds>:last-child{grid-column:auto}.inds.f-inds>:last-child .ind-img{aspect-ratio:556/275}}
@media (max-width:600px){.f-steps4{grid-template-columns:minmax(0,1fr)}.d-btns .btn,.d-card .btn,.f-check .btn{width:100%;white-space:normal;text-align:center;line-height:1.25}.d-page .btn-lg{padding:0 16px}.f-plan .lbl{display:none}.f-check-in{padding:24px 20px}.f-check-list label{padding:15px 2px;gap:14px}.f-zlist li{padding:14px}}
@media (max-width:400px){.hdr .wrap{gap:10px}.hdr-right{gap:8px}.logo{gap:8px}.logo-mark{width:34px;height:34px}.logo-name{font-size:15px}.phone i,.burger{width:40px;height:40px}}@media (max-width:340px){.logo-sub{display:none}}
/* Раздел «Нормативная база»: /normativnaya-baza/ и /normativnaya-baza/proverochnye-listy/ (класс nb-page) */
/* первый экран: фото на всю ширину и текст слева на градиенте — как у «Программы пест-контроля» в разделе «Материалы».
   На телефоне (до 860 px) порядок: заголовок → фото → текст → кнопки; надзаголовок не показывается, крошки скрыты правилом m-crumbs */
.d-hero.nb-hero{position:relative;overflow:hidden;display:flex;align-items:flex-end;min-height:clamp(680px,54vw,940px);padding:calc(clamp(68px,6vw,115px) + 28px) 0 clamp(40px,4vw,64px);background:#000}
.nb-hero .wrap{width:100%;display:grid;grid-template-columns:minmax(0,1.28fr) minmax(0,.72fr);gap:0 clamp(28px,4vw,80px);align-items:end}
.nb-hero .d-hero-copy{grid-column:1;min-width:0}
.nb-hero .d-hero-copy>*:not(.d-hero-media),.nb-hero .nb-toc{position:relative;z-index:1}
.nb-hero .d-hero-media{position:absolute;inset:0;z-index:0;pointer-events:none;overflow:hidden;margin:0}
.nb-hero .d-hero-media::before{content:"";position:absolute;inset:0;z-index:1;background:linear-gradient(90deg,rgba(0,0,0,.95) 0%,rgba(0,0,0,.86) 40%,rgba(0,0,0,.3) 58%,rgba(0,0,0,0) 70%),linear-gradient(180deg,#000 0,rgba(0,0,0,.55) 90px,rgba(0,0,0,0) 260px),linear-gradient(0deg,#000 0,rgba(0,0,0,.65) 110px,rgba(0,0,0,0) 300px)}
.nb-hero .d-hero-img{position:absolute;inset:0;width:100%;height:100%;object-fit:cover;object-position:100% 50%}
.nb-hero .f-crumbs{margin:0 0 22px}
.nb-hero .eyebrow{margin:0}
.d-hero.nb-hero h1{font-size:clamp(36px,3.6vw,66px);line-height:1.08;letter-spacing:-.055em;font-weight:300;margin:18px 0 0}
.nb-hero h1 .ln{display:block;padding:0 .08em .08em 0;margin-bottom:-.08em}
.nb-hero h1 .ln>span{display:inline-block}
.nb-hero p.lead{font-size:clamp(15px,1.02vw,18px);line-height:1.62;color:#c4c4cc;max-width:720px;margin:22px 0 0}
.nb-hero .d-btns{margin-top:26px}
.nb-byline{font-size:13px;line-height:1.5;color:var(--t3);margin:16px 0 0;max-width:720px}
.nb-hero .nb-toc{grid-column:1/-1;margin-top:clamp(28px,2.6vw,44px)}
.nb-toc{display:flex;flex-wrap:wrap;gap:8px}
.nb-toc a{display:inline-block;padding:9px 16px;border:1px solid var(--line2);border-radius:999px;font-size:14px;color:var(--t2);background:rgba(0,0,0,.45);transition:border-color .2s,color .2s}
.nb-toc a:hover,.nb-toc a:focus-visible{border-color:var(--acc);color:var(--t1)}
@media (min-width:1600px){.nb-hero p.lead,.nb-byline{max-width:820px}}
/* планшет и телефон (до 1180 px): заголовок → фото → кнопки → абзац-ответ (решение владельца 08–09.11.2026, «вариант 1»):
   обе кнопки на первом экране телефона. При наложении текста на фото на этих ширинах люди на снимке уходили бы под текст.
   В HTML порядок прежний (абзац сразу после фото) — меняется только показ */
@media (max-width:1180px){
  .d-hero.nb-hero{display:block;min-height:0;padding:calc(clamp(68px,6vw,115px) + 18px) 0 clamp(32px,6vw,48px)}
  .nb-hero .wrap{display:block}
  .nb-hero .d-hero-copy{display:flex;flex-direction:column}
  .nb-hero .eyebrow{display:none}
  .d-hero.nb-hero h1{order:1;margin:0}
  .nb-hero h1 .ln{display:inline}
  .nb-hero .d-hero-media{order:2;position:relative;inset:auto;aspect-ratio:16/9;max-height:min(560px,52vh);margin:22px calc(var(--pad) * -1) 0}
  .nb-hero .d-hero-media::before{background:linear-gradient(0deg,#000 0,rgba(0,0,0,0) 24%)}
  .nb-hero .d-hero-img{object-position:50% 15%}
  .nb-hero .d-btns{order:3;margin-top:24px}
  .nb-hero p.lead{order:5;margin:26px 0 0;max-width:820px}
  .nb-hero .nb-byline{order:6;max-width:820px}
  .nb-hero .f-crumbs{order:7;margin:18px 0 0}
  .nb-hero .nb-toc{margin-top:28px}
}
@media (max-width:860px){
  .d-hero.nb-hero h1{font-size:clamp(28px,7.8vw,36px);line-height:1.08}
  /* фото 16:9, на низких экранах (iPhone SE, встроенные браузеры) ниже — чтобы обе кнопки были на первом экране;
     --nb-hero-rsv — место под шапку, заголовок и кнопки (у страниц с длинным заголовком больше) */
  .nb-hero .d-hero-media{aspect-ratio:auto;height:min(56.25vw,calc(100vh - var(--nb-hero-rsv,400px)));min-height:140px;max-height:none;margin-top:18px}
  @supports (height:100svh){.nb-hero .d-hero-media{height:min(56.25vw,calc(100svh - var(--nb-hero-rsv,400px)))}}
  .nb-hub-hero{--nb-hero-rsv:430px}  /* заголовок хаба на 360–375 px — в 5 строк */
  .nb-hero .d-hero-img{object-position:50% 40%}
  .nb-listy-hero .d-hero-img{object-position:50% 12%}  /* на низком фото не срезать головы */
  .nb-hero p.lead{margin:24px 0 0;font-size:15px;line-height:1.55;max-width:none}
  .nb-hero .d-btns{margin-top:18px;gap:10px}
  .nb-hero .nb-byline{margin-top:14px}
  .nb-hero .nb-toc{margin-top:26px}
}

/* ссылки в тексте */
.nb-page .nb-tbl td a,.nb-after a,.nb-dl a,.nb-fact a,.nb-errs a,.nb-q-note a,.nb-food a,.nb-base a,.nb-five a,.nb-lic a,.nb-page .cta .sub a{color:var(--t1);border-bottom:1px solid rgba(124,134,255,.45);transition:border-color .25s}
.nb-page .nb-tbl td a:hover,.nb-after a:hover,.nb-dl a:hover,.nb-fact a:hover,.nb-errs a:hover,.nb-q-note a:hover,.nb-food a:hover,.nb-base a:hover,.nb-five a:hover,.nb-lic a:hover,.nb-page .cta .sub a:hover{border-color:var(--t1)}
.nb-lic{margin-top:8px}
.nb-lic a{text-decoration:none}

/* пять главных пунктов */
.nb-five{list-style:none;counter-reset:nb;padding:0;margin:0;display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:16px}
.nb-five li{counter-increment:nb;position:relative;padding:clamp(24px,2.2vw,34px) clamp(22px,2vw,32px) clamp(24px,2.2vw,34px) clamp(60px,4.4vw,82px);color:var(--t2);line-height:1.62}
.nb-five li{padding-left:clamp(80px,5.8vw,104px)}
.nb-five .nb-ic{position:absolute;left:clamp(22px,2vw,32px);top:clamp(24px,2.2vw,34px)}
.nb-five li b{display:block;color:var(--t1);font-weight:500;font-size:clamp(17px,1.2vw,21px);line-height:1.35;margin-bottom:10px}
.nb-five li:last-child:nth-child(odd){grid-column:1/-1}

/* таблицы: до 900 px — карточки */
.nb-h3{font-size:clamp(20px,1.5vw,26px);font-weight:400;letter-spacing:-.02em;line-height:1.3;color:var(--t1);margin:clamp(48px,4vw,72px) 0 6px}
.nb-h3:first-of-type{margin-top:0}
.nb-doc{color:var(--acc);font-weight:500}
.nb-date{color:var(--t1)}
.nb-val{color:var(--t1);font-weight:500}
.nb-old s{text-decoration-color:rgba(255,100,103,.75);text-decoration-thickness:1.5px}
.nb-after{margin:22px 0 0;color:var(--t2);line-height:1.62;max-width:1000px}
@media (min-width:901px){
  .nb-docs td:nth-child(1){width:30%}
  .nb-docs td:nth-child(3){width:15%}
  .nb-docs td:nth-child(4){width:15%}
  .nb-docs.nb-3 td:nth-child(3){width:22%}
  .nb-freq td:nth-child(2){width:24%}
  .nb-freq td:nth-child(3),.nb-freq td:nth-child(3){width:9%;white-space:nowrap}
  .nb-freq2 td:nth-child(2){width:28%}
  .nb-old td:nth-child(1){width:46%}
  .nb-old td:nth-child(3){width:26%}
  .nb-obj td:nth-child(1){width:22%}
  .nb-obj td:nth-child(3){width:30%}
  .nb-forms td:nth-child(1){width:20%}
  .nb-forms td:nth-child(2){width:13%;white-space:nowrap}
  .nb-forms td:nth-child(3){width:16%}
  .nb-answers td:nth-child(1){width:28%}
  .nb-answers td:nth-child(3){width:22%}
}
@media (max-width:900px){
  .nb-tbl thead{display:none}
  .nb-tbl,.nb-tbl tbody,.nb-tbl tr,.nb-tbl td{display:block;width:100%}
  .nb-tbl tr{border:1px solid var(--line2);border-radius:var(--r);padding:6px 16px;margin-bottom:12px}
  .nb-tbl td{border:0;padding:10px 0}
  .nb-tbl td+td{border-top:1px solid var(--line)}
  .nb-tbl td::before{content:attr(data-l);display:block;font-size:13px;color:var(--t3);margin-bottom:4px}
}

/* хроника изменений */
.nb-tl{list-style:none;padding:0;margin:0;position:relative;max-width:1240px}
.nb-tl::before{content:"";position:absolute;left:7px;top:10px;bottom:10px;width:1px;background:var(--line2)}
.nb-tl li{position:relative;display:grid;grid-template-columns:minmax(120px,.2fr) minmax(0,1fr) minmax(0,.78fr);gap:clamp(14px,2vw,40px);padding:0 0 clamp(28px,2.4vw,40px) 42px}
.nb-tl li:last-child{padding-bottom:0}
.nb-tl li::before{content:"";position:absolute;left:0;top:5px;width:15px;height:15px;border-radius:50%;border:2px solid var(--acc);background:#09090b;box-sizing:border-box}
.nb-tl-d{color:var(--acc);font-weight:500;font-size:clamp(16px,1.12vw,20px);line-height:1.3;white-space:nowrap}
.nb-tl-w{color:var(--t1);line-height:1.6}
.nb-tl-a{color:var(--t2);line-height:1.6;font-size:15px}
.nb-tl-k{display:block;font-size:12px;letter-spacing:.1em;text-transform:uppercase;color:var(--t3);margin-bottom:4px}
.nb-tl li.is-past::before{border-color:#52525b;background:#52525b}
.nb-tl li.is-past .nb-tl-d{color:var(--t3)}
.nb-tl li.is-past .nb-tl-w{color:var(--t2)}
.nb-tl a{color:var(--t1);border-bottom:1px solid rgba(124,134,255,.45)}
@media (max-width:760px){.nb-tl li{grid-template-columns:minmax(0,1fr);gap:6px;padding-left:34px}}

/* разборы и образцы */
.nb-links{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:16px}
.nb-link{display:flex;flex-direction:column;gap:12px;padding:0 0 clamp(22px,2vw,30px);min-height:190px;color:var(--t1);overflow:hidden}
.nb-link>:not(.nb-link-img){margin:0 clamp(22px,2vw,32px)}
.nb-link-img{display:block;aspect-ratio:16/9;overflow:hidden;background:#18181b;margin-bottom:8px;border-bottom:1px solid var(--line)}
.nb-link-img img{display:block;width:100%;height:100%;object-fit:cover;transition:transform .7s cubic-bezier(.16,1,.3,1)}
.nb-link-img.is-doc{background:#f4f4f5}
.nb-link-img.is-doc img{object-position:50% 0}
.nb-link:hover .nb-link-img img,.nb-link:focus-visible .nb-link-img img{transform:scale(1.04)}
.nb-link-k{font-size:12px;font-weight:500;letter-spacing:.12em;text-transform:uppercase;color:var(--acc)}
.nb-link b{font-weight:400;font-size:clamp(18px,1.3vw,23px);line-height:1.32;letter-spacing:-.01em}
.nb-link-go{margin-top:auto;color:var(--t2);font-size:15px;transition:color .25s}
.nb-link:hover .nb-link-go,.nb-link:focus-visible .nb-link-go{color:var(--t1)}
/* карточка на всю ширину: фото слева, текст справа (перечень «Документы для Роспотребнадзора») */
.nb-link-wide{grid-column:1/-1;display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1fr);gap:0;padding:0;min-height:0}
.nb-link-wide>:not(.nb-link-img){margin:0}
.nb-link-wide .nb-link-img{margin:0;border-bottom:0;border-right:1px solid var(--line);aspect-ratio:16/9}
.nb-link-txt{display:flex;flex-direction:column;gap:12px;padding:clamp(24px,2.6vw,44px)}
.nb-link-d{color:var(--t2);font-size:15px;line-height:1.6;max-width:560px}
.nb-link-wide b{font-size:clamp(20px,1.6vw,28px)}

/* автор */
.nb-author-wrap{display:grid;grid-template-columns:minmax(0,.75fr) minmax(0,1.25fr);gap:clamp(24px,3vw,56px);align-items:center}
.nb-author{display:flex;gap:20px;align-items:center;padding:clamp(24px,2.4vw,36px)}
.nb-avatar{flex:none;display:block;width:112px;height:112px;border-radius:50%;object-fit:cover;background:#18181b;border:1px solid rgba(124,134,255,.4)}
.nb-author p{margin:0}
.nb-author-name{font-size:clamp(20px,1.5vw,26px);color:var(--t1);letter-spacing:-.02em;margin-bottom:4px!important}
.nb-author-role{color:var(--t2);margin-bottom:4px!important}
.nb-author-date{color:var(--t3);font-size:14px}
.nb-author-note{color:var(--t3);font-size:13px;margin-top:6px!important}
.nb-author-text{color:#c4c4cc;font-size:clamp(16px,1.08vw,19px);line-height:1.65;margin:0;max-width:760px}

/* источники — свёрнутый список */
.nb-page #istochniki{padding:clamp(48px,4.6vw,84px) 0}
.nb-src{border:1.4px solid var(--line);border-radius:var(--r);background:var(--card)}
.nb-src summary{list-style:none;cursor:pointer;display:flex;flex-direction:column;gap:8px;padding:clamp(22px,2vw,32px) calc(clamp(22px,2vw,32px) + 48px) clamp(22px,2vw,32px) clamp(22px,2vw,32px);position:relative;border-radius:var(--r)}
.nb-src summary::-webkit-details-marker{display:none}
.nb-src summary .eyebrow{margin:0}
.nb-src-t{font-size:clamp(20px,1.5vw,26px);font-weight:300;letter-spacing:-.02em;line-height:1.3;color:var(--t1)}
.nb-src summary::after{content:"+";position:absolute;right:clamp(22px,2vw,32px);top:50%;width:32px;height:32px;margin-top:-16px;border:1px solid var(--line2);border-radius:50%;display:flex;align-items:center;justify-content:center;color:var(--t2);font-size:18px;line-height:1;transition:border-color .25s}
.nb-src summary:hover::after{border-color:var(--acc)}
.nb-src[open] summary::after{content:"−"}
.nb-base{list-style:none;padding:0 clamp(22px,2vw,32px) clamp(18px,1.6vw,26px);margin:0}
.nb-base li{position:relative;padding:13px 0 13px 28px;border-top:1px solid var(--line2);color:var(--t2);line-height:1.6;font-size:15px}
.nb-base li::before{content:"§";position:absolute;left:3px;top:13px;color:var(--acc)}

/* проверочные листы: изменения, пять вопросов, пищевые производства, шаги, ошибки */
.nb-grid2{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:16px}
.nb-fact{padding:clamp(22px,2.2vw,34px);color:var(--t2);line-height:1.65}
.nb-fact b{display:block;color:var(--t1);font-weight:500;font-size:clamp(17px,1.2vw,21px);margin-bottom:8px}
.nb-qs{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:16px}
.nb-q{padding:clamp(24px,2.4vw,40px)}
.nb-q-wide{grid-column:1/-1}
.nb-q h3{display:flex;gap:16px;align-items:baseline;font-size:clamp(21px,1.6vw,28px);font-weight:400;letter-spacing:-.02em;line-height:1.25;margin:0 0 20px;color:var(--t1)}
.nb-q-n{font-size:14px;font-weight:500;letter-spacing:0;color:var(--acc);flex-shrink:0}
.nb-quote{margin:0 0 22px;padding:18px 20px;border-left:2px solid var(--acc);background:rgba(124,134,255,.06);border-radius:0 10px 10px 0;color:var(--t1);line-height:1.6;font-size:clamp(15px,1.02vw,17px)}
.nb-quote-k{display:block;font-size:12px;font-weight:500;letter-spacing:.12em;text-transform:uppercase;color:var(--acc);margin-bottom:8px}
.nb-dl{display:grid;grid-template-columns:minmax(120px,.3fr) minmax(0,1fr);margin:0}
.nb-dl dt{color:var(--t3);font-size:14px;line-height:1.5;padding:12px 16px 12px 0;border-top:1px solid var(--line2)}
.nb-dl dd{margin:0;color:var(--t2);line-height:1.6;padding:12px 0;border-top:1px solid var(--line2)}
.nb-q-wide .nb-dl{grid-template-columns:minmax(140px,.16fr) minmax(0,1fr)}
.nb-q .nb-tbl{margin:12px 0 18px}
.nb-q-note{color:var(--t2);line-height:1.62;margin:0 0 8px;max-width:1160px}
.nb-food{margin-top:clamp(28px,2.6vw,44px);padding:clamp(24px,2.4vw,40px)}
.nb-food h3{font-size:clamp(20px,1.5vw,26px);font-weight:400;letter-spacing:-.02em;line-height:1.3;margin:0 0 12px;color:var(--t1)}
.nb-food p{margin:0;color:var(--t2);line-height:1.65;max-width:1200px}
.nb-page .nb-steps{grid-template-columns:repeat(3,minmax(0,1fr));gap:28px 18px}
.nb-errs{list-style:none;padding:0;margin:0;display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:0 clamp(24px,3vw,56px);max-width:1440px}
.nb-errs li{position:relative;padding:16px 0 16px 34px;border-top:1px solid var(--line2);color:var(--t2);line-height:1.6}
.nb-errs li::before,.nb-errs li::after{content:"";position:absolute;left:3px;top:27px;width:14px;height:2px;background:var(--red);transform:rotate(45deg)}
.nb-errs li::after{transform:rotate(-45deg)}
.nb-errs-wrap{display:grid;grid-template-columns:minmax(0,1.3fr) minmax(0,.7fr);gap:clamp(24px,3.4vw,64px);align-items:start}
.nb-errs-wrap .nb-errs{grid-template-columns:minmax(0,1fr)}
.nb-errs-ph{margin:0;position:sticky;top:110px}
.nb-errs-ph img{display:block;width:100%;height:auto;border-radius:var(--r);border:1px solid var(--line2);background:#18181b}
.nb-errs-ph figcaption{margin-top:10px;color:var(--t3);font-size:13px;line-height:1.5}

@media (max-width:1100px){
  .nb-links{grid-template-columns:repeat(2,minmax(0,1fr))}
}
@media (max-width:900px){
  .nb-qs,.nb-author-wrap,.nb-errs-wrap{grid-template-columns:minmax(0,1fr)}
  .nb-errs-ph{position:static;max-width:640px}
  .nb-page .nb-steps{grid-template-columns:repeat(2,minmax(0,1fr))}
}
@media (max-width:760px){
  .nb-five,.nb-grid2,.nb-errs{grid-template-columns:minmax(0,1fr)}
  .nb-toc{gap:6px}
  .nb-toc a{padding:8px 13px;font-size:13px}
}
@media (max-width:600px){
  .nb-links{grid-template-columns:minmax(0,1fr)}
  .nb-link{min-height:0}
  .nb-link-wide{display:flex;flex-direction:column}
  .nb-link-wide .nb-link-img{aspect-ratio:4/3;border-right:0;border-bottom:1px solid var(--line)}
  .nb-link-txt{padding:4px clamp(22px,2vw,32px) clamp(22px,2vw,30px)}
  .nb-page .nb-steps{grid-template-columns:minmax(0,1fr)}
  .nb-dl,.nb-q-wide .nb-dl{grid-template-columns:minmax(0,1fr)}
  .nb-dl dt{padding-bottom:2px}
  .nb-dl dd{border-top:0;padding-top:2px}
  .nb-avatar{width:80px;height:80px}
  .nb-author{align-items:flex-start}
  .nb-five li{padding-left:22px;padding-top:82px}
  .nb-five .nb-ic{top:24px;left:22px}
  .nb-q h3{flex-direction:column;gap:6px}
}

/* ---------- инфографика раздела: свёрстана кодом, текст остаётся текстом ---------- */
.nb-fig{margin:0 0 clamp(32px,3vw,52px)}
.nb-fig-head{display:flex;flex-direction:column;gap:6px;margin:0 0 18px}
.nb-fig-t{font-size:clamp(21px,1.6vw,28px);font-weight:300;letter-spacing:-.025em;line-height:1.22;color:var(--t1)}
.nb-fig-t em{font-style:italic;font-weight:500}
.nb-fig-d{color:var(--t2);font-size:15px;line-height:1.55;max-width:860px}
.nb-fig-note{color:var(--t3);font-size:13px;line-height:1.5;margin:14px 0 0}
.nb-ic{display:grid;place-items:center;flex:none;width:42px;height:42px;border-radius:12px;background:rgba(124,134,255,.1);border:1px solid rgba(124,134,255,.28);color:var(--acc)}
.nb-ic svg{width:20px;height:20px}

/* месяц на объекте особого значения */
.nb-cal{display:grid;grid-template-columns:minmax(170px,.9fr) repeat(4,minmax(0,1fr));border:1px solid var(--line2);border-radius:var(--r);overflow:hidden;background:var(--card)}
.nb-cal-row{display:contents}
.nb-cal-r,.nb-cal-c,.nb-cal-h{display:flex;align-items:center;min-height:66px;padding:14px 16px;border-bottom:1px solid var(--line)}
.nb-cal-c,.nb-cal-h{border-left:1px solid var(--line)}
.nb-cal-hd>*{min-height:46px;background:rgba(255,255,255,.03)}
.nb-cal-h{color:var(--t3);font-size:12px;letter-spacing:.08em;text-transform:uppercase}
.nb-cal-r{flex-direction:column;align-items:flex-start;justify-content:center;gap:2px}
.nb-cal-r b{color:var(--t1);font-weight:500;font-size:15px;line-height:1.3}
.nb-cal-r small{color:var(--t3);font-size:12px;line-height:1.35}
.nb-cal-row:last-child>*{border-bottom:0}
.nb-dot{display:inline-flex;align-items:center;gap:8px;font-size:13px;line-height:1.3;color:var(--t2);border:1px solid;border-radius:99px;padding:6px 12px 6px 7px}
.nb-dot>b{flex:none;display:inline-grid;place-items:center;width:22px;height:22px;border-radius:50%;color:#000;font-size:12px;font-weight:700}
.nb-dot-w{display:none}
.nb-dot.is-ins{border-color:rgba(124,134,255,.45)}.nb-dot.is-ins>b{background:var(--acc)}
.nb-dot.is-rod{border-color:rgba(255,137,4,.45)}.nb-dot.is-rod>b{background:var(--org)}
.nb-dot.is-bin{border-color:rgba(5,223,114,.4)}.nb-dot.is-bin>b{background:var(--grn)}
.nb-dot.is-tr{border-style:dashed;border-color:var(--t4);color:var(--t3)}.nb-dot.is-tr>b{background:none;border:1px dashed var(--t3);color:var(--t3)}
/* до 900 px (телефон и планшет) — карточка на каждую строку: что проверяют, норма и отметки «Неделя N · …» */
@media (max-width:900px){
  .nb-cal{display:flex;flex-direction:column;gap:10px;border:0;border-radius:0;background:none;overflow:visible}
  .nb-cal-row{display:flex;flex-wrap:wrap;gap:8px;padding:16px;border:1px solid var(--line2);border-radius:var(--r);background:var(--card)}
  .nb-cal-hd{display:none}
  .nb-cal-r,.nb-cal-c,.nb-cal-row:last-child>*{min-height:0;padding:0;border:0}
  .nb-cal-r{flex:1 1 100%;margin-bottom:4px}
  .nb-cal-c:empty{display:none}
  .nb-dot-w{display:inline}
}

/* дорожная карта норм: на компьютере ось слева направо, на телефоне — сверху вниз */
.nb-road{list-style:none;margin:0;padding:0;position:relative;height:300px}
.nb-road-axis{position:absolute;left:0;right:0;top:150px;height:2px;background:rgba(124,134,255,.55)}
.nb-road-fill{position:absolute;left:0;top:0;bottom:0;background:var(--t4)}
.nb-road-pt{position:absolute;top:0;left:var(--x);width:clamp(132px,12.5vw,200px);transform:translateX(-50%);display:flex;flex-direction:column;align-items:center;text-align:center}
.nb-road-pt::before{content:"";flex:none;width:18px;height:18px;border-radius:50%;border:2px solid var(--acc);background:var(--bg2);box-shadow:0 0 0 6px rgba(124,134,255,.12);box-sizing:border-box}
.nb-road-pt time{font-weight:600;font-size:15px;line-height:1.3;color:var(--acc);margin-bottom:6px}
.nb-road-pt span{color:var(--t2);font-size:13px;line-height:1.4}
.nb-road-pt.is-up{height:159px;justify-content:flex-end}
.nb-road-pt.is-up::before{order:3;margin-top:14px}
.nb-road-pt.is-down{top:141px}
.nb-road-pt.is-down::before{margin-bottom:14px}
.nb-road-pt.is-past time,.nb-road-pt.is-past span{color:var(--t3)}
.nb-road-pt.is-past::before{border-color:var(--t4);background:var(--t4);box-shadow:none}
.nb-road-now{position:absolute;left:var(--x);top:151px;transform:translate(-50%,-50%);z-index:2}
.nb-road-now span{display:block;white-space:nowrap;font-size:11px;font-weight:700;letter-spacing:.06em;text-transform:uppercase;color:#000;background:var(--yel);border-radius:99px;padding:4px 10px;box-shadow:0 0 0 5px rgba(253,199,0,.16)}
@media (max-width:760px){
  .nb-road{height:auto;display:flex;flex-direction:column;gap:20px;padding:2px 0 2px 34px}
  .nb-road-axis{left:8px;right:auto;top:8px;bottom:8px;width:2px;height:auto;background:var(--line2)}
  .nb-road-fill{display:none}
  .nb-road-pt,.nb-road-pt.is-up,.nb-road-pt.is-down{position:relative;left:auto;top:auto;width:auto;height:auto;transform:none;align-items:flex-start;justify-content:flex-start;text-align:left;order:var(--o)}
  .nb-road-pt::before,.nb-road-pt.is-up::before,.nb-road-pt.is-down::before{position:absolute;left:-34px;top:1px;margin:0}
  .nb-road-pt time{margin-bottom:2px}
  .nb-road-pt span{font-size:14px}
  .nb-road-now{position:relative;left:auto;top:auto;transform:none;order:var(--o);margin-left:-34px;align-self:flex-start}
}

/* от закона до журнала */
.nb-tier-list{list-style:none;margin:0;padding:0;display:grid;gap:18px}
.nb-tier{position:relative;display:grid;grid-template-columns:minmax(190px,.26fr) minmax(0,1fr);border:1px solid var(--line2);border-radius:var(--r);background:var(--card)}
.nb-tier+.nb-tier::before{content:"";position:absolute;left:clamp(40px,4vw,64px);top:-15px;width:8px;height:8px;border-right:1.5px solid var(--t4);border-bottom:1.5px solid var(--t4);transform:rotate(45deg)}
.nb-tier-n{display:flex;flex-direction:column;justify-content:center;gap:2px;padding:18px 20px;border-right:1px solid var(--line2)}
.nb-tier-n b{font-size:15px;font-weight:600;color:var(--t1)}
.nb-tier-n small{font-size:12px;line-height:1.35;color:var(--t3)}
.nb-tier-ch{display:flex;flex-wrap:wrap;align-items:center;gap:8px;padding:14px 18px}
.nb-chip{display:inline-block;font-size:13px;line-height:1.3;color:var(--t1);border:1px solid var(--line2);border-radius:99px;padding:6px 12px;background:rgba(255,255,255,.02);transition:border-color .2s,background .2s}
span.nb-chip{color:var(--t2)}
a.nb-chip:hover,a.nb-chip:focus-visible{border-color:var(--acc);background:rgba(124,134,255,.08)}
.nb-chip.is-key{border-color:rgba(124,134,255,.55);background:rgba(124,134,255,.12)}
.nb-tier.is-own{border-color:rgba(124,134,255,.45);background:rgba(124,134,255,.06)}
@media (max-width:760px){
  .nb-tier{grid-template-columns:minmax(0,1fr)}
  .nb-tier-n{border-right:0;border-bottom:1px solid var(--line2);padding:14px 16px}
  .nb-tier-ch{padding:12px 16px 14px}
}

/* выберите вид объекта */
.nb-objs{display:grid;grid-template-columns:repeat(6,minmax(0,1fr));gap:14px}
.nb-obj{display:flex;flex-direction:column;overflow:hidden;color:var(--t1)}
.nb-obj-img{display:block;aspect-ratio:16/10;overflow:hidden;background:#18181b}
.nb-obj-img img{display:block;width:100%;height:100%;object-fit:cover;transition:transform .7s cubic-bezier(.16,1,.3,1)}
.nb-obj:hover .nb-obj-img img,.nb-obj:focus-visible .nb-obj-img img{transform:scale(1.05)}
.nb-obj-t{display:flex;flex-direction:column;gap:3px;padding:12px 14px 14px}
.nb-obj-t b{font-size:14px;font-weight:600;line-height:1.3}
.nb-obj-t small{font-size:12px;line-height:1.35;color:var(--t3)}
@media (max-width:1100px){.nb-objs{grid-template-columns:repeat(3,minmax(0,1fr))}}
@media (max-width:600px){.nb-objs{grid-template-columns:repeat(2,minmax(0,1fr));gap:10px}}

/* было → стало */
.nb-bs{display:grid;grid-template-columns:minmax(0,1fr) 64px minmax(0,1.3fr);align-items:center;gap:10px}
.nb-bs-col{display:grid;gap:12px}
.nb-ord{border:1px solid var(--line2);border-radius:var(--r);padding:18px 20px;background:var(--card)}
.nb-ord b{display:block;font-size:17px;font-weight:600;color:var(--t1);margin-bottom:4px}
.nb-ord>span:not(.nb-ord-n){color:var(--t2);font-size:14px;line-height:1.5}
.nb-ord.is-old{background:none;border-style:dashed}
.nb-ord.is-old b{color:#c4c4cc;text-decoration:line-through;text-decoration-color:var(--red);text-decoration-thickness:2px}
.nb-ord.is-old>span{color:#a1a1aa}
.nb-ord.is-new{border-color:rgba(124,134,255,.5)}
.nb-ord-n{float:right;margin:0 0 6px 14px;font-size:34px;font-weight:300;line-height:1;color:var(--acc)}
.nb-bs-arrow{display:grid;place-items:center;color:var(--acc)}
.nb-bs-arrow svg{width:34px;height:34px}
.nb-bs-tot{margin:2px 0 0;color:var(--t3);font-size:14px}
@media (max-width:760px){
  .nb-bs{grid-template-columns:minmax(0,1fr)}
  .nb-bs-arrow svg{transform:rotate(90deg)}
}

/* фрагмент формы проверочного листа */
.nb-sheet{max-width:1120px;background:#f4f4f5;color:#18181b;border-radius:8px;padding:clamp(16px,2vw,28px);box-shadow:0 30px 60px rgba(0,0,0,.5);transform:rotate(-.5deg)}
.nb-sheet-h{display:flex;flex-wrap:wrap;justify-content:space-between;gap:6px 16px;margin:0 0 14px;font-size:12px;color:#52525c}
.nb-sheet table{width:100%;border-collapse:collapse;font-size:13px;line-height:1.45}
.nb-sheet th{text-align:left;font-weight:600;font-size:12px;color:#18181b;background:#e4e4e7;border:1px solid #a1a1aa;padding:8px}
.nb-sheet td{vertical-align:top;border:1px solid #a1a1aa;padding:8px;background:rgba(124,134,255,.09)}
.nb-sheet-n{width:40px;font-weight:600}
.nb-sheet-norm{width:200px;color:#52525c;font-size:12px}
.nb-sheet-c{width:58px;text-align:center}
.nb-box{display:inline-block;position:relative;vertical-align:middle;width:16px;height:16px;border:1.5px solid #3f3f46;border-radius:2px}
.nb-box.is-on::after{content:"";position:absolute;left:4px;top:0;width:5px;height:10px;border:solid var(--acc2);border-width:0 2.5px 2.5px 0;transform:rotate(45deg)}
@media (max-width:760px){
  .nb-sheet{transform:none;padding:14px}
  .nb-sheet thead{display:none}
  .nb-sheet table,.nb-sheet tbody{display:block}
  .nb-sheet tr{display:flex;flex-wrap:wrap;align-items:center;gap:6px 16px;margin-bottom:10px;padding:12px;border:1px solid #a1a1aa;border-radius:6px;background:rgba(124,134,255,.09)}
  .nb-sheet tr:last-child{margin-bottom:0}
  .nb-sheet td{display:block;border:0;padding:0;background:none}
  .nb-sheet-n{flex:0 0 26px;align-self:flex-start}
  .nb-sheet-q{flex:1 1 calc(100% - 42px)}
  .nb-sheet-norm{flex:1 1 100%;width:auto;padding-left:42px!important}
  .nb-sheet-c{flex:0 0 auto;width:auto;display:inline-flex!important;align-items:center;gap:6px}
  .nb-sheet-c:nth-child(4){margin-left:42px}
  .nb-sheet-c::after{content:attr(data-l);font-size:12px;color:#52525c}
}

/* папка к проверке */
.nb-folder{display:grid;grid-template-columns:repeat(5,minmax(0,1fr));gap:16px}
.nb-fdoc{display:flex;flex-direction:column;gap:6px;padding:12px 12px 18px;color:var(--t1)}
.nb-fdoc-img{display:block;aspect-ratio:3/4;overflow:hidden;border-radius:8px;background:#fff;margin-bottom:8px}
.nb-fdoc-img img{display:block;width:100%;height:100%;object-fit:cover;object-position:50% 0;transition:transform .7s cubic-bezier(.16,1,.3,1)}
.nb-fdoc-img.is-photo img{object-position:50% 50%}
.nb-fdoc:hover .nb-fdoc-img img,.nb-fdoc:focus-visible .nb-fdoc-img img{transform:scale(1.03)}
.nb-fdoc b{font-size:15px;font-weight:600;line-height:1.3;padding:0 4px}
.nb-fdoc small{font-size:13px;line-height:1.4;color:var(--t3);padding:0 4px}
@media (max-width:1100px){.nb-folder{grid-template-columns:repeat(3,minmax(0,1fr))}}
@media (max-width:600px){.nb-folder{grid-template-columns:repeat(2,minmax(0,1fr));gap:10px}}

/* иконки: виды объектов в таблице, шаги подготовки */
.nb-obj-ic{display:inline-flex;align-items:center;gap:12px;color:var(--t1)}
.nb-obj-ic .nb-ic{width:34px;height:34px;border-radius:10px}
.nb-obj-ic .nb-ic svg{width:17px;height:17px}
.nb-page .nb-steps li::before{display:inline-block;vertical-align:middle;margin:0 12px 14px 0}
.nb-steps .nb-ic{display:inline-grid;vertical-align:middle;width:36px;height:36px;border-radius:10px;margin:0 0 14px}
.nb-steps .nb-ic svg{width:18px;height:18px}
/* «Документы для Роспотребнадзора» (/normativnaya-baza/dokumenty-dlya-rospotrebnadzora/): свои блоки dk-*, остальное — из page.css (nb-*) */
/* первый экран — как у хаба и проверочных листов (page.css: .d-hero.nb-hero), свои — ссылка на PDF и кадр фото */
.dk-pdf-line{margin:20px 0 0}
.dk-pdf-line a{display:inline-flex;align-items:center;gap:10px;color:var(--t2);font-size:15px;line-height:1.4;border-bottom:1px solid rgba(124,134,255,.35);padding-bottom:2px;transition:color .25s,border-color .25s}
.dk-pdf-line a:hover,.dk-pdf-line a:focus-visible{color:var(--t1);border-color:var(--t1)}
.dk-pdf-line svg{width:18px;height:18px;flex:none;color:var(--acc)}
.dk-hero .d-hero-media::before{background:linear-gradient(90deg,rgba(0,0,0,.95) 0%,rgba(0,0,0,.9) 42%,rgba(0,0,0,.42) 58%,rgba(0,0,0,0) 70%),linear-gradient(180deg,#000 0,rgba(0,0,0,.55) 90px,rgba(0,0,0,0) 260px),linear-gradient(0deg,#000 0,rgba(0,0,0,.65) 110px,rgba(0,0,0,0) 300px)}

/* чек-лист PDF: обложка, описание, кнопка */
.dk-pdfcard{display:grid;grid-template-columns:132px minmax(0,1fr) auto;gap:clamp(20px,2.6vw,44px);align-items:center;margin-top:clamp(28px,2.6vw,44px);padding:clamp(22px,2.2vw,34px) clamp(22px,2.8vw,48px)}
.dk-cover{display:block;border-radius:6px;overflow:hidden;box-shadow:0 18px 40px -14px rgba(0,0,0,.8),0 0 0 1px rgba(255,255,255,.1);transform:rotate(-2deg);transition:transform .4s var(--ease)}
.dk-pdfcard:hover .dk-cover{transform:rotate(0) translateY(-2px)}
.dk-cover img{display:block;width:100%;height:auto;background:#fff}
.dk-pdfcard-k{margin:0 0 10px;font-size:clamp(19px,1.4vw,24px);font-weight:400;letter-spacing:-.02em;line-height:1.3;color:var(--t1)}
.dk-pdfcard-t p:last-child{margin:0;color:var(--t2);line-height:1.62;max-width:820px}
.dk-pdfcard-b{white-space:nowrap}
/* образец акта под таблицей «Акты»: та же карточка, две кнопки (образец и бланк) */
.dk-aktcard{margin-top:16px}
.dk-aktcard-b{display:flex;flex-direction:column;gap:10px}
.dk-aktcard-b .btn{white-space:nowrap;justify-content:center}
/* строка перечня, к которой перешли из поиска по сайту (tools/search) или по ссылке #p3-4 */
.dk-tbl tr:target>td,.dk-tbl tr.dk-hl>td{background:rgba(97,95,255,.14);transition:background .6s}

/* восемь групп */
.dk-gs{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:16px}
.dk-g{display:flex;flex-direction:column;gap:10px;padding:clamp(20px,1.8vw,28px);color:var(--t1);min-height:220px}
.dk-g-n{font-size:14px;font-weight:500;color:var(--acc)}
.dk-g b{font-weight:400;font-size:clamp(18px,1.25vw,22px);line-height:1.3;letter-spacing:-.01em}
.dk-g-d{color:var(--t2);font-size:15px;line-height:1.55}
.dk-g-c{margin-top:auto;color:var(--t3);font-size:14px;transition:color .25s}
.dk-g:hover .dk-g-c,.dk-g:focus-visible .dk-g-c{color:var(--t1)}

/* конструктор */
.dk-picks{display:flex;flex-wrap:wrap;gap:10px;margin:0 0 28px}
.dk-pick{display:inline-flex;align-items:center;gap:10px;min-height:46px;padding:8px 10px 8px 18px;border:1.4px solid var(--line2);border-radius:999px;background:rgba(255,255,255,.03);color:var(--t2);font:inherit;font-size:15px;cursor:pointer;transition:border-color .25s,color .25s,background .25s}
.dk-pick small{min-width:30px;padding:3px 8px;border-radius:999px;background:rgba(255,255,255,.07);color:var(--t3);font-size:13px;text-align:center;transition:background .25s,color .25s}
.dk-pick:hover,.dk-pick:focus-visible{border-color:var(--acc);color:var(--t1)}
.dk-pick[aria-pressed="true"]{border-color:var(--acc);background:rgba(124,134,255,.14);color:var(--t1)}
.dk-pick[aria-pressed="true"] small{background:var(--acc2);color:#fff}
.dk-list{min-height:96px}
.dk-empty{margin:0;padding:26px 28px;border:1.4px dashed var(--line2);border-radius:var(--r);color:var(--t2);line-height:1.6;max-width:900px}
.dk-lg{margin:0 0 26px}
.dk-lg h3{display:flex;gap:12px;align-items:baseline;margin:0 0 6px;font-size:clamp(17px,1.15vw,20px);font-weight:500;color:var(--t1)}
.dk-lg h3 span{color:var(--acc);font-size:14px}
.dk-row{display:grid;grid-template-columns:52px minmax(0,1fr) auto;gap:6px 16px;align-items:center;padding:12px 0;border-top:1px solid var(--line2)}
.dk-row:last-child{border-bottom:1px solid var(--line2)}
.dk-row-n{color:var(--acc);font-weight:500;font-size:15px;white-space:nowrap}
.dk-row-t{color:var(--t1);line-height:1.45}
.dk-row-t small{display:block;color:var(--t3);font-size:13px;margin-top:2px}
.dk-seg{display:inline-flex;gap:6px}
.dk-seg button{min-width:44px;min-height:38px;padding:0 14px;border:1.4px solid var(--line2);border-radius:999px;background:transparent;color:var(--t2);font:inherit;font-size:14px;cursor:pointer;transition:border-color .2s,background .2s,color .2s}
.dk-seg button:hover,.dk-seg button:focus-visible{border-color:var(--acc);color:var(--t1)}
.dk-seg button[aria-pressed="true"][data-v="y"]{background:rgba(5,223,114,.14);border-color:rgba(5,223,114,.7);color:#d1fae5}
.dk-seg button[aria-pressed="true"][data-v="n"]{background:rgba(255,100,103,.14);border-color:rgba(255,100,103,.75);color:#ffe4e6}
.dk-seg button[aria-pressed="true"][data-v="x"]{background:rgba(255,255,255,.14);border-color:rgba(255,255,255,.6);color:#fff}
.dk-row.is-y .dk-row-t{color:var(--t2)}
.dk-row.is-n .dk-row-n{color:#ff8a8c}
.dk-row.is-x .dk-row-t{color:var(--t3)}
.dk-bar{position:sticky;bottom:14px;z-index:6;display:flex;flex-wrap:wrap;align-items:center;justify-content:space-between;gap:14px 24px;margin-top:22px;padding:14px 14px 14px 24px;border:1.4px solid var(--line2);border-radius:20px;background:rgba(12,12,16,.94);-webkit-backdrop-filter:blur(10px);backdrop-filter:blur(10px)}
.dk-bar[hidden]{display:none}
@media (min-width:761px){.dk-bar{margin-right:max(0px,calc(96px - (100vw - 100%) / 2))}}  /* не под кнопками мессенджеров */
.dk-mini{display:none}
.dk-count{margin:0;color:var(--t2);font-size:15px;line-height:1.5}
.dk-count b{color:var(--t1);font-weight:500}
.dk-count .dk-miss{color:#ffb3b5}
.dk-acts{display:flex;flex-wrap:wrap;gap:10px}
.dk-acts .btn{height:48px;padding:0 22px;font-size:15px}
.dk-privacy{margin:16px 0 0;color:var(--t3);font-size:14px;line-height:1.55}
.dk-privacy a{color:var(--t2);border-bottom:1px solid rgba(124,134,255,.45)}

/* таблицы групп */
.dk-sec .head{margin-bottom:clamp(32px,3vw,56px)}
.dk-tbl{font-size:15px}
.dk-tbl td{color:var(--t2)}
.dk-tbl td b{display:block;color:var(--t1);font-weight:500;line-height:1.45}
.dk-note{display:block;margin-top:4px;color:var(--t2);font-size:14px;line-height:1.55}
.dk-n{color:var(--acc)!important;font-weight:500;white-space:nowrap}
.dk-ours{color:var(--acc2);margin-left:6px;font-size:12px;vertical-align:1px}
.dk-sec tr:target td{background:rgba(124,134,255,.08)}
@media (min-width:901px){
  .dk-tbl td:nth-child(1){width:6.5%}
  .dk-tbl td:nth-child(2){width:29%}
  .dk-tbl td:nth-child(3){width:13%}
  .dk-tbl td:nth-child(4){width:22%}
  .dk-tbl td:nth-child(5){width:14%}
  .dk-tbl td:nth-child(6){width:15.5%}
}
@media (max-width:900px){
  /* карточка пункта: номер и название, ниже — короткие строки «подпись — значение» */
  .dk-tbl tr{padding:6px 16px 10px}
  .dk-tbl td.dk-n{font-size:16px;padding-bottom:4px}
  .dk-tbl td.dk-n::before{display:none}
  .dk-tbl td.dk-n+td{border-top:0;padding-top:0;padding-bottom:12px}
  .dk-tbl td.dk-n+td::before{display:none}
  .dk-tbl td:nth-child(n+3){position:relative;padding:6px 0 6px 116px;font-size:14px;line-height:1.5}
  .dk-tbl td:nth-child(n+4){border-top:0}
  .dk-tbl td:nth-child(n+3)::before{position:absolute;left:0;top:6px;width:104px;margin:0;font-size:12.5px;line-height:1.6}
  .dk-tbl td:nth-child(3){padding-top:10px}
  .dk-tbl td:nth-child(3)::before{top:10px}
  .dk-tbl td.dk-0{display:none}
}
@media (max-width:380px){
  /* узкие телефоны: «СанПиН 2.3/2.4.4282-26;» помещается в колонку значения */
  .dk-tbl tr{padding:6px 12px 10px}
  .dk-tbl td:nth-child(n+3){padding-left:98px}
  .dk-tbl td:nth-child(n+3)::before{width:90px;font-size:12px}
}
.dk-akt{margin-top:clamp(28px,2.6vw,44px);padding:clamp(24px,2.4vw,40px);color:var(--t2);line-height:1.65}
.dk-akt-h{margin:0 0 12px;font-size:clamp(20px,1.5vw,26px);font-weight:400;letter-spacing:-.02em;line-height:1.3;color:var(--t1)}
.dk-akt p{margin:0;max-width:1100px}
.dk-akt ul{margin:12px 0 16px;padding-left:22px;columns:2;column-gap:56px}
.dk-akt li{break-inside:avoid;margin-bottom:4px}
.dk-akt a{color:var(--t1);border-bottom:1px solid rgba(124,134,255,.45)}

/* по видам объектов: на компьютере — вкладки, на телефоне — аккордеон */
.dk-tabs{display:none}
.dk-o{border:1.4px solid var(--line);border-radius:var(--r);background:var(--card);margin-bottom:12px}
.dk-o summary{list-style:none;cursor:pointer;display:flex;align-items:center;justify-content:space-between;gap:16px;padding:18px 64px 18px 22px;position:relative;color:var(--t1);font-size:17px}
.dk-o summary::-webkit-details-marker{display:none}
.dk-o summary small{color:var(--t3);font-size:14px;white-space:nowrap}
.dk-o summary::after{content:"+";position:absolute;right:20px;top:50%;width:30px;height:30px;margin-top:-15px;border:1px solid var(--line2);border-radius:50%;display:flex;align-items:center;justify-content:center;color:var(--t2);font-size:17px;line-height:1}
.dk-o[open] summary::after{content:"−"}
.dk-o-b{display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1fr);gap:clamp(20px,3vw,56px);padding:4px 22px 24px}
.dk-o-k{margin:18px 0 8px;font-size:12px;font-weight:500;letter-spacing:.12em;text-transform:uppercase;color:var(--acc)}
.dk-o-col>.dk-o-k:first-child{margin-top:0}
.dk-x{list-style:none;padding:0;margin:0}
.dk-x li{padding:9px 0;border-top:1px solid var(--line2);color:var(--t1);line-height:1.5}
.dk-x-n{color:var(--acc);font-weight:500;margin-right:6px}
.dk-x-c{color:var(--t3)}
.dk-x-none,.dk-o-cl{margin:0;color:var(--t2);line-height:1.6}
.dk-imp{margin:0;padding-left:20px;color:var(--t2);line-height:1.62}
.dk-imp li+li{margin-top:8px}
.dk-o-page{margin:18px 0 0}
.dk-o-page a{color:var(--t1);border-bottom:1px solid rgba(124,134,255,.45)}
@media (min-width:761px){
  .js .dk-tabs{display:flex;flex-wrap:wrap;gap:8px;margin:0 0 18px}
  .js .dk-tab{padding:10px 18px;border:1.4px solid var(--line2);border-radius:999px;background:transparent;color:var(--t2);font:inherit;font-size:15px;cursor:pointer;transition:border-color .25s,color .25s,background .25s}
  .js .dk-tab:hover,.js .dk-tab:focus-visible{border-color:var(--acc);color:var(--t1)}
  .js .dk-tab[aria-selected="true"]{border-color:var(--acc);background:rgba(124,134,255,.14);color:var(--t1)}
  .js .dk-o summary{display:none}
  .js .dk-o:not([open]){display:none}
  .js .dk-o-b{padding-top:clamp(22px,2.2vw,34px)}
}

/* как запрашивают документы */
.dk-rules{list-style:none;padding:0;margin:0;max-width:1240px}
.dk-rules li{position:relative;padding:16px 0 16px 34px;border-top:1px solid var(--line2);color:var(--t2);line-height:1.62}
.dk-rules li::before{content:"";position:absolute;left:4px;top:25px;width:9px;height:9px;border-radius:50%;background:var(--acc)}
.dk-rules b{color:var(--t1);font-weight:500}
.dk-rules a{color:var(--t1);border-bottom:1px solid rgba(124,134,255,.45)}
.dk-h3{margin-top:clamp(40px,3.6vw,64px)!important;margin-bottom:14px!important}

/* что готовим мы */
/* пять карточек: три в первом ряду, две во втором — на всю ширину */
.dk-we{display:grid;grid-template-columns:repeat(6,minmax(0,1fr));gap:16px}
.dk-we-c{grid-column:span 2;min-height:250px;padding-top:clamp(22px,2vw,30px)}
/* 6 карточек (с 10.11.2026 — «Лабораторные исследования»): два ряда по три */
.dk-we-d{color:var(--t2);font-size:15px;line-height:1.6}

/* печать списка из конструктора */
#dk-print-area{display:none}
@media print{
  body.dk-printing>*:not(#dk-print-area){display:none!important}
  body.dk-printing #dk-print-area{display:block;color:#000;font:12pt/1.45 Inter,Arial,sans-serif}
  #dk-print-area h1{font-size:18pt;margin:0 0 4pt}
  #dk-print-area p{margin:0 0 10pt}
  #dk-print-area h2{font-size:12.5pt;margin:12pt 0 4pt}
  #dk-print-area table{width:100%;border-collapse:collapse}
  #dk-print-area td{border:1px solid #bbb;padding:4pt 6pt;vertical-align:top}
  #dk-print-area td:first-child{width:9%;white-space:nowrap}
  #dk-print-area td:last-child{width:16%}
}

@media (max-width:1100px){
  .dk-gs{grid-template-columns:repeat(2,minmax(0,1fr))}
  .dk-we{grid-template-columns:repeat(2,minmax(0,1fr))}
  .dk-we-c,.dk-we-c:nth-child(n+4){grid-column:auto}
}
@media (max-width:1180px){
  /* телефон и планшет (решение владельца 08.11.2026, «вариант 1»): заголовок → фото → кнопки → PDF → абзац-ответ.
     В HTML порядок прежний (абзац сразу после фото) — меняется только показ */
  .dk-hero .dk-pdf-line{order:4}  /* общий порядок (кнопки 3, абзац 5, автор 6, крошки 7) — в page.css */
  .dk-hero .d-hero-media::before{background:linear-gradient(0deg,#000 0,rgba(0,0,0,0) 24%)}
}
@media (max-width:860px){
  /* высота фото и отступы кнопок и абзаца — общие, в page.css */
  .dk-hero .d-btns .btn{font-size:15px}  /* «Проверить папку с санитарным врачом» — в одну строку от 375 px */
  .dk-hero .dk-pdf-line{margin-top:16px}
}
@media (max-width:374px){
  .dk-hero .d-btns .btn{padding-left:10px;padding-right:10px}
}
@media (max-width:760px){
  .dk-pdfcard{grid-template-columns:64px minmax(0,1fr);gap:16px 18px}
  .dk-pdfcard-t{display:contents}
  .dk-pdfcard-k{align-self:center;margin:0}
  .dk-pdfcard-t p:last-child{grid-column:1/-1}
  .dk-pdfcard-b{grid-column:1/-1;justify-content:center}
  .dk-aktcard-b{grid-column:1/-1;display:grid;grid-template-columns:repeat(2,minmax(0,1fr))}
  .dk-aktcard-b .btn{height:48px;padding:0 14px;font-size:14px}
  .dk-o-b{grid-template-columns:minmax(0,1fr);gap:0}
  .dk-o-col+.dk-o-col{margin-top:18px}
  .dk-akt ul{columns:1}
  .dk-row{grid-template-columns:44px minmax(0,1fr)}
  .dk-seg{grid-column:2}
  .dk-bar{position:static;padding:12px;border-radius:16px}
  /* счётчик над нижней панелью сайта и слева от кнопок мессенджеров */
  .dk-mini:not([hidden]){display:flex;width:max-content;max-width:calc(100% - 64px);position:sticky;bottom:calc(88px + env(safe-area-inset-bottom));z-index:6;align-items:center;gap:10px;margin-top:14px;padding:10px 16px;border:1.4px solid var(--line2);border-radius:999px;background:rgba(12,12,16,.94);-webkit-backdrop-filter:blur(10px);backdrop-filter:blur(10px);color:var(--t2);font:inherit;font-size:14px;line-height:1.35;text-align:left;cursor:pointer}
  .dk-mini-t{white-space:nowrap;overflow:hidden;text-overflow:ellipsis;min-width:0}
  .dk-mini b{color:var(--t1);font-weight:500}
  .dk-mini .dk-miss{color:#ffb3b5}
  .dk-mini-go{color:var(--acc)}
  .dk-acts{width:100%}
  .dk-acts .btn{flex:1 1 auto;height:46px;padding:0 16px;font-size:14px}
  .dk-acts .dk-dl{display:none}
}
@media (max-width:600px){
  .dk-gs,.dk-we{grid-template-columns:minmax(0,1fr)}
  .dk-g{min-height:0}
  .dk-we-c{min-height:0}
  .dk-pick{font-size:14px;min-height:44px;padding:6px 8px 6px 14px}
  /* название вида объекта, под ним число документов: длинные названия («Непродовольственный магазин») не наезжают на «+» */
  .dk-o summary{flex-direction:column;align-items:flex-start;justify-content:center;gap:3px;font-size:16px;padding:14px 58px 14px 18px;line-height:1.3}
  .dk-o summary small{font-size:13px}
  .dk-o-b{padding:2px 18px 20px}
}
/* образец акта: на узких телефонах кнопки «Скачать образец» и «Бланк для печати» одна под другой */
@media (max-width:440px){.dk-aktcard-b{grid-template-columns:minmax(0,1fr)}}</style>
<script type="application/ld+json">{"@context": "https://schema.org", "@graph": [{"@type": "Organization", "@id": "https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/#org", "name": "ПЕСТКОНТРОЛЬ Центр", "legalName": "ООО «Центр дезинфекционных услуг»", "url": "https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/", "telephone": "+7 495 104-35-70", "email": "b2b@pestcontrol-center.ru"}, {"@type": "BreadcrumbList", "itemListElement": [{"@type": "ListItem", "position": 1, "name": "Главная", "item": "https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/"}, {"@type": "ListItem", "position": 2, "name": "Нормативная база", "item": "https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/normativnaya-baza/"}, {"@type": "ListItem", "position": 3, "name": "Документы для Роспотребнадзора", "item": "https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/normativnaya-baza/dokumenty-dlya-rospotrebnadzora/"}]}, {"@type": "Article", "@id": "https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/normativnaya-baza/dokumenty-dlya-rospotrebnadzora/#article", "headline": "Документы для Роспотребнадзора: полный перечень для проверки", "description": "Какие документы нужны для проверки Роспотребнадзора: договоры, акты, протоколы лабораторных исследований, журналы и ППК. Перечень по объектам и чек-лист PDF.", "inLanguage": "ru", "datePublished": "2026-11-08", "dateModified": "2026-11-10", "author": {"@type": "Person", "name": "Марианна Семерина", "jobTitle": "Санитарный врач"}, "publisher": {"@id": "https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/#org"}, "mainEntityOfPage": "https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/normativnaya-baza/dokumenty-dlya-rospotrebnadzora/", "image": [{"@type": "ImageObject", "url": "https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/img/dok-hero.webp", "width": 1920, "height": 1072, "caption": "Менеджер по качеству отмечает пункты чек-листа рядом с папками документов для проверки, специалист по пест-контролю передаёт ей подписанный акт"}, {"@type": "ImageObject", "url": "https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/img/dok-og.jpg", "width": 1200, "height": 630}], "about": ["Проверка Роспотребнадзора", "Производственный контроль", "Дезинсекция и дератизация"], "isPartOf": {"@id": "https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/normativnaya-baza/#webpage"}, "hasPart": {"@type": "DigitalDocument", "name": "Чек-лист «Документы для Роспотребнадзора»", "encodingFormat": "application/pdf", "inLanguage": "ru", "url": "https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/normativnaya-baza/dokumenty-dlya-rospotrebnadzora/chek-list-dokumentov-dlya-rospotrebnadzora.pdf", "author": {"@type": "Person", "name": "Марианна Семерина", "jobTitle": "Санитарный врач"}, "publisher": {"@id": "https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/#org"}}}, {"@type": "FAQPage", "@id": "https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/normativnaya-baza/dokumenty-dlya-rospotrebnadzora/#faq", "mainEntity": [{"@type": "Question", "name": "Какие документы нужны для проверки Роспотребнадзора?", "acceptedAnswer": {"@type": "Answer", "text": "Программа производственного контроля, приказы об ответственных, договоры и акты по дезинсекции и дератизации, договоры и протоколы лабораторных исследований, договор на вывоз отходов, журналы, медкнижки и документы о медосмотрах, документы на продукцию и дезинфицирующие средства. Точный состав зависит от вида деятельности. Исчерпывающий перечень сведений, которые может запросить инспектор, публикуют управления Роспотребнадзора, а общий список и дополнения для 15 видов объектов — в таблицах выше и в чек-листе PDF."}}, {"@type": "Question", "name": "Какие договоры нужны для Роспотребнадзора?", "acceptedAnswer": {"@type": "Answer", "text": "Почти любому объекту нужны договоры на дезинсекцию и дератизацию с исполнителем, у которого есть лицензия, на лабораторные исследования по программе производственного контроля, на вывоз твёрдых коммунальных отходов с региональным оператором и на медосмотры. По ситуации добавляются договоры на стирку одежды и белья, очистку и дезинфекцию вентиляции, передачу ртутных ламп, утилизацию отходов производства и профилактическую дезинфекцию. К каждому договору храните акты выполненных работ."}}, {"@type": "Question", "name": "Какие документы проверяет Роспотребнадзор в общепите?", "acceptedAnswer": {"@type": "Answer", "text": "Кроме общего списка — программу производственного контроля на принципах ХАССП, гигиенический журнал, журналы температуры холодильного оборудования и температуры и влажности склада, записи о замене фритюрных жиров, технологические карты и товаросопроводительные документы (СанПиН 2.3/2.4.4282-26). При питании пациентов, детей и в организациях социального обслуживания добавляются журналы бракеража. Вопросы инспектора — в проверочном листе № 580, приложение 2."}}, {"@type": "Question", "name": "Нужен ли договор на дезинсекцию и дератизацию, если вредителей нет?", "acceptedAnswer": {"@type": "Answer", "text": "Да, если вы не проводите эти работы своими силами. Организации и ИП обязаны обследовать объекты и проводить профилактику независимо от того, есть ли вредители (п. 88 СанПиН 3.3686-21), а пищевым объектам, гостиницам и другим объектам из п. 98 нужны обследования на насекомых не реже 2 раз в месяц и ежемесячная оценка заселённости грызунами. Своими силами для собственных нужд можно работать без лицензии, но программа, журналы и учёт обследований всё равно нужны."}}, {"@type": "Question", "name": "Что должно быть в акте дезинсекции и дератизации?", "acceptedAnswer": {"@type": "Answer", "text": "Единой обязательной формы нет. Чтобы акт подтверждал работу на проверке, в нём указывают дату и время, помещения, вид работ, результаты обследования по точкам контроля, средство с номером свидетельства о госрегистрации, концентрацию и способ применения, меры безопасности, исполнителя с номером лицензии и подписи обеих сторон. В общепите время обработки особенно важно: во время дезинсекции и дератизации нельзя хранить и готовить продукцию (п. 45 СанПиН 2.3/2.4.4282-26)."}}, {"@type": "Question", "name": "Какие протоколы лабораторных исследований нужны?", "acceptedAnswer": {"@type": "Answer", "text": "Те, что предусмотрены вашей программой производственного контроля: обычно смывы, пробы воздуха, микроклимат, освещённость и шум, вода и продукция. Вместо замеров условий труда можно использовать результаты спецоценки не старше 6 месяцев. При централизованных системах кондиционирования и увлажнения добавляются исследования на легионеллы не реже 2 раз в год. Исследования выполняет аккредитованная лаборатория — своя или по договору. Все эти исследования делает наша лаборатория: отбираем пробы на объекте и передаём протоколы."}}, {"@type": "Question", "name": "Можно ли вести журналы и медкнижки в электронном виде?", "acceptedAnswer": {"@type": "Answer", "text": "Да. СанПиН общепита прямо разрешает вести гигиенический журнал, журналы температуры и записи о замене фритюрных жиров на бумаге или в электронном виде (пп. 25, 35, 44), правила торговли — журнал температуры и влажности (п. 38 СП 2.3.6.4281-26). Медкнижки формируются электронно, а бумажные прежней формы можно выдавать и вести до 1 сентября 2027 года. Инспектору документы по умолчанию тоже направляют в электронном виде."}}, {"@type": "Question", "name": "Сколько времени дают, чтобы представить документы?", "acceptedAnswer": {"@type": "Answer", "text": "Столько, сколько указано в требовании инспектора; при документарной проверке — 10 рабочих дней со дня получения требования. Если не успеваете, сразу направьте письменное ходатайство с причиной и новым сроком — инспектор ответит в течение 24 часов. При инспекционном визите документы, которые должны быть на объекте, показывают сразу."}}, {"@type": "Question", "name": "Какие документы нужны ИП для Роспотребнадзора?", "acceptedAnswer": {"@type": "Answer", "text": "Те же, что организации того же профиля: программа производственного контроля, договоры и акты, журналы, медкнижки работников, документы на продукцию. Вместо учредительных документов — документ о государственной регистрации ИП. Производственный контроль и дезинсекция с дератизацией обязательны для ИП так же, как для юридических лиц."}}, {"@type": "Question", "name": "Какие документы подают в Роспотребнадзор при открытии бизнеса?", "acceptedAnswer": {"@type": "Answer", "text": "Если вид деятельности есть в перечне постановления Правительства № 725, до начала работы через Госуслуги подают уведомление о начале деятельности. Для отдельных видов деятельности нужно санитарно-эпидемиологическое заключение — это отдельная госуслуга. Документы для проверки заранее никуда не подают: их показывают по требованию инспектора."}}]}]}</script>
<style id="srch-st">/* лупа поиска в шапке и раскладка шапки с ней (tools/menu/apply_menu.py) */.srch-btn{flex:none;width:44px;height:44px;padding:0;border-radius:50%;display:grid;place-items:center;background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.1);color:#fff;cursor:pointer;transition:color .25s,border-color .3s,background .3s,transform .35s cubic-bezier(.16,1,.3,1)}.srch-btn:hover{border-color:#7c86ff;background:rgba(97,95,255,.2);transform:translateY(-2px)}.srch-btn:focus-visible{outline:2px solid #7c86ff;outline-offset:2px}.srch-btn svg{width:18px;height:18px;display:block}@media (min-width:761px){.hdr .wrap{gap:16px}.hdr .msg{display:none}.srch-btn{width:38px;height:38px;background:none;border-color:transparent;color:var(--t2);margin-right:calc(4px - clamp(14px,2vw,40px))}.srch-btn svg{width:20px;height:20px}.srch-btn:hover{color:#fff;background:rgba(255,255,255,.07);border-color:rgba(255,255,255,.1);transform:none}}@media (min-width:761px) and (max-width:1440px){.hdr-right{gap:18px}.srch-btn{margin-right:-14px}}@media (min-width:761px) and (max-width:1000px){.hdr-right{gap:12px}.srch-btn{margin-right:-8px}}@media (max-width:900px){.logo-txt{display:flex;flex-direction:column;align-items:flex-start}.logo-sub{margin:0}}@media (max-width:760px){.hdr .wrap{gap:12px}.hdr-right{gap:8px}}@media (max-width:400px){.hdr .wrap{gap:10px}.srch-btn{width:40px;height:40px}}@media (max-width:360px){.hdr .wrap{gap:8px}.hdr-right{gap:6px}.srch-btn,.phone i,.burger{width:38px;height:38px}}@media (max-width:340px){.logo-mark{display:none}.logo-sub{display:block}}</style><script id="srch-js">/* поиск по сайту: движок и индекс загружаются по первому нажатию на лупу или «/» (tools/search) */(function(r,v){var d=document,ld=0,w=null;function go(o){if(window.PCSearch)return window.PCSearch.open(r,v,o);w=o;if(ld)return;ld=1;var s=d.createElement("script");s.src=r+"search.min.js?v="+v;s.async=true;s.onload=function(){window.PCSearch&&window.PCSearch.open(r,v,w)};s.onerror=function(){ld=0};d.head.appendChild(s)}d.addEventListener("click",function(e){var b=e.target.closest&&e.target.closest("[data-srch]");if(b){e.preventDefault();go({btn:b})}});d.addEventListener("keydown",function(e){if(e.key!=="/"||e.ctrlKey||e.metaKey||e.altKey)return;var t=e.target,n=t&&t.tagName;if(n==="INPUT"||n==="TEXTAREA"||n==="SELECT"||t.isContentEditable)return;e.preventDefault();go({})});if(/^#q\d+$/.test(location.hash)){var c=0,t=setInterval(function(){var b=d.getElementById(location.hash.slice(1));if(b&&d.documentElement.classList.contains("anim-ready")){clearInterval(t);if(b.getAttribute("aria-expanded")==="false")b.click()}else if(++c>60)clearInterval(t)},150)}})("../../","20261108");</script>
<style data-fx>
/* подсветка рамки карточек за курсором — как у .card на главной (tools/site/fx.py) */
:where(.d-card,.p-sec,.p-fcard,.p-duty-box,.p-dl-card,.pm-step-card,.pm-scen,.pm-link-card,.k-err,.w-sample,.d-doc-prev){position:relative}
:where(.d-card,.p-sec,.p-fcard,.p-duty-box,.p-dl-card,.pm-step-card,.pm-scen,.pm-link-card,.k-err,.w-sample,.d-doc-prev)::after{content:"";position:absolute;inset:0;border-radius:inherit;padding:1.4px;pointer-events:none;background:radial-gradient(360px circle at var(--mx,-999px) var(--my,-999px),rgba(124,134,255,.85),rgba(124,134,255,.15) 35%,transparent 60%);-webkit-mask:linear-gradient(#000 0 0) content-box,linear-gradient(#000 0 0);-webkit-mask-composite:xor;mask:linear-gradient(#000 0 0) content-box,linear-gradient(#000 0 0);mask-composite:exclude;opacity:0;transition:opacity .4s;z-index:2}
@media (hover:hover) and (pointer:fine){:where(.d-card,.p-sec,.p-fcard,.p-duty-box,.p-dl-card,.pm-step-card,.pm-scen,.pm-link-card,.k-err,.w-sample,.d-doc-prev):hover::after{opacity:1}}
/* «фонарь» на фото первого экрана — как на главной (tools/site/fx.py) */
.fx-lit{position:absolute;inset:0;opacity:0;pointer-events:none;-webkit-mask-image:radial-gradient(circle var(--sr,320px) at var(--sx,72%) var(--sy,46%),#000 0%,rgba(0,0,0,.55) 45%,transparent 72%);mask-image:radial-gradient(circle var(--sr,320px) at var(--sx,72%) var(--sy,46%),#000 0%,rgba(0,0,0,.55) 45%,transparent 72%);transition:opacity 1.8s cubic-bezier(.16,1,.3,1)}
#hero :is(.d-hero-media,.hero-media)>picture>img{transition:filter 1.8s cubic-bezier(.16,1,.3,1)}
#hero.fx-lit-on :is(.d-hero-media,.hero-media)>picture>img{filter:grayscale(.3) brightness(.56)}
#hero.fx-lit-on .fx-lit img{filter:brightness(1.08) contrast(1.06) saturate(1.06)}
#hero.fx-lit-on .fx-lit{opacity:1}
</style>
<style id="m-crumbs">/* крошки на телефоне не показываем: для SEO хватает BreadcrumbList и ссылок в HTML */@media (max-width:900px){.d-crumbs,.f-crumbs{display:none!important}}</style>
<style id="t-inset">/* таблицы: текст не прижимается к краю — отступ первой и последней колонки */@media (min-width:901px){.d-table tr>:first-child{padding-left:clamp(16px,1.5vw,24px)}.d-table tr>:last-child{padding-right:clamp(16px,1.5vw,24px)}}</style>
<style id="hero-fold">/* кнопки первого экрана видны целиком на любом экране (tools/site/hero_fold.py) */@media (max-width:760px){#hero.hero:not(.f-hero) .hero-copy{display:flex;flex-direction:column}#hero.hero:not(.f-hero) .hero-copy>*{order:6}#hero.hero:not(.f-hero) .hero-copy>.badge{order:1;align-self:flex-start}#hero.hero:not(.f-hero) .hero-copy>h1{order:2;margin-bottom:0}#hero.hero:not(.f-hero) .hero-copy>.hero-ctas{order:3;margin-top:22px}#hero.hero:not(.f-hero) .hero-copy>.lead{order:4;margin-top:24px}}@media (max-width:760px) and (max-height:620px){#hero.hero:not(.f-hero){padding-top:92px}#hero.hero:not(.f-hero) h1{margin-top:18px}}@media (max-width:900px){#hero.f-hero .hero-copy{display:flex;flex-direction:column}#hero.f-hero .hero-copy>*{order:6}#hero.f-hero .hero-copy>.f-crumbs{order:0}#hero.f-hero .hero-copy>.badge{order:1;align-self:flex-start}#hero.f-hero .hero-copy>h1{order:2;margin-bottom:0}#hero.f-hero .hero-copy>.hero-ctas{order:3;margin-top:22px}#hero.f-hero .hero-copy>.lead{order:4;margin-top:24px}#hero.f-hero .hero-media{aspect-ratio:auto;height:clamp(104px,calc(100vh - 440px),56.25vw);height:clamp(104px,calc(100svh - 440px),56.25vw)}}@media (max-width:760px){#hero.f-hero .hero-media{height:clamp(104px,calc(100vh - 440px),75vw);height:clamp(104px,calc(100svh - 440px),75vw)}.rp-page #hero.f-hero .hero-media,.lb-page #hero.f-hero .hero-media{height:clamp(104px,calc(100vh - 480px),75vw);height:clamp(104px,calc(100svh - 480px),75vw)}}@media (max-width:900px) and (max-height:620px){#hero.f-hero .hero-copy>.badge{display:none}#hero.f-hero .hero-media{height:clamp(96px,calc(100vh - 400px),75vw);height:clamp(96px,calc(100svh - 400px),75vw)}.rp-page #hero.f-hero .hero-copy>h1{font-size:clamp(26px,7.6vw,34px)}#hero.f-hero .hero-copy>h1{margin-top:30px}}@media (max-width:860px){#hero.d-hero .d-hero-media{aspect-ratio:auto;height:clamp(104px,calc(100vh - 380px),56.25vw);height:clamp(104px,calc(100svh - 380px),56.25vw)}}@media (max-width:860px) and (max-height:620px){#hero.d-hero{padding-top:84px}#hero.d-hero .d-hero-media{margin-top:14px}#hero.d-hero .d-btns{margin-top:16px}}@media (max-width:860px) and (max-height:520px){#hero.d-hero .d-hero-media{display:none}#hero.d-hero h1{margin-bottom:0}}@media (max-width:900px) and (max-height:520px){#hero.f-hero{padding-top:76px}#hero.f-hero .hero-media{display:none}#hero.f-hero .wrap{margin-top:0}#hero.f-hero .hero-copy>h1{margin-top:0}}@media (max-width:400px){#hero .hero-copy{min-width:0}#hero .hero-ctas .btn{min-width:0;max-width:100%;white-space:normal;padding:0 14px}#hero .hero-ctas .btn-t{white-space:normal;text-align:center}}@media (max-width:860px) and (max-height:620px){#hero.d-hero .d-hero-media{height:clamp(104px,calc(100vh - 410px),56.25vw);height:clamp(104px,calc(100svh - 410px),56.25vw)}}@media (max-height:520px){#hero.p-hero .p-hero-copy>.d-btns{order:3;margin-top:18px}#hero.p-hero .p-hero-copy>.p-def{order:4;margin-top:18px}}@media (max-width:760px) and (max-height:620px){#hero.p-hero .p-hero-copy>.d-btns{order:3;margin-top:18px}#hero.p-hero .p-hero-copy>.p-def{order:4;margin-top:18px}}@media (min-width:761px) and (max-height:520px){#hero.hero:not(.f-hero){padding-top:84px;min-height:0}#hero.hero:not(.f-hero) .hero-copy{display:flex;flex-direction:column}#hero.hero:not(.f-hero) .hero-copy>*{order:6}#hero.hero:not(.f-hero) .hero-copy>.badge{order:1;align-self:flex-start}#hero.hero:not(.f-hero) .hero-copy>h1{order:2;margin:14px 0 0}#hero.hero:not(.f-hero) .hero-copy>.hero-ctas{order:3;margin-top:18px}#hero.hero:not(.f-hero) .hero-copy>.lead{order:4;margin-top:18px}}@media (min-width:861px){#hero.d-hero .d-hero-copy{display:flex;flex-direction:column}#hero.d-hero .d-hero-copy>*{order:6}#hero.d-hero .d-hero-copy>.d-crumbs{order:0}#hero.d-hero .d-hero-copy>.eyebrow{order:1}#hero.d-hero .d-hero-copy>h1{order:2}#hero.d-hero .d-hero-copy>:is(.lead,.sub,.p-def):not(:is(.lead,.sub,.p-def)~*){order:3}#hero.d-hero .d-hero-copy>.d-btns:not(.d-btns~*){order:4}#hero.d-hero .d-hero-copy>.d-ticks{margin-bottom:0}}@media (min-width:901px){#hero.f-hero .hero-copy{display:flex;flex-direction:column}#hero.f-hero .hero-copy>*{order:6}#hero.f-hero .hero-copy>.f-crumbs{order:0}#hero.f-hero .hero-copy>.badge{order:1;align-self:flex-start}#hero.f-hero .hero-copy>h1{order:2}#hero.f-hero .hero-copy>.lead{order:3}#hero.f-hero .hero-copy>.hero-ctas{order:4}#hero.f-hero .hero-copy>.rp-hero-list{margin-top:26px}}@media (min-width:861px) and (max-height:820px){#hero.d-hero{padding-top:calc(clamp(68px,6vw,115px) + 8px)}#hero.d-hero .d-hero-copy>.d-crumbs{margin-bottom:0}#hero.d-hero .d-hero-copy>.eyebrow{margin:16px 0 0}#hero.d-hero .d-hero-copy>h1{margin-top:14px;line-height:1.02}#hero.d-hero .d-hero-copy>:is(.lead,.sub,.p-def){margin-top:16px}#hero.d-hero .d-btns{margin-top:20px}}@media (min-width:901px) and (max-height:820px){#hero.f-hero{padding-top:80px}#hero.f-hero .hero-copy>.f-crumbs{margin-bottom:10px}#hero.f-hero .hero-copy>h1{font-size:min(8.2vh,4.4vw);margin:16px 0 14px}.rp-page #hero.f-hero .hero-copy>h1,.lb-page #hero.f-hero .hero-copy>h1{font-size:min(8vh,3.4vw)}#hero.f-hero .hero-copy>.lead{line-height:1.5}#hero.f-hero .hero-copy>.hero-ctas{margin-top:26px}}@media (min-width:761px) and (max-height:820px){#hero.p-hero h1{font-size:min(8.4vh,4.4vw)}#hero.p-hero .p-hero-copy>.d-btns{margin-top:20px}}@media (min-width:761px) and (max-height:820px){#hero.hero:not(.f-hero) h1{font-size:min(8.4vh,4.4vw);margin:22px 0 18px}#hero.hero:not(.f-hero) .hero-ctas{margin-top:28px}}</style>
</head>
<body class="d-page nb-page">
<a class="skip" href="#main">Перейти к содержанию</a>

<!-- ============ INTRO ============ -->
<div class="intro" id="intro" aria-hidden="true">
  <div class="intro-in">
    <svg class="intro-mark" viewBox="0 0 24 24" fill="none" stroke-width="1" stroke-linejoin="round"><path class="im-shield" pathLength="100" d="M12 2.5l7.5 3v6c0 5-3.2 8.6-7.5 10-4.3-1.4-7.5-5-7.5-10v-6z" stroke="#fff"/><circle class="im-c" pathLength="100" cx="12" cy="11.5" r="2.6" stroke="#7c86ff"/><path class="im-x" pathLength="100" d="M12 6.2v2.7M12 14.1v2.7M6.8 11.5h2.6M14.6 11.5h2.6" stroke="#7c86ff"/></svg>
    <div class="intro-word"><span>ПЕСТКОНТРОЛЬ</span><b>Центр</b></div>
    <div class="intro-bar"><i></i></div>
  </div>
</div>

<div class="progress" aria-hidden="true"><i id="progress"></i></div>
<div class="cursor" aria-hidden="true"><i class="cursor-dot"></i><i class="cursor-ring"></i></div>
<div class="grain" aria-hidden="true"></div>

<header class="hdr" id="hdr">
  <div class="wrap">
    <a href="../../" class="logo" aria-label="ПЕСТКОНТРОЛЬ Центр — на главную">
      <span class="logo-mark"><svg viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="1.6" stroke-linejoin="round" aria-hidden="true"><path d="M12 2.5l7.5 3v6c0 5-3.2 8.6-7.5 10-4.3-1.4-7.5-5-7.5-10v-6z"/><circle cx="12" cy="11.5" r="2.6" stroke="#7c86ff"/><path d="M12 6.2v2.7M12 14.1v2.7M6.8 11.5h2.6M14.6 11.5h2.6" stroke="#7c86ff"/></svg></span>
      <span class="logo-txt"><span class="logo-name">ПЕСТКОНТРОЛЬ</span> <span class="logo-sub">Центр</span></span>
    </a>
    <nav class="nav" aria-label="Основное меню">
      <div class="nav-dd"><button class="nav-dd-btn" type="button" aria-expanded="false" aria-controls="nav-uslugi">Услуги<svg viewBox="0 0 12 12" aria-hidden="true"><path d="M2.5 4.5 6 8l3.5-3.5" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></button><div class="nav-dd-panel" id="nav-uslugi"><a href="../../dezinfektsiya/">Дезинфекция для организаций<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../../deratizatsiya/">Дератизация для организаций<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../../dezinsektsiya/">Дезинсекция для организаций<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../../deratizatsiya-i-dezinsektsiya/">Дератизация и дезинсекция<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../../sanitarnyy-audit/"><span>Санитарный аудит <span class="nw">(СЭС-аудит)</span></span><svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../../laboratornye-issledovaniya/">Лабораторные исследования<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../../razrabotka-ppk/">Разработка ППК<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="./" aria-current="page">Документы для Роспотребнадзора<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../../ochistka-dezinfektsiya-ventilyatsii/">Очистка и дезинфекция вентиляции<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../../dogovor-deratizatsiya-dezinsektsiya/">Договор на обслуживание<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../../#podhod" class="nav-dd-all"><span>Пест-контроль по системе IPM</span><svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a></div></div><div class="nav-dd"><button class="nav-dd-btn" type="button" aria-expanded="false" aria-controls="nav-otrasli">Отрасли<svg viewBox="0 0 12 12" aria-hidden="true"><path d="M2.5 4.5 6 8l3.5-3.5" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></button><div class="nav-dd-panel" id="nav-otrasli"><a href="../../pishchevoe-proizvodstvo/">Пищевые производства<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../../magaziny-i-torgovye-seti/">Магазины и торговые сети<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../../restorany-i-kafe/">Рестораны и кафе<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../../sklady-i-logistika/">Склады и логистика<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../../farmatsevticheskie-proizvodstva/">Фармацевтические производства<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../../gostinitsy/">Гостиницы и отели<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../../#otrasli" class="nav-dd-all">Все отрасли<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a></div></div><a href="../../dogovor-deratizatsiya-dezinsektsiya/">Договор</a><a href="../../#podhod">Метод IPM</a><a href="../../#usloviya">Цена</a><div class="nav-dd"><button class="nav-dd-btn active" type="button" aria-expanded="false" aria-controls="nav-materialy">Материалы<svg viewBox="0 0 12 12" aria-hidden="true"><path d="M2.5 4.5 6 8l3.5-3.5" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></button><div class="nav-dd-panel" id="nav-materialy"><a href="../../normativnaya-baza/">Нормативная база<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="./" aria-current="page">Документы для Роспотребнадзора<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../../materialy/programma-pest-kontrolya/"><span>Программа <span class="nw">пест-контроля</span></span><svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../../materialy/zhurnal-pest-kontrolya/"><span>Журнал <span class="nw">пест-контроля</span></span><svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../../materialy/pest-menedzhment-ili-razovaya-obrabotka/"><span><span class="nw">Пест-менеджмент</span> или разовая обработка</span><svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../../materialy/programma-proizvodstvennogo-kontrolya-haccp/">Программа производственного контроля по ХАССП<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../../materialy/" class="nav-dd-all">Все материалы<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a></div></div>
    </nav>
    <div class="hdr-right">
      <button class="srch-btn" type="button" data-srch aria-label="Поиск по сайту" aria-haspopup="dialog"><svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="11" cy="11" r="7" fill="none" stroke="currentColor" stroke-width="2"/><path d="m20 20-3.6-3.6" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg></button>
      <a class="phone" href="tel:+74951043570" aria-label="Позвонить: +7 (495) 104-35-70"><i><svg viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2" aria-hidden="true"><path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1 1 .4 1.9.7 2.8a2 2 0 0 1-.5 2.1L8 9.9a16 16 0 0 0 6 6l1.3-1.3a2 2 0 0 1 2.1-.4c.9.3 1.8.6 2.8.7a2 2 0 0 1 1.7 2z"/></svg></i><span>+7 (495) 104-35-70</span></a>
      <div class="msg">
        <a href="https://max.ru/u/f9LHodD0cOIlIUXFkt4KMFP88lD8n4TArBiTcV7RI1XML5c4o39QfsDBXUc" class="max" aria-label="Написать в Max" target="_blank" rel="noopener noreferrer"><svg viewBox="0 0 24 24" fill="#fff" aria-hidden="true"><path d="M12 3a9 9 0 0 0-7.7 13.7L3 21l4.4-1.2A9 9 0 1 0 12 3zm-3.6 12.3V8.7h1.6l2 2.8 2-2.8h1.6v6.6h-1.7v-3.9L12 14l-1.9-2.6v3.9z"/></svg></a>
        <a href="https://t.me/Centr_Dezinfection?text=%D0%97%D0%B4%D1%80%D0%B0%D0%B2%D1%81%D1%82%D0%B2%D1%83%D0%B9%D1%82%D0%B5!%20%D0%9F%D0%B8%D1%88%D1%83%20%D1%81%20%D1%81%D0%B0%D0%B9%D1%82%D0%B0%20%D0%BF%D0%B5%D1%81%D1%82%D0%BA%D0%BE%D0%BD%D1%82%D1%80%D0%BE%D0%BB%D1%8C-%D1%86%D0%B5%D0%BD%D1%82%D1%80.%D1%80%D1%84" class="tg" aria-label="Написать в Telegram" target="_blank" rel="noopener noreferrer"><svg viewBox="0 0 24 24" fill="#fff" aria-hidden="true"><path d="M21.4 4.3 2.9 11.4c-1.3.5-1.2 1.2-.2 1.5l4.7 1.5 1.8 5.6c.2.6.4.8.9.8.4 0 .6-.2.9-.4l2.3-2.2 4.7 3.5c.9.5 1.5.2 1.7-.8l3.1-14.6c.3-1.3-.5-1.8-1.4-1.5zM9.6 14.1l8.6-5.4c.4-.3.8-.1.5.2l-7.1 6.4-.3 3.3z"/></svg></a>
      </div>
      <a href="#zayavka" class="btn btn-w btn-sm" data-magnet><span class="btn-t">Бесплатный выезд</span></a>
      <button class="burger" id="burger" aria-label="Открыть меню" aria-expanded="false" aria-controls="mmenu"><span></span></button>
    </div>
  </div>
</header>
<nav class="mmenu" id="mmenu" aria-label="Мобильное меню">
  <div class="mm-group"><button class="mm-toggle" type="button" aria-expanded="false" aria-controls="mm-uslugi">Услуги<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m6 9 6 6 6-6" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/></svg></button><div class="mm-sub" id="mm-uslugi"><div><a href="../../dezinfektsiya/">Дезинфекция для организаций</a><a href="../../deratizatsiya/">Дератизация для организаций</a><a href="../../dezinsektsiya/">Дезинсекция для организаций</a><a href="../../deratizatsiya-i-dezinsektsiya/">Дератизация и дезинсекция</a><a href="../../sanitarnyy-audit/"><span>Санитарный аудит <span class="nw">(СЭС-аудит)</span></span></a><a href="../../laboratornye-issledovaniya/">Лабораторные исследования</a><a href="../../razrabotka-ppk/">Разработка ППК</a><a href="./" aria-current="page">Документы для Роспотребнадзора</a><a href="../../ochistka-dezinfektsiya-ventilyatsii/">Очистка и дезинфекция вентиляции</a><a href="../../dogovor-deratizatsiya-dezinsektsiya/">Договор на обслуживание</a><a href="../../#podhod"><span class="nw">Пест-контроль</span> по системе IPM</a></div></div></div><div class="mm-group"><button class="mm-toggle" type="button" aria-expanded="false" aria-controls="mm-otrasli">Отрасли<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m6 9 6 6 6-6" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/></svg></button><div class="mm-sub" id="mm-otrasli"><div><a href="../../pishchevoe-proizvodstvo/">Пищевые производства</a><a href="../../magaziny-i-torgovye-seti/">Магазины и торговые сети</a><a href="../../restorany-i-kafe/">Рестораны и кафе</a><a href="../../sklady-i-logistika/">Склады и логистика</a><a href="../../farmatsevticheskie-proizvodstva/">Фармацевтические производства</a><a href="../../gostinitsy/">Гостиницы и отели</a><a href="../../#otrasli">Все отрасли</a></div></div></div><a href="../../dogovor-deratizatsiya-dezinsektsiya/">Договор <small>на дератизацию и дезинсекцию</small></a><a href="../../#podhod">Метод IPM</a><a href="../../#usloviya">Цена</a><div class="mm-group open" data-open><button class="mm-toggle" type="button" aria-expanded="true" aria-controls="mm-materialy">Материалы<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m6 9 6 6 6-6" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/></svg></button><div class="mm-sub" id="mm-materialy"><div><a href="../../normativnaya-baza/">Нормативная база</a><a href="./" aria-current="page">Документы для Роспотребнадзора</a><a href="../../materialy/programma-pest-kontrolya/"><span>Программа <span class="nw">пест-контроля</span></span></a><a href="../../materialy/zhurnal-pest-kontrolya/"><span>Журнал <span class="nw">пест-контроля</span></span></a><a href="../../materialy/pest-menedzhment-ili-razovaya-obrabotka/"><span><span class="nw">Пест-менеджмент</span> или разовая обработка</span></a><a href="../../materialy/programma-proizvodstvennogo-kontrolya-haccp/">Программа производственного контроля по ХАССП</a><a href="../../materialy/">Все материалы</a></div></div></div>
  <a href="#zayavka" class="btn btn-w btn-lg"><span class="btn-t">Заказать бесплатное обследование</span></a>
</nav>

<main id="main" tabindex="-1">
<section class="d-hero nb-hero dk-hero" id="hero">
  <div class="wrap">
    <div class="d-hero-copy">
      <nav class="f-crumbs" aria-label="Навигационная цепочка" data-h><a href="../../">Главная</a><span aria-hidden="true">→</span><a href="../../normativnaya-baza/">Нормативная база</a><span aria-hidden="true">→</span><span aria-current="page">Документы для Роспотребнадзора</span></nav>
      <div class="eyebrow">Для организаций и ИП · Москва и Московская область</div>
      <h1><span class="ln"><span>Документы для Роспотребнадзора:</span></span> <span class="ln"><span><em>полный перечень</em> для проверки</span></span></h1>
      <div class="d-hero-media"><picture><source media="(max-width:860px)" srcset="../../img/dok-hero-mob-760.webp 760w, ../../img/dok-hero-mob.webp 1024w" sizes="100vw" width="1024" height="768"><img class="d-hero-img" src="../../img/dok-hero.webp" srcset="../../img/dok-hero-1440.webp 1440w, ../../img/dok-hero.webp 1920w" sizes="100vw" width="1920" height="1072" alt="Менеджер по качеству отмечает пункты чек-листа рядом с папками документов для проверки, специалист по пест-контролю передаёт ей подписанный акт" fetchpriority="high" decoding="async"></picture><div class="fx-lit" aria-hidden="true"><picture><source media="(max-width:860px)" srcset="../../img/dok-hero-mob-760.webp 760w, ../../img/dok-hero-mob.webp 1024w" sizes="100vw" width="1024" height="768"><img class="d-hero-img fx-lit-img" src="../../img/dok-hero.webp" srcset="../../img/dok-hero-1440.webp 1440w, ../../img/dok-hero.webp 1920w" sizes="100vw" width="1920" height="1072" alt="" decoding="async"></picture></div></div>
      <p class="lead" data-h>Для проверки Роспотребнадзора на объекте должны быть программа производственного контроля (ППК), договоры и акты по дезинсекции и дератизации, протоколы лабораторных исследований, договоры на вывоз отходов и медосмотры, журналы, медкнижки и документы на продукцию. Состав зависит от вида деятельности: ниже — общий список из 41 документа и дополнения для 15 видов объектов.</p>
      <div class="d-btns" data-h>
        <a href="#konstruktor" class="btn btn-w btn-lg" data-magnet><span class="btn-t">Собрать список для моего объекта</span></a>
        <a href="#zayavka" class="btn btn-o btn-lg" data-magnet><span class="btn-t">Проверить папку с санитарным врачом</span></a>
      </div>
      <p class="dk-pdf-line p-hero-note" data-h><a href="../../normativnaya-baza/dokumenty-dlya-rospotrebnadzora/chek-list-dokumentov-dlya-rospotrebnadzora.pdf" download data-dl="pdf"><svg aria-hidden="true" focusable="false" class="lucide lucide-file-down" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z" /> <path d="M14 2v4a2 2 0 0 0 2 2h4" /> <path d="M12 18v-6" /> <path d="m9 15 3 3 3-3" /> </svg><span>Скачать <span class="nw">чек-лист</span> PDF · 14 страниц</span></a></p>
      <p class="nb-byline p-hero-note" data-h>Сверено с официальными текстами 09.11.2026 · подготовила Марианна Семерина, санитарный врач · <span class="nw">чек-лист</span> PDF можно распечатать и заполнить</p>
    </div>
    <nav class="p-toc nb-toc" aria-label="Разделы страницы" data-h><a href="#gruppy">Восемь групп</a><a href="#konstruktor">Конструктор</a><a href="#dogovory">Договоры</a><a href="#akty">Акты</a><a href="#protokoly">Протоколы</a><a href="#po-obektam">По видам объектов</a><a href="#kak-zaprashivayut">Сроки ответа</a><a href="#sroki">2027 год</a><a href="#oshibki">Ошибки</a><a href="#voprosy">Вопросы</a></nav>
  </div>
</section>

<div class="strip" role="group" aria-label="Коротко о документах для Роспотребнадзора">
  <div class="strip-track" id="stripTrack">
    <div class="strip-set">
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-list-checks" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M13 5h8" /> <path d="M13 12h8" /> <path d="M13 19h8" /> <path d="m3 17 2 2 4-4" /> <path d="m3 7 2 2 4-4" /> </svg><b>41 документ</b> — общий список для любого объекта</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-factory" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M12 16h.01" /> <path d="M16 16h.01" /> <path d="M3 19a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V8.5a.5.5 0 0 0-.769-.422l-4.462 2.844A.5.5 0 0 1 15 10.5v-2a.5.5 0 0 0-.769-.422L9.77 10.922A.5.5 0 0 1 9 10.5V5a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2z" /> <path d="M8 16h.01" /> </svg><b>15 видов объектов</b> — свои дополнения</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-notebook-pen" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M13.4 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-7.4" /> <path d="M2 6h4" /> <path d="M2 10h4" /> <path d="M2 14h4" /> <path d="M2 18h4" /> <path d="M21.378 5.626a1 1 0 1 0-3.004-3.004l-5.01 5.012a2 2 0 0 0-.506.854l-.837 2.87a.5.5 0 0 0 .62.62l2.87-.837a2 2 0 0 0 .854-.506z" /> </svg><b>Кто готовит</b> — у каждого документа</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-clipboard-check" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <rect width="8" height="4" x="8" y="2" rx="1" ry="1" /> <path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2" /> <path d="m9 14 2 2 4-4" /> </svg><b>Конструктор</b> — отметки «Есть», «Нет», «Не нужно»</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-file-down" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z" /> <path d="M14 2v4a2 2 0 0 0 2 2h4" /> <path d="M12 18v-6" /> <path d="m9 15 3 3 3-3" /> </svg><b><span class="nw">Чек-лист</span> PDF</b> — 14 страниц</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-clock" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg><b>10 рабочих дней</b> — при документарной проверке</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-file-signature" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M14.364 13.634a2 2 0 0 0-.506.854l-.837 2.87a.5.5 0 0 0 .62.62l2.87-.837a2 2 0 0 0 .854-.506l4.013-4.009a1 1 0 0 0-3.004-3.004z" /> <path d="M14.487 7.858A1 1 0 0 1 14 7V2" /> <path d="M20 19.645V20a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.704.706l2.516 2.516" /> <path d="M8 18h1" /> </svg><b>Договоры и акты</b> — по дезинсекции и дератизации</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-shield-check" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z" /> <path d="m9 12 2 2 4-4" /> </svg><b>Сверка папки</b> — бесплатно, дистанционно</div>
    </div>
    <div class="strip-set" aria-hidden="true">
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-list-checks" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M13 5h8" /> <path d="M13 12h8" /> <path d="M13 19h8" /> <path d="m3 17 2 2 4-4" /> <path d="m3 7 2 2 4-4" /> </svg><b>41 документ</b> — общий список для любого объекта</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-factory" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M12 16h.01" /> <path d="M16 16h.01" /> <path d="M3 19a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V8.5a.5.5 0 0 0-.769-.422l-4.462 2.844A.5.5 0 0 1 15 10.5v-2a.5.5 0 0 0-.769-.422L9.77 10.922A.5.5 0 0 1 9 10.5V5a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2z" /> <path d="M8 16h.01" /> </svg><b>15 видов объектов</b> — свои дополнения</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-notebook-pen" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M13.4 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-7.4" /> <path d="M2 6h4" /> <path d="M2 10h4" /> <path d="M2 14h4" /> <path d="M2 18h4" /> <path d="M21.378 5.626a1 1 0 1 0-3.004-3.004l-5.01 5.012a2 2 0 0 0-.506.854l-.837 2.87a.5.5 0 0 0 .62.62l2.87-.837a2 2 0 0 0 .854-.506z" /> </svg><b>Кто готовит</b> — у каждого документа</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-clipboard-check" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <rect width="8" height="4" x="8" y="2" rx="1" ry="1" /> <path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2" /> <path d="m9 14 2 2 4-4" /> </svg><b>Конструктор</b> — отметки «Есть», «Нет», «Не нужно»</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-file-down" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z" /> <path d="M14 2v4a2 2 0 0 0 2 2h4" /> <path d="M12 18v-6" /> <path d="m9 15 3 3 3-3" /> </svg><b><span class="nw">Чек-лист</span> PDF</b> — 14 страниц</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-clock" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg><b>10 рабочих дней</b> — при документарной проверке</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-file-signature" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M14.364 13.634a2 2 0 0 0-.506.854l-.837 2.87a.5.5 0 0 0 .62.62l2.87-.837a2 2 0 0 0 .854-.506l4.013-4.009a1 1 0 0 0-3.004-3.004z" /> <path d="M14.487 7.858A1 1 0 0 1 14 7V2" /> <path d="M20 19.645V20a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.704.706l2.516 2.516" /> <path d="M8 18h1" /> </svg><b>Договоры и акты</b> — по дезинсекции и дератизации</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-shield-check" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z" /> <path d="m9 12 2 2 4-4" /> </svg><b>Сверка папки</b> — бесплатно, дистанционно</div>
    </div>
  </div>
</div>

<section class="s" id="gruppy">
  <div class="wrap">
    <div class="head"><div class="eyebrow" data-eyebrow>Восемь групп</div><h2 data-split>Какие документы нужны <em>для проверки Роспотребнадзора</em></h2><p class="sub" data-fade>Проверку Роспотребнадзора по привычке называют проверкой СЭС — перечень документов от этого не меняется. Документы удобно собирать в восемь групп:</p></div>
    <div class="dk-gs" data-group="cards">
      <a class="card dk-g" href="#programmy"><span class="dk-g-n">01</span><b>Организационные документы и программы</b><span class="dk-g-d">Учредительные документы, приказы об ответственных, программа производственного контроля, программа <span class="nw">пест-контроля</span>.</span><span class="dk-g-c">12 пунктов →</span></a>
      <a class="card dk-g" href="#dogovory"><span class="dk-g-n">02</span><b>Договоры</b><span class="dk-g-d">На дезинсекцию и дератизацию, лабораторные исследования, вывоз отходов, медосмотры, а по ситуации — на стирку, вентиляцию, ртутные лампы.</span><span class="dk-g-c">15 пунктов →</span></a>
      <a class="card dk-g" href="#akty"><span class="dk-g-n">03</span><b>Акты</b><span class="dk-g-d">Обследований и обработок, мусорокамер и контейнерной площадки, работ по вентиляции.</span><span class="dk-g-c">9 пунктов →</span></a>
      <a class="card dk-g" href="#protokoly"><span class="dk-g-n">04</span><b>Протоколы лабораторных исследований</b><span class="dk-g-d">Смывы, воздух, микроклимат и освещённость, вода, продукция, легионеллы. Все исследования делает наша лаборатория.</span><span class="dk-g-c">11 пунктов →</span></a>
      <a class="card dk-g" href="#zhurnaly"><span class="dk-g-n">05</span><b>Журналы и графики</b><span class="dk-g-d"><span class="nw">Пест-контроль</span>, вентиляция, уборки, а в общепите и торговле — температура, влажность и осмотр работников.</span><span class="dk-g-c">14 пунктов →</span></a>
      <a class="card dk-g" href="#personal"><span class="dk-g-n">06</span><b>Документы на персонал</b><span class="dk-g-d">Медкнижки, медосмотры, гигиеническая аттестация.</span><span class="dk-g-c">6 пунктов →</span></a>
      <a class="card dk-g" href="#ispolnitel"><span class="dk-g-n">07</span><b>Документы исполнителя</b><span class="dk-g-d">Лицензия, свидетельства о госрегистрации средств, инструкции.</span><span class="dk-g-c">3 пунктов →</span></a>
      <a class="card dk-g" href="#produkciya"><span class="dk-g-n">08</span><b>Документы на продукцию и средства</b><span class="dk-g-d">Накладные, декларации, сертификаты, технологические карты.</span><span class="dk-g-c">8 пунктов →</span></a>
    </div>
    <div class="card dk-pdfcard" data-fade>
      <a class="dk-cover" href="../../normativnaya-baza/dokumenty-dlya-rospotrebnadzora/chek-list-dokumentov-dlya-rospotrebnadzora.pdf" download data-dl="pdf" tabindex="-1" aria-hidden="true"><img src="../../img/dok-cover-240.webp?v=20261109" srcset="../../img/dok-cover-240.webp?v=20261109 240w, ../../img/dok-cover-360.webp?v=20261109 360w, ../../img/dok-cover-480.webp?v=20261109 480w" sizes="(max-width:760px) 64px, 132px" width="240" height="339" alt="" loading="lazy" decoding="async"></a>
      <div class="dk-pdfcard-t">
        <p class="dk-pdfcard-k"><span class="nw">Чек-лист</span> PDF · 14 страниц</p>
        <p>Что должно быть в папке объекта к проверке: 41 общий документ и разделы для 15 видов объектов. У каждого документа — кто его готовит и на каком основании. Можно распечатать и заполнить: «Есть», «Нет», «Не нужно».</p>
      </div>
      <a class="btn btn-w btn-lg dk-pdfcard-b" href="../../normativnaya-baza/dokumenty-dlya-rospotrebnadzora/chek-list-dokumentov-dlya-rospotrebnadzora.pdf" download data-dl="pdf"><span class="btn-t">Скачать <span class="nw">чек-лист</span> PDF</span></a>
    </div>
  </div>
</section>

<section class="s dk-builder" id="konstruktor">
  <div class="wrap">
    <div class="head"><div class="eyebrow" data-eyebrow>Конструктор</div><h2 data-split>Соберите папку <em>для вашего объекта</em></h2><p class="sub" data-fade>Выберите вид деятельности — если их несколько, например гостиница с рестораном, выберите все. Отметьте, что у вас есть: конструктор покажет, чего не хватает, и соберёт список, который можно распечатать или отправить санитарному врачу.</p></div>
    <div class="dk-picks" role="group" aria-label="Вид деятельности" data-fade>
        <button type="button" class="dk-pick" data-obj="pp" data-slug="pishchevoe-proizvodstvo" aria-pressed="false"><span>Пищевое производство</span><small>49</small></button>
        <button type="button" class="dk-pick" data-obj="ob" data-slug="restorany" aria-pressed="false"><span>Ресторан, кафе, столовая</span><small>50</small></button>
        <button type="button" class="dk-pick" data-obj="tr" data-slug="magaziny" aria-pressed="false"><span>Магазин продуктов, торговая сеть</span><small>47</small></button>
        <button type="button" class="dk-pick" data-obj="sk" data-slug="sklady" aria-pressed="false"><span>Склад пищевой продукции</span><small>44</small></button>
        <button type="button" class="dk-pick" data-obj="fa" data-slug="farmproizvodstvo" aria-pressed="false"><span>Фармацевтическое производство</span><small>46</small></button>
        <button type="button" class="dk-pick" data-obj="go" data-slug="gostinitsy" aria-pressed="false"><span>Гостиница, хостел</span><small>41</small></button>
        <button type="button" class="dk-pick" data-obj="md" data-slug="meditsina" aria-pressed="false"><span>Медицинская организация</span><small>58</small></button>
        <button type="button" class="dk-pick" data-obj="ap" data-slug="apteki" aria-pressed="false"><span>Аптека</span><small>41</small></button>
        <button type="button" class="dk-pick" data-obj="sh" data-slug="shkoly" aria-pressed="false"><span>Школа, детский сад, лагерь</span><small>51</small></button>
        <button type="button" class="dk-pick" data-obj="us" data-slug="uslugi" aria-pressed="false"><span>Салон красоты, парикмахерская</span><small>46</small></button>
        <button type="button" class="dk-pick" data-obj="bn" data-slug="bani" aria-pressed="false"><span>Баня, сауна</span><small>45</small></button>
        <button type="button" class="dk-pick" data-obj="pr" data-slug="prachechnye" aria-pressed="false"><span>Прачечная, химчистка</span><small>45</small></button>
        <button type="button" class="dk-pick" data-obj="sp" data-slug="sport" aria-pressed="false"><span>Спорт, бассейн, фитнес</span><small>43</small></button>
        <button type="button" class="dk-pick" data-obj="nt" data-slug="neprod" aria-pressed="false"><span>Непродовольственный магазин</span><small>41</small></button>
        <button type="button" class="dk-pick" data-obj="dr" data-slug="drugoy" aria-pressed="false"><span>Другой объект</span><small>41</small></button>
    </div>
    <div class="dk-list" id="dk-list" aria-live="polite" data-fade><p class="dk-empty">Выберите вид объекта — появится список документов с отметками «Есть», «Нет» и «Не нужно». Число на кнопке — сколько документов в списке.</p></div>
    <button type="button" class="dk-mini" id="dk-mini" hidden></button>
    <div class="dk-bar" id="dk-bar" hidden>
      <p class="dk-count" id="dk-count" aria-live="polite"></p>
      <div class="dk-acts">
        <button type="button" class="btn btn-w dk-send" id="dk-send"><span class="btn-t">Отправить список санитарному врачу</span></button>
        <button type="button" class="btn btn-o dk-print" id="dk-print"><span class="btn-t">Распечатать список</span></button>
        <a class="btn btn-o dk-dl" href="../../normativnaya-baza/dokumenty-dlya-rospotrebnadzora/chek-list-dokumentov-dlya-rospotrebnadzora.pdf" download data-dl="pdf"><span class="btn-t">Скачать <span class="nw">чек-лист</span> PDF</span></a>
      </div>
    </div>
    <p class="dk-privacy" data-fade>Отметки хранятся только в вашем браузере. Мы увидим список, только если вы отправите заявку.</p>
    <noscript><p class="dk-privacy">Конструктор работает при включённом JavaScript. Полный перечень — в таблицах ниже и в <a href="../../normativnaya-baza/dokumenty-dlya-rospotrebnadzora/chek-list-dokumentov-dlya-rospotrebnadzora.pdf"><span class="nw">чек-листе</span> PDF</a>.</p></noscript>
  </div>
</section>

<section class="s dk-sec" id="programmy">
  <div class="wrap">
    <div class="head"><div class="eyebrow" data-eyebrow>Группа 1 из 8</div><h2 data-split>Организационные документы <em>и программы</em></h2><p class="sub" data-fade>Основа папки. По программе производственного контроля инспектор сверяет всё остальное: какие исследования вы должны были провести, какие журналы вести и кто за что отвечает.</p></div>
    <div class="dk-tw" data-fade><table class="d-table nb-tbl dk-tbl">
      <thead><tr><th scope="col">№</th><th scope="col">Документ</th><th scope="col">Кто готовит</th><th scope="col">Основание</th><th scope="col">Для кого</th><th scope="col">Образец или услуга</th></tr></thead>
      <tbody>
        <tr id="p1-1"><td data-l="№" class="dk-n">1.1</td><td data-l="Документ"><b>Учредительные документы</b><span class="dk-note">Для ИП — документ о государственной регистрации</span></td><td data-l="Кто готовит">Вы</td><td data-l="Основание"><a href="https://39.rospotrebnadzor.ru/content/perechen-svedeniy-kotorye-mogut-zaprashivatsya-kontrolnym-nadzornym-organom-u" target="_blank" rel="noopener">перечень сведений</a></td><td data-l="Для кого">все объекты</td><td data-l="Образец или услуга" class="dk-0">—</td></tr>
        <tr id="p1-2"><td data-l="№" class="dk-n">1.2</td><td data-l="Документ"><b>Документы на помещение</b><span class="dk-note">Право собственности или договор аренды (субаренды)</span></td><td data-l="Кто готовит">Вы</td><td data-l="Основание"><a href="https://39.rospotrebnadzor.ru/content/perechen-svedeniy-kotorye-mogut-zaprashivatsya-kontrolnym-nadzornym-organom-u" target="_blank" rel="noopener">перечень сведений</a></td><td data-l="Для кого">все объекты</td><td data-l="Образец или услуга" class="dk-0">—</td></tr>
        <tr id="p1-3"><td data-l="№" class="dk-n">1.3</td><td data-l="Документ"><b>Приказы о назначении ответственных, должностные инструкции</b><span class="dk-note">Кто отвечает за производственный контроль и соблюдение санитарных правил</span></td><td data-l="Кто готовит">Вы</td><td data-l="Основание"><a href="https://39.rospotrebnadzor.ru/content/perechen-svedeniy-kotorye-mogut-zaprashivatsya-kontrolnym-nadzornym-organom-u" target="_blank" rel="noopener">перечень сведений</a></td><td data-l="Для кого">все объекты</td><td data-l="Образец или услуга" class="dk-0">—</td></tr>
        <tr id="p1-4"><td data-l="№" class="dk-n">1.4</td><td data-l="Документ"><b>Список работников и штатное расписание</b><span class="dk-note">ФИО, профессия, дата приёма. По списку сверяют медкнижки и медосмотры</span></td><td data-l="Кто готовит">Вы</td><td data-l="Основание"><a href="https://39.rospotrebnadzor.ru/content/perechen-svedeniy-kotorye-mogut-zaprashivatsya-kontrolnym-nadzornym-organom-u" target="_blank" rel="noopener">перечень сведений</a></td><td data-l="Для кого">все объекты</td><td data-l="Образец или услуга" class="dk-0">—</td></tr>
        <tr id="p1-5"><td data-l="№" class="dk-n">1.5</td><td data-l="Документ"><b>Уведомление о начале деятельности</b><span class="dk-note">Если вид деятельности есть в перечне; подают через Госуслуги до начала работы</span></td><td data-l="Кто готовит">Вы</td><td data-l="Основание">постановление Правительства РФ № 725 (<a href="https://86.rospotrebnadzor.ru/news/obnovlenyi-trebovaniya-k-podache-uvedomlenij-o-nachale-osushhestvleniya-nekotoryix-vidov-deyatelnosti.html" target="_blank" rel="noopener">Роспотребнадзор по ХМАО</a>)</td><td data-l="Для кого">если вид деятельности в перечне</td><td data-l="Образец или услуга" class="dk-0">—</td></tr>
        <tr id="p1-6"><td data-l="№" class="dk-n">1.6<span class="dk-ours" title="Делаем мы">●<span class="sr-only"> — делаем мы</span></span></td><td data-l="Документ"><b>Программа производственного контроля (ППК)</b><span class="dk-note">Со ссылками на правила 2026 года и планом лабораторных исследований. Утверждает руководитель. Разрабатываем целиком или только раздел о дезинсекции и дератизации</span></td><td data-l="Кто готовит">Вы или мы</td><td data-l="Основание"><span class="nw">52-ФЗ</span>, ст. 11 и 32; СП <span class="nw">1.1.1058-01</span> (<a href="https://cgon.rospotrebnadzor.ru/biznesu/profilaktika-nadzor-uslsugi/profilakticheskie-meropriatiya/proizvodstvennyy-kontrol-chto-organizovat-biznesu/" target="_blank" rel="noopener">ЦГОН</a>)</td><td data-l="Для кого">все объекты</td><td data-l="Образец или услуга"><a href="../../razrabotka-ppk/">Разработка ППК</a>, <a href="../../materialy/programma-proizvodstvennogo-kontrolya-haccp/">образец ППК по ХАССП</a></td></tr>
        <tr id="p1-7"><td data-l="№" class="dk-n">1.7<span class="dk-ours" title="Делаем мы">●<span class="sr-only"> — делаем мы</span></span></td><td data-l="Документ"><b>Программа <span class="nw">пест-контроля</span></b><span class="dk-note">Зоны, кратность обследований, схема точек контроля, график визитов</span></td><td data-l="Кто готовит">Мы</td><td data-l="Основание"><a href="http://pravo.gov.ru/proxy/ips/?docbody=&amp;nd=602107773" target="_blank" rel="noopener">СанПиН <span class="nw">3.3686-21</span></a>, пп. 88, 101, 110</td><td data-l="Для кого">все объекты</td><td data-l="Образец или услуга"><a href="../../materialy/programma-pest-kontrolya/">Образец программы</a></td></tr>
        <tr id="p1-8"><td data-l="№" class="dk-n">1.8<span class="dk-ours" title="Делаем мы">●<span class="sr-only"> — делаем мы</span></span></td><td data-l="Документ"><b>Документы по процедурам ХАССП</b><span class="dk-note">Программа, схема помещений с критическими контрольными точками, схема движения сырья. Разрабатываем в составе ППК</span></td><td data-l="Кто готовит">Вы или мы</td><td data-l="Основание"><a href="https://docs.cntd.ru/document/902320560" target="_blank" rel="noopener"><span class="nw">ТР ТС 021/2011</span></a>, ст. 10; общепит — п. 4 <a href="https://base.garant.ru/414329257/53f89421bbdaf741eb2d1ecc4ddb4c33/" target="_blank" rel="noopener">СанПиН <span class="nw">2.3/2.4.4282-26</span></a>; <a href="https://35.rospotrebnadzor.ru/informirovanie/perechen-svedeniy/" target="_blank" rel="noopener">перечень сведений</a>; детские и медицинские организации — <a href="https://39.rospotrebnadzor.ru/content/perechen-svedeniy-kotorye-mogut-zaprashivatsya-kontrolnym-nadzornym-organom-u" target="_blank" rel="noopener">перечень сведений</a></td><td data-l="Для кого">пищевые производства, общепит, торговля продуктами — если есть собственное производство, детские организации — если есть свой пищеблок, медицинские организации — если есть пищеблок</td><td data-l="Образец или услуга"><a href="../../razrabotka-ppk/#haccp">ППК по ХАССП</a>, <a href="../../materialy/programma-proizvodstvennogo-kontrolya-haccp/">образец</a></td></tr>
        <tr id="p1-9"><td data-l="№" class="dk-n">1.9</td><td data-l="Документ"><b>Перечень сырья и материалов, список оборудования — источников ультразвука, инфразвука и излучений</b><span class="dk-note">Для промышленных предприятий</span></td><td data-l="Кто готовит">Вы</td><td data-l="Основание"><a href="https://39.rospotrebnadzor.ru/content/perechen-svedeniy-kotorye-mogut-zaprashivatsya-kontrolnym-nadzornym-organom-u" target="_blank" rel="noopener">перечень сведений</a>, раздел о промышленных предприятиях</td><td data-l="Для кого">фармпроизводства</td><td data-l="Образец или услуга" class="dk-0">—</td></tr>
        <tr id="p1-10"><td data-l="№" class="dk-n">1.10</td><td data-l="Документ"><b>Документы по обращению с медицинскими отходами</b><span class="dk-note">Схема и инструкция по обращению с отходами, приказ о назначении ответственного, сведения об обучении персонала</span></td><td data-l="Кто готовит">Вы</td><td data-l="Основание"><a href="https://39.rospotrebnadzor.ru/content/perechen-svedeniy-kotorye-mogut-zaprashivatsya-kontrolnym-nadzornym-organom-u" target="_blank" rel="noopener">перечень сведений</a>, раздел о медицинских организациях</td><td data-l="Для кого">медицинские организации</td><td data-l="Образец или услуга" class="dk-0">—</td></tr>
        <tr id="p1-11"><td data-l="№" class="dk-n">1.11</td><td data-l="Документ"><b>План профилактических и противоэпидемических мероприятий</b><span class="dk-note">С документом о назначении ответственного; инструктажи персонала по противоэпидемическому режиму, стандартные операционные процедуры (СОПы)</span></td><td data-l="Кто готовит">Вы</td><td data-l="Основание"><a href="https://39.rospotrebnadzor.ru/content/perechen-svedeniy-kotorye-mogut-zaprashivatsya-kontrolnym-nadzornym-organom-u" target="_blank" rel="noopener">перечень сведений</a>, раздел о медицинских организациях</td><td data-l="Для кого">медицинские организации</td><td data-l="Образец или услуга" class="dk-0">—</td></tr>
        <tr id="p1-12"><td data-l="№" class="dk-n">1.12</td><td data-l="Документ"><b>Примерное меню и расписание занятий</b><span class="dk-note">Перспективное (примерное) меню; учебное расписание — в школах, расписание занятий — в детских садах</span></td><td data-l="Кто готовит">Вы</td><td data-l="Основание"><a href="https://39.rospotrebnadzor.ru/content/perechen-svedeniy-kotorye-mogut-zaprashivatsya-kontrolnym-nadzornym-organom-u" target="_blank" rel="noopener">перечень сведений</a>, раздел о детских и подростковых организациях</td><td data-l="Для кого">детские организации</td><td data-l="Образец или услуга" class="dk-0">—</td></tr>
      </tbody>
    </table></div>
    <p class="nb-after" data-fade>Программу производственного контроля и программу <span class="nw">пест-контроля</span> сверяют между собой: кратность обследований, зоны и исполнитель должны совпадать. Образцы обеих программ — в разделе <a href="../../materialy/">«Материалы»</a>.</p>
  </div>
</section>

<section class="s dk-sec" id="dogovory">
  <div class="wrap">
    <div class="head"><div class="eyebrow" data-eyebrow>Группа 2 из 8</div><h2 data-split>Какие договоры нужны <em>для Роспотребнадзора</em></h2><p class="sub" data-fade>Договор показывает, кто и как часто выполняет работы. Инспектор сверяет его с актами: если в договоре нет кратности обследований или нужных зон, вопросы будут к договору.</p></div>
    <div class="dk-tw" data-fade><table class="d-table nb-tbl dk-tbl">
      <thead><tr><th scope="col">№</th><th scope="col">Документ</th><th scope="col">Кто готовит</th><th scope="col">Основание</th><th scope="col">Для кого</th><th scope="col">Образец или услуга</th></tr></thead>
      <tbody>
        <tr id="p2-1"><td data-l="№" class="dk-n">2.1<span class="dk-ours" title="Делаем мы">●<span class="sr-only"> — делаем мы</span></span></td><td data-l="Документ"><b>Дезинсекция и дератизация — с исполнителем, у которого есть лицензия</b><span class="dk-note">Обследования на насекомых не реже 2 раз в месяц для объектов из п. 98, ежемесячная оценка заселённости грызунами, мусорокамеры и площадка, сроки внеплановых выездов</span></td><td data-l="Кто готовит">Мы</td><td data-l="Основание"><a href="http://pravo.gov.ru/proxy/ips/?docbody=&amp;nd=602107773" target="_blank" rel="noopener">СанПиН <span class="nw">3.3686-21</span></a>, пп. 88, 98, 101, 110, 133; лицензия — с 01.03.2025 (<a href="https://cgon.rospotrebnadzor.ru/biznesu/profilaktika-nadzor-uslsugi/nadzornie-meropriatiya/litsenzirovanie-dezinfektsionnoy-deyatelnosti/" target="_blank" rel="noopener">ЦГОН</a>)</td><td data-l="Для кого">все объекты</td><td data-l="Образец или услуга"><a href="../../dogovor-deratizatsiya-dezinsektsiya/">Образец договора</a></td></tr>
        <tr id="p2-2"><td data-l="№" class="dk-n">2.2<span class="dk-ours" title="Делаем мы">●<span class="sr-only"> — делаем мы</span></span></td><td data-l="Документ"><b>Лабораторные исследования и инструментальные замеры</b><span class="dk-note">Если нет своей аккредитованной лаборатории. Перечень исследований — по ППК</span></td><td data-l="Кто готовит">Наша лаборатория</td><td data-l="Основание">п. 2.5 СП <span class="nw">1.1.1058-01</span> (<a href="https://www.garant.ru/consult/work_law/1620091/" target="_blank" rel="noopener">Гарант</a>); <a href="https://39.rospotrebnadzor.ru/content/perechen-svedeniy-kotorye-mogut-zaprashivatsya-kontrolnym-nadzornym-organom-u" target="_blank" rel="noopener">перечень сведений</a></td><td data-l="Для кого">все объекты</td><td data-l="Образец или услуга"><a href="../../laboratornye-issledovaniya/">Лабораторные исследования</a>; смывы и воздух — в <a href="../../sanitarnyy-audit/">санаудите</a></td></tr>
        <tr id="p2-3"><td data-l="№" class="dk-n">2.3</td><td data-l="Документ"><b>Вывоз твёрдых коммунальных отходов</b><span class="dk-note">С региональным оператором; акты оказанных услуг</span></td><td data-l="Кто готовит">Региональный оператор</td><td data-l="Основание">п. 4 ст. 24.7 <span class="nw">89-ФЗ</span> (<a href="https://www.consultant.ru/law/podborki/obyazatelno_li_zaklyuchat_dogovor_s_regionalnym_operatorom/" target="_blank" rel="noopener">КонсультантПлюс</a>)</td><td data-l="Для кого">все объекты</td><td data-l="Образец или услуга" class="dk-0">—</td></tr>
        <tr id="p2-4"><td data-l="№" class="dk-n">2.4</td><td data-l="Документ"><b>Отходы I–II класса опасности: отработанные ртутные лампы и другие</b><span class="dk-note">Передача ФГУП «ФЭО» через ФГИС ОПВК — если такие отходы образуются</span></td><td data-l="Кто готовит">ФГУП «ФЭО»</td><td data-l="Основание">ст. 14.4 <span class="nw">89-ФЗ</span> (<a href="https://rpn.gov.ru/regions/51/news/o-neobkhodimosti-registratsii-v-fgis-opvk-pri-obrashchenii-s-otkhodami-i-i-ii-klassov-opasnosti-5825141.html" target="_blank" rel="noopener">Росприроднадзор</a>)</td><td data-l="Для кого">если такие отходы образуются</td><td data-l="Образец или услуга" class="dk-0">—</td></tr>
        <tr id="p2-5"><td data-l="№" class="dk-n">2.5</td><td data-l="Документ"><b>Предварительные и периодические медицинские осмотры</b><span class="dk-note">С медицинской организацией, у которой есть лицензия</span></td><td data-l="Кто готовит">Медорганизация</td><td data-l="Основание">приказ Минздрава № 29н (<a href="https://77.rospotrebnadzor.ru/index.php/press-centr/press-relizy/15322-o-vazhnosti-prokhozhdeniya-periodicheskikh-meditsinskikh-osmotrov-19-04-2026" target="_blank" rel="noopener">Роспотребнадзор по Москве</a>)</td><td data-l="Для кого">все объекты</td><td data-l="Образец или услуга" class="dk-0">—</td></tr>
        <tr id="p2-6"><td data-l="№" class="dk-n">2.6</td><td data-l="Документ"><b>Стирка санитарной и специальной одежды, белья</b><span class="dk-note">Если стирают не на объекте</span></td><td data-l="Кто готовит">Прачечная</td><td data-l="Основание"><a href="https://39.rospotrebnadzor.ru/content/perechen-svedeniy-kotorye-mogut-zaprashivatsya-kontrolnym-nadzornym-organom-u" target="_blank" rel="noopener">перечень сведений</a></td><td data-l="Для кого">если стирают не на объекте</td><td data-l="Образец или услуга" class="dk-0">—</td></tr>
        <tr id="p2-7"><td data-l="№" class="dk-n">2.7<span class="dk-ours" title="Делаем мы">●<span class="sr-only"> — делаем мы</span></span></td><td data-l="Документ"><b>Очистка и дезинфекция вентиляции и кондиционирования</b><span class="dk-note">Централизованные системы кондиционирования и увлажнения: профилактическая очистка и дезинфекция — не реже 1 раза в год</span></td><td data-l="Кто готовит">Мы</td><td data-l="Основание">п. 132 СанПиН <span class="nw">3.3686-21</span> (<a href="https://cgon.rospotrebnadzor.ru/biznesu/articles/ventilyatsiya-ochistka-i-dezinfektsiya/" target="_blank" rel="noopener">ЦГОН</a>)</td><td data-l="Для кого">если есть такие системы</td><td data-l="Образец или услуга"><a href="../../ochistka-dezinfektsiya-ventilyatsii/">Вентиляция</a></td></tr>
        <tr id="p2-8"><td data-l="№" class="dk-n">2.8<span class="dk-ours" title="Делаем мы">●<span class="sr-only"> — делаем мы</span></span></td><td data-l="Документ"><b>Профилактическая дезинфекция</b><span class="dk-note">Если её выполняет подрядчик, а не ваш персонал</span></td><td data-l="Кто готовит">Мы или ваш персонал</td><td data-l="Основание">ППК</td><td data-l="Для кого">если работает подрядчик</td><td data-l="Образец или услуга"><a href="../../dezinfektsiya/">Дезинфекция</a></td></tr>
        <tr id="p2-9"><td data-l="№" class="dk-n">2.9</td><td data-l="Документ"><b>Передача и утилизация отходов производства</b><span class="dk-note">Договоры и акты выполненных работ</span></td><td data-l="Кто готовит">Специализированная организация</td><td data-l="Основание"><a href="https://39.rospotrebnadzor.ru/content/perechen-svedeniy-kotorye-mogut-zaprashivatsya-kontrolnym-nadzornym-organom-u" target="_blank" rel="noopener">перечень сведений</a></td><td data-l="Для кого">пищевые производства, фармпроизводства</td><td data-l="Образец или услуга" class="dk-0">—</td></tr>
        <tr id="p2-10"><td data-l="№" class="dk-n">2.10</td><td data-l="Документ"><b>Водоснабжение, водоотведение, тепло- и электроснабжение</b><span class="dk-note">Договоры с ресурсоснабжающими организациями</span></td><td data-l="Кто готовит">Ресурсоснабжающие организации</td><td data-l="Основание"><a href="https://39.rospotrebnadzor.ru/content/perechen-svedeniy-kotorye-mogut-zaprashivatsya-kontrolnym-nadzornym-organom-u" target="_blank" rel="noopener">перечень сведений</a>, раздел о персональных услугах</td><td data-l="Для кого">салоны красоты, бани и сауны, прачечные и химчистки</td><td data-l="Образец или услуга" class="dk-0">—</td></tr>
        <tr id="p2-11"><td data-l="№" class="dk-n">2.11</td><td data-l="Документ"><b>Вывоз и обезвреживание медицинских отходов</b><span class="dk-note">Договоры со специализированной организацией, акты (квитанции) выполненных работ</span></td><td data-l="Кто готовит">Специализированная организация</td><td data-l="Основание"><a href="https://39.rospotrebnadzor.ru/content/perechen-svedeniy-kotorye-mogut-zaprashivatsya-kontrolnym-nadzornym-organom-u" target="_blank" rel="noopener">перечень сведений</a>, раздел о медицинских организациях; подп. 8 п. 44 СП <span class="nw">2.1.4284-26</span> (<a href="https://base.garant.ru/414956074/b89690251be5277812a78962f6302560/" target="_blank" rel="noopener">вопрос 145 проверочного листа</a>)</td><td data-l="Для кого">медицинские организации</td><td data-l="Образец или услуга" class="dk-0">—</td></tr>
        <tr id="p2-12"><td data-l="№" class="dk-n">2.12</td><td data-l="Документ"><b>Обслуживание медицинской техники</b><span class="dk-note">Договор или журнал технического обслуживания</span></td><td data-l="Кто готовит">Сервисная организация</td><td data-l="Основание"><a href="https://39.rospotrebnadzor.ru/content/perechen-svedeniy-kotorye-mogut-zaprashivatsya-kontrolnym-nadzornym-organom-u" target="_blank" rel="noopener">перечень сведений</a>, раздел о медицинских организациях</td><td data-l="Для кого">медицинские организации</td><td data-l="Образец или услуга" class="dk-0">—</td></tr>
        <tr id="p2-13"><td data-l="№" class="dk-n">2.13</td><td data-l="Документ"><b>Медицинское обслуживание детей</b><span class="dk-note">Договор оказания медицинских услуг с медицинской организацией</span></td><td data-l="Кто готовит">Медорганизация</td><td data-l="Основание"><a href="https://39.rospotrebnadzor.ru/content/perechen-svedeniy-kotorye-mogut-zaprashivatsya-kontrolnym-nadzornym-organom-u" target="_blank" rel="noopener">перечень сведений</a>, раздел о детских и подростковых организациях</td><td data-l="Для кого">детские организации</td><td data-l="Образец или услуга" class="dk-0">—</td></tr>
        <tr id="p2-14"><td data-l="№" class="dk-n">2.14</td><td data-l="Документ"><b>Камерная обработка постельных принадлежностей</b><span class="dk-note">Договор и акты — в детских садах и организациях отдыха и оздоровления детей</span></td><td data-l="Кто готовит">Специализированная организация</td><td data-l="Основание"><a href="https://39.rospotrebnadzor.ru/content/perechen-svedeniy-kotorye-mogut-zaprashivatsya-kontrolnym-nadzornym-organom-u" target="_blank" rel="noopener">перечень сведений</a>, раздел о детских и подростковых организациях</td><td data-l="Для кого">детские организации — для детских садов и лагерей</td><td data-l="Образец или услуга" class="dk-0">—</td></tr>
        <tr id="p2-15"><td data-l="№" class="dk-n">2.15</td><td data-l="Документ"><b>Противоклещевые (акарицидные) обработки</b><span class="dk-note">Договор и акты выполненных работ; в загородных лагерях — до начала смены</span></td><td data-l="Кто готовит">Исполнитель с лицензией</td><td data-l="Основание"><a href="https://39.rospotrebnadzor.ru/content/perechen-svedeniy-kotorye-mogut-zaprashivatsya-kontrolnym-nadzornym-organom-u" target="_blank" rel="noopener">перечень сведений</a>, раздел о детских и подростковых организациях; подп. 6 п. 14 и подп. 4 п. 21 СП <span class="nw">2.4.2.4283-26</span> (<a href="https://base.garant.ru/414956074/8599a70d26e5983585d90ff6adf82e89/" target="_blank" rel="noopener">вопрос 64 проверочного листа</a>)</td><td data-l="Для кого">детские организации — для загородных лагерей</td><td data-l="Образец или услуга" class="dk-0">—</td></tr>
      </tbody>
    </table></div>
    <p class="nb-after" data-fade>Своими силами для собственных нужд дезинсекцию и дератизацию можно проводить без лицензии и без договора, но программа, журналы и учёт обследований всё равно нужны. Лицензию подрядчика проверяют в <a href="https://fp.rospotrebnadzor.ru/licen/" target="_blank" rel="noopener">реестре Роспотребнадзора</a>.</p>
  </div>
</section>

<section class="s dk-sec" id="akty">
  <div class="wrap">
    <div class="head"><div class="eyebrow" data-eyebrow>Группа 3 из 8</div><h2 data-split>Акты: <em>чем подтвердить, что работы выполнены</em></h2><p class="sub" data-fade>Акты подтверждают, что работы по договору действительно проводились. Инспектор смотрит даты, кратность и результаты, а не только подписи.</p></div>
    <div class="dk-tw" data-fade><table class="d-table nb-tbl dk-tbl">
      <thead><tr><th scope="col">№</th><th scope="col">Документ</th><th scope="col">Кто готовит</th><th scope="col">Основание</th><th scope="col">Для кого</th><th scope="col">Образец или услуга</th></tr></thead>
      <tbody>
        <tr id="p3-1"><td data-l="№" class="dk-n">3.1<span class="dk-ours" title="Делаем мы">●<span class="sr-only"> — делаем мы</span></span></td><td data-l="Документ"><b>Акт первичного обследования объекта</b><span class="dk-note">Заселённость, места проникновения, точки контроля, риски</span></td><td data-l="Кто готовит">Мы</td><td data-l="Основание">п. 88 <a href="http://pravo.gov.ru/proxy/ips/?docbody=&amp;nd=602107773" target="_blank" rel="noopener">СанПиН <span class="nw">3.3686-21</span></a></td><td data-l="Для кого">все объекты</td><td data-l="Образец или услуга" class="dk-0">—</td></tr>
        <tr id="p3-2"><td data-l="№" class="dk-n">3.2<span class="dk-ours" title="Делаем мы">●<span class="sr-only"> — делаем мы</span></span></td><td data-l="Документ"><b>Акты плановых обследований на насекомых</b><span class="dk-note">Не реже 2 раз в месяц на объектах из п. 98, на остальных — ежемесячно</span></td><td data-l="Кто готовит">Мы</td><td data-l="Основание">п. 101 <a href="http://pravo.gov.ru/proxy/ips/?docbody=&amp;nd=602107773" target="_blank" rel="noopener">СанПиН <span class="nw">3.3686-21</span></a></td><td data-l="Для кого">все объекты</td><td data-l="Образец или услуга"><a href="#obrazets-akta">Образец акта</a></td></tr>
        <tr id="p3-3"><td data-l="№" class="dk-n">3.3<span class="dk-ours" title="Делаем мы">●<span class="sr-only"> — делаем мы</span></span></td><td data-l="Документ"><b>Отчёт об оценке заселённости грызунами и решение о дератизации</b><span class="dk-note">На объектах из п. 98 — ежемесячно</span></td><td data-l="Кто готовит">Мы</td><td data-l="Основание">п. 110 <a href="http://pravo.gov.ru/proxy/ips/?docbody=&amp;nd=602107773" target="_blank" rel="noopener">СанПиН <span class="nw">3.3686-21</span></a></td><td data-l="Для кого">все объекты</td><td data-l="Образец или услуга" class="dk-0">—</td></tr>
        <tr id="p3-4"><td data-l="№" class="dk-n">3.4<span class="dk-ours" title="Делаем мы">●<span class="sr-only"> — делаем мы</span></span></td><td data-l="Документ"><b>Акты выполненных работ по каждой обработке</b><span class="dk-note">Дата и время, помещения, средство и номер СГР, концентрация, способ, меры безопасности, исполнитель</span></td><td data-l="Кто готовит">Мы</td><td data-l="Основание"><a href="https://39.rospotrebnadzor.ru/content/perechen-svedeniy-kotorye-mogut-zaprashivatsya-kontrolnym-nadzornym-organom-u" target="_blank" rel="noopener">перечень сведений</a>; п. 102 СанПиН <span class="nw">3.3686-21</span>; общепит — п. 45 <a href="https://base.garant.ru/414329257/53f89421bbdaf741eb2d1ecc4ddb4c33/" target="_blank" rel="noopener">СанПиН <span class="nw">2.3/2.4.4282-26</span></a></td><td data-l="Для кого">все объекты</td><td data-l="Образец или услуга"><a href="#obrazets-akta">Образец акта</a></td></tr>
        <tr id="p3-5"><td data-l="№" class="dk-n">3.5<span class="dk-ours" title="Делаем мы">●<span class="sr-only"> — делаем мы</span></span></td><td data-l="Документ"><b>Обследование мусорокамер и обработка контейнерной площадки</b><span class="dk-note">Мусорокамеры — не реже 1 раза в месяц; площадка, если она ваша, — с кратностью по прил. 1 к СанПиН <span class="nw">2.1.3684-21</span></span></td><td data-l="Кто готовит">Мы</td><td data-l="Основание">п. 133 СанПиН <span class="nw">3.3686-21</span>; п. 8 и прил. 1 <a href="http://pravo.gov.ru/proxy/ips/?doc_itself=&amp;backlink=1&amp;nd=602024221&amp;page=1&amp;rdk=3" target="_blank" rel="noopener">СанПиН <span class="nw">2.1.3684-21</span></a>; торговля — п. 72 СП <span class="nw">2.3.6.4281-26</span></td><td data-l="Для кого">если есть мусорокамера или площадка</td><td data-l="Образец или услуга" class="dk-0">—</td></tr>
        <tr id="p3-6"><td data-l="№" class="dk-n">3.6<span class="dk-ours" title="Делаем мы">●<span class="sr-only"> — делаем мы</span></span></td><td data-l="Документ"><b>Акт очистки и дезинфекции вентиляции</b><span class="dk-note">С записью в журнале учёта работ</span></td><td data-l="Кто готовит">Мы</td><td data-l="Основание">п. 132 СанПиН <span class="nw">3.3686-21</span> (<a href="https://cgon.rospotrebnadzor.ru/biznesu/articles/ventilyatsiya-ochistka-i-dezinfektsiya/" target="_blank" rel="noopener">ЦГОН</a>); МР <span class="nw">3.5.0396-25</span></td><td data-l="Для кого">если есть такие системы</td><td data-l="Образец или услуга"><a href="../../ochistka-dezinfektsiya-ventilyatsii/">Вентиляция</a></td></tr>
        <tr id="p3-7"><td data-l="№" class="dk-n">3.7</td><td data-l="Документ"><b>Акт обследования технического состояния вентиляции</b><span class="dk-note">С инструментальными измерениями объёмов вытяжки: перед вводом в эксплуатацию или реконструкцией, через 2 года, затем не реже 1 раза в 10 лет</span></td><td data-l="Кто готовит">Подрядчик по вентиляции</td><td data-l="Основание">п. 8 <a href="http://publication.pravo.gov.ru/file/pdf?eoNumber=0001202606020088" target="_blank" rel="noopener">СП <span class="nw">2.1.4284-26</span></a>; вопрос проверочного листа № 578 (<a href="https://base.garant.ru/414956074/172a6d689833ce3e42dc0a8a7b3cddf9/" target="_blank" rel="noopener">Гарант</a>)</td><td data-l="Для кого">если на объект распространяется СП <span class="nw">2.1.4284-26</span></td><td data-l="Образец или услуга" class="dk-0">—</td></tr>
        <tr id="p3-8"><td data-l="№" class="dk-n">3.8<span class="dk-ours" title="Делаем мы">●<span class="sr-only"> — делаем мы</span></span></td><td data-l="Документ"><b>Акт очистки вентиляции от горючих отложений</b><span class="dk-note">Его запрашивает пожарный надзор, но удобно хранить в той же папке</span></td><td data-l="Кто готовит">Мы</td><td data-l="Основание">Правила противопожарного режима, п. 43</td><td data-l="Для кого">если есть вентиляция</td><td data-l="Образец или услуга"><a href="../../ochistka-dezinfektsiya-ventilyatsii/">Вентиляция</a></td></tr>
        <tr id="p3-9"><td data-l="№" class="dk-n">3.9<span class="dk-ours" title="Делаем мы">●<span class="sr-only"> — делаем мы</span></span></td><td data-l="Документ"><b>Ежегодная проверка эффективности, очистка и дезинфекция вентиляции</b><span class="dk-note">Механическая <span class="nw">приточно-вытяжная</span> вентиляция и кондиционирование — не реже 1 раза в год; фильтры <span class="nw">сплит-систем</span> — не реже 1 раза в 3 месяца</span></td><td data-l="Кто готовит">Мы и подрядчик по вентиляции</td><td data-l="Основание">подп. 2 и 22 п. 24 СП <span class="nw">2.1.4284-26</span> (<a href="https://base.garant.ru/414956074/b89690251be5277812a78962f6302560/" target="_blank" rel="noopener">вопросы 49 и 60 проверочного листа</a>)</td><td data-l="Для кого">медицинские организации</td><td data-l="Образец или услуга"><a href="../../ochistka-dezinfektsiya-ventilyatsii/">Вентиляция</a></td></tr>
      </tbody>
    </table></div>
    <div class="card dk-akt" data-fade><h3 class="dk-akt-h">Что должно быть в акте дезинсекции и дератизации</h3><p>Единой обязательной формы акта нет. Чтобы акт подтверждал работу на проверке, в нём указывают:</p><ul><li>дату и время начала и окончания работ;</li><li>адрес и помещения, где проводили обследование или обработку;</li><li>вид работ: обследование, профилактика, дезинсекция, дератизация;</li><li>вредителей и результаты обследования по точкам контроля;</li><li>средство, номер свидетельства о госрегистрации, концентрацию и способ применения;</li><li>меры безопасности и когда можно вернуться в помещения;</li><li>исполнителя, номер его лицензии, подписи исполнителя и представителя объекта.</li></ul><p>В общепите время обработки особенно важно: во время дезинсекции и дератизации нельзя хранить и готовить продукцию, а распыляемые и рассыпаемые средства нельзя применять при посетителях и персонале (п. 45 <a href="https://base.garant.ru/414329257/53f89421bbdaf741eb2d1ecc4ddb4c33/" target="_blank" rel="noopener">СанПиН <span class="nw">2.3/2.4.4282-26</span></a>).</p></div><div class="card dk-pdfcard dk-aktcard" id="obrazets-akta" data-fade><a class="dk-cover" href="../../normativnaya-baza/dokumenty-dlya-rospotrebnadzora/obrazets-akta-dezinsektsii-i-deratizatsii.pdf" download data-dl="akt" tabindex="-1" aria-hidden="true"><img src="../../img/akt-obrazets-p1-360.webp" srcset="../../img/akt-obrazets-p1-360.webp 360w, ../../img/akt-obrazets-p1-720.webp 720w" sizes="(max-width:760px) 64px, 132px" width="360" height="509" alt="" loading="lazy" decoding="async"></a><div class="dk-pdfcard-t"><p class="dk-pdfcard-k">Образец акта · PDF, 2 листа</p><p>Так выглядит наш акт по каждому визиту: время работ, обследование по точкам контроля, средства с концентрацией и номером СГР, условия обработки, контроль эффективности и рекомендации — всё из списка выше. Данные заказчика в образце скрыты, бланк — та же форма без записей.</p></div><div class="dk-aktcard-b"><a class="btn btn-w btn-lg" href="../../normativnaya-baza/dokumenty-dlya-rospotrebnadzora/obrazets-akta-dezinsektsii-i-deratizatsii.pdf" download data-dl="akt"><span class="btn-t">Скачать образец</span></a><a class="btn btn-o btn-lg" href="../../normativnaya-baza/dokumenty-dlya-rospotrebnadzora/blank-akta-dezinsektsii-i-deratizatsii.pdf" download data-dl="akt-blank"><span class="btn-t">Бланк для печати</span></a></div></div>
  </div>
</section>

<section class="s dk-sec" id="protokoly">
  <div class="wrap">
    <div class="head"><div class="eyebrow" data-eyebrow>Группа 4 из 8</div><h2 data-split>Протоколы <em>лабораторных исследований</em></h2><p class="sub" data-fade>Все исследования из этой группы выполняет наша лаборатория: отбираем пробы на объекте и передаём протоколы. Какие исследования нужны и как часто, устанавливает ваша программа производственного контроля. Инспектор сверяет протоколы с планом исследований в программе и проверяет, что лаборатория аккредитована.</p></div>
    <div class="dk-tw" data-fade><table class="d-table nb-tbl dk-tbl">
      <thead><tr><th scope="col">№</th><th scope="col">Документ</th><th scope="col">Кто готовит</th><th scope="col">Основание</th><th scope="col">Для кого</th><th scope="col">Образец или услуга</th></tr></thead>
      <tbody>
        <tr id="p4-1"><td data-l="№" class="dk-n">4.1<span class="dk-ours" title="Делаем мы">●<span class="sr-only"> — делаем мы</span></span></td><td data-l="Документ"><b>Смывы с поверхностей, оборудования, инвентаря и рук персонала</b><span class="dk-note">По плану ППК</span></td><td data-l="Кто готовит">Наша лаборатория; входят в санаудит</td><td data-l="Основание">ППК; СП <span class="nw">1.1.1058-01</span></td><td data-l="Для кого">все объекты</td><td data-l="Образец или услуга"><a href="../../sanitarnyy-audit/">Санитарный аудит</a></td></tr>
        <tr id="p4-2"><td data-l="№" class="dk-n">4.2<span class="dk-ours" title="Делаем мы">●<span class="sr-only"> — делаем мы</span></span></td><td data-l="Документ"><b>Пробы воздуха помещений</b><span class="dk-note">По плану ППК</span></td><td data-l="Кто готовит">Наша лаборатория; входят в санаудит</td><td data-l="Основание">ППК</td><td data-l="Для кого">все объекты</td><td data-l="Образец или услуга"><a href="../../sanitarnyy-audit/">Санитарный аудит</a></td></tr>
        <tr id="p4-3"><td data-l="№" class="dk-n">4.3<span class="dk-ours" title="Делаем мы">●<span class="sr-only"> — делаем мы</span></span></td><td data-l="Документ"><b>Микроклимат, освещённость, шум на рабочих местах</b><span class="dk-note">Можно использовать результаты спецоценки условий труда не старше 6 месяцев</span></td><td data-l="Кто готовит">Наша лаборатория</td><td data-l="Основание">ППК; п. 1.1 ст. 32 <span class="nw">52-ФЗ</span> (<a href="https://www.consultant.ru/document/cons_doc_LAW_384394/d4d04d2e799bdca563354397e3c1f53374d9dce4/" target="_blank" rel="noopener">КонсультантПлюс</a>)</td><td data-l="Для кого">все объекты</td><td data-l="Образец или услуга"><a href="../../laboratornye-issledovaniya/">Лабораторные исследования</a></td></tr>
        <tr id="p4-4"><td data-l="№" class="dk-n">4.4<span class="dk-ours" title="Делаем мы">●<span class="sr-only"> — делаем мы</span></span></td><td data-l="Документ"><b>Питьевая вода</b><span class="dk-note">Если исследования предусмотрены ППК</span></td><td data-l="Кто готовит">Наша лаборатория</td><td data-l="Основание">ППК</td><td data-l="Для кого">если предусмотрено ППК</td><td data-l="Образец или услуга"><a href="../../laboratornye-issledovaniya/">Лабораторные исследования</a></td></tr>
        <tr id="p4-5"><td data-l="№" class="dk-n">4.5<span class="dk-ours" title="Делаем мы">●<span class="sr-only"> — делаем мы</span></span></td><td data-l="Документ"><b>Пищевая продукция и сырьё</b><span class="dk-note">По плану ППК и процедурам ХАССП</span></td><td data-l="Кто готовит">Наша лаборатория</td><td data-l="Основание">ППК; <a href="https://docs.cntd.ru/document/902320560" target="_blank" rel="noopener"><span class="nw">ТР ТС 021/2011</span></a></td><td data-l="Для кого">пищевые производства, общепит, торговля продуктами — если есть собственное производство</td><td data-l="Образец или услуга"><a href="../../laboratornye-issledovaniya/">Лабораторные исследования</a></td></tr>
        <tr id="p4-6"><td data-l="№" class="dk-n">4.6<span class="dk-ours" title="Делаем мы">●<span class="sr-only"> — делаем мы</span></span></td><td data-l="Документ"><b>Легионеллы в системах кондиционирования и увлажнения</b><span class="dk-note">Не реже 2 раз в год; кроме установок малой мощности без увлажнения <span class="nw">и сплит-систем</span></span></td><td data-l="Кто готовит">Наша лаборатория</td><td data-l="Основание">п. 132 СанПиН <span class="nw">3.3686-21</span> (<a href="https://cgon.rospotrebnadzor.ru/biznesu/articles/ventilyatsiya-ochistka-i-dezinfektsiya/" target="_blank" rel="noopener">ЦГОН</a>)</td><td data-l="Для кого">если есть такие системы</td><td data-l="Образец или услуга"><a href="../../ochistka-dezinfektsiya-ventilyatsii/">Вентиляция</a></td></tr>
        <tr id="p4-7"><td data-l="№" class="dk-n">4.7<span class="dk-ours" title="Делаем мы">●<span class="sr-only"> — делаем мы</span></span></td><td data-l="Документ"><b>Оценка эффективности дезинфекции</b><span class="dk-note">Смывы после обработки — по ППК или договору</span></td><td data-l="Кто готовит">Наша лаборатория</td><td data-l="Основание">ППК; договор</td><td data-l="Для кого">если предусмотрено</td><td data-l="Образец или услуга"><a href="../../dezinfektsiya/">Дезинфекция</a></td></tr>
        <tr id="p4-8"><td data-l="№" class="dk-n">4.8<span class="dk-ours" title="Делаем мы">●<span class="sr-only"> — делаем мы</span></span></td><td data-l="Документ"><b>Атмосферный воздух на границе <span class="nw">санитарно-защитной</span> зоны</b><span class="dk-note">Если у предприятия есть выбросы</span></td><td data-l="Кто готовит">Наша лаборатория</td><td data-l="Основание"><a href="https://39.rospotrebnadzor.ru/content/perechen-svedeniy-kotorye-mogut-zaprashivatsya-kontrolnym-nadzornym-organom-u" target="_blank" rel="noopener">перечень сведений</a>, раздел о промышленных предприятиях</td><td data-l="Для кого">фармпроизводства — если есть выбросы</td><td data-l="Образец или услуга"><a href="../../laboratornye-issledovaniya/">Лабораторные исследования</a></td></tr>
        <tr id="p4-9"><td data-l="№" class="dk-n">4.9<span class="dk-ours" title="Делаем мы">●<span class="sr-only"> — делаем мы</span></span></td><td data-l="Документ"><b>Контроль стерилизации инструментов и работы стерилизаторов</b><span class="dk-note">Договор и протоколы исследований — если стерилизуете инструменты</span></td><td data-l="Кто готовит">Наша лаборатория</td><td data-l="Основание"><a href="https://39.rospotrebnadzor.ru/content/perechen-svedeniy-kotorye-mogut-zaprashivatsya-kontrolnym-nadzornym-organom-u" target="_blank" rel="noopener">перечень сведений</a>, раздел о персональных услугах</td><td data-l="Для кого">салоны красоты — если стерилизуете инструменты</td><td data-l="Образец или услуга"><a href="../../laboratornye-issledovaniya/">Лабораторные исследования</a></td></tr>
        <tr id="p4-10"><td data-l="№" class="dk-n">4.10<span class="dk-ours" title="Делаем мы">●<span class="sr-only"> — делаем мы</span></span></td><td data-l="Документ"><b>Вода бассейна</b><span class="dk-note">Мутность, цветность, запах — раз в сутки; обеззараживающий реагент, температура воды и воздуха — перед открытием и каждые 4 часа; микробиология — раз в месяц, паразитология — раз в квартал; пробы по этапам водоподготовки</span></td><td data-l="Кто готовит">Наша лаборатория; ежедневные замеры — ваш персонал</td><td data-l="Основание">подп. 31–33 п. 73 и прил. 6 <a href="https://www.consultant.ru/document/cons_doc_LAW_535828/d3a65cf056a7c1d728cf8966a09f98f749c89fb8/" target="_blank" rel="noopener">СП <span class="nw">2.1.4284-26</span></a></td><td data-l="Для кого">спорт и бассейны — если есть бассейн или аквапарк</td><td data-l="Образец или услуга"><a href="../../laboratornye-issledovaniya/">Лабораторные исследования</a></td></tr>
        <tr id="p4-11"><td data-l="№" class="dk-n">4.11<span class="dk-ours" title="Делаем мы">●<span class="sr-only"> — делаем мы</span></span></td><td data-l="Документ"><b>Смывы в бассейне на колиформные бактерии и яйца гельминтов</b><span class="dk-note">Не реже 1 раза в квартал: поручни ванны, скамейки в раздевалках, пол душевой, ручки дверей, инвентарь</span></td><td data-l="Кто готовит">Наша лаборатория</td><td data-l="Основание">подп. 35 п. 73 <a href="https://www.consultant.ru/document/cons_doc_LAW_535828/d3a65cf056a7c1d728cf8966a09f98f749c89fb8/" target="_blank" rel="noopener">СП <span class="nw">2.1.4284-26</span></a></td><td data-l="Для кого">спорт и бассейны — если есть бассейн</td><td data-l="Образец или услуга"><a href="../../laboratornye-issledovaniya/">Лабораторные исследования</a></td></tr>
      </tbody>
    </table></div>
    <p class="nb-after" data-fade>Все исследования из этой таблицы выполняет наша лаборатория: отбираем пробы на объекте и передаём протоколы. Цены и расчёт — на странице <a href="../../laboratornye-issledovaniya/">«Лабораторные исследования»</a>. Смывы и пробы воздуха входят и в <a href="../../sanitarnyy-audit/">санитарный аудит</a>.</p>
  </div>
</section>

<section class="s dk-sec" id="zhurnaly">
  <div class="wrap">
    <div class="head"><div class="eyebrow" data-eyebrow>Группа 5 из 8</div><h2 data-split>Журналы <em>и графики</em></h2><p class="sub" data-fade>Журналы показывают, что контроль идёт каждый день или по графику. Для большинства журналов форма рекомендуемая: важны полнота записей и отсутствие пропусков.</p></div>
    <div class="dk-tw" data-fade><table class="d-table nb-tbl dk-tbl">
      <thead><tr><th scope="col">№</th><th scope="col">Документ</th><th scope="col">Кто готовит</th><th scope="col">Основание</th><th scope="col">Для кого</th><th scope="col">Образец или услуга</th></tr></thead>
      <tbody>
        <tr id="p5-1"><td data-l="№" class="dk-n">5.1<span class="dk-ours" title="Делаем мы">●<span class="sr-only"> — делаем мы</span></span></td><td data-l="Документ"><b>Журнал <span class="nw">пест-контроля</span> (учёта дезинсекции и дератизации)</b><span class="dk-note">Визиты, состояние точек контроля, находки, принятые меры</span></td><td data-l="Кто готовит">Мы</td><td data-l="Основание">СанПиН <span class="nw">3.3686-21</span>, раздел III</td><td data-l="Для кого">все объекты</td><td data-l="Образец или услуга"><a href="../../materialy/zhurnal-pest-kontrolya/">Образец журнала</a></td></tr>
        <tr id="p5-2"><td data-l="№" class="dk-n">5.2<span class="dk-ours" title="Делаем мы">●<span class="sr-only"> — делаем мы</span></span></td><td data-l="Документ"><b>Журнал учёта работ по вентиляции</b><span class="dk-note">Очистка, дезинфекция, лабораторный контроль</span></td><td data-l="Кто готовит">Мы</td><td data-l="Основание">МР <span class="nw">3.5.0396-25</span>, прил. 3</td><td data-l="Для кого">если есть такие системы</td><td data-l="Образец или услуга"><a href="../../ochistka-dezinfektsiya-ventilyatsii/">Вентиляция</a></td></tr>
        <tr id="p5-3"><td data-l="№" class="dk-n">5.3</td><td data-l="Документ"><b>Графики уборки и генеральных уборок, журнал генеральных уборок</b></td><td data-l="Кто готовит">Вы</td><td data-l="Основание"><a href="https://39.rospotrebnadzor.ru/content/perechen-svedeniy-kotorye-mogut-zaprashivatsya-kontrolnym-nadzornym-organom-u" target="_blank" rel="noopener">перечень сведений</a></td><td data-l="Для кого">все объекты</td><td data-l="Образец или услуга" class="dk-0">—</td></tr>
        <tr id="p5-4"><td data-l="№" class="dk-n">5.4</td><td data-l="Документ"><b>Контроль дезинфицирующих средств и рабочих растворов</b><span class="dk-note">Маркировка ёмкостей, контроль концентрации — если дезинфекцию проводит ваш персонал</span></td><td data-l="Кто готовит">Вы</td><td data-l="Основание">ППК; общепит — п. 47 <a href="https://base.garant.ru/414329257/53f89421bbdaf741eb2d1ecc4ddb4c33/" target="_blank" rel="noopener">СанПиН <span class="nw">2.3/2.4.4282-26</span></a></td><td data-l="Для кого">если дезинфицирует ваш персонал</td><td data-l="Образец или услуга" class="dk-0">—</td></tr>
        <tr id="p5-5"><td data-l="№" class="dk-n">5.5</td><td data-l="Документ"><b>Журнал учёта работы бактерицидных облучателей</b><span class="dk-note">Если облучатели установлены; вместе с их паспортами</span></td><td data-l="Кто готовит">Вы</td><td data-l="Основание"><a href="https://35.rospotrebnadzor.ru/informirovanie/perechen-svedeniy/" target="_blank" rel="noopener">перечень сведений</a></td><td data-l="Для кого">если установлены облучатели</td><td data-l="Образец или услуга" class="dk-0">—</td></tr>
        <tr id="p5-6"><td data-l="№" class="dk-n">5.6</td><td data-l="Документ"><b>Гигиенический журнал</b><span class="dk-note">Ежедневный осмотр работников перед сменой; на бумаге или в электронном виде</span></td><td data-l="Кто готовит">Вы</td><td data-l="Основание">п. 25 и прил. 1 <a href="https://base.garant.ru/414329257/53f89421bbdaf741eb2d1ecc4ddb4c33/" target="_blank" rel="noopener">СанПиН <span class="nw">2.3/2.4.4282-26</span></a>; детские организации — <a href="https://39.rospotrebnadzor.ru/content/perechen-svedeniy-kotorye-mogut-zaprashivatsya-kontrolnym-nadzornym-organom-u" target="_blank" rel="noopener">перечень сведений</a></td><td data-l="Для кого">общепит, детские организации, медицинские организации — если есть пищеблок</td><td data-l="Образец или услуга" class="dk-0">—</td></tr>
        <tr id="p5-7"><td data-l="№" class="dk-n">5.7</td><td data-l="Документ"><b>Журналы температуры холодильного оборудования, температуры и влажности склада</b><span class="dk-note">Ежедневно, на бумаге и (или) в электронном виде</span></td><td data-l="Кто готовит">Вы</td><td data-l="Основание">п. 35 и прил. 2, 3 <a href="https://base.garant.ru/414329257/53f89421bbdaf741eb2d1ecc4ddb4c33/" target="_blank" rel="noopener">СанПиН <span class="nw">2.3/2.4.4282-26</span></a>; детские организации — <a href="https://39.rospotrebnadzor.ru/content/perechen-svedeniy-kotorye-mogut-zaprashivatsya-kontrolnym-nadzornym-organom-u" target="_blank" rel="noopener">перечень сведений</a></td><td data-l="Для кого">общепит, детские организации, медицинские организации — если есть пищеблок</td><td data-l="Образец или услуга" class="dk-0">—</td></tr>
        <tr id="p5-8"><td data-l="№" class="dk-n">5.8</td><td data-l="Документ"><b>Учёт замены фритюрных жиров</b><span class="dk-note">Если есть фритюр: ежедневный контроль, записи хранят не менее 3 месяцев</span></td><td data-l="Кто готовит">Вы</td><td data-l="Основание">п. 44 <a href="https://base.garant.ru/414329257/53f89421bbdaf741eb2d1ecc4ddb4c33/" target="_blank" rel="noopener">СанПиН <span class="nw">2.3/2.4.4282-26</span></a></td><td data-l="Для кого">общепит — если есть фритюр</td><td data-l="Образец или услуга" class="dk-0">—</td></tr>
        <tr id="p5-9"><td data-l="№" class="dk-n">5.9</td><td data-l="Документ"><b>Журналы бракеража готовой и скоропортящейся продукции</b><span class="dk-note">При питании пациентов, детей, в организациях социального обслуживания</span></td><td data-l="Кто готовит">Вы</td><td data-l="Основание">п. 56, раздел VIII и прил. 4, 5 <a href="https://base.garant.ru/414329257/53f89421bbdaf741eb2d1ecc4ddb4c33/" target="_blank" rel="noopener">СанПиН <span class="nw">2.3/2.4.4282-26</span></a></td><td data-l="Для кого">общепит, детские организации, медицинские организации — при питании пациентов, детей, в соцобслуживании</td><td data-l="Образец или услуга" class="dk-0">—</td></tr>
        <tr id="p5-10"><td data-l="№" class="dk-n">5.10</td><td data-l="Документ"><b>Журнал температуры и влажности хранения</b><span class="dk-note">Ежедневно — холодильное оборудование и склады, на бумаге и (или) в электронном виде</span></td><td data-l="Кто готовит">Вы</td><td data-l="Основание">п. 38 СП <span class="nw">2.3.6.4281-26</span> (<a href="https://legalacts.ru/doc/postanovlenie-glavnogo-gosudarstvennogo-sanitarnogo-vracha-rf-ot-02062026-n_2/" target="_blank" rel="noopener">legalacts.ru</a>)</td><td data-l="Для кого">торговля продуктами</td><td data-l="Образец или услуга" class="dk-0">—</td></tr>
        <tr id="p5-11"><td data-l="№" class="dk-n">5.11</td><td data-l="Документ"><b>Технологические журналы и журнал поступления сырья</b></td><td data-l="Кто готовит">Вы</td><td data-l="Основание"><a href="https://39.rospotrebnadzor.ru/content/perechen-svedeniy-kotorye-mogut-zaprashivatsya-kontrolnym-nadzornym-organom-u" target="_blank" rel="noopener">перечень сведений</a>, <a href="https://35.rospotrebnadzor.ru/informirovanie/perechen-svedeniy/" target="_blank" rel="noopener">вологодский вариант</a></td><td data-l="Для кого">пищевые производства</td><td data-l="Образец или услуга" class="dk-0">—</td></tr>
        <tr id="p5-12"><td data-l="№" class="dk-n">5.12</td><td data-l="Документ"><b>Журнал температуры и влажности хранения</b><span class="dk-note">Условия хранения, установленные изготовителем</span></td><td data-l="Кто готовит">Вы</td><td data-l="Основание">п. 7 ст. 17 <a href="https://docs.cntd.ru/document/902320560" target="_blank" rel="noopener"><span class="nw">ТР ТС 021/2011</span></a></td><td data-l="Для кого">склады</td><td data-l="Образец или услуга" class="dk-0">—</td></tr>
        <tr id="p5-13"><td data-l="№" class="dk-n">5.13</td><td data-l="Документ"><b>Технологические журналы учёта медицинских отходов</b></td><td data-l="Кто готовит">Вы</td><td data-l="Основание"><a href="https://39.rospotrebnadzor.ru/content/perechen-svedeniy-kotorye-mogut-zaprashivatsya-kontrolnym-nadzornym-organom-u" target="_blank" rel="noopener">перечень сведений</a>, раздел о медицинских организациях</td><td data-l="Для кого">медицинские организации</td><td data-l="Образец или услуга" class="dk-0">—</td></tr>
        <tr id="p5-14"><td data-l="№" class="dk-n">5.14</td><td data-l="Документ"><b>Журналы контроля стерилизаторов и предстерилизационной очистки</b><span class="dk-note">Работа стерилизаторов, накрытие стерильного стола, качество предстерилизационной очистки, работа ультрафиолетовых камер для хранения стерильных изделий</span></td><td data-l="Кто готовит">Вы</td><td data-l="Основание"><a href="https://39.rospotrebnadzor.ru/content/perechen-svedeniy-kotorye-mogut-zaprashivatsya-kontrolnym-nadzornym-organom-u" target="_blank" rel="noopener">перечень сведений</a>, раздел о медицинских организациях</td><td data-l="Для кого">медицинские организации</td><td data-l="Образец или услуга" class="dk-0">—</td></tr>
      </tbody>
    </table></div>
  </div>
</section>

<section class="s dk-sec" id="personal">
  <div class="wrap">
    <div class="head"><div class="eyebrow" data-eyebrow>Группа 6 из 8</div><h2 data-split>Документы на персонал: <em>медкнижки, медосмотры, гигиеническая аттестация</em></h2><p class="sub" data-fade>Медкнижки и медосмотры проверяют почти на каждом объекте. Инспектор сверяет их со списком работников.</p></div>
    <div class="dk-tw" data-fade><table class="d-table nb-tbl dk-tbl">
      <thead><tr><th scope="col">№</th><th scope="col">Документ</th><th scope="col">Кто готовит</th><th scope="col">Основание</th><th scope="col">Для кого</th><th scope="col">Образец или услуга</th></tr></thead>
      <tbody>
        <tr id="p6-1"><td data-l="№" class="dk-n">6.1</td><td data-l="Документ"><b>Личные медицинские книжки</b><span class="dk-note">С отметками о медосмотрах, гигиенической аттестации и прививках. Бумажные по прежней форме — до 1 сентября 2027 года, далее — электронные</span></td><td data-l="Кто готовит">Работник; сроки контролируете вы</td><td data-l="Основание">ст. 34 <span class="nw">52-ФЗ</span>; приказы Минздрава № 90н и № 705н (<a href="https://cgon.rospotrebnadzor.ru/lichnye-meditsinskie-knizhki/" target="_blank" rel="noopener">ЦГОН</a>)</td><td data-l="Для кого">если работникам она положена</td><td data-l="Образец или услуга" class="dk-0">—</td></tr>
        <tr id="p6-2"><td data-l="№" class="dk-n">6.2</td><td data-l="Документ"><b>Документы о медосмотрах</b><span class="dk-note">Список работников для осмотров, заключения предварительных осмотров, заключительный акт по периодическим</span></td><td data-l="Кто готовит">Вы и медорганизация</td><td data-l="Основание">приказ Минздрава № 29н (<a href="https://77.rospotrebnadzor.ru/index.php/press-centr/press-relizy/15322-o-vazhnosti-prokhozhdeniya-periodicheskikh-meditsinskikh-osmotrov-19-04-2026" target="_blank" rel="noopener">Роспотребнадзор по Москве</a>)</td><td data-l="Для кого">все объекты</td><td data-l="Образец или услуга" class="dk-0">—</td></tr>
        <tr id="p6-3"><td data-l="№" class="dk-n">6.3</td><td data-l="Документ"><b>Гигиеническая подготовка и аттестация</b><span class="dk-note">При приёме на работу, затем ежегодно — <span class="nw">с мясо-молочной</span> <span class="nw">и кремово-кондитерской</span> продукцией, детским питанием; остальным — раз в 2 года</span></td><td data-l="Кто готовит">Работник; организует работодатель</td><td data-l="Основание">приказ Минздрава № 229 (<a href="https://ppt.ru/news/medknijka/gigienicheskuyu-podgotovku-rabotnikov-razreshat-prohodit-samostoyatelno" target="_blank" rel="noopener">ppt.ru</a>); торговля — п. 6 СП <span class="nw">2.3.6.4281-26</span> (<a href="https://www.consultant.ru/document/cons_doc_LAW_535840/63e10d7dbe480f3e143ca0dec69ae0b31222f4ff/" target="_blank" rel="noopener">КонсультантПлюс</a>)</td><td data-l="Для кого">если работникам она положена</td><td data-l="Образец или услуга" class="dk-0">—</td></tr>
        <tr id="p6-4"><td data-l="№" class="dk-n">6.4</td><td data-l="Документ"><b>Сводная ведомость спецоценки условий труда</b></td><td data-l="Кто готовит">Вы и организация по СОУТ</td><td data-l="Основание"><a href="https://39.rospotrebnadzor.ru/content/perechen-svedeniy-kotorye-mogut-zaprashivatsya-kontrolnym-nadzornym-organom-u" target="_blank" rel="noopener">перечень сведений</a>, разделы о промышленных предприятиях и медицинских организациях</td><td data-l="Для кого">фармпроизводства, медицинские организации</td><td data-l="Образец или услуга" class="dk-0">—</td></tr>
        <tr id="p6-5"><td data-l="№" class="dk-n">6.5</td><td data-l="Документ"><b>Карточки выдачи СИЗ и документы на их качество</b></td><td data-l="Кто готовит">Вы</td><td data-l="Основание"><a href="https://39.rospotrebnadzor.ru/content/perechen-svedeniy-kotorye-mogut-zaprashivatsya-kontrolnym-nadzornym-organom-u" target="_blank" rel="noopener">перечень сведений</a>, разделы о промышленных предприятиях и медицинских организациях</td><td data-l="Для кого">фармпроизводства, медицинские организации</td><td data-l="Образец или услуга" class="dk-0">—</td></tr>
        <tr id="p6-6"><td data-l="№" class="dk-n">6.6</td><td data-l="Документ"><b>Сведения о прививках работников</b><span class="dk-note">Списочный состав с прививочным анамнезом, документы о подаче списка на иммунизацию и о назначении ответственного</span></td><td data-l="Кто готовит">Вы</td><td data-l="Основание"><a href="https://39.rospotrebnadzor.ru/content/perechen-svedeniy-kotorye-mogut-zaprashivatsya-kontrolnym-nadzornym-organom-u" target="_blank" rel="noopener">перечень сведений</a>, раздел о медицинских организациях</td><td data-l="Для кого">медицинские организации</td><td data-l="Образец или услуга" class="dk-0">—</td></tr>
      </tbody>
    </table></div>
    <p class="nb-after" data-fade>Порядок гигиенической подготовки могут изменить. Законопроект, внесённый в Госдуму 07.10.2026, предлагает проходить её при поступлении на работу и затем раз в 5 лет, с самостоятельной подготовкой и электронной оценкой. Если закон примут, изменения вступят в силу с 01.09.2027, а пока действует приказ № 229 (<a href="https://ppt.ru/news/medknijka/gigienicheskuyu-podgotovku-rabotnikov-razreshat-prohodit-samostoyatelno" target="_blank" rel="noopener">ppt.ru</a>, <a href="https://cntd.ru/news/read/pravitelstvo-predlozilo-obnovit-poriadok-gigieniceskoi-podgotovki-rabotnikov" target="_blank" rel="noopener">Техэксперт</a>).</p>
  </div>
</section>

<section class="s dk-sec" id="ispolnitel">
  <div class="wrap">
    <div class="head"><div class="eyebrow" data-eyebrow>Группа 7 из 8</div><h2 data-split>Документы исполнителя, <em>которые должны храниться у вас</em></h2><p class="sub" data-fade>Эти документы готовит подрядчик, но храниться они должны у вас: инспектор запрашивает их у проверяемой организации.</p></div>
    <div class="dk-tw" data-fade><table class="d-table nb-tbl dk-tbl">
      <thead><tr><th scope="col">№</th><th scope="col">Документ</th><th scope="col">Кто готовит</th><th scope="col">Основание</th><th scope="col">Для кого</th><th scope="col">Образец или услуга</th></tr></thead>
      <tbody>
        <tr id="p7-1"><td data-l="№" class="dk-n">7.1<span class="dk-ours" title="Делаем мы">●<span class="sr-only"> — делаем мы</span></span></td><td data-l="Документ"><b>Номер лицензии исполнителя и выписка из реестра</b><span class="dk-note">Лицензия на дезинфекционную деятельность; проверяется в реестре Роспотребнадзора</span></td><td data-l="Кто готовит">Мы</td><td data-l="Основание"><span class="nw">99-ФЗ</span>; постановление Правительства РФ № 337; <a href="https://fp.rospotrebnadzor.ru/licen/" target="_blank" rel="noopener">реестр лицензий</a></td><td data-l="Для кого">все объекты</td><td data-l="Образец или услуга" class="dk-0">—</td></tr>
        <tr id="p7-2"><td data-l="№" class="dk-n">7.2<span class="dk-ours" title="Делаем мы">●<span class="sr-only"> — делаем мы</span></span></td><td data-l="Документ"><b>Свидетельства о госрегистрации (СГР) и инструкции на средства исполнителя</b><span class="dk-note">На все средства, которые применяют на объекте; по запросу — паспорта безопасности</span></td><td data-l="Кто готовит">Мы</td><td data-l="Основание"><a href="https://39.rospotrebnadzor.ru/content/perechen-svedeniy-kotorye-mogut-zaprashivatsya-kontrolnym-nadzornym-organom-u" target="_blank" rel="noopener">перечень сведений</a></td><td data-l="Для кого">все объекты</td><td data-l="Образец или услуга" class="dk-0">—</td></tr>
        <tr id="p7-3"><td data-l="№" class="dk-n">7.3<span class="dk-ours" title="Делаем мы">●<span class="sr-only"> — делаем мы</span></span></td><td data-l="Документ"><b>Рекомендации по защите объекта и отметки о выполнении</b><span class="dk-note">Сетки, уплотнители, закрытие проёмов — то, что делает сам объект</span></td><td data-l="Кто готовит">Мы и вы</td><td data-l="Основание">п. 88 <a href="http://pravo.gov.ru/proxy/ips/?docbody=&amp;nd=602107773" target="_blank" rel="noopener">СанПиН <span class="nw">3.3686-21</span></a>; торговля — п. 78 СП <span class="nw">2.3.6.4281-26</span></td><td data-l="Для кого">все объекты</td><td data-l="Образец или услуга" class="dk-0">—</td></tr>
      </tbody>
    </table></div>
    <p class="nb-after" data-fade>Попросите подрядчика передать эти документы вместе с договором: без них инспектор не увидит, кто и чем обрабатывал объект.</p>
  </div>
</section>

<section class="s dk-sec" id="produkciya">
  <div class="wrap">
    <div class="head"><div class="eyebrow" data-eyebrow>Группа 8 из 8</div><h2 data-split>Документы на продукцию <em>и средства</em></h2><p class="sub" data-fade>Эти документы подтверждают происхождение, безопасность и прослеживаемость продукции. Их запрашивают на пищевых объектах, в торговле и сфере услуг.</p></div>
    <div class="dk-tw" data-fade><table class="d-table nb-tbl dk-tbl">
      <thead><tr><th scope="col">№</th><th scope="col">Документ</th><th scope="col">Кто готовит</th><th scope="col">Основание</th><th scope="col">Для кого</th><th scope="col">Образец или услуга</th></tr></thead>
      <tbody>
        <tr id="p8-1"><td data-l="№" class="dk-n">8.1</td><td data-l="Документ"><b>Товаросопроводительные документы</b><span class="dk-note">Накладные, ТТН — на продукцию, которая есть на объекте</span></td><td data-l="Кто готовит">Поставщик; храните вы</td><td data-l="Основание"><a href="https://39.rospotrebnadzor.ru/content/perechen-svedeniy-kotorye-mogut-zaprashivatsya-kontrolnym-nadzornym-organom-u" target="_blank" rel="noopener">перечень сведений</a>; общепит — п. 5 <a href="https://base.garant.ru/414329257/53f89421bbdaf741eb2d1ecc4ddb4c33/" target="_blank" rel="noopener">СанПиН <span class="nw">2.3/2.4.4282-26</span></a></td><td data-l="Для кого">пищевые производства, общепит, торговля продуктами, склады, детские организации — если есть пищеблок, медицинские организации — если есть пищеблок, салоны красоты, бани и сауны, прачечные и химчистки</td><td data-l="Образец или услуга" class="dk-0">—</td></tr>
        <tr id="p8-2"><td data-l="№" class="dk-n">8.2</td><td data-l="Документ"><b>Декларации и сертификаты соответствия, СГР</b><span class="dk-note">На продукцию, для которой они обязательны</span></td><td data-l="Кто готовит">Изготовитель или поставщик</td><td data-l="Основание"><a href="https://39.rospotrebnadzor.ru/content/perechen-svedeniy-kotorye-mogut-zaprashivatsya-kontrolnym-nadzornym-organom-u" target="_blank" rel="noopener">перечень сведений</a></td><td data-l="Для кого">пищевые производства, общепит, торговля продуктами, склады, детские организации — если есть пищеблок, медицинские организации — если есть пищеблок, салоны красоты, бани и сауны, прачечные и химчистки</td><td data-l="Образец или услуга" class="dk-0">—</td></tr>
        <tr id="p8-3"><td data-l="№" class="dk-n">8.3</td><td data-l="Документ"><b>Технологические <span class="nw">и технико-технологические</span> карты</b><span class="dk-note">Утверждены руководителем; названия блюд в меню — как в картах</span></td><td data-l="Кто готовит">Вы</td><td data-l="Основание">п. 11 <a href="https://base.garant.ru/414329257/53f89421bbdaf741eb2d1ecc4ddb4c33/" target="_blank" rel="noopener">СанПиН <span class="nw">2.3/2.4.4282-26</span></a></td><td data-l="Для кого">общепит</td><td data-l="Образец или услуга" class="dk-0">—</td></tr>
        <tr id="p8-4"><td data-l="№" class="dk-n">8.4</td><td data-l="Документ"><b>Документация на выпускаемую продукцию</b><span class="dk-note">Нормативная и техническая документация, ассортиментный перечень, декларации</span></td><td data-l="Кто готовит">Вы</td><td data-l="Основание"><a href="https://35.rospotrebnadzor.ru/informirovanie/perechen-svedeniy/" target="_blank" rel="noopener">перечень сведений</a></td><td data-l="Для кого">пищевые производства</td><td data-l="Образец или услуга" class="dk-0">—</td></tr>
        <tr id="p8-5"><td data-l="№" class="dk-n">8.5</td><td data-l="Документ"><b>Маркировка и данные системы «Честный знак»</b><span class="dk-note">Этикетки и коды маркировки — если продаёте маркируемые товары</span></td><td data-l="Кто готовит">Вы</td><td data-l="Основание"><a href="https://35.rospotrebnadzor.ru/informirovanie/perechen-svedeniy/" target="_blank" rel="noopener">перечень сведений</a></td><td data-l="Для кого">торговля продуктами — если продаёте маркируемые товары</td><td data-l="Образец или услуга" class="dk-0">—</td></tr>
        <tr id="p8-6"><td data-l="№" class="dk-n">8.6</td><td data-l="Документ"><b>Сведения о применении пестицидов в растительном сырье</b><span class="dk-note">Если используете растительное сырьё</span></td><td data-l="Кто готовит">Поставщик</td><td data-l="Основание"><a href="https://39.rospotrebnadzor.ru/content/perechen-svedeniy-kotorye-mogut-zaprashivatsya-kontrolnym-nadzornym-organom-u" target="_blank" rel="noopener">перечень сведений</a></td><td data-l="Для кого">пищевые производства — если используете растительное сырьё</td><td data-l="Образец или услуга" class="dk-0">—</td></tr>
        <tr id="p8-7"><td data-l="№" class="dk-n">8.7</td><td data-l="Документ"><b>Документы на дезинфицирующие и моющие средства</b><span class="dk-note">СГР или декларации и инструкции — на средства, которые применяет ваш персонал</span></td><td data-l="Кто готовит">Поставщик; храните вы</td><td data-l="Основание"><a href="https://39.rospotrebnadzor.ru/content/perechen-svedeniy-kotorye-mogut-zaprashivatsya-kontrolnym-nadzornym-organom-u" target="_blank" rel="noopener">перечень сведений</a></td><td data-l="Для кого">все объекты</td><td data-l="Образец или услуга" class="dk-0">—</td></tr>
        <tr id="p8-8"><td data-l="№" class="dk-n">8.8</td><td data-l="Документ"><b>Документы на оборудование</b><span class="dk-note">Стерилизаторы, бактерицидные облучатели, ультразвуковые установки — паспорта, сертификаты, инструкции; в медицинских организациях — и упаковочный материал для стерилизации, для солярия — на оборудование и лампы</span></td><td data-l="Кто готовит">Поставщик; храните вы</td><td data-l="Основание"><a href="https://39.rospotrebnadzor.ru/content/perechen-svedeniy-kotorye-mogut-zaprashivatsya-kontrolnym-nadzornym-organom-u" target="_blank" rel="noopener">перечень сведений</a>, разделы о персональных услугах и медицинских организациях</td><td data-l="Для кого">медицинские организации, салоны красоты, бани и сауны, прачечные и химчистки — если есть такое оборудование</td><td data-l="Образец или услуга" class="dk-0">—</td></tr>
      </tbody>
    </table></div>
  </div>
</section>


<section class="s" id="po-obektam">
  <div class="wrap">
    <div class="head"><div class="eyebrow" data-eyebrow>По видам объектов</div><h2 data-split>Что добавить к общему списку <em>для вашего объекта</em></h2></div>
    <div class="dk-objs" data-dk-tabs data-fade>
      <div class="dk-tabs" role="tablist" aria-label="Вид объекта"><button type="button" role="tab" class="dk-tab" id="dk-tab-pp" aria-controls="obj-pp" aria-selected="true" data-obj="pp">Пищевое производство</button><button type="button" role="tab" class="dk-tab" id="dk-tab-ob" aria-controls="obj-ob" aria-selected="false" data-obj="ob">Ресторан, кафе, столовая</button><button type="button" role="tab" class="dk-tab" id="dk-tab-tr" aria-controls="obj-tr" aria-selected="false" data-obj="tr">Магазин продуктов, торговая сеть</button><button type="button" role="tab" class="dk-tab" id="dk-tab-sk" aria-controls="obj-sk" aria-selected="false" data-obj="sk">Склад пищевой продукции</button><button type="button" role="tab" class="dk-tab" id="dk-tab-fa" aria-controls="obj-fa" aria-selected="false" data-obj="fa">Фармацевтическое производство</button><button type="button" role="tab" class="dk-tab" id="dk-tab-go" aria-controls="obj-go" aria-selected="false" data-obj="go">Гостиница, хостел</button><button type="button" role="tab" class="dk-tab" id="dk-tab-md" aria-controls="obj-md" aria-selected="false" data-obj="md">Медицинская организация</button><button type="button" role="tab" class="dk-tab" id="dk-tab-ap" aria-controls="obj-ap" aria-selected="false" data-obj="ap">Аптека</button><button type="button" role="tab" class="dk-tab" id="dk-tab-sh" aria-controls="obj-sh" aria-selected="false" data-obj="sh">Школа, детский сад, лагерь</button><button type="button" role="tab" class="dk-tab" id="dk-tab-us" aria-controls="obj-us" aria-selected="false" data-obj="us">Салон красоты, парикмахерская</button><button type="button" role="tab" class="dk-tab" id="dk-tab-bn" aria-controls="obj-bn" aria-selected="false" data-obj="bn">Баня, сауна</button><button type="button" role="tab" class="dk-tab" id="dk-tab-pr" aria-controls="obj-pr" aria-selected="false" data-obj="pr">Прачечная, химчистка</button><button type="button" role="tab" class="dk-tab" id="dk-tab-sp" aria-controls="obj-sp" aria-selected="false" data-obj="sp">Спорт, бассейн, фитнес</button><button type="button" role="tab" class="dk-tab" id="dk-tab-nt" aria-controls="obj-nt" aria-selected="false" data-obj="nt">Непродовольственный магазин</button><button type="button" role="tab" class="dk-tab" id="dk-tab-dr" aria-controls="obj-dr" aria-selected="false" data-obj="dr">Другой объект</button></div>
      <details class="dk-o" id="obj-pp" data-obj="pp" open><summary>Пищевое производство<small>49 документов</small></summary><div class="dk-o-b" role="tabpanel" aria-labelledby="dk-tab-pp"><div class="dk-o-col"><p class="dk-o-k">Добавьте к общему списку</p><ul class="dk-x"><li><a href="#p1-8" class="dk-x-n">1.8</a> Документы по процедурам ХАССП</li><li><a href="#p2-9" class="dk-x-n">2.9</a> Передача и утилизация отходов производства</li><li><a href="#p4-5" class="dk-x-n">4.5</a> Пищевая продукция и сырьё</li><li><a href="#p5-11" class="dk-x-n">5.11</a> Технологические журналы и журнал поступления сырья</li><li><a href="#p8-1" class="dk-x-n">8.1</a> Товаросопроводительные документы</li><li><a href="#p8-2" class="dk-x-n">8.2</a> Декларации и сертификаты соответствия, СГР</li><li><a href="#p8-4" class="dk-x-n">8.4</a> Документация на выпускаемую продукцию</li><li><a href="#p8-6" class="dk-x-n">8.6</a> Сведения о применении пестицидов в растительном сырье <span class="dk-x-c">(если используете растительное сырьё)</span></li></ul><p class="dk-o-k">Проверочный лист</p><p class="dk-o-cl">Отдельной формы в приказах № 578 и № 580 нет</p></div><div class="dk-o-col"><p class="dk-o-k">Что важно</p><ul class="dk-imp"><li>Объект из п. 98 СанПиН <span class="nw">3.3686-21</span>: обследования на насекомых не реже 2 раз в месяц, ежемесячная оценка заселённости грызунами. Насекомых и грызунов на объекте быть не должно (п. 128).</li><li>Процедуры ХАССП оценивают по МР <span class="nw">5.1.0098-14</span>: инспектор запрашивает инструкции, договоры, акты <span class="nw">сдачи-приёмки</span>, журналы и графики.</li></ul><p class="dk-o-page"><a href="../../pishchevoe-proizvodstvo/"><span class="nw">Пест-контроль</span> на пищевом производстве →</a></p></div></div></details>
      <details class="dk-o" id="obj-ob" data-obj="ob"><summary>Ресторан, кафе, столовая<small>50 документов</small></summary><div class="dk-o-b" role="tabpanel" aria-labelledby="dk-tab-ob"><div class="dk-o-col"><p class="dk-o-k">Добавьте к общему списку</p><ul class="dk-x"><li><a href="#p1-8" class="dk-x-n">1.8</a> Документы по процедурам ХАССП</li><li><a href="#p4-5" class="dk-x-n">4.5</a> Пищевая продукция и сырьё</li><li><a href="#p5-6" class="dk-x-n">5.6</a> Гигиенический журнал</li><li><a href="#p5-7" class="dk-x-n">5.7</a> Журналы температуры холодильного оборудования, температуры и влажности склада</li><li><a href="#p5-8" class="dk-x-n">5.8</a> Учёт замены фритюрных жиров <span class="dk-x-c">(если есть фритюр)</span></li><li><a href="#p5-9" class="dk-x-n">5.9</a> Журналы бракеража готовой и скоропортящейся продукции <span class="dk-x-c">(при питании пациентов, детей, в соцобслуживании)</span></li><li><a href="#p8-1" class="dk-x-n">8.1</a> Товаросопроводительные документы</li><li><a href="#p8-2" class="dk-x-n">8.2</a> Декларации и сертификаты соответствия, СГР</li><li><a href="#p8-3" class="dk-x-n">8.3</a> Технологические <span class="nw">и технико-технологические</span> карты</li></ul><p class="dk-o-k">Проверочный лист</p><p class="dk-o-cl">№ 580, прил. 2 — вопросы 11, 58, 108, 109. Питание детей — № 578, прил. 24</p></div><div class="dk-o-col"><p class="dk-o-k">Что важно</p><ul class="dk-imp"><li>ППК — на принципах ХАССП (п. 4 СанПиН <span class="nw">2.3/2.4.4282-26</span>).</li><li>Во время дезинсекции и дератизации нельзя хранить и готовить продукцию, а распыляемые и рассыпаемые средства — применять при посетителях и персонале (п. 45). Поэтому в актах важны дата и время обработки.</li></ul><p class="dk-o-page"><a href="../../restorany-i-kafe/"><span class="nw">Пест-контроль</span> ресторанов и кафе →</a></p></div></div></details>
      <details class="dk-o" id="obj-tr" data-obj="tr"><summary>Магазин продуктов, торговая сеть<small>47 документов</small></summary><div class="dk-o-b" role="tabpanel" aria-labelledby="dk-tab-tr"><div class="dk-o-col"><p class="dk-o-k">Добавьте к общему списку</p><ul class="dk-x"><li><a href="#p1-8" class="dk-x-n">1.8</a> Документы по процедурам ХАССП <span class="dk-x-c">(если есть собственное производство)</span></li><li><a href="#p4-5" class="dk-x-n">4.5</a> Пищевая продукция и сырьё <span class="dk-x-c">(если есть собственное производство)</span></li><li><a href="#p5-10" class="dk-x-n">5.10</a> Журнал температуры и влажности хранения</li><li><a href="#p8-1" class="dk-x-n">8.1</a> Товаросопроводительные документы</li><li><a href="#p8-2" class="dk-x-n">8.2</a> Декларации и сертификаты соответствия, СГР</li><li><a href="#p8-5" class="dk-x-n">8.5</a> Маркировка и данные системы «Честный знак» <span class="dk-x-c">(если продаёте маркируемые товары)</span></li></ul><p class="dk-o-k">Проверочный лист</p><p class="dk-o-cl">№ 580, прил. 1 — вопросы 58, 89, 138, 153, 155</p></div><div class="dk-o-col"><p class="dk-o-k">Что важно</p><ul class="dk-imp"><li>Ежедневный журнал температуры и влажности (п. 38 СП <span class="nw">2.3.6.4281-26</span>), термометры или автоматическая регистрация (п. 32).</li><li>Гигиеническая подготовка работников, контактирующих с продукцией, — при приёме и не реже 1 раза в 2 года (п. 6). Сыпучие продукты — в помещениях без амбарных вредителей (п. 46), дератизация площадки накопления отходов (п. 72), насекомые и грызуны не допускаются (п. 78).</li></ul><p class="dk-o-page"><a href="../../magaziny-i-torgovye-seti/"><span class="nw">Пест-контроль</span> для магазинов и торговых сетей →</a></p></div></div></details>
      <details class="dk-o" id="obj-sk" data-obj="sk"><summary>Склад пищевой продукции<small>44 документа</small></summary><div class="dk-o-b" role="tabpanel" aria-labelledby="dk-tab-sk"><div class="dk-o-col"><p class="dk-o-k">Добавьте к общему списку</p><ul class="dk-x"><li><a href="#p5-12" class="dk-x-n">5.12</a> Журнал температуры и влажности хранения</li><li><a href="#p8-1" class="dk-x-n">8.1</a> Товаросопроводительные документы</li><li><a href="#p8-2" class="dk-x-n">8.2</a> Декларации и сертификаты соответствия, СГР</li></ul><p class="dk-o-k">Проверочный лист</p><p class="dk-o-cl">Отдельной формы нет</p></div><div class="dk-o-col"><p class="dk-o-k">Что важно</p><ul class="dk-imp"><li>Хранение пищевой продукции входит в п. 98 СанПиН <span class="nw">3.3686-21</span> — кратность обследований как у пищевых объектов.</li><li>Журнал температуры и влажности — по условиям изготовителя (ст. 17 <span class="nw">ТР ТС 021/2011</span>); документы, подтверждающие прослеживаемость партий.</li></ul><p class="dk-o-page"><a href="../../sklady-i-logistika/"><span class="nw">Пест-контроль</span> для складов и логистики →</a></p></div></div></details>
      <details class="dk-o" id="obj-fa" data-obj="fa"><summary>Фармацевтическое производство<small>46 документов</small></summary><div class="dk-o-b" role="tabpanel" aria-labelledby="dk-tab-fa"><div class="dk-o-col"><p class="dk-o-k">Добавьте к общему списку</p><ul class="dk-x"><li><a href="#p1-9" class="dk-x-n">1.9</a> Перечень сырья и материалов, список оборудования — источников ультразвука, инфразвука и излучений</li><li><a href="#p2-9" class="dk-x-n">2.9</a> Передача и утилизация отходов производства</li><li><a href="#p4-8" class="dk-x-n">4.8</a> Атмосферный воздух на границе <span class="nw">санитарно-защитной</span> зоны <span class="dk-x-c">(если есть выбросы)</span></li><li><a href="#p6-4" class="dk-x-n">6.4</a> Сводная ведомость спецоценки условий труда</li><li><a href="#p6-5" class="dk-x-n">6.5</a> Карточки выдачи СИЗ и документы на их качество</li></ul><p class="dk-o-k">Проверочный лист</p><p class="dk-o-cl">Отдельной формы нет</p></div><div class="dk-o-col"><p class="dk-o-k">Что важно</p><ul class="dk-imp"><li>Для Роспотребнадзора — документы промышленного предприятия: условия труда, спецоценка, медосмотры, СИЗ, замеры, отходы, <span class="nw">санитарно-защитная</span> зона. Так же собирают папку другие промышленные предприятия.</li><li><span class="nw">Пест-контроль</span> по п. 3.4 Правил GMP ЕАЭС оценивают на инспекциях GMP и аудитах — это отдельная проверка.</li></ul><p class="dk-o-page"><a href="../../farmatsevticheskie-proizvodstva/"><span class="nw">Пест-контроль</span> фармацевтического производства по GMP →</a></p></div></div></details>
      <details class="dk-o" id="obj-go" data-obj="go"><summary>Гостиница, хостел<small>41 документ</small></summary><div class="dk-o-b" role="tabpanel" aria-labelledby="dk-tab-go"><div class="dk-o-col"><p class="dk-o-k">Добавьте к общему списку</p><p class="dk-x-none">Ничего — подходит общий список.</p><p class="dk-o-k">Проверочный лист</p><p class="dk-o-cl">№ 578, прил. 2 — вопросы 28 и 39–43</p></div><div class="dk-o-col"><p class="dk-o-k">Что важно</p><ul class="dk-imp"><li>Гостиницы входят в п. 98: обследования не реже 2 раз в месяц, ежемесячная оценка заселённости грызунами, обследование мусорокамер (п. 133), легионеллы — при централизованном кондиционировании и увлажнении (п. 132).</li><li>Уведомление о начале деятельности гостиницы не подают: гостиничные услуги исключены из перечня постановления № 725. Если есть ресторан, добавьте раздел «Ресторан, кафе, столовая».</li></ul><p class="dk-o-page"><a href="../../gostinitsy/"><span class="nw">Пест-контроль</span> гостиниц и отелей →</a></p></div></div></details>
      <details class="dk-o" id="obj-md" data-obj="md"><summary>Медицинская организация<small>58 документов</small></summary><div class="dk-o-b" role="tabpanel" aria-labelledby="dk-tab-md"><div class="dk-o-col"><p class="dk-o-k">Добавьте к общему списку</p><ul class="dk-x"><li><a href="#p1-8" class="dk-x-n">1.8</a> Документы по процедурам ХАССП <span class="dk-x-c">(если есть пищеблок)</span></li><li><a href="#p1-10" class="dk-x-n">1.10</a> Документы по обращению с медицинскими отходами</li><li><a href="#p1-11" class="dk-x-n">1.11</a> План профилактических и противоэпидемических мероприятий</li><li><a href="#p2-11" class="dk-x-n">2.11</a> Вывоз и обезвреживание медицинских отходов</li><li><a href="#p2-12" class="dk-x-n">2.12</a> Обслуживание медицинской техники</li><li><a href="#p3-9" class="dk-x-n">3.9</a> Ежегодная проверка эффективности, очистка и дезинфекция вентиляции</li><li><a href="#p5-6" class="dk-x-n">5.6</a> Гигиенический журнал <span class="dk-x-c">(если есть пищеблок)</span></li><li><a href="#p5-7" class="dk-x-n">5.7</a> Журналы температуры холодильного оборудования, температуры и влажности склада <span class="dk-x-c">(если есть пищеблок)</span></li><li><a href="#p5-9" class="dk-x-n">5.9</a> Журналы бракеража готовой и скоропортящейся продукции <span class="dk-x-c">(при питании пациентов, детей, в соцобслуживании)</span></li><li><a href="#p5-13" class="dk-x-n">5.13</a> Технологические журналы учёта медицинских отходов</li><li><a href="#p5-14" class="dk-x-n">5.14</a> Журналы контроля стерилизаторов и предстерилизационной очистки</li><li><a href="#p6-4" class="dk-x-n">6.4</a> Сводная ведомость спецоценки условий труда</li><li><a href="#p6-5" class="dk-x-n">6.5</a> Карточки выдачи СИЗ и документы на их качество</li><li><a href="#p6-6" class="dk-x-n">6.6</a> Сведения о прививках работников</li><li><a href="#p8-1" class="dk-x-n">8.1</a> Товаросопроводительные документы <span class="dk-x-c">(если есть пищеблок)</span></li><li><a href="#p8-2" class="dk-x-n">8.2</a> Декларации и сертификаты соответствия, СГР <span class="dk-x-c">(если есть пищеблок)</span></li><li><a href="#p8-8" class="dk-x-n">8.8</a> Документы на оборудование <span class="dk-x-c">(если есть такое оборудование)</span></li></ul><p class="dk-o-k">Проверочный лист</p><p class="dk-o-cl">№ 578, прил. 10 — вопросы 8, 9, 10, 67, 144, 198</p></div><div class="dk-o-col"><p class="dk-o-k">Что важно</p><ul class="dk-imp"><li>Медицинские организации входят в п. 98 СанПиН <span class="nw">3.3686-21</span>: обследования на насекомых не реже 2 раз в месяц, ежемесячная оценка заселённости грызунами, дератизация по п. 110 (вопрос 198 листа). Ещё вопросы — грызунонепроницаемость перекрытий и мест прохода коммуникаций (9), защита продухов чердаков и подвалов (67).</li><li>Не реже 1 раза в год — проверка эффективности работы, очистка и дезинфекция механической <span class="nw">приточно-вытяжной</span> вентиляции и кондиционирования (подп. 2 п. 24 СП <span class="nw">2.1.4284-26</span>). Если есть пищеблок, к папке добавляются программа ХАССП, журналы пищеблока и документы на продукты.</li></ul></div></div></details>
      <details class="dk-o" id="obj-ap" data-obj="ap"><summary>Аптека<small>41 документ</small></summary><div class="dk-o-b" role="tabpanel" aria-labelledby="dk-tab-ap"><div class="dk-o-col"><p class="dk-o-k">Добавьте к общему списку</p><p class="dk-x-none">Ничего — подходит общий список.</p><p class="dk-o-k">Проверочный лист</p><p class="dk-o-cl">№ 578, прил. 11 — вопросы 19, 24–27</p></div><div class="dk-o-col"><p class="dk-o-k">Что важно</p><ul class="dk-imp"><li>В листе для аптек — почти полный набор вопросов о вредителях, кроме мусорокамер: отсутствие насекомых и грызунов, обработки силами организации, осуществляющей дезинфекционную деятельность, кратность обследований, ежемесячная оценка заселённости грызунами, контейнерная площадка (вопросы 19, 24–27).</li><li>Помещения аптеки ежедневно убирают влажным способом с моющими и дезинфицирующими средствами, запас средств — на 3 дня (п. 64 СП <span class="nw">2.1.4284-26</span>). Уборка с обработкой стен, полов, оборудования и светильников — не реже 1 раза в месяц, в помещениях асептического изготовления лекарств — еженедельно (п. 67).</li></ul></div></div></details>
      <details class="dk-o" id="obj-sh" data-obj="sh"><summary>Школа, детский сад, лагерь<small>51 документ</small></summary><div class="dk-o-b" role="tabpanel" aria-labelledby="dk-tab-sh"><div class="dk-o-col"><p class="dk-o-k">Добавьте к общему списку</p><ul class="dk-x"><li><a href="#p1-8" class="dk-x-n">1.8</a> Документы по процедурам ХАССП <span class="dk-x-c">(если есть свой пищеблок)</span></li><li><a href="#p1-12" class="dk-x-n">1.12</a> Примерное меню и расписание занятий</li><li><a href="#p2-13" class="dk-x-n">2.13</a> Медицинское обслуживание детей</li><li><a href="#p2-14" class="dk-x-n">2.14</a> Камерная обработка постельных принадлежностей <span class="dk-x-c">(для детских садов и лагерей)</span></li><li><a href="#p2-15" class="dk-x-n">2.15</a> Противоклещевые (акарицидные) обработки <span class="dk-x-c">(для загородных лагерей)</span></li><li><a href="#p5-6" class="dk-x-n">5.6</a> Гигиенический журнал</li><li><a href="#p5-7" class="dk-x-n">5.7</a> Журналы температуры холодильного оборудования, температуры и влажности склада</li><li><a href="#p5-9" class="dk-x-n">5.9</a> Журналы бракеража готовой и скоропортящейся продукции <span class="dk-x-c">(при питании пациентов, детей, в соцобслуживании)</span></li><li><a href="#p8-1" class="dk-x-n">8.1</a> Товаросопроводительные документы <span class="dk-x-c">(если есть пищеблок)</span></li><li><a href="#p8-2" class="dk-x-n">8.2</a> Декларации и сертификаты соответствия, СГР <span class="dk-x-c">(если есть пищеблок)</span></li></ul><p class="dk-o-k">Проверочный лист</p><p class="dk-o-cl">№ 578, прил. 14 (школы) — вопрос 64; питание детей — № 578, прил. 24</p></div><div class="dk-o-col"><p class="dk-o-k">Что важно</p><ul class="dk-imp"><li>Детские организации входят в п. 98 СанПиН <span class="nw">3.3686-21</span>: обследования на насекомых не реже 2 раз в месяц, ежемесячная оценка заселённости грызунами. В листе для школ — вопрос 64: организация и контроль дезинфекции, дезинсекции, дератизации и противоклещевых обработок (подп. 6 п. 14 и подп. 4 п. 21 СП <span class="nw">2.4.2.4283-26</span>).</li><li>В загородных лагерях до начала смены проводят противоклещевую обработку и мероприятия по борьбе с грызунами, в детских садах и лагерях — камерную обработку постельных принадлежностей. Акт обследования вентиляции запрашивают по перечню сведений для детских организаций.</li></ul></div></div></details>
      <details class="dk-o" id="obj-us" data-obj="us"><summary>Салон красоты, парикмахерская<small>46 документов</small></summary><div class="dk-o-b" role="tabpanel" aria-labelledby="dk-tab-us"><div class="dk-o-col"><p class="dk-o-k">Добавьте к общему списку</p><ul class="dk-x"><li><a href="#p2-10" class="dk-x-n">2.10</a> Водоснабжение, водоотведение, тепло- и электроснабжение</li><li><a href="#p4-9" class="dk-x-n">4.9</a> Контроль стерилизации инструментов и работы стерилизаторов <span class="dk-x-c">(если стерилизуете инструменты)</span></li><li><a href="#p8-1" class="dk-x-n">8.1</a> Товаросопроводительные документы</li><li><a href="#p8-2" class="dk-x-n">8.2</a> Декларации и сертификаты соответствия, СГР</li><li><a href="#p8-8" class="dk-x-n">8.8</a> Документы на оборудование <span class="dk-x-c">(если есть такое оборудование)</span></li></ul><p class="dk-o-k">Проверочный лист</p><p class="dk-o-cl">№ 580, прил. 5 — вопросы 20, 28–33, 89, 90</p></div><div class="dk-o-col"><p class="dk-o-k">Что важно</p><ul class="dk-imp"><li>Перечень сведений для персональных услуг включает договоры на водо-, тепло- и электроснабжение, на стирку белья, на утилизацию ламп, документы на стерилизаторы и облучатели и контроль стерилизации.</li><li>Ежедневная профилактическая дезинфекция, а также дезинсекция и дератизация (подп. 20 п. 99 СП <span class="nw">2.1.4284-26</span>). Производственный контроль: освещённость — раз в год, качество стерилизации и работа стерилизаторов — 2 раза в год (подп. 38).</li></ul></div></div></details>
      <details class="dk-o" id="obj-bn" data-obj="bn"><summary>Баня, сауна<small>45 документов</small></summary><div class="dk-o-b" role="tabpanel" aria-labelledby="dk-tab-bn"><div class="dk-o-col"><p class="dk-o-k">Добавьте к общему списку</p><ul class="dk-x"><li><a href="#p2-10" class="dk-x-n">2.10</a> Водоснабжение, водоотведение, тепло- и электроснабжение</li><li><a href="#p8-1" class="dk-x-n">8.1</a> Товаросопроводительные документы</li><li><a href="#p8-2" class="dk-x-n">8.2</a> Декларации и сертификаты соответствия, СГР</li><li><a href="#p8-8" class="dk-x-n">8.8</a> Документы на оборудование <span class="dk-x-c">(если есть такое оборудование)</span></li></ul><p class="dk-o-k">Проверочный лист</p><p class="dk-o-cl">№ 580, прил. 6 — вопросы 25, 35–39</p></div><div class="dk-o-col"><p class="dk-o-k">Что важно</p><ul class="dk-imp"><li>Лист для бань и саун — полный набор вопросов о вредителях: отсутствие насекомых и грызунов, обработки силами организации, осуществляющей дезинфекционную деятельность, кратность обследований, ежемесячная оценка заселённости грызунами, мусорокамеры и контейнерная площадка (вопросы 25, 35–39).</li><li>Ежедневно в отсутствие посетителей — уборка всех помещений с дезинфицирующими средствами, раз в неделю — с обработкой стен, полов, оборудования и светильников (подп. 13 и 14 п. 102 СП <span class="nw">2.1.4284-26</span>). Чистое и использованное бельё хранят в разных помещениях (подп. 10).</li></ul></div></div></details>
      <details class="dk-o" id="obj-pr" data-obj="pr"><summary>Прачечная, химчистка<small>45 документов</small></summary><div class="dk-o-b" role="tabpanel" aria-labelledby="dk-tab-pr"><div class="dk-o-col"><p class="dk-o-k">Добавьте к общему списку</p><ul class="dk-x"><li><a href="#p2-10" class="dk-x-n">2.10</a> Водоснабжение, водоотведение, тепло- и электроснабжение</li><li><a href="#p8-1" class="dk-x-n">8.1</a> Товаросопроводительные документы</li><li><a href="#p8-2" class="dk-x-n">8.2</a> Декларации и сертификаты соответствия, СГР</li><li><a href="#p8-8" class="dk-x-n">8.8</a> Документы на оборудование <span class="dk-x-c">(если есть такое оборудование)</span></li></ul><p class="dk-o-k">Проверочный лист</p><p class="dk-o-cl">№ 580, прил. 4 — вопросы 28, 49, 50, 68, 69</p></div><div class="dk-o-col"><p class="dk-o-k">Что важно</p><ul class="dk-imp"><li>В листе для прачечных и химчисток дератизация и дезинсекция — отдельными вопросами 68 и 69: их проводят по санитарным правилам профилактики инфекционных болезней (подп. 7 п. 98 СП <span class="nw">2.1.4284-26</span>). Ещё вопросы — отсутствие насекомых и грызунов (49), мусорокамеры (50), контейнерная площадка (28).</li><li>В прачечной — ежедневная влажная уборка, раз в месяц — уборка с обработкой стен, полов, оборудования и светильников, еженедельная дезинфекция. Потоки чистого и грязного белья не пересекаются, кроме прачечных самообслуживания (подп. 3, 7 и 8 п. 100 СП <span class="nw">2.1.4284-26</span>).</li></ul></div></div></details>
      <details class="dk-o" id="obj-sp" data-obj="sp"><summary>Спорт, бассейн, фитнес<small>43 документа</small></summary><div class="dk-o-b" role="tabpanel" aria-labelledby="dk-tab-sp"><div class="dk-o-col"><p class="dk-o-k">Добавьте к общему списку</p><ul class="dk-x"><li><a href="#p4-10" class="dk-x-n">4.10</a> Вода бассейна <span class="dk-x-c">(если есть бассейн или аквапарк)</span></li><li><a href="#p4-11" class="dk-x-n">4.11</a> Смывы в бассейне на колиформные бактерии и яйца гельминтов <span class="dk-x-c">(если есть бассейн)</span></li></ul><p class="dk-o-k">Проверочный лист</p><p class="dk-o-cl">№ 580, прил. 3 — вопросы 27, 51–55</p></div><div class="dk-o-col"><p class="dk-o-k">Что важно</p><ul class="dk-imp"><li>Лист для спорта, бассейнов и аквапарков — вопросы 27, 51–55: отсутствие насекомых и грызунов, обработки силами организации, осуществляющей дезинфекционную деятельность, кратность обследований (прямо в тексте вопроса 53), ежемесячная оценка заселённости грызунами, мусорокамеры и контейнерная площадка.</li><li>В бассейне по программе производственного контроля ведут лабораторный контроль воды, микроклимата, воздуха в зоне дыхания пловцов, шума и освещённости (подп. 31 п. 73 СП <span class="nw">2.1.4284-26</span>). Если качество воды не соответствует требованиям, результаты передают в Роспотребнадзор в течение 1 дня (подп. 36).</li></ul></div></div></details>
      <details class="dk-o" id="obj-nt" data-obj="nt"><summary>Непродовольственный магазин<small>41 документ</small></summary><div class="dk-o-b" role="tabpanel" aria-labelledby="dk-tab-nt"><div class="dk-o-col"><p class="dk-o-k">Добавьте к общему списку</p><p class="dk-x-none">Ничего — подходит общий список.</p><p class="dk-o-k">Проверочный лист</p><p class="dk-o-cl">№ 578, прил. 1 — вопрос 28</p></div><div class="dk-o-col"><p class="dk-o-k">Что важно</p><ul class="dk-imp"><li>В листе для торговли непродовольственными товарами один вопрос о вредителях — 28: при появлении насекомых и грызунов дезинсекцию и дератизацию проводит организация, осуществляющая дезинфекционную деятельность, в отсутствие работников и покупателей. Нужны договор с исполнителем, у которого есть лицензия, и акты.</li><li>Отделка помещений хранения и продажи товаров должна позволять ежедневную уборку с моющими средствами (п. 15 СП <span class="nw">2.1.4284-26</span>). Пестициды, агрохимикаты и строительные материалы хранят в отдельных помещениях или выделенных зонах склада (п. 19).</li></ul></div></div></details>
      <details class="dk-o" id="obj-dr" data-obj="dr"><summary>Другой объект<small>41 документ</small></summary><div class="dk-o-b" role="tabpanel" aria-labelledby="dk-tab-dr"><div class="dk-o-col"><p class="dk-o-k">Добавьте к общему списку</p><p class="dk-x-none">Ничего — подходит общий список.</p><p class="dk-o-k">Проверочный лист</p><p class="dk-o-cl">Форма — по виду деятельности, см. разбор проверочных листов</p></div><div class="dk-o-col"><p class="dk-o-k">Что важно</p><ul class="dk-imp"><li>Сверьтесь с официальным перечнем сведений и проверочным листом для своего вида деятельности: вопросы о вредителях есть в 20 из 37 форм приказов № 578 и № 580. Офисам <span class="nw">и бизнес-центрам</span> обычно достаточно общего списка.</li></ul></div></div></details>
    </div>
    <p class="nb-after" data-fade>Это ориентир. На одном объекте могут применяться несколько разделов и несколько форм проверочных листов — например, в гостинице с рестораном. Разбор вопросов о вредителях по каждой форме — на странице <a href="../../normativnaya-baza/proverochnye-listy/">«Проверочные листы 2026»</a>.</p>
  </div>
</section>

<section class="s" id="kak-zaprashivayut">
  <div class="wrap">
    <div class="head"><div class="eyebrow" data-eyebrow>Требование инспектора</div><h2 data-split>Как запрашивают документы <em>и в какой срок их представить</em></h2></div>
    <ul class="dk-rules" data-fade>
      <li><b>Инспекционный визит проводится без предварительного уведомления.</b> Инспектор вправе потребовать документы, которые по обязательным требованиям должны находиться на объекте (<a href="https://base.garant.ru/483427111/2c2bb927757944432208533b3ff87c36/" target="_blank" rel="noopener">ст. 70 <span class="nw">248-ФЗ</span></a>). Поэтому папка должна лежать на объекте, а не только в офисе.</li>
      <li><b>Срок указывают в требовании.</b> Если не успеваете, сразу направьте инспектору письменное ходатайство с причиной и сроком, в который сможете представить документы. Инспектор продлевает срок или отказывает в течение 24 часов (<a href="https://base.garant.ru/74449814/134df926347d321d8dc82c9551519f33/" target="_blank" rel="noopener">ч. 4 ст. 80 <span class="nw">248-ФЗ</span></a>).</li>
      <li><b>При документарной проверке — 10 рабочих дней</b> со дня получения требования (<a href="https://www.consultant.ru/document/cons_doc_LAW_358750/b4e4c47c5158a23084ade806c3f6ea297ea65ca5/" target="_blank" rel="noopener">ч. 4 ст. 72 <span class="nw">248-ФЗ</span></a>).</li>
      <li><b>Документы направляют в электронном виде,</b> если инспектор не потребовал бумагу. На бумаге — подлинники или копии, заверенные вами. Нотариального заверения копий требовать не вправе (<a href="https://base.garant.ru/74449814/134df926347d321d8dc82c9551519f33/" target="_blank" rel="noopener">ч. 2 ст. 80</a>).</li>
      <li><b>Повторно не отправляют.</b> Документы, которые вы уже представляли, можно не отправлять снова — достаточно сообщить, когда и с каким документом они были направлены (<a href="https://base.garant.ru/74449814/134df926347d321d8dc82c9551519f33/" target="_blank" rel="noopener">ч. 5 ст. 80</a>).</li>
    </ul>
    <h3 class="nb-h3 dk-h3" data-fade>Если документы нужно подать, а не показать</h3>
    <ul class="dk-rules" data-fade>
      <li><b>Уведомление о начале деятельности.</b> С 01.09.2025 действует постановление Правительства № 725: перечень видов деятельности сократился с 90 до 60, гостиничные услуги из него исключены (<a href="https://86.rospotrebnadzor.ru/news/obnovlenyi-trebovaniya-k-podache-uvedomlenij-o-nachale-osushhestvleniya-nekotoryix-vidov-deyatelnosti.html" target="_blank" rel="noopener">Роспотребнадзор по ХМАО</a>). Уведомление подают через Госуслуги до начала работы (<a href="http://26.rospotrebnadzor.ru/ond/uonpd/" target="_blank" rel="noopener">Роспотребнадзор по Ставропольскому краю</a>).</li>
      <li><b><span class="nw">Санитарно-эпидемиологическое</span> заключение</b> — отдельная госуслуга для отдельных видов деятельности. На этой странице её не разбираем.</li>
    </ul>
  </div>
</section>

<section class="s" id="sroki">
  <div class="wrap">
    <div class="head"><div class="eyebrow" data-eyebrow>Сроки 2027 года</div><h2 data-split>Что пересмотреть в папке <em>в 2027 году</em></h2></div>
    <ol class="nb-tl" data-fade>
      <li class="is-next"><span class="nb-tl-d">01.03.2027</span><p class="nb-tl-w">Заканчивается срок СанПиН <span class="nw">2.1.3684-21</span> — в нём требования к контейнерным площадкам (п. 8, прил. 1). После утверждения замены сверьте ссылки в ППК и договоре.</p><p class="nb-tl-a"><span class="nb-tl-k">Источник</span><a href="https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/normativnaya-baza/" target="_blank" rel="noopener">нормативная база сайта</a></p></li>
      <li class="is-next"><span class="nb-tl-d">01.09.2027</span><p class="nb-tl-w">Заканчивается срок СанПиН <span class="nw">3.3686-21</span> — главного документа о дезинсекции и дератизации. Программу <span class="nw">пест-контроля</span>, договор и раздел ППК нужно будет обновить.</p><p class="nb-tl-a"><span class="nb-tl-k">Источник</span><a href="https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/normativnaya-baza/" target="_blank" rel="noopener">нормативная база сайта</a></p></li>
      <li class="is-next"><span class="nb-tl-d">до 01.09.2027</span><p class="nb-tl-w">Можно выдавать и вести бумажные медкнижки прежней формы. Проверьте, у кого из работников они бумажные.</p><p class="nb-tl-a"><span class="nb-tl-k">Источник</span><a href="https://cgon.rospotrebnadzor.ru/lichnye-meditsinskie-knizhki/" target="_blank" rel="noopener">ЦГОН</a></p></li>
      <li class="is-next"><span class="nb-tl-d">с 01.09.2027</span><p class="nb-tl-w">Если примут законопроект, внесённый 07.10.2026, гигиеническая подготовка изменится: при поступлении на работу и затем раз в 5 лет, с самостоятельной подготовкой и электронной оценкой. Пока действует приказ № 229.</p><p class="nb-tl-a"><span class="nb-tl-k">Источник</span><a href="https://ppt.ru/news/medknijka/gigienicheskuyu-podgotovku-rabotnikov-razreshat-prohodit-samostoyatelno" target="_blank" rel="noopener">ppt.ru</a></p></li>
    </ol>
  </div>
</section>

<section class="s" id="oshibki">
  <div class="wrap">
    <div class="head"><div class="eyebrow" data-eyebrow>Ошибки</div><h2 data-split>Ошибки в папке, <em>которые видит инспектор</em></h2></div>
    <ul class="nb-errs" data-fade>
      <li>В договоре на дезинсекцию и дератизацию только «обработка раз в месяц», а актов обследований нет. Для объектов из п. 98 СанПиН <span class="nw">3.3686-21</span> обследования на насекомых нужны не реже 2 раз в месяц.</li>
      <li>Номер лицензии исполнителя не указан ни в договоре, ни в актах, или исполнителя нет в <a href="https://fp.rospotrebnadzor.ru/licen/" target="_blank" rel="noopener">реестре лицензий</a>.</li>
      <li>Акты без даты и времени, без средства и номера свидетельства о госрегистрации, без подписи представителя объекта.</li>
      <li>Мусорокамеры и контейнерная площадка не включены в договор и график.</li>
      <li>Схема точек контроля не совпадает с объектом: после ремонта или перепланировки её не обновили.</li>
      <li>Программа производственного контроля ссылается на отменённые правила — СанПиН <span class="nw">2.3/2.4.3590-20</span>, СП <span class="nw">2.3.6.3668-20</span>, СП <span class="nw">2.1.3678-20</span>, СП <span class="nw">2.2.3670-20</span>. С 1 сентября 2026 года действуют правила 2026 года.</li>
      <li>Протоколы лаборатории, у которой нужного исследования нет в области аккредитации.</li>
      <li>У части работников просрочен медосмотр или нет отметки о гигиенической аттестации.</li>
      <li>В журнале температуры пропущены дни.</li>
      <li>Нет договора с региональным оператором на вывоз отходов или актов к нему.</li>
      <li>Папка хранится в офисе, а на объекте документов нет.</li>
    </ul>
  </div>
</section>

<section class="s" id="gotovim">
  <div class="wrap">
    <div class="head"><div class="eyebrow" data-eyebrow>Что делаем мы</div><h2 data-split>Что из перечня <em>готовим мы</em></h2><p class="sub" data-fade>В таблицах эти строки отмечены значком <span class="dk-ours" aria-hidden="true">●</span>.</p></div>
    <div class="dk-we" data-group="cards">
      <a class="card nb-link dk-we-c" href="../../dogovor-deratizatsiya-dezinsektsiya/"><span class="nb-link-k">Пункты 1.6, 1.7, 2.1, 3.1–3.5, 5.1, 7.1–7.3</span><b><span class="nw">Пест-контроль</span> по договору</b><span class="dk-we-d">Программа <span class="nw">пест-контроля</span> и схема точек, журнал, акты обследований и обработок, отчёты по грызунам, раздел ППК о дезинсекции и дератизации, номер лицензии, свидетельства о госрегистрации и инструкции на средства, рекомендации по защите объекта.</span><span class="nb-link-go">Образец договора →</span></a>
      <a class="card nb-link dk-we-c" href="../../razrabotka-ppk/"><span class="nb-link-k">Пункты 1.6, 1.8</span><b>Разработка ППК</b><span class="dk-we-d">Программа производственного контроля (ППК) целиком под ваш объект: план лабораторных исследований, процедуры ХАССП для пищевых объектов, раздел о дезинсекции и дератизации.</span><span class="nb-link-go">Разработка программы производственного контроля →</span></a>
      <a class="card nb-link dk-we-c" href="../../ochistka-dezinfektsiya-ventilyatsii/"><span class="nb-link-k">Пункты 2.7, 3.6, 3.8, 3.9, 4.6, 5.2</span><b>Вентиляция</b><span class="dk-we-d">Очистка и дезинфекция, акты, журнал учёта работ, смывы на легионеллы в нашей лаборатории, очистка от горючих отложений.</span><span class="nb-link-go">Очистка и дезинфекция вентиляции →</span></a>
      <a class="card nb-link dk-we-c" href="../../dezinfektsiya/"><span class="nb-link-k">Пункты 2.8, 4.7</span><b>Дезинфекция</b><span class="dk-we-d">Профилактическая дезинфекция и оценка её эффективности.</span><span class="nb-link-go">Дезинфекция →</span></a>
      <a class="card nb-link dk-we-c" href="../../sanitarnyy-audit/"><span class="nb-link-k">Пункты 4.1, 4.2</span><b>Санитарный аудит</b><span class="dk-we-d">Проверим объект и папку документов до инспектора. Смывы и пробы воздуха входят в стоимость — от 9 000 ₽; если после аудита вы заключаете договор <span class="nw">на пест-контроль</span>, стоимость аудита засчитываем.</span><span class="nb-link-go">Санитарный аудит →</span></a>
      <a class="card nb-link dk-we-c" href="../../laboratornye-issledovaniya/"><span class="nb-link-k">Пункты 2.2, 4.1–4.11</span><b>Лабораторные исследования</b><span class="dk-we-d">Своя лаборатория: смывы, пробы воздуха, микроклимат, освещённость и шум, вода, продукция, легионеллы, эффективность дезинфекции. Отбираем пробы на объекте и передаём протоколы.</span><span class="nb-link-go">Цены и расчёт →</span></a>
    </div>
    <p class="nb-after" data-fade>Остальное готовите вы или профильные организации: медосмотры, гигиеническое обучение, вывоз отходов, документы на продукцию.</p>
  </div>
</section>

<section class="s" id="avtor">
  <div class="wrap">
    <div class="head"><div class="eyebrow" data-eyebrow>Автор и сверка</div><h2 data-split>Кто подготовил <em>перечень</em></h2></div>
    <div class="nb-author-wrap" data-fade>
      <div class="card nb-author">
        <img class="nb-avatar" src="../../img/san-author-photo-240.webp" srcset="../../img/san-author-photo-240.webp 240w, ../../img/san-author-photo-480.webp 480w" sizes="(max-width:600px) 80px, 112px" width="240" height="240" loading="lazy" decoding="async" alt="Иллюстративное фото санитарного врача, изображение сгенерировано">
        <div><p class="nb-author-name">Марианна Семерина</p><p class="nb-author-role">Санитарный врач, автор материала</p><p class="nb-author-date">Сверено с официальными текстами — 09.11.2026</p><p class="nb-author-note">Фото иллюстративное</p></div>
      </div>
      <p class="nb-author-text">Материал подготовила Марианна Семерина, санитарный врач. Тексты норм сверены с официальными публикациями 09.11.2026. Если вы заметили неточность или изменение, которое мы пропустили, напишите нам — исправим.</p>
    </div>
  </div>
</section>

<section class="s" id="istochniki">
  <div class="wrap">
    <details class="nb-src">
      <summary><span class="eyebrow" data-eyebrow>Источники</span><span class="nb-src-t">Официальные тексты и перечни (проверено 09.11.2026)</span></summary>
      <ul class="nb-base" data-fade>
        <li>Исчерпывающий перечень сведений по видам деятельности — <a href="https://39.rospotrebnadzor.ru/content/perechen-svedeniy-kotorye-mogut-zaprashivatsya-kontrolnym-nadzornym-organom-u" target="_blank" rel="noopener">Управление Роспотребнадзора по Калининградской области</a>, <a href="https://35.rospotrebnadzor.ru/informirovanie/perechen-svedeniy/" target="_blank" rel="noopener">Управление Роспотребнадзора по Вологодской области</a></li>
        <li>Производственный контроль — <a href="https://cgon.rospotrebnadzor.ru/biznesu/profilaktika-nadzor-uslsugi/profilakticheskie-meropriatiya/proizvodstvennyy-kontrol-chto-organizovat-biznesu/" target="_blank" rel="noopener">ЦГОН Роспотребнадзора</a>; п. 2.5 СП <span class="nw">1.1.1058-01</span> — <a href="https://www.garant.ru/consult/work_law/1620091/" target="_blank" rel="noopener">Гарант</a>; п. 1.1 ст. 32 <span class="nw">52-ФЗ</span> — <a href="https://www.consultant.ru/document/cons_doc_LAW_384394/d4d04d2e799bdca563354397e3c1f53374d9dce4/" target="_blank" rel="noopener">КонсультантПлюс</a></li>
        <li>СанПиН <span class="nw">3.3686-21</span> — <a href="http://pravo.gov.ru/proxy/ips/?docbody=&amp;nd=602107773" target="_blank" rel="noopener">pravo.gov.ru</a>; СанПиН <span class="nw">2.1.3684-21</span> — <a href="http://pravo.gov.ru/proxy/ips/?doc_itself=&amp;backlink=1&amp;nd=602024221&amp;page=1&amp;rdk=3" target="_blank" rel="noopener">pravo.gov.ru</a></li>
        <li>СанПиН <span class="nw">2.3/2.4.4282-26</span>, общественное питание — <a href="https://base.garant.ru/414329257/53f89421bbdaf741eb2d1ecc4ddb4c33/" target="_blank" rel="noopener">Гарант</a></li>
        <li>СП <span class="nw">2.3.6.4281-26</span>, торговля — <a href="https://www.consultant.ru/document/cons_doc_LAW_535840/63e10d7dbe480f3e143ca0dec69ae0b31222f4ff/" target="_blank" rel="noopener">КонсультантПлюс, пп. 4–6</a>, <a href="https://legalacts.ru/doc/postanovlenie-glavnogo-gosudarstvennogo-sanitarnogo-vracha-rf-ot-02062026-n_2/" target="_blank" rel="noopener">legalacts.ru, пп. 32 и 38</a></li>
        <li>СП <span class="nw">2.1.4284-26</span> — <a href="http://publication.pravo.gov.ru/file/pdf?eoNumber=0001202606020088" target="_blank" rel="noopener">официальное опубликование</a>; вопрос проверочного листа № 578 о вентиляции — <a href="https://base.garant.ru/414956074/172a6d689833ce3e42dc0a8a7b3cddf9/" target="_blank" rel="noopener">Гарант</a>; разделы о спорте и бассейнах и о бытовых услугах — КонсультантПлюс: <a href="https://www.consultant.ru/document/cons_doc_LAW_535828/d3a65cf056a7c1d728cf8966a09f98f749c89fb8/" target="_blank" rel="noopener">раздел VI</a>, <a href="https://www.consultant.ru/document/cons_doc_LAW_535828/45a6768995a9fa7489e36f9e456c2e12414a3907/" target="_blank" rel="noopener">раздел VIII</a></li>
        <li>Вентиляция, п. 132 СанПиН <span class="nw">3.3686-21</span> — <a href="https://cgon.rospotrebnadzor.ru/biznesu/articles/ventilyatsiya-ochistka-i-dezinfektsiya/" target="_blank" rel="noopener">ЦГОН</a></li>
        <li>Медкнижки — <a href="https://cgon.rospotrebnadzor.ru/lichnye-meditsinskie-knizhki/" target="_blank" rel="noopener">ЦГОН</a>; медосмотры, приказ № 29н — <a href="https://77.rospotrebnadzor.ru/index.php/press-centr/press-relizy/15322-o-vazhnosti-prokhozhdeniya-periodicheskikh-meditsinskikh-osmotrov-19-04-2026" target="_blank" rel="noopener">Роспотребнадзор по Москве</a>; гигиеническая подготовка — <a href="https://ppt.ru/news/medknijka/gigienicheskuyu-podgotovku-rabotnikov-razreshat-prohodit-samostoyatelno" target="_blank" rel="noopener">ppt.ru</a>, <a href="https://cntd.ru/news/read/pravitelstvo-predlozilo-obnovit-poriadok-gigieniceskoi-podgotovki-rabotnikov" target="_blank" rel="noopener">Техэксперт</a></li>
        <li>Вывоз ТКО — <a href="https://www.consultant.ru/law/podborki/obyazatelno_li_zaklyuchat_dogovor_s_regionalnym_operatorom/" target="_blank" rel="noopener">КонсультантПлюс</a>; отходы I–II класса — <a href="https://rpn.gov.ru/regions/51/news/o-neobkhodimosti-registratsii-v-fgis-opvk-pri-obrashchenii-s-otkhodami-i-i-ii-klassov-opasnosti-5825141.html" target="_blank" rel="noopener">Росприроднадзор</a></li>
        <li>Лицензирование — <a href="https://cgon.rospotrebnadzor.ru/biznesu/profilaktika-nadzor-uslsugi/nadzornie-meropriatiya/litsenzirovanie-dezinfektsionnoy-deyatelnosti/" target="_blank" rel="noopener">ЦГОН</a>, <a href="https://fp.rospotrebnadzor.ru/licen/" target="_blank" rel="noopener">реестр лицензий</a></li>
        <li>Уведомление о начале деятельности — <a href="https://86.rospotrebnadzor.ru/news/obnovlenyi-trebovaniya-k-podache-uvedomlenij-o-nachale-osushhestvleniya-nekotoryix-vidov-deyatelnosti.html" target="_blank" rel="noopener">Роспотребнадзор по ХМАО</a>, <a href="http://26.rospotrebnadzor.ru/ond/uonpd/" target="_blank" rel="noopener">Роспотребнадзор по Ставропольскому краю</a></li>
        <li><span class="nw">248-ФЗ</span>: ст. 70 — <a href="https://base.garant.ru/483427111/2c2bb927757944432208533b3ff87c36/" target="_blank" rel="noopener">Гарант</a>; ст. 72 — <a href="https://www.consultant.ru/document/cons_doc_LAW_358750/b4e4c47c5158a23084ade806c3f6ea297ea65ca5/" target="_blank" rel="noopener">КонсультантПлюс</a>; ст. 80 — <a href="https://base.garant.ru/74449814/134df926347d321d8dc82c9551519f33/" target="_blank" rel="noopener">Гарант</a></li>
        <li><span class="nw">ТР ТС 021/2011</span> — <a href="https://docs.cntd.ru/document/902320560" target="_blank" rel="noopener">Техэксперт</a>; МР <span class="nw">5.1.0098-14</span> — <a href="http://79.rospotrebnadzor.ru/upload/iblock_content/028bdce347a503c6ca4b9b2ce907161a.pdf" target="_blank" rel="noopener">Роспотребнадзор</a>; Правила GMP ЕАЭС — <a href="https://base.garant.ru/483423312/" target="_blank" rel="noopener">Гарант</a></li>
        <li>Проверочные листы № 578 и № 580 — Гарант: <a href="https://base.garant.ru/414956074/" target="_blank" rel="noopener">№ 578</a>, <a href="https://base.garant.ru/414962758/" target="_blank" rel="noopener">№ 580</a>; разбор вопросов — <a href="../../normativnaya-baza/proverochnye-listy/">«Проверочные листы 2026»</a></li>
      </ul>
    </details>
  </div>
</section>


<!-- ============ СМОТРИТЕ ТАКЖЕ (перелинковка) ============ -->
<section class="s s-rel" id="smotrite-takzhe">
  <div class="wrap">
    <div class="head">
      <div class="eyebrow" data-eyebrow>Смотрите также</div>
      <h2 data-split>Связанные услуги <em>и материалы</em></h2>
    </div>
    <div class="rel-grid" data-group="cards">
      <a class="card rel-card" href="../../normativnaya-baza/proverochnye-listy/"><span class="rel-k">Разбор</span><span class="rel-t">Проверочные листы Роспотребнадзора 2026</span><span class="rel-d">Вопросы о насекомых и грызунах по приказам № 578 и № 580 — по видам объектов и с документами для ответа.</span><span class="rel-a" aria-hidden="true"><svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></span></a>
      <a class="card rel-card" href="../../materialy/programma-pest-kontrolya/"><span class="rel-k">Материал</span><span class="rel-t">Программа <span class="nw">пест-контроля</span></span><span class="rel-d">Образец и шаблон в PDF: 7 разделов, оценка <span class="nw">пест-риска</span> по зонам и план мероприятий.</span><span class="rel-a" aria-hidden="true"><svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></span></a>
      <a class="card rel-card" href="../../materialy/zhurnal-pest-kontrolya/"><span class="rel-k">Материал</span><span class="rel-t">Журнал <span class="nw">пест-контроля</span></span><span class="rel-d">Образец заполнения и шаблон в PDF: 9 разделов на 10 листах — точки контроля, ловушки, предписания.</span><span class="rel-a" aria-hidden="true"><svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></span></a>
      <a class="card rel-card" href="../../sanitarnyy-audit/"><span class="rel-k">Услуга</span><span class="rel-t">Санитарный аудит (<span class="nw">СЭС-аудит</span>)</span><span class="rel-d">Проверка по проверочным листам и СанПиН 2026 года, смывы и пробы воздуха, акт с реестром нарушений.</span><span class="rel-a" aria-hidden="true"><svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></span></a>
    </div>
  </div>
</section>

<section class="s" id="voprosy">
  <div class="wrap">
    <div class="head"><div class="eyebrow" data-eyebrow>Вопросы</div><h2 data-split>Вопросы <em>о документах для проверки</em></h2></div>
    <div class="faq">
      <div class="faq-col" data-group="faq">
        <div class="card qa open"><button aria-expanded="true" aria-controls="a1" id="q1"><span>Какие документы нужны для проверки Роспотребнадзора?</span><span class="pm"></span></button><div class="ans" id="a1" role="region" aria-labelledby="q1"><div><p>Программа производственного контроля, приказы об ответственных, договоры и акты по дезинсекции и дератизации, договоры и протоколы лабораторных исследований, договор на вывоз отходов, журналы, медкнижки и документы о медосмотрах, документы на продукцию и дезинфицирующие средства. Точный состав зависит от вида деятельности. Исчерпывающий перечень сведений, которые может запросить инспектор, публикуют управления Роспотребнадзора, а общий список и дополнения для 15 видов объектов — в таблицах выше и <span class="nw">в чек-листе</span> PDF.</p></div></div></div>
        <div class="card qa open"><button aria-expanded="true" aria-controls="a2" id="q2"><span>Какие договоры нужны для Роспотребнадзора?</span><span class="pm"></span></button><div class="ans" id="a2" role="region" aria-labelledby="q2"><div><p>Почти любому объекту нужны договоры на дезинсекцию и дератизацию с исполнителем, у которого есть лицензия, на лабораторные исследования по программе производственного контроля, на вывоз твёрдых коммунальных отходов с региональным оператором и на медосмотры. По ситуации добавляются договоры на стирку одежды и белья, очистку и дезинфекцию вентиляции, передачу ртутных ламп, утилизацию отходов производства и профилактическую дезинфекцию. К каждому договору храните акты выполненных работ.</p></div></div></div>
        <div class="card qa open"><button aria-expanded="true" aria-controls="a3" id="q3"><span>Какие документы проверяет Роспотребнадзор в общепите?</span><span class="pm"></span></button><div class="ans" id="a3" role="region" aria-labelledby="q3"><div><p>Кроме общего списка — программу производственного контроля на принципах ХАССП, гигиенический журнал, журналы температуры холодильного оборудования и температуры и влажности склада, записи о замене фритюрных жиров, технологические карты и товаросопроводительные документы (СанПиН <span class="nw">2.3/2.4.4282-26</span>). При питании пациентов, детей и в организациях социального обслуживания добавляются журналы бракеража. Вопросы инспектора — в проверочном листе № 580, приложение 2.</p></div></div></div>
        <div class="card qa open"><button aria-expanded="true" aria-controls="a4" id="q4"><span>Нужен ли договор на дезинсекцию и дератизацию, если вредителей нет?</span><span class="pm"></span></button><div class="ans" id="a4" role="region" aria-labelledby="q4"><div><p>Да, если вы не проводите эти работы своими силами. Организации и ИП обязаны обследовать объекты и проводить профилактику независимо от того, есть ли вредители (п. 88 СанПиН <span class="nw">3.3686-21</span>), а пищевым объектам, гостиницам и другим объектам из п. 98 нужны обследования на насекомых не реже 2 раз в месяц и ежемесячная оценка заселённости грызунами. Своими силами для собственных нужд можно работать без лицензии, но программа, журналы и учёт обследований всё равно нужны.</p></div></div></div>
        <div class="card qa open"><button aria-expanded="true" aria-controls="a5" id="q5"><span>Что должно быть в акте дезинсекции и дератизации?</span><span class="pm"></span></button><div class="ans" id="a5" role="region" aria-labelledby="q5"><div><p>Единой обязательной формы нет. Чтобы акт подтверждал работу на проверке, в нём указывают дату и время, помещения, вид работ, результаты обследования по точкам контроля, средство с номером свидетельства о госрегистрации, концентрацию и способ применения, меры безопасности, исполнителя с номером лицензии и подписи обеих сторон. В общепите время обработки особенно важно: во время дезинсекции и дератизации нельзя хранить и готовить продукцию (п. 45 СанПиН <span class="nw">2.3/2.4.4282-26</span>).</p></div></div></div>
      </div>
      <div class="faq-col" data-group="faq">
        <div class="card qa open"><button aria-expanded="true" aria-controls="a6" id="q6"><span>Какие протоколы лабораторных исследований нужны?</span><span class="pm"></span></button><div class="ans" id="a6" role="region" aria-labelledby="q6"><div><p>Те, что предусмотрены вашей программой производственного контроля: обычно смывы, пробы воздуха, микроклимат, освещённость и шум, вода и продукция. Вместо замеров условий труда можно использовать результаты спецоценки не старше 6 месяцев. При централизованных системах кондиционирования и увлажнения добавляются исследования на легионеллы не реже 2 раз в год. Исследования выполняет аккредитованная лаборатория — своя или по договору. Все эти исследования делает наша лаборатория: отбираем пробы на объекте и передаём протоколы.</p></div></div></div>
        <div class="card qa open"><button aria-expanded="true" aria-controls="a7" id="q7"><span>Можно ли вести журналы и медкнижки в электронном виде?</span><span class="pm"></span></button><div class="ans" id="a7" role="region" aria-labelledby="q7"><div><p>Да. СанПиН общепита прямо разрешает вести гигиенический журнал, журналы температуры и записи о замене фритюрных жиров на бумаге или в электронном виде (пп. 25, 35, 44), правила торговли — журнал температуры и влажности (п. 38 СП <span class="nw">2.3.6.4281-26</span>). Медкнижки формируются электронно, а бумажные прежней формы можно выдавать и вести до 1 сентября 2027 года. Инспектору документы по умолчанию тоже направляют в электронном виде.</p></div></div></div>
        <div class="card qa open"><button aria-expanded="true" aria-controls="a8" id="q8"><span>Сколько времени дают, чтобы представить документы?</span><span class="pm"></span></button><div class="ans" id="a8" role="region" aria-labelledby="q8"><div><p>Столько, сколько указано в требовании инспектора; при документарной проверке — 10 рабочих дней со дня получения требования. Если не успеваете, сразу направьте письменное ходатайство с причиной и новым сроком — инспектор ответит в течение 24 часов. При инспекционном визите документы, которые должны быть на объекте, показывают сразу.</p></div></div></div>
        <div class="card qa open"><button aria-expanded="true" aria-controls="a9" id="q9"><span>Какие документы нужны ИП для Роспотребнадзора?</span><span class="pm"></span></button><div class="ans" id="a9" role="region" aria-labelledby="q9"><div><p>Те же, что организации того же профиля: программа производственного контроля, договоры и акты, журналы, медкнижки работников, документы на продукцию. Вместо учредительных документов — документ о государственной регистрации ИП. Производственный контроль и дезинсекция с дератизацией обязательны для ИП так же, как для юридических лиц.</p></div></div></div>
        <div class="card qa open"><button aria-expanded="true" aria-controls="a10" id="q10"><span>Какие документы подают в Роспотребнадзор при открытии бизнеса?</span><span class="pm"></span></button><div class="ans" id="a10" role="region" aria-labelledby="q10"><div><p>Если вид деятельности есть в перечне постановления Правительства № 725, до начала работы через Госуслуги подают уведомление о начале деятельности. Для отдельных видов деятельности нужно <span class="nw">санитарно-эпидемиологическое</span> заключение — это отдельная госуслуга. Документы для проверки заранее никуда не подают: их показывают по требованию инспектора.</p></div></div></div>
      </div>
    </div>
  </div>
</section>

<section class="cta" id="zayavka"><div class="cta-bg f-lazy" aria-hidden="true" data-parallax-bg></div><div class="cta-orb" id="orb" aria-hidden="true"></div>
  <div class="wrap">
    <div>
      <div class="eyebrow" data-eyebrow>Заявка</div>
      <h2 data-split>Проверим папку документов <em>вашего объекта</em></h2>
      <p class="sub" data-fade>Пришлите список из конструктора или просто опишите объект. Санитарный врач бесплатно сверит перечень дистанционно и скажет, чего не хватает и какие ссылки в документах устарели. Если нужна проверка на месте со смывами и пробами воздуха, проведём <a href="../../sanitarnyy-audit/">санитарный аудит</a>: от 9 000 ₽, лабораторные исследования входят в стоимость.</p>
      <ul class="cta-list" data-group="ctalist">
        <li><svg aria-hidden="true" focusable="false" class="lucide lucide-circle-check" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <circle cx="12" cy="12" r="10" /> <path d="m16 9-5.5 5.5L8 12" /> </svg>Сверка перечня с вашим видом деятельности — бесплатно</li>
        <li><svg aria-hidden="true" focusable="false" class="lucide lucide-circle-check" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <circle cx="12" cy="12" r="10" /> <path d="m16 9-5.5 5.5L8 12" /> </svg>Список документов, которых не хватает</li>
        <li><svg aria-hidden="true" focusable="false" class="lucide lucide-circle-check" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <circle cx="12" cy="12" r="10" /> <path d="m16 9-5.5 5.5L8 12" /> </svg>Какие ссылки на нормы в документах устарели</li>
      </ul>
      <div class="cta-contacts" data-fade>
        <a class="ph" href="tel:+74951043570">+7 (495) 104-35-70</a>
        <div class="msg">
          <a href="https://max.ru/u/f9LHodD0cOIlIUXFkt4KMFP88lD8n4TArBiTcV7RI1XML5c4o39QfsDBXUc" class="max" aria-label="Написать в Max" target="_blank" rel="noopener noreferrer"><svg viewBox="0 0 24 24" fill="#fff" aria-hidden="true"><path d="M12 3a9 9 0 0 0-7.7 13.7L3 21l4.4-1.2A9 9 0 1 0 12 3zm-3.6 12.3V8.7h1.6l2 2.8 2-2.8h1.6v6.6h-1.7v-3.9L12 14l-1.9-2.6v3.9z"/></svg></a>
          <a href="https://t.me/Centr_Dezinfection?text=%D0%97%D0%B4%D1%80%D0%B0%D0%B2%D1%81%D1%82%D0%B2%D1%83%D0%B9%D1%82%D0%B5!%20%D0%9F%D0%B8%D1%88%D1%83%20%D1%81%20%D1%81%D0%B0%D0%B9%D1%82%D0%B0%20%D0%BF%D0%B5%D1%81%D1%82%D0%BA%D0%BE%D0%BD%D1%82%D1%80%D0%BE%D0%BB%D1%8C-%D1%86%D0%B5%D0%BD%D1%82%D1%80.%D1%80%D1%84" class="tg" aria-label="Написать в Telegram" target="_blank" rel="noopener noreferrer"><svg viewBox="0 0 24 24" fill="#fff" aria-hidden="true"><path d="M21.4 4.3 2.9 11.4c-1.3.5-1.2 1.2-.2 1.5l4.7 1.5 1.8 5.6c.2.6.4.8.9.8.4 0 .6-.2.9-.4l2.3-2.2 4.7 3.5c.9.5 1.5.2 1.7-.8l3.1-14.6c.3-1.3-.5-1.8-1.4-1.5zM9.6 14.1l8.6-5.4c.4-.3.8-.1.5.2l-7.1 6.4-.3 3.3z"/></svg></a>
        </div>
      </div>
    </div>
    <form class="form" id="form" novalidate data-form>
      <div class="fbody">
        <h3>Проверить папку</h3>
        <p class="fs">Заполнение займёт меньше минуты</p>
        <div class="fg">
<div class="field"><label class="sr-only" for="f-name">Ваше имя</label><input id="f-name" name="name" placeholder="Ваше имя *" required autocomplete="name"><small class="ferr">Укажите имя</small></div>
<div class="field"><label class="sr-only" for="phone">Телефон</label><input name="phone" id="phone" type="tel" inputmode="tel" placeholder="+7 (___) ___-__-__ *" required autocomplete="tel"><small class="ferr">Укажите телефон полностью</small></div>
<div class="field full"><label class="sr-only" for="f-company">Компания</label><input id="f-company" name="company" placeholder="Компания (необязательно)" autocomplete="organization"></div>
<div class="field full"><label class="sr-only" for="f-type">Вид объекта</label><select id="f-type" name="type" required><option value="" selected>Вид объекта *</option><option>Пищевое производство</option><option value="Ресторан или кафе">Ресторан, кафе, столовая</option><option value="Магазин или торговая сеть">Магазин продуктов, торговая сеть</option><option value="Склад, логистика">Склад пищевой продукции</option><option>Фармацевтическое производство</option><option value="Гостиница">Гостиница, хостел</option><option value="Другое">Медицинская организация</option><option value="Другое">Аптека</option><option value="Другое">Школа, детский сад, лагерь</option><option value="Другое">Салон красоты, парикмахерская</option><option value="Другое">Баня, сауна</option><option value="Другое">Прачечная, химчистка</option><option value="Другое">Спорт, бассейн, фитнес</option><option value="Магазин или торговая сеть">Непродовольственный магазин</option><option value="Другое">Другой объект</option></select><small class="ferr">Выберите вид объекта</small></div>
<div class="field full"><label class="sr-only" for="f-msg">Комментарий</label><textarea id="f-msg" name="comment" placeholder="Комментарий: что уже есть, ближайшая проверка"></textarea></div>
<input type="hidden" name="msg" value="">
<div class="field" hidden><input type="hidden" name="email" value=""></div>
<input type="hidden" name="page" value="Документы для Роспотребнадзора">
</div>
        <button type="submit" class="btn btn-w btn-lg" id="submitBtn"><span class="btn-t">Проверить папку</span><svg class="btn-ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M5 12h14M13 6l6 6-6 6"/></svg><i class="spin" aria-hidden="true"></i></button>
        <p class="legal">Нажимая кнопку, вы даёте <a href="../../soglasie/" target="_blank" rel="noopener">согласие на обработку персональных данных</a> и подтверждаете, что ознакомились с <a href="../../privacy/" target="_blank" rel="noopener">политикой конфиденциальности</a>.</p>
        <p class="legal nb-lic">Работы выполняет ООО «Центр дезинфекционных услуг», лицензия на дезинфекционную деятельность <a href="https://fp.rospotrebnadzor.ru/licen/?oper=search&amp;numb_history=&amp;numb=&amp;firmget_name=&amp;ogrn_inn_nza=7714462211" target="_blank" rel="noopener">№ Л064-00111-77/01942445</a></p>
      </div>
      <div class="ok" role="status" aria-live="polite">
        <svg class="ok-ic" viewBox="0 0 52 52" aria-hidden="true"><circle cx="26" cy="26" r="24" fill="none"/><path fill="none" d="M15 27l7 7 15-16"/></svg>
        <h3>Заявка отправлена</h3><p>Перезвоним в ближайшее рабочее время и договоримся, как удобнее прислать документы на сверку.</p>
      </div>
    </form>
  </div>
</section>
</main>
<script type="application/json" id="dk-data">{"g":[[1,"Организационные документы и программы"],[2,"Договоры"],[3,"Акты и отчёты"],[4,"Протоколы лабораторных исследований"],[5,"Журналы и графики"],[6,"Персонал"],[7,"Документы исполнителя"],[8,"Документы на продукцию и средства"]],"i":[["1.1","Учредительные документы","Вы",1,0,0,0],["1.2","Документы на помещение","Вы",1,0,0,0],["1.3","Приказы о назначении ответственных, должностные инструкции","Вы",1,0,0,0],["1.4","Список работников и штатное расписание","Вы",1,0,0,0],["1.5","Уведомление о начале деятельности","Вы",1,0,1,0],["1.6","Программа производственного контроля (ППК)","Вы или мы",1,0,0,1],["1.7","Программа пест-контроля","Мы",1,0,0,1],["1.8","Документы по процедурам ХАССП","Вы или мы",1,["pp","ob","tr","sh","md"],{"tr":"если есть собственное производство","sh":"если есть свой пищеблок","md":"если есть пищеблок"},1],["1.9","Перечень сырья и материалов, список оборудования — источников ультразвука, инфразвука и излучений","Вы",1,["fa"],0,0],["1.10","Документы по обращению с медицинскими отходами","Вы",1,["md"],0,0],["1.11","План профилактических и противоэпидемических мероприятий","Вы",1,["md"],0,0],["1.12","Примерное меню и расписание занятий","Вы",1,["sh"],0,0],["2.1","Дезинсекция и дератизация — с исполнителем, у которого есть лицензия","Мы",2,0,0,1],["2.2","Лабораторные исследования и инструментальные замеры","Наша лаборатория",2,0,0,1],["2.3","Вывоз твёрдых коммунальных отходов","Региональный оператор",2,0,0,0],["2.4","Отходы I–II класса опасности: отработанные ртутные лампы и другие","ФГУП «ФЭО»",2,0,1,0],["2.5","Предварительные и периодические медицинские осмотры","Медорганизация",2,0,0,0],["2.6","Стирка санитарной и специальной одежды, белья","Прачечная",2,0,1,0],["2.7","Очистка и дезинфекция вентиляции и кондиционирования","Мы",2,0,1,1],["2.8","Профилактическая дезинфекция","Мы или ваш персонал",2,0,1,1],["2.9","Передача и утилизация отходов производства","Специализированная организация",2,["pp","fa"],0,0],["2.10","Водоснабжение, водоотведение, тепло- и электроснабжение","Ресурсоснабжающие организации",2,["us","bn","pr"],0,0],["2.11","Вывоз и обезвреживание медицинских отходов","Специализированная организация",2,["md"],0,0],["2.12","Обслуживание медицинской техники","Сервисная организация",2,["md"],0,0],["2.13","Медицинское обслуживание детей","Медорганизация",2,["sh"],0,0],["2.14","Камерная обработка постельных принадлежностей","Специализированная организация",2,["sh"],1,0],["2.15","Противоклещевые (акарицидные) обработки","Исполнитель с лицензией",2,["sh"],1,0],["3.1","Акт первичного обследования объекта","Мы",3,0,0,1],["3.2","Акты плановых обследований на насекомых","Мы",3,0,0,1],["3.3","Отчёт об оценке заселённости грызунами и решение о дератизации","Мы",3,0,0,1],["3.4","Акты выполненных работ по каждой обработке","Мы",3,0,0,1],["3.5","Обследование мусорокамер и обработка контейнерной площадки","Мы",3,0,1,1],["3.6","Акт очистки и дезинфекции вентиляции","Мы",3,0,1,1],["3.7","Акт обследования технического состояния вентиляции","Подрядчик по вентиляции",3,0,1,0],["3.8","Акт очистки вентиляции от горючих отложений","Мы",3,0,1,1],["3.9","Ежегодная проверка эффективности, очистка и дезинфекция вентиляции","Мы и подрядчик по вентиляции",3,["md"],0,1],["4.1","Смывы с поверхностей, оборудования, инвентаря и рук персонала","Наша лаборатория; входят в санаудит",4,0,0,1],["4.2","Пробы воздуха помещений","Наша лаборатория; входят в санаудит",4,0,0,1],["4.3","Микроклимат, освещённость, шум на рабочих местах","Наша лаборатория",4,0,0,1],["4.4","Питьевая вода","Наша лаборатория",4,0,1,1],["4.5","Пищевая продукция и сырьё","Наша лаборатория",4,["pp","ob","tr"],{"tr":"если есть собственное производство"},1],["4.6","Легионеллы в системах кондиционирования и увлажнения","Наша лаборатория",4,0,1,1],["4.7","Оценка эффективности дезинфекции","Наша лаборатория",4,0,1,1],["4.8","Атмосферный воздух на границе санитарно-защитной зоны","Наша лаборатория",4,["fa"],1,1],["4.9","Контроль стерилизации инструментов и работы стерилизаторов","Наша лаборатория",4,["us"],1,1],["4.10","Вода бассейна","Наша лаборатория; ежедневные замеры — ваш персонал",4,["sp"],1,1],["4.11","Смывы в бассейне на колиформные бактерии и яйца гельминтов","Наша лаборатория",4,["sp"],1,1],["5.1","Журнал пест-контроля (учёта дезинсекции и дератизации)","Мы",5,0,0,1],["5.2","Журнал учёта работ по вентиляции","Мы",5,0,1,1],["5.3","Графики уборки и генеральных уборок, журнал генеральных уборок","Вы",5,0,0,0],["5.4","Контроль дезинфицирующих средств и рабочих растворов","Вы",5,0,1,0],["5.5","Журнал учёта работы бактерицидных облучателей","Вы",5,0,1,0],["5.6","Гигиенический журнал","Вы",5,["ob","sh","md"],{"md":"если есть пищеблок"},0],["5.7","Журналы температуры холодильного оборудования, температуры и влажности склада","Вы",5,["ob","sh","md"],{"md":"если есть пищеблок"},0],["5.8","Учёт замены фритюрных жиров","Вы",5,["ob"],1,0],["5.9","Журналы бракеража готовой и скоропортящейся продукции","Вы",5,["ob","sh","md"],1,0],["5.10","Журнал температуры и влажности хранения","Вы",5,["tr"],0,0],["5.11","Технологические журналы и журнал поступления сырья","Вы",5,["pp"],0,0],["5.12","Журнал температуры и влажности хранения","Вы",5,["sk"],0,0],["5.13","Технологические журналы учёта медицинских отходов","Вы",5,["md"],0,0],["5.14","Журналы контроля стерилизаторов и предстерилизационной очистки","Вы",5,["md"],0,0],["6.1","Личные медицинские книжки","Работник; сроки контролируете вы",6,0,1,0],["6.2","Документы о медосмотрах","Вы и медорганизация",6,0,0,0],["6.3","Гигиеническая подготовка и аттестация","Работник; организует работодатель",6,0,1,0],["6.4","Сводная ведомость спецоценки условий труда","Вы и организация по СОУТ",6,["fa","md"],0,0],["6.5","Карточки выдачи СИЗ и документы на их качество","Вы",6,["fa","md"],0,0],["6.6","Сведения о прививках работников","Вы",6,["md"],0,0],["7.1","Номер лицензии исполнителя и выписка из реестра","Мы",7,0,0,1],["7.2","Свидетельства о госрегистрации (СГР) и инструкции на средства исполнителя","Мы",7,0,0,1],["7.3","Рекомендации по защите объекта и отметки о выполнении","Мы и вы",7,0,0,1],["8.1","Товаросопроводительные документы","Поставщик; храните вы",8,["pp","ob","tr","sk","sh","md","us","bn","pr"],{"sh":"если есть пищеблок","md":"если есть пищеблок"},0],["8.2","Декларации и сертификаты соответствия, СГР","Изготовитель или поставщик",8,["pp","ob","tr","sk","sh","md","us","bn","pr"],{"sh":"если есть пищеблок","md":"если есть пищеблок"},0],["8.3","Технологические и технико-технологические карты","Вы",8,["ob"],0,0],["8.4","Документация на выпускаемую продукцию","Вы",8,["pp"],0,0],["8.5","Маркировка и данные системы «Честный знак»","Вы",8,["tr"],1,0],["8.6","Сведения о применении пестицидов в растительном сырье","Поставщик",8,["pp"],1,0],["8.7","Документы на дезинфицирующие и моющие средства","Поставщик; храните вы",8,0,0,0],["8.8","Документы на оборудование","Поставщик; храните вы",8,["md","us","bn","pr"],1,0]],"o":[["pp","Пищевое производство","pishchevoe-proizvodstvo"],["ob","Ресторан, кафе, столовая","restorany"],["tr","Магазин продуктов, торговая сеть","magaziny"],["sk","Склад пищевой продукции","sklady"],["fa","Фармацевтическое производство","farmproizvodstvo"],["go","Гостиница, хостел","gostinitsy"],["md","Медицинская организация","meditsina"],["ap","Аптека","apteki"],["sh","Школа, детский сад, лагерь","shkoly"],["us","Салон красоты, парикмахерская","uslugi"],["bn","Баня, сауна","bani"],["pr","Прачечная, химчистка","prachechnye"],["sp","Спорт, бассейн, фитнес","sport"],["nt","Непродовольственный магазин","neprod"],["dr","Другой объект","drugoy"]]}</script>


<footer>
  <div class="wrap">
    <div class="ft">
      <div>
        <a href="../../" class="logo" aria-label="ПЕСТКОНТРОЛЬ Центр — на главную"><span class="logo-mark"><svg viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="1.6" stroke-linejoin="round" aria-hidden="true"><path d="M12 2.5l7.5 3v6c0 5-3.2 8.6-7.5 10-4.3-1.4-7.5-5-7.5-10v-6z"/><circle cx="12" cy="11.5" r="2.6" stroke="#7c86ff"/><path d="M12 6.2v2.7M12 14.1v2.7M6.8 11.5h2.6M14.6 11.5h2.6" stroke="#7c86ff"/></svg></span><span class="logo-txt"><span class="logo-name">ПЕСТКОНТРОЛЬ</span> <span class="logo-sub">Центр</span></span></a>
        <p class="d"><span class="nw">Пест-контроль</span> и <span class="nw">пест-менеджмент</span> по системе IPM для бизнеса в Москве и Московской области: бесплатный аудит, оценка <span class="nw">пест-риска</span>, мониторинг вредителей и отчётность.</p>
      </div>
      <div><h4>Услуги</h4><ul><li><a href="../../dezinfektsiya/">Дезинфекция для организаций</a></li><li><a href="../../deratizatsiya/">Дератизация для организаций</a></li><li><a href="../../dezinsektsiya/">Дезинсекция для организаций</a></li><li><a href="../../deratizatsiya-i-dezinsektsiya/">Дератизация и дезинсекция</a></li><li><a href="../../sanitarnyy-audit/"><span>Санитарный аудит <span class="nw">(СЭС-аудит)</span></span></a></li><li><a href="../../laboratornye-issledovaniya/">Лабораторные исследования</a></li><li><a href="../../razrabotka-ppk/">Разработка ППК</a></li><li><a href="./" aria-current="page">Документы для Роспотребнадзора</a></li><li><a href="../../ochistka-dezinfektsiya-ventilyatsii/">Очистка и дезинфекция вентиляции</a></li><li><a href="../../dogovor-deratizatsiya-dezinsektsiya/">Договор на дератизацию и дезинсекцию</a></li><li><a href="../../#podhod"><span><span class="nw">Пест-контроль</span> по системе IPM</span></a></li><li><a href="../../#etapy">Этапы работы</a></li><li><a href="../../#vrediteli">Вредители</a></li><li><a href="../../#usloviya">Цена</a></li><li><a href="../../#voprosy">Вопросы</a></li></ul></div>
      <div><h4>Отрасли</h4><ul><li><a href="../../pishchevoe-proizvodstvo/">Пищевые производства</a></li><li><a href="../../magaziny-i-torgovye-seti/">Магазины и торговые сети</a></li><li><a href="../../restorany-i-kafe/">Рестораны и кафе</a></li><li><a href="../../sklady-i-logistika/">Склады и логистика</a></li><li><a href="../../farmatsevticheskie-proizvodstva/">Фармацевтические производства</a></li><li><a href="../../gostinitsy/">Гостиницы и отели</a></li></ul></div>
      <div><h4>Материалы</h4><ul><li><a href="../../normativnaya-baza/">Нормативная база</a></li><li><a href="../../normativnaya-baza/proverochnye-listy/">Проверочные листы 2026</a></li><li><a href="./" aria-current="page">Документы для Роспотребнадзора</a></li><li><a href="../../materialy/programma-pest-kontrolya/"><span>Программа <span class="nw">пест-контроля</span></span></a></li><li><a href="../../materialy/zhurnal-pest-kontrolya/"><span>Журнал <span class="nw">пест-контроля</span></span></a></li><li><a href="../../materialy/pest-menedzhment-ili-razovaya-obrabotka/"><span><span class="nw">Пест-менеджмент</span> или разовая обработка</span></a></li><li><a href="../../materialy/programma-proizvodstvennogo-kontrolya-haccp/">Программа производственного контроля по ХАССП</a></li><li><a href="../../materialy/">Все материалы</a></li></ul></div>
      <div><h4>Контакты</h4><ul><li><a href="tel:+74951043570">+7 (495) 104-35-70</a></li><li><a href="mailto:b2b@pestcontrol-center.ru">b2b@<wbr><span style="white-space:nowrap">pestcontrol-center.ru</span></a></li><li>Пн–Пт: 8:00–20:00</li><li>Срочные выезды: 24/7</li></ul>
        <div class="msg"><a href="https://max.ru/u/f9LHodD0cOIlIUXFkt4KMFP88lD8n4TArBiTcV7RI1XML5c4o39QfsDBXUc" class="max" aria-label="Написать в Max" target="_blank" rel="noopener noreferrer"><svg viewBox="0 0 24 24" fill="#fff" aria-hidden="true"><path d="M12 3a9 9 0 0 0-7.7 13.7L3 21l4.4-1.2A9 9 0 1 0 12 3zm-3.6 12.3V8.7h1.6l2 2.8 2-2.8h1.6v6.6h-1.7v-3.9L12 14l-1.9-2.6v3.9z"/></svg></a><a href="https://t.me/Centr_Dezinfection?text=%D0%97%D0%B4%D1%80%D0%B0%D0%B2%D1%81%D1%82%D0%B2%D1%83%D0%B9%D1%82%D0%B5!%20%D0%9F%D0%B8%D1%88%D1%83%20%D1%81%20%D1%81%D0%B0%D0%B9%D1%82%D0%B0%20%D0%BF%D0%B5%D1%81%D1%82%D0%BA%D0%BE%D0%BD%D1%82%D1%80%D0%BE%D0%BB%D1%8C-%D1%86%D0%B5%D0%BD%D1%82%D1%80.%D1%80%D1%84" class="tg" aria-label="Написать в Telegram" target="_blank" rel="noopener noreferrer"><svg viewBox="0 0 24 24" fill="#fff" aria-hidden="true"><path d="M21.4 4.3 2.9 11.4c-1.3.5-1.2 1.2-.2 1.5l4.7 1.5 1.8 5.6c.2.6.4.8.9.8.4 0 .6-.2.9-.4l2.3-2.2 4.7 3.5c.9.5 1.5.2 1.7-.8l3.1-14.6c.3-1.3-.5-1.8-1.4-1.5zM9.6 14.1l8.6-5.4c.4-.3.8-.1.5.2l-7.1 6.4-.3 3.3z"/></svg></a></div>
      </div>
    </div>
    <div class="fb"><span>© 2026 ПЕСТКОНТРОЛЬ Центр</span><a href="../../privacy/">Политика конфиденциальности</a><a href="../../soglasie/">Согласие на обработку данных</a><span>Информация на сайте не является публичной офертой</span></div>
  </div>
</footer>

<div class="mbar" id="mbar">
  <a href="tel:+74951043570" class="c1"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1 1 .4 1.9.7 2.8a2 2 0 0 1-.5 2.1L8 9.9a16 16 0 0 0 6 6l1.3-1.3a2 2 0 0 1 2.1-.4c.9.3 1.8.6 2.8.7a2 2 0 0 1 1.7 2z"/></svg>Позвонить</a>
  <a href="#zayavka" class="c2"><span>Обследование</span></a>
</div>
<div class="fab" role="group" aria-label="Написать в мессенджер">
  <a href="https://max.ru/u/f9LHodD0cOIlIUXFkt4KMFP88lD8n4TArBiTcV7RI1XML5c4o39QfsDBXUc" class="max" aria-label="Написать в Max" target="_blank" rel="noopener noreferrer"><svg viewBox="0 0 24 24" fill="#fff" aria-hidden="true"><path d="M12 3a9 9 0 0 0-7.7 13.7L3 21l4.4-1.2A9 9 0 1 0 12 3zm-3.6 12.3V8.7h1.6l2 2.8 2-2.8h1.6v6.6h-1.7v-3.9L12 14l-1.9-2.6v3.9z"/></svg></a>
  <a href="https://t.me/Centr_Dezinfection?text=%D0%97%D0%B4%D1%80%D0%B0%D0%B2%D1%81%D1%82%D0%B2%D1%83%D0%B9%D1%82%D0%B5!%20%D0%9F%D0%B8%D1%88%D1%83%20%D1%81%20%D1%81%D0%B0%D0%B9%D1%82%D0%B0%20%D0%BF%D0%B5%D1%81%D1%82%D0%BA%D0%BE%D0%BD%D1%82%D1%80%D0%BE%D0%BB%D1%8C-%D1%86%D0%B5%D0%BD%D1%82%D1%80.%D1%80%D1%84" class="tg" aria-label="Написать в Telegram" target="_blank" rel="noopener noreferrer"><svg viewBox="0 0 24 24" fill="#fff" aria-hidden="true"><path d="M21.4 4.3 2.9 11.4c-1.3.5-1.2 1.2-.2 1.5l4.7 1.5 1.8 5.6c.2.6.4.8.9.8.4 0 .6-.2.9-.4l2.3-2.2 4.7 3.5c.9.5 1.5.2 1.7-.8l3.1-14.6c.3-1.3-.5-1.8-1.4-1.5zM9.6 14.1l8.6-5.4c.4-.3.8-.1.5.2l-7.1 6.4-.3 3.3z"/></svg></a>
</div>

<script>
/* Предпросмотр: вне рабочего домена заявка не отправляется (на пестконтроль-центр.рф этот блок не срабатывает) */
(function(){if(/^(www\.)?xn----itbbsflddbfpfdodg9d0f\.xn--p1ai$/i.test(location.hostname))return;var f=window.fetch;window.fetch=function(u){if(typeof u==='string'&&u.indexOf('send.php')>-1)return new Promise(function(r){setTimeout(function(){r(new Response('{"success":true}',{status:200,headers:{'Content-Type':'application/json'}}))},500)});return f.apply(this,arguments)};document.addEventListener('DOMContentLoaded',function(){var p=document.querySelector('.form .fs');if(p)p.textContent='Предпросмотр: заявка никуда не отправляется'})})();
</script>
<script data-fx>
/* Эффекты под курсором, как на главной (tools/site/fx.py) */
(function(){
  var mm=window.matchMedia;if(!mm)return;
  var fine=mm('(hover: hover) and (pointer: fine)').matches;
  /* «фонарь»: следует за мышью, без движения мыши плавно ходит сам; на сенсорных экранах ходит сам (30 кадров в секунду).
     Не считаем, пока первый экран не виден или вкладка скрыта. Старт — вместе со входом первого экрана */
  var hero=document.getElementById('hero'),lit=hero&&hero.querySelector('.fx-lit');
  if(lit&&!mm('(prefers-reduced-motion: reduce)').matches){
    var media=lit.parentNode,small=mm('(max-width:860px)').matches,full=hero.classList.contains('f-hero');
    lit.style.setProperty('--sr',small?'150px':'clamp(240px, 21vw, 400px)');
    var cx=small?.5:(full?.68:.74),ax=small?.24:(full?.16:.13),cy=small?.5:.47,ay=small?.2:.17;
    var sx=cx,sy=cy,tx=cx,ty=cy,last=-1e9,vis=true,on=false,raf=0,lt=0;
    var frame=function(now){
      raf=0;if(!on||!vis||document.hidden)return;
      var dt=now-lt;if(!fine&&dt<30){raf=requestAnimationFrame(frame);return;}
      lt=now;if(now-last>2600){var t=now/1000;tx=cx+ax*Math.sin(t*.33);ty=cy+ay*Math.sin(t*.47+1.3);}
      var k=1-Math.pow(.94,Math.min(dt,100)/16.67);sx+=(tx-sx)*k;sy+=(ty-sy)*k;
      lit.style.setProperty('--sx',(sx*100).toFixed(2)+'%');lit.style.setProperty('--sy',(sy*100).toFixed(2)+'%');
      raf=requestAnimationFrame(frame);
    };
    var kick=function(){if(!raf&&on&&vis&&!document.hidden){lt=performance.now();raf=requestAnimationFrame(frame);}};
    hero.addEventListener('pointermove',function(e){
      if(e.pointerType!=='mouse')return;var r=media.getBoundingClientRect();if(!r.width||!r.height)return;
      tx=(e.clientX-r.left)/r.width;ty=(e.clientY-r.top)/r.height;last=performance.now();kick();
    },{passive:true});
    if('IntersectionObserver' in window)new IntersectionObserver(function(es){vis=es[0].isIntersecting;kick();}).observe(hero);
    document.addEventListener('visibilitychange',kick);
    var start=function(){if(on)return;on=true;hero.classList.add('fx-lit-on');kick();};
    var eb=hero.querySelector('.eyebrow');
    if(eb&&'MutationObserver' in window){
      if(eb.classList.contains('in'))start();
      else{var mo=new MutationObserver(function(){if(eb.classList.contains('in')){mo.disconnect();start();}});mo.observe(eb,{attributes:true,attributeFilter:['class']});}
    }
    setTimeout(start,eb?5000:2500);
  }
  /* подсветка рамки карточек за курсором — как у .card на главной */
  if(fine)document.addEventListener('pointermove',function(e){
    var c=e.target.closest&&e.target.closest('.d-card,.p-sec,.p-fcard,.p-duty-box,.p-dl-card,.pm-step-card,.pm-scen,.pm-link-card,.k-err,.w-sample,.d-doc-prev');if(!c)return;
    var r=c.getBoundingClientRect();c.style.setProperty('--mx',(e.clientX-r.left)+'px');c.style.setProperty('--my',(e.clientY-r.top)+'px');
  },{passive:true});
})();
</script>
<script>
  /* скрипты анимаций подключаются сразу после первой отрисовки: фото и заголовок первого экрана не ждут их загрузки */
  (function (r, l) {
    var go = function () { l.forEach(function (u) { var e = document.createElement('script'); e.src = r + u; e.async = false; document.body.appendChild(e); }); };
    if (document.visibilityState === 'hidden' || !window.requestAnimationFrame) setTimeout(go, 0);
    else requestAnimationFrame(function () { setTimeout(go, 0); });
  })('../../', ['app.min.js?v=20261106s2']);
</script>
<script>/* Форма: вид объекта, комментарий и страница — в поле msg, которое читает send.php */
document.addEventListener('submit',function(ev){var f=ev.target;if(!f||f.id!=='form')return;var e=f.elements,s=e.type,o=s&&s.selectedIndex>0?s.options[s.selectedIndex].text:'не выбран',c=e.comment.value.trim();e.msg.value='Вид объекта: '+o+(c?'\nКомментарий: '+c:'')+'\nСтраница: Документы для Роспотребнадзора (/normativnaya-baza/dokumenty-dlya-rospotrebnadzora/)';},true);</script>
<script>(function(){var E=document.getElementById("dk-data");if(!E)return;var s;try{s=JSON.parse(E.textContent)}catch(t){return}var w="pkc-dokumenty-v1",L={y:"Есть",n:"Нет",x:"Не нужно"},O={pp:"Пищевое производство",ob:"Ресторан, кафе, столовая",tr:"Магазин продуктов, торговая сеть",sk:"Склад пищевой продукции",fa:"Фармацевтическое производство",go:"Гостиница, хостел",md:"Медицинская организация",ap:"Аптека",sh:"Школа, детский сад, лагерь",us:"Салон красоты, парикмахерская",bn:"Баня, сауна",pr:"Прачечная, химчистка",sp:"Спорт, бассейн, фитнес",nt:"Непродовольственный магазин",dr:"Другой объект"},p={},k={};s.o.forEach(function(t){p[t[0]]=t[1],k[t[2]]=t[0]});var i={o:[],m:{}};try{var v=JSON.parse(localStorage.getItem(w)||"null");v&&v.o&&v.m&&(i=v)}catch(t){}var b=/[?&]obekt=([a-z-]+)/.exec(location.search);b&&k[b[1]]&&(i.o=[k[b[1]]]),i.o=i.o.filter(function(t){return p[t]});function A(){try{localStorage.setItem(w,JSON.stringify(i))}catch(t){}}function f(t){try{typeof ym=="function"&&ym(113675622,"reachGoal",t)}catch(e){}}function d(t){return String(t).replace(/[&<>"]/g,function(e){return{"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[e]})}function _(t){return i.o.length?t[4]===0?i.o.slice():i.o.filter(function(e){return t[4].indexOf(e)>=0}):[]}function z(t,e){return t[5]===1?!0:t[5]&&typeof t[5]=="object"?e.every(function(n){return t[5][n]}):!1}function g(){var t=[];return s.i.forEach(function(e){var n=_(e);n.length&&t.push({it:e,opt:z(e,n)})}),t}var u=document.getElementById("dk-list"),y=document.getElementById("dk-bar"),I=document.getElementById("dk-count"),l=document.getElementById("dk-mini"),N=u?u.innerHTML:"",S=[].slice.call(document.querySelectorAll(".dk-pick")),x;function D(){clearTimeout(x),x=setTimeout(function(){try{window.ScrollTrigger&&window.ScrollTrigger.refresh()}catch(t){}},350)}function T(){if(S.forEach(function(a){a.setAttribute("aria-pressed",i.o.indexOf(a.getAttribute("data-obj"))>=0?"true":"false")}),!!u){var t=g();if(D(),!t.length){u.innerHTML=N,y.hidden=!0,l&&(l.hidden=!0);return}var e="",n=0;t.forEach(function(a){var r=a.it,o=i.m[r[0]];o==="x"&&!a.opt&&(o=void 0),r[3]!==n&&(n&&(e+="</div>"),n=r[3],e+='<div class="dk-lg"><h3><span>'+n+"</span>"+d(s.g[n-1][1])+"</h3>"),e+='<div class="dk-row'+(o?" is-"+o:"")+'" data-id="'+r[0]+'"><span class="dk-row-n">'+r[0]+'</span><span class="dk-row-t">'+d(r[1])+"<small>"+d(r[2])+(r[6]?" · ●":"")+'</small></span><span class="dk-seg" role="group" aria-label="'+d(r[1])+'">',["y","n"].concat(a.opt?["x"]:[]).forEach(function(c){e+='<button type="button" data-v="'+c+'" aria-pressed="'+(o===c?"true":"false")+'">'+L[c]+"</button>"}),e+="</span></div>"}),u.innerHTML=e+"</div>",y.hidden=!1,l&&(l.hidden=!1),j(t)}}function j(t){t=t||g();var e=0,n=0;t.forEach(function(a){var r=i.m[a.it[0]];r==="x"&&!a.opt&&(r=0),r&&e++,r==="n"&&n++}),I.innerHTML="Отмечено <b>"+e+"</b> из <b>"+t.length+"</b>"+(n?' · <span class="dk-miss">не хватает '+n+"</span>":""),l&&(l.innerHTML='<span class="dk-mini-t">'+I.innerHTML+'</span><span class="dk-mini-go" aria-hidden="true">↓</span>')}l&&l.addEventListener("click",function(){y.scrollIntoView({block:"center"})}),S.forEach(function(t){t.addEventListener("click",function(){var e=t.getAttribute("data-obj"),n=i.o.indexOf(e);n>=0?i.o.splice(n,1):i.o.push(e),A(),T(),i.o.length&&h(i.o[i.o.length-1])})}),u&&u.addEventListener("click",function(t){var e=t.target.closest(".dk-seg button");if(e){var n=e.closest(".dk-row"),a=n.getAttribute("data-id"),r=e.getAttribute("data-v");i.m[a]===r?delete i.m[a]:i.m[a]=r,A(),[].forEach.call(n.querySelectorAll(".dk-seg button"),function(o){o.setAttribute("aria-pressed",i.m[a]===o.getAttribute("data-v")?"true":"false")}),n.className="dk-row"+(i.m[a]?" is-"+i.m[a]:""),j()}});function J(){var t=g(),e=[],n=[];return t.forEach(function(a){var r=i.m[a.it[0]];r==="n"?e.push(a.it[0]+" "+a.it[1]):(!r||r==="x"&&!a.opt)&&n.push(a.it[0])}),`Список из конструктора «Документы для Роспотребнадзора»
Вид объекта: `+i.o.map(function(a){return p[a]}).join(", ")+`
Нет (`+e.length+"): "+(e.length?e.join("; "):"—")+(n.length?`
Не отмечено: `+n.length+" из "+t.length:"")}var B=document.getElementById("dk-send");B&&B.addEventListener("click",function(){var t=document.getElementById("form");if(t){var e=t.elements.type,n=t.elements.comment,a=O[i.o[0]];e&&a&&[].forEach.call(e.options,function(c,H){c.text===a&&(e.selectedIndex=H)}),n&&(n.value=J()),f("dokumenty_spisok");var r=document.querySelector('a[href="#zayavka"]'),o=document.getElementById("zayavka");r?r.click():o&&o.scrollIntoView(),window.matchMedia&&matchMedia("(pointer:fine)").matches&&setTimeout(function(){var c=t.elements.name;if(c)try{c.focus({preventScroll:!0})}catch(H){c.focus()}},1600)}});var M=document.getElementById("dk-print");M&&M.addEventListener("click",function(){var t=g(),e="<h1>Документы для Роспотребнадзора</h1><p>Вид объекта: "+d(i.o.map(function(r){return p[r]}).join(", "))+" · "+new Date().toLocaleDateString("ru-RU")+" · пестконтроль-центр.рф</p>",n=0;t.forEach(function(r){var o=r.it,c=i.m[o[0]];c==="x"&&!r.opt&&(c=0),o[3]!==n&&(n&&(e+="</table>"),n=o[3],e+="<h2>"+n+". "+d(s.g[n-1][1])+"</h2><table>"),e+="<tr><td>"+o[0]+"</td><td>"+d(o[1])+"</td><td>"+d(o[2])+"</td><td>"+(c?L[c]:"☐ Есть ☐ Нет")+"</td></tr>"});var a=document.getElementById("dk-print-area")||document.body.appendChild(document.createElement("div"));a.id="dk-print-area",a.innerHTML=e+"</table>",document.body.classList.add("dk-printing"),f("dokumenty_spisok"),window.print()}),window.addEventListener("afterprint",function(){document.body.classList.remove("dk-printing")}),document.addEventListener("click",function(t){t.target.closest('[data-dl="pdf"]')?f("dokumenty_pdf"):t.target.closest('[data-dl="akt"]')?f("akt_obrazets"):t.target.closest('[data-dl="akt-blank"]')&&f("akt_shablon")});var m=[].slice.call(document.querySelectorAll(".dk-tab")),q=[].slice.call(document.querySelectorAll(".dk-o"));function h(t){q.length&&(m.forEach(function(e){e.setAttribute("aria-selected",e.getAttribute("data-obj")===t?"true":"false"),e.tabIndex=e.getAttribute("data-obj")===t?0:-1}),q.forEach(function(e){e.open=e.getAttribute("data-obj")===t}))}m.forEach(function(t,e){t.tabIndex=t.getAttribute("aria-selected")==="true"?0:-1,t.addEventListener("click",function(){h(t.getAttribute("data-obj"))}),t.addEventListener("keydown",function(n){var a=n.key==="ArrowRight"?1:n.key==="ArrowLeft"?-1:0;if(a){var r=m[(e+a+m.length)%m.length];r.focus(),h(r.getAttribute("data-obj"))}})}),T(),i.o.length&&h(i.o[0])})();</script>
<!-- Yandex.Metrika counter + UIS + Radist: загружаются после первого действия посетителя (касание, прокрутка, мышь, клавиатура) или через 5 с после загрузки страницы -->
<script type="text/javascript">
    (function (w, d) {
        w.ym = w.ym || function () { (w.ym.a = w.ym.a || []).push(arguments); };
        w.ym.l = 1 * new Date();
        ym(113675622, 'init', {ssr:true, webvisor:true, clickmap:true, ecommerce:"dataLayer", referrer: document.referrer, url: location.href, accurateTrackBounce:true, trackLinks:true});
        var done = false, ready = false, wait = null, ev = ['pointerdown', 'touchstart', 'keydown', 'scroll', 'wheel', 'mousemove'];
        w.__cs = w.__cs || [];
        w.__cs.push(['waitForTrackViewAndRun', function () { ready = true; }]);
        // Radist: код заявки в ссылках Telegram и MAX — сразу, скрипт Radist загрузится вместе со счётчиками
        var rmsg = 'Здравствуйте! Пишу с сайта пестконтроль-центр.рф. Номер заявки: {radist_tracker}';
        w.radist_tracker = w.radist_tracker || function () { (w.radist_tracker.a = w.radist_tracker.a || []).push(arguments); };
        w.radist_tracker.l = 1 * new Date();
        w.radist_tracker({ message: rmsg, whatsapp_enabled: true, tgbot_enabled: true, tg_enabled: true, max_enabled: true, vk_enabled: true });
        (function () {
            var id = null, abc = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789', s = 'ro', i, txt;
            try {
                id = sessionStorage.getItem('radistVisit');
                if (!id || id.length !== 12) {
                    for (i = 0; i < 10; i++) s += abc.charAt(Math.floor(Math.random() * abc.length));
                    sessionStorage.setItem('radistVisit', s);
                    id = sessionStorage.getItem('radistVisit');
                }
            } catch (e) { id = null; }
            if (!id || id.length !== 12) return;
            txt = encodeURIComponent(rmsg.replace(/{radist_tracker}/g, id));
            [].forEach.call(d.querySelectorAll('a[href*="//t.me/"], a[href*="//max.ru/"]'), function (a) {
                try {
                    var u = new URL(a.href), n = u.pathname.split('/')[1] || '';
                    if (u.host === 'max.ru') a.href = 'https://max.ru/' + u.pathname.substring(1) + '?start=' + id;
                    else if (u.host === 't.me' && !/bot$/i.test(n)) a.href = 'https://t.me' + u.pathname + '?text=' + txt;
                } catch (e) {}
            });
        })();
        function add(src) { var k = d.createElement('script'); k.async = true; k.src = src; d.head.appendChild(k); return k; }
        function load() {
            if (done) return; done = true;
            ev.forEach(function (e) { w.removeEventListener(e, load, true); });
            add('https://mc.yandex.ru/metrika/tag.js?id=113675622');
            var p = d.createElement('link'); p.rel = 'preconnect'; p.href = 'https://tracker.comagic.ru'; d.head.appendChild(p);
            add('https://app.uiscom.ru/static/cs.min.js?k=ICWycQx6m3NSBe3WlCeDAdAKMTmNhMHC').onerror = function () { ready = true; };
            add('https://track.radist.me/tracker.min.js');
        }
        ev.forEach(function (e) { w.addEventListener(e, load, { capture: true, passive: true }); });
        function later() { setTimeout(load, 5000); }
        if (d.readyState === 'complete') later(); else w.addEventListener('load', later);
        // Ожидание подмены номера при первом касании: набор откладывается до ответа UIS, максимум 0,8–1 с
        d.addEventListener('click', function (e) {
            if (ready) return;
            var a = e.target && e.target.closest ? e.target.closest('a[href^="tel:"]') : null;
            if (!a || e.button || e.ctrlKey || e.metaKey || e.shiftKey || e.altKey) return;
            e.preventDefault();
            if (wait) return;
            load();
            var href = a.getAttribute('href'), op = a.style.opacity, max = 'GestureEvent' in w ? 800 : 1000, t;
            function go() {
                for (var i = 0; i < wait.length; i++) clearTimeout(wait[i]);
                wait = null; ready = true; a.style.opacity = op;
                w.location.href = a.href;
            }
            function check(last) { return function () { if (wait && (last || ready || a.getAttribute('href') !== href)) go(); }; }
            wait = [];
            a.style.opacity = '.6';
            for (t = 50; t <= max; t += 50) wait.push(setTimeout(check(t === max), t));
        }, true);
    })(window, document);
</script>
<noscript><div><img src="https://mc.yandex.ru/watch/113675622" style="position:absolute; left:-9999px;" alt="" /></div></noscript>
<!-- /Yandex.Metrika counter -->
</body>
</html>
