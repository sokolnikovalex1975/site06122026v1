<!doctype html>
<html lang="ru">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>Программа производственного контроля по ХАССП: образец ППК в PDF — ПЕСТКОНТРОЛЬ Центр</title>
<meta name="description" content="Образец программы производственного контроля для пищевого производства: PDF на 27 страниц, ККТ, лабораторный контроль, медосмотры, формы учёта. Что вписать о дезинсекции и дератизации по СанПиН 2026 года.">
<link rel="canonical" href="https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/materialy/programma-proizvodstvennogo-kontrolya-haccp/">
<meta name="theme-color" content="#000000">
<meta property="og:type" content="website">
<meta property="og:locale" content="ru_RU">
<meta property="og:site_name" content="ПЕСТКОНТРОЛЬ Центр">
<meta property="og:url" content="https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/materialy/programma-proizvodstvennogo-kontrolya-haccp/">
<meta property="og:title" content="Образец программы производственного контроля по ХАССП и раздел пест-контроля">
<meta property="og:description" content="Образец программы производственного контроля для пищевого производства: PDF на 27 страниц, ККТ, лабораторный контроль, медосмотры, формы учёта. Что вписать о дезинсекции и дератизации по СанПиН 2026 года.">
<meta property="og:image" content="https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/img/ppk-og.jpg">
<meta property="og:image:type" content="image/jpeg">
<meta property="og:image:width" content="1200">
<meta property="og:image:height" content="630">
<meta property="og:image:alt" content="Инженер по качеству и специалист по пест-контролю сверяют раздел программы производственного контроля и схему точек контроля">
<meta name="twitter:card" content="summary_large_image">
<link rel="icon" href="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%2032%2032'%3E%3Ccircle%20cx='16'%20cy='16'%20r='15'%20fill='%2309090b'%20stroke='%237c86ff'%20stroke-width='2'/%3E%3Cpath%20d='M16%207l7%203v5c0%205-3%208.5-7%2010-4-1.5-7-5-7-10v-5z'%20fill='none'%20stroke='%23fff'%20stroke-width='2'/%3E%3C/svg%3E">
<link rel="preload" href="../../fonts/inter-ru-wght-normal.woff2" as="font" type="font/woff2" crossorigin>
<link rel="preload" as="image" media="(min-width:861px)" imagesrcset="../../img/ppk-hero-1440.webp 1440w, ../../img/ppk-hero.webp 1920w" imagesizes="100vw" fetchpriority="high">
<link rel="preload" as="image" media="(max-width:860px)" imagesrcset="../../img/ppk-hero-mob-760.webp 760w, ../../img/ppk-hero-mob.webp 1024w" imagesizes="100vw" fetchpriority="high">
<script>
  /* начальные состояния анимаций — только при работающем JS; страховка — через 4 с всё показывается.
     Заставка — один раз за посещение: при переходе по ссылке с якорем и между страницами сайта её нет */
  (function (d) {
    d.classList.add('js');
    try { if (location.hash || sessionStorage.getItem('pc-intro')) d.classList.add('no-intro'); else sessionStorage.setItem('pc-intro', '1'); }
    catch (e) { if (location.hash) d.classList.add('no-intro'); }
    setTimeout(function () { if (!d.classList.contains('anim-ready')) d.classList.add('anim-fail'); }, 4000);
  })(document.documentElement);
</script>
<link rel="stylesheet" href="../../style.css?v=20261106s2">
<style>html{scroll-behavior:auto}.d-page .s{padding:clamp(64px,7vw,128px) 0;border-top:1px solid var(--line)}.d-crumbs{font-size:14px;color:var(--t3);display:flex;flex-wrap:wrap;gap:8px;margin:0 0 clamp(20px,2.4vw,32px)}.d-crumbs a{color:var(--t2)}.d-crumbs a:hover{color:var(--t1)}.p-def{font-size:clamp(16px,1.18vw,20px);line-height:1.62;color:var(--t2);margin:24px 0 0;max-width:660px}.p-def strong{color:var(--t1);font-weight:500}.d-ticks{list-style:none;padding:0;margin:24px 0 0;display:grid;gap:12px}.d-ticks li{position:relative;padding-left:30px;line-height:1.52;color:var(--t1)}.d-ticks li::before{content:"";position:absolute;left:2px;top:.45em;width:13px;height:7px;border-left:2px solid var(--acc);border-bottom:2px solid var(--acc);transform:rotate(-45deg)}.d-btns{display:flex;flex-wrap:wrap;gap:12px;margin-top:28px}.d-card{background:var(--card);border:1px solid var(--line2);border-radius:var(--r);padding:clamp(22px,2vw,32px)}.d-card h3{font-size:clamp(19px,1.4vw,24px);font-weight:400;letter-spacing:-.02em;margin:0 0 12px}.d-card p{color:var(--t2);line-height:1.6;margin:0}.d-table{width:100%;border-collapse:collapse;border:1px solid var(--line2);border-radius:var(--r);overflow:hidden;background:var(--card);margin-top:28px}.d-table th,.d-table td{padding:16px 20px;text-align:left;border-bottom:1px solid var(--line);line-height:1.52;vertical-align:top;font-size:15px}.d-table th{font-size:12px;letter-spacing:.08em;text-transform:uppercase;color:var(--t3);font-weight:500;background:rgba(255,255,255,.02)}.d-table tr:last-child td{border-bottom:0}.d-table td:first-child{color:var(--t1);font-weight:500}.d-table td:not(:first-child){color:var(--t2)}.p-secs{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:16px}.p-sec{background:var(--card);border:1px solid var(--line2);border-radius:var(--r);padding:clamp(22px,2.2vw,32px);display:flex;flex-direction:column;justify-content:space-between}.p-sec-top{display:flex;align-items:center;justify-content:space-between;gap:12px;margin-bottom:14px}.p-sec-num{font-size:12px;letter-spacing:.08em;text-transform:uppercase;color:var(--acc);font-weight:500;padding:4px 10px;border-radius:99px;background:rgba(124,134,255,.1);border:1px solid rgba(124,134,255,.28)}.p-sec-who{font-size:12px;color:var(--t3)}.p-sec h3{font-size:clamp(19px,1.4vw,24px);font-weight:400;letter-spacing:-.02em;margin:0 0 12px;color:var(--t1)}.p-sec p{color:var(--t2);line-height:1.62;margin:0;font-size:15px}.p-sec ul{margin:12px 0 0;padding-left:18px;color:var(--t2);display:grid;gap:6px;font-size:14px;line-height:1.55}.p-sec li strong{color:var(--t1);font-weight:500}.d-cols2{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:16px;margin-top:16px}.d-steps{list-style:none;padding:0;margin:0;display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:16px;counter-reset:st}.d-steps li{background:var(--card);border:1px solid var(--line2);border-top:2px solid var(--acc);border-radius:var(--r);padding:24px;counter-increment:st}.d-steps li::before{content:"0" counter(st);display:block;font-size:13px;letter-spacing:.08em;color:var(--acc);margin-bottom:14px}.d-steps b{display:block;font-size:19px;font-weight:400;margin-bottom:8px;color:var(--t1)}.d-steps span{display:block;color:var(--t2);line-height:1.55;font-size:15px}.d-chips{list-style:none;padding:0;margin:24px 0 0;display:flex;flex-wrap:wrap;gap:10px}.d-chips a{display:inline-flex;align-items:center;gap:8px;padding:12px 18px;border:1px solid var(--line2);border-radius:99px;background:var(--card);color:var(--t1);font-size:14px;transition:border-color .2s,background .2s}.d-chips a:hover{border-color:var(--acc);background:rgba(124,134,255,.08)}.d-hero{position:relative;overflow:hidden;padding:calc(clamp(68px,6vw,115px) + 20px) 0 clamp(64px,7vw,116px);min-height:clamp(640px,52vw,860px);display:flex;align-items:center}.d-hero .wrap{width:100%;display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1fr);gap:clamp(28px,4vw,80px);align-items:center}.d-hero-copy>*:not(.d-hero-media){position:relative;z-index:1}.d-hero-media{position:absolute;inset:0;z-index:0;pointer-events:none;overflow:hidden}.d-hero-media::before{content:"";position:absolute;inset:0;z-index:1;background:linear-gradient(90deg,rgba(0,0,0,.95) 0%,rgba(0,0,0,.86) 38%,rgba(0,0,0,.3) 55%,rgba(0,0,0,0) 66%),linear-gradient(180deg,#000 0,rgba(0,0,0,.55) 90px,rgba(0,0,0,0) 260px),linear-gradient(0deg,#000 0,rgba(0,0,0,0) 20%)}.d-hero-img{position:absolute;inset:0;width:100%;height:100%;object-fit:cover;object-position:100% 50%}.d-hero h1{font-size:clamp(38px,4.1vw,76px);line-height:1.1;letter-spacing:-.055em;font-weight:300;margin:18px 0 0}.d-hero h1 .ln{display:block;padding:0 .08em .08em 0;margin-bottom:-.08em}.d-hero h1 .ln>span{display:inline-block}.d-hero .p-def{margin-top:22px}.p-hero-note{margin:14px 0 0;font-size:13px;color:var(--t3)}.p-hero-note a{color:var(--t2);text-decoration:underline;text-underline-offset:3px}.p-obr{display:grid;grid-template-columns:minmax(0,1.05fr) minmax(0,.95fr);gap:clamp(24px,3.4vw,56px);align-items:start}.p-obr-pages{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:14px}.p-obr-page{display:block;color:var(--t2);font-size:13px;line-height:1.4}.p-obr-page span{display:block;border-radius:10px;overflow:hidden;border:1px solid var(--line2);background:#fff;box-shadow:0 14px 36px rgba(0,0,0,.45);transition:border-color .2s,transform .2s;margin-bottom:10px}.p-obr-page img{display:block;width:100%;height:auto;aspect-ratio:720/1018}.p-obr-page:hover span{border-color:var(--acc);transform:translateY(-2px)}.p-obr-page b{display:block;color:var(--t1);font-weight:500}.p-obr-info{background:var(--card);border:1px solid var(--line2);border-top:2px solid var(--acc);border-radius:var(--r);padding:clamp(22px,2.4vw,34px)}.p-obr-info h3{font-size:clamp(19px,1.4vw,24px);font-weight:400;letter-spacing:-.02em;margin:0 0 14px;color:var(--t1)}.p-obr-list{list-style:none;padding:0;margin:0 0 22px;display:grid;gap:10px;counter-reset:pg}.p-obr-list li{display:grid;grid-template-columns:52px minmax(0,1fr);gap:10px;color:var(--t2);font-size:14px;line-height:1.5}.p-obr-list li b{font-family:var(--mono,monospace);font-size:12px;color:var(--acc);font-weight:500;padding-top:2px}.p-obr-btns{display:flex;flex-wrap:wrap;gap:12px}.p-obr-meta{margin:14px 0 0;font-size:13px;color:var(--t3);line-height:1.5}.p-obr-meta a{color:var(--t2);text-decoration:underline;text-underline-offset:3px}@media (max-width:1180px){.d-hero{min-height:0}.d-hero .wrap{grid-template-columns:minmax(0,.82fr) minmax(0,1.18fr)}.d-hero .btn-lg{height:52px;padding:0 22px;font-size:15px}}@media (max-width:1100px){.p-obr{grid-template-columns:minmax(0,1fr)}}@media (max-width:860px){.d-hero{display:block;min-height:0;padding:calc(clamp(68px,6vw,115px) + 20px) 0 clamp(36px,6vw,56px)}.d-hero .wrap{grid-template-columns:minmax(0,1fr)}.d-hero-copy{display:flex;flex-direction:column}.d-hero .eyebrow{display:none}.d-hero h1{order:1;font-size:clamp(28px,7.8vw,34px);line-height:1.08;margin:0}.d-hero h1 .ln{display:inline}.d-hero-media{order:2;position:relative;inset:auto;aspect-ratio:16/9;margin:18px calc(var(--pad) * -1) 0}.d-hero-media::before{display:none}.d-hero-img{height:100%;min-height:0}.d-hero .d-btns{order:3;margin-top:20px;gap:10px}.d-hero .p-hero-note{order:4}.d-hero .d-ticks{order:5;margin:22px 0 0;gap:9px;font-size:15px}.d-hero .p-def{order:6;margin:18px 0 0;font-size:15px;line-height:1.5}.d-hero .d-crumbs{order:7;margin:18px 0 0;font-size:11px;line-height:1.2;gap:6px;flex-wrap:nowrap;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;opacity:1;color:#8b8b93}.d-hero .d-crumbs a,.d-hero .d-crumbs span{color:#8b8b93}.p-obr-pages{gap:10px}.p-obr-page{font-size:12px}}@media (max-width:600px){.p-obr-btns .btn{width:100%;white-space:normal;text-align:center;line-height:1.25}.p-obr-page b{font-size:12px}.p-obr-page small{display:none}}@media (max-width:1100px){.d-steps{grid-template-columns:repeat(2,minmax(0,1fr))}}@media (max-width:900px){.hdr{background:rgba(0,0,0,.72);backdrop-filter:blur(18px);-webkit-backdrop-filter:blur(18px);border-color:var(--line)}.p-secs,.d-cols2{grid-template-columns:minmax(0,1fr)}}@media (max-width:860px){.d-table,.d-table tbody,.d-table tr,.d-table td{display:block;width:100%}.d-table thead{display:none}.d-table tr{padding:16px 18px;border-bottom:1px solid var(--line)}.d-table td{padding:6px 0;border:0}.d-table td::before{content:attr(data-l);display:block;font-size:11px;letter-spacing:.08em;text-transform:uppercase;color:var(--t3);margin-bottom:2px}}@media (max-width:600px){.d-steps{grid-template-columns:minmax(0,1fr)}.d-btns .btn{width:100%;white-space:normal;text-align:center;line-height:1.25}.d-page .btn-lg{padding:0 16px}}@media (max-width:400px){.hdr .wrap{gap:10px}.hdr-right{gap:8px}.logo{gap:8px}.logo-mark{width:34px;height:34px}.logo-name{font-size:15px}.phone i,.burger{width:40px;height:40px}}@media (max-width:340px){.logo-sub{display:none}}@media (max-width:480px){#submitBtn{padding:0 18px;gap:10px}#submitBtn .btn-t{white-space:normal;text-align:center;line-height:1.2}}.d-hero h1{font-size:clamp(36px,3.75vw,68px)}.d-hero .p-def strong{color:var(--t1);font-weight:500}.k-facts{list-style:none;margin:0;padding:0;border:1px solid var(--line2);border-radius:var(--r);background:var(--card);overflow:hidden}.k-facts li{display:grid;grid-template-columns:56px minmax(0,1fr) minmax(0,280px);gap:10px 28px;padding:24px clamp(18px,2.2vw,32px);border-bottom:1px solid var(--line);align-items:start}.k-facts li:last-child{border-bottom:0}.k-n{font-size:13px;letter-spacing:.08em;color:var(--acc);padding-top:5px}.k-facts h3{font-size:clamp(18px,1.35vw,22px);font-weight:400;letter-spacing:-.02em;line-height:1.3;margin:0 0 8px;color:var(--t1)}.k-facts p{margin:0;color:var(--t2);line-height:1.6;font-size:15px}.k-ref{display:block;font-size:13px;line-height:1.5;color:var(--t3)}.k-facts .k-ref{padding-top:5px}.k-obr .p-obr-list li{grid-template-columns:78px minmax(0,1fr)}.k-obr .p-obr-list li b{white-space:nowrap}@media (max-width:600px){.k-obr .p-obr-list li{grid-template-columns:72px minmax(0,1fr);gap:8px;font-size:13.5px}.k-obr .p-obr-list li b{font-size:11px}}.k-norms td:nth-child(2) s{color:var(--t3);text-decoration-color:rgba(255,100,103,.55)}.k-norms td:nth-child(3){color:var(--t1);font-weight:500}.k-callout{margin:16px 0 0;background:rgba(124,134,255,.07);border:1px solid rgba(124,134,255,.3);border-radius:var(--r);padding:clamp(18px,2vw,26px) clamp(18px,2.2vw,32px);color:var(--t2);line-height:1.6;max-width:none}.k-callout b{color:var(--t1);font-weight:500}.k-map{display:grid;grid-template-columns:minmax(0,1.15fr) minmax(0,.85fr);gap:clamp(18px,2.6vw,40px);align-items:start}.k-stack{list-style:none;margin:0;padding:0;display:grid;gap:10px}.k-stack li{position:relative;display:grid;grid-template-columns:92px minmax(0,1fr);gap:4px 18px;background:var(--card);border:1px solid var(--line2);border-radius:var(--r);padding:18px clamp(16px,1.8vw,24px)}.k-stack li:nth-child(2){margin-left:clamp(0px,1.6vw,24px)}.k-stack li:nth-child(3){margin-left:clamp(0px,3.2vw,48px)}.k-stack li:nth-child(4){margin-left:clamp(0px,4.8vw,72px)}.k-stack li:nth-child(5){margin-left:clamp(0px,6.4vw,96px)}.k-stack li+li::before{content:"";position:absolute;left:40px;top:-11px;width:1px;height:10px;background:rgba(124,134,255,.45)}.k-lvl{font-size:12px;letter-spacing:.08em;text-transform:uppercase;color:var(--t3);padding-top:3px}.k-stack b{display:block;font-weight:500;color:var(--t1);font-size:16px;line-height:1.35;margin-bottom:4px}.k-d{display:block;color:var(--t2);font-size:14px;line-height:1.55}.k-stack .k-ref{margin-top:6px}.k-stack li.on{border-color:rgba(124,134,255,.55);background:linear-gradient(180deg,rgba(124,134,255,.12),rgba(24,24,27,.5))}.k-stack li.on .k-lvl{color:var(--acc)}.k-side{display:grid;gap:16px}.k-more{margin:14px 0 0!important}.k-more .link-arrow{padding:4px 0}.k-sample{display:grid;grid-template-columns:minmax(0,1.4fr) minmax(0,.6fr);gap:clamp(18px,2.6vw,40px);align-items:start}.k-doc{background:#f4f4f1;color:#1f1f24;border-radius:var(--r);padding:clamp(22px,3vw,48px);box-shadow:0 30px 70px rgba(0,0,0,.55);font-size:15px;line-height:1.62}.k-doc-top{display:flex;flex-wrap:wrap;justify-content:space-between;gap:6px 16px;border-bottom:1px solid #d7d7d1;padding-bottom:14px;margin-bottom:20px;font-size:12px;letter-spacing:.06em;text-transform:uppercase;color:#5f5f68}.k-doc h3{font-size:clamp(20px,1.6vw,26px);font-weight:600;letter-spacing:-.01em;line-height:1.25;margin:0 0 16px;color:#111114}.k-doc ol{list-style:none;margin:0;padding:0;display:grid;gap:11px}.k-doc li{display:grid;grid-template-columns:42px minmax(0,1fr);gap:6px}.k-doc li b{font-weight:600;color:#111114}.k-doc mark{background:#ffef9e;color:#3a3000;border-radius:3px;padding:0 .2em;box-decoration-break:clone;-webkit-box-decoration-break:clone}.k-doc-foot{margin:20px 0 0;padding-top:12px;border-top:1px solid #d7d7d1;font-size:12px;line-height:1.5;color:#5f5f68}.k-aside{position:sticky;top:96px}.k-aside .d-card h3{margin-bottom:14px}.k-list{list-style:none;margin:0 0 20px;padding:0;display:grid;gap:9px}.k-list li{position:relative;padding-left:22px;color:var(--t2);font-size:15px;line-height:1.5}.k-list li::before{content:"";position:absolute;left:2px;top:.55em;width:9px;height:9px;border-radius:2px;background:#ffef9e}.k-aside-btns{display:grid;gap:10px}.k-aside-btns .btn{width:100%;justify-content:center}.k-aside-note{margin:16px 0 0!important;font-size:14px}.k-aside-note a{color:var(--acc);text-decoration:underline;text-underline-offset:3px}.k-errs{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:16px}.k-err{background:var(--card);border:1px solid var(--line2);border-radius:var(--r);padding:clamp(20px,2vw,28px);display:flex;flex-direction:column;gap:10px}.k-err-tag{align-self:flex-start;font-size:12px;letter-spacing:.08em;text-transform:uppercase;color:var(--yel);padding:4px 10px;border-radius:99px;background:rgba(253,199,0,.08);border:1px solid rgba(253,199,0,.25)}.k-err h3{font-size:clamp(18px,1.35vw,22px);font-weight:400;letter-spacing:-.02em;line-height:1.3;margin:4px 0 0;color:var(--t1)}.k-err p{margin:0;color:var(--t2);font-size:15px;line-height:1.58}.k-err .k-fix{margin-top:auto;padding-top:12px;border-top:1px solid var(--line);color:var(--t1);font-size:14px}.k-fix::before{content:"Как исправить: ";color:var(--acc)}.k-steps{grid-template-columns:repeat(5,minmax(0,1fr))}.k-price{margin-top:16px}@media (max-width:1180px){.k-steps{grid-template-columns:repeat(3,minmax(0,1fr))}.k-errs{grid-template-columns:repeat(2,minmax(0,1fr))}}@media (max-width:1024px){.k-map,.k-sample{grid-template-columns:minmax(0,1fr)}.k-aside{position:static}}@media (max-width:860px){.k-facts li{grid-template-columns:34px minmax(0,1fr);padding:20px 18px}.k-facts .k-ref{grid-column:2;padding-top:0}.k-stack li{grid-template-columns:minmax(0,1fr);gap:6px}.k-stack li:nth-child(n){margin-left:0}.k-stack li+li::before{left:28px}.k-steps{grid-template-columns:repeat(2,minmax(0,1fr))}}@media (max-width:640px){.k-errs,.k-steps{grid-template-columns:minmax(0,1fr)}.k-doc{padding:22px 18px;font-size:14.5px}.k-doc li{grid-template-columns:36px minmax(0,1fr)}}.k-src{margin:14px 0 0;font-size:14px;line-height:1.7;color:var(--t3)}.k-src a{color:var(--t2);text-decoration:underline;text-decoration-color:rgba(255,255,255,.25);text-underline-offset:3px;transition:color .2s}.k-src a:hover{color:var(--t1)}.d-steps .nw{display:inline;color:inherit;font-size:inherit;line-height:inherit;margin:0}.p-sec-top{flex-wrap:wrap;row-gap:8px}.p-sec-num{flex-shrink:0;white-space:nowrap}.p-sec-who{text-align:right}.qa-q{flex:1 1 auto;min-width:0}@media (max-width:640px){.p-sec-who{text-align:left}}.d-crumbs [aria-current]{min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}@media (min-width:861px) and (max-height:820px){.d-hero h1{font-size:clamp(34px,3.2vw,56px)}}.k-more .link-arrow{white-space:normal}</style>
<script type="application/ld+json">{"@context": "https://schema.org", "@graph": [{"@type": "BreadcrumbList", "itemListElement": [{"@type": "ListItem", "position": 1, "name": "Главная", "item": "https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/"}, {"@type": "ListItem", "position": 2, "name": "Материалы", "item": "https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/materialy/"}, {"@type": "ListItem", "position": 3, "name": "Программа производственного контроля по ХАССП", "item": "https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/materialy/programma-proizvodstvennogo-kontrolya-haccp/"}]}, {"@type": "TechArticle", "headline": "Программа производственного контроля по ХАССП: раздел пест-контроля", "image": "https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/img/ppk-og.jpg", "description": "Образец программы производственного контроля для пищевого производства: PDF на 27 страниц, ККТ, лабораторный контроль, медосмотры, формы учёта. Что вписать о дезинсекции и дератизации по СанПиН 2026 года.", "inLanguage": "ru-RU", "mainEntityOfPage": "https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/materialy/programma-proizvodstvennogo-kontrolya-haccp/", "datePublished": "2026-11-06", "dateModified": "2026-11-07", "about": ["Программа производственного контроля", "ХАССП", "Дезинсекция", "Дератизация"], "author": {"@type": "Organization", "name": "Методический отдел ПЕСТКОНТРОЛЬ Центр", "url": "https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/"}, "publisher": {"@type": "Organization", "name": "ПЕСТКОНТРОЛЬ Центр", "url": "https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/", "telephone": "+7-495-104-35-70", "email": "b2b@pestcontrol-center.ru"}, "citation": [{"@type": "Legislation", "name": "СанПиН 2.3/2.4.4282-26 «Санитарно-эпидемиологические требования к организации общественного питания населения»", "url": "http://publication.pravo.gov.ru/document/0001202606020084"}, {"@type": "Legislation", "name": "СП 2.3.6.4281-26 «Санитарно-эпидемиологические требования к условиям деятельности торговых объектов и рынков, реализующих пищевую продукцию»", "url": "http://publication.pravo.gov.ru/document/0001202606020079"}, {"@type": "Legislation", "name": "СП 2.1.4284-26 «Санитарно-эпидемиологические требования к эксплуатации помещений, зданий, сооружений, оборудования и транспорта, а также условиям деятельности хозяйствующих субъектов, осуществляющих продажу товаров, выполнение работ или оказание услуг»", "url": "http://publication.pravo.gov.ru/document/0001202606020088"}, {"@type": "Legislation", "name": "СанПиН 3.3686-21 «Санитарно-эпидемиологические требования по профилактике инфекционных болезней»", "url": "http://pravo.gov.ru/proxy/ips/?docbody=&nd=602107773"}]}, {"@type": "DigitalDocument", "name": "Образец программы производственного контроля для пищевого производства (PDF, 27 страниц)", "encodingFormat": "application/pdf", "url": "https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/materialy/programma-proizvodstvennogo-kontrolya-haccp/obrazets-programmy-proizvodstvennogo-kontrolya.pdf", "inLanguage": "ru-RU", "publisher": {"@type": "Organization", "name": "ПЕСТКОНТРОЛЬ Центр"}}, {"@type": "Service", "name": "Подготовка раздела «Дезинсекция и дератизация» для программы производственного контроля", "serviceType": "Пест-контроль по ХАССП и программа производственного контроля", "provider": {"@type": "Organization", "name": "ПЕСТКОНТРОЛЬ Центр", "url": "https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/", "telephone": "+7-495-104-35-70"}, "areaServed": [{"@type": "City", "name": "Москва"}, {"@type": "AdministrativeArea", "name": "Московская область"}]}, {"@type": "FAQPage", "mainEntity": [{"@type": "Question", "name": "Нужна ли программа производственного контроля по ХАССП кафе или магазину?", "acceptedAnswer": {"@type": "Answer", "text": "Программа производственного контроля нужна любому юрлицу и ИП: её составляют до начала деятельности (СП 1.1.1058-01, п. 2.6). Общепит ведёт производственный контроль на принципах ХАССП — это п. 4 СанПиН 2.3/2.4.4282-26. Для магазина производственный контроль обязателен по п. 3 СП 2.3.6.4281-26, а процедуры ХАССП ТР ТС 021/2011 требует от изготовителей пищевой продукции: если в магазине есть кулинария или пекарня, это уже производство."}}, {"@type": "Question", "name": "Где взять образец программы производственного контроля для пищевого производства?", "acceptedAnswer": {"@type": "Answer", "text": "На этой странице — бесплатный образец ППК на 27 страниц для хлебопекарного и кондитерского производства: в PDF. В нём все пункты раздела 3 СП 1.1.1058-01, лабораторный контроль сырья, продукции, смывов и воды, 4 критические контрольные точки ХАССП, медосмотры и гигиеническая подготовка по должностям, раздел о дезинсекции и дератизации, аварийные ситуации и 19 форм учёта. Реквизиты в образце условные: программу адаптируют под свой объект, утверждает её руководитель."}}, {"@type": "Question", "name": "Нужно ли включать дезинсекцию и дератизацию в программу производственного контроля?", "acceptedAnswer": {"@type": "Answer", "text": "Да. ТР ТС 021/2011 требует выбрать способы, установить периодичность и проводить дезинсекцию и дератизацию (ст. 10 ч. 3 п. 10), а также определить меры против проникновения грызунов, насекомых и синантропных птиц (ст. 11 ч. 3 пп. 7–8). Для торговли и объектов услуг обязанность проводить дезинсекцию и дератизацию закреплена в п. 78 СП 2.3.6.4281-26 и п. 14 СП 2.1.4284-26."}}, {"@type": "Question", "name": "Как часто проводить дезинсекцию и дератизацию по программе производственного контроля?", "acceptedAnswer": {"@type": "Answer", "text": "На объектах особого эпидемиологического значения — в пищевой промышленности, общепите, на складах и в магазинах пищевой продукции — обследования на насекомых проводятся не реже 2 раз в месяц, а дератизация — по результатам ежемесячной оценки (СанПиН 3.3686-21, пп. 98, 101, 110). Конкретный график визитов и срок внепланового выезда закрепляются в договоре и программе пест-контроля, а в ППК — ссылкой на них."}}, {"@type": "Question", "name": "Кто составляет и утверждает программу производственного контроля?", "acceptedAnswer": {"@type": "Answer", "text": "Программу составляет само предприятие — в произвольной форме и без ограничения срока действия; утверждает её руководитель или уполномоченное лицо (СП 1.1.1058-01, п. 2.6). Санитарные правила не требуют согласовывать её с Роспотребнадзором. Раздел о дезинсекции и дератизации удобно поручить исполнителю с лицензией: он отвечает за периодичность, средства и документы по обработкам."}}, {"@type": "Question", "name": "Чем программа производственного контроля отличается от программы пест-контроля?", "acceptedAnswer": {"@type": "Answer", "text": "ППК — общий документ предприятия по всем санитарным требованиям: нормы, ответственные, лабораторный контроль, медосмотры, формы учёта. Программа пест-контроля — подробный рабочий документ только по вредителям: зоны риска, схема точек, пороги численности, средства и график. В ППК достаточно раздела с обязательствами и ссылкой на программу пест-контроля как приложение."}}, {"@type": "Question", "name": "Пест-контроль — это ККТ в плане ХАССП?", "acceptedAnswer": {"@type": "Answer", "text": "Как правило, нет. Борьба с вредителями относится к программам обязательных предварительных мероприятий (ПОПМ) — ГОСТ Р ИСО 22000-2019 называет её среди них в п. 8.2.4. Критические контрольные точки устанавливают для параметров технологического процесса, например температуры. Если анализ опасностей выявил значимую опасность, связанную с вредителями, меры по её управлению оформляют как ППОПМ с измеримыми или наблюдаемыми критериями действия (п. 8.5.4.2)."}}, {"@type": "Question", "name": "Нужно ли менять ППК после 1 сентября 2026 года?", "acceptedAnswer": {"@type": "Answer", "text": "Да, если в ней остались ссылки на СанПиН 2.3/2.4.3590-20, СП 2.3.6.3668-20 или СП 2.1.3678-20: с 1 сентября 2026 года вместо них действуют СанПиН 2.3/2.4.4282-26, СП 2.3.6.4281-26 и СП 2.1.4284-26. Для торговых объектов Роспотребнадзор прямо указывает на необходимость внести изменения в программу производственного контроля. Новую редакцию утверждает руководитель."}}, {"@type": "Question", "name": "Какие документы по пест-контролю хранить вместе с ППК?", "acceptedAnswer": {"@type": "Answer", "text": "Договор с исполнителем, сведения о его лицензии, акты выполненных работ, журнал учёта, схему точек контроля, перечень применяемых средств с документами о государственной регистрации и ежемесячные отчёты. ТР ТС 021/2011 разрешает вести и хранить документацию на бумажных и (или) электронных носителях (ст. 10 ч. 3 п. 11)."}}, {"@type": "Question", "name": "Сколько стоит подготовка раздела ППК по пест-контролю?", "acceptedAnswer": {"@type": "Answer", "text": "Текст раздела готовим вместе с программой пест-контроля при запуске обслуживания по договору. Абонентское обслуживание — от 3 500 ₽ в месяц для кафе и магазинов и от 4 500 ₽ для складов до 1 000 м²; для пищевых производств расчёт делаем после бесплатного выезда."}}]}]}</script>
<style id="m-crumbs">/* крошки на телефоне не показываем: для SEO хватает BreadcrumbList и ссылок в HTML */@media (max-width:900px){.d-crumbs,.f-crumbs{display:none!important}}</style>
<style data-fx>
/* подсветка рамки карточек за курсором — как у .card на главной (tools/site/fx.py) */
:where(.d-card,.p-sec,.p-fcard,.p-duty-box,.p-dl-card,.pm-step-card,.pm-scen,.pm-link-card,.k-err,.w-sample,.d-doc-prev){position:relative}
:where(.d-card,.p-sec,.p-fcard,.p-duty-box,.p-dl-card,.pm-step-card,.pm-scen,.pm-link-card,.k-err,.w-sample,.d-doc-prev)::after{content:"";position:absolute;inset:0;border-radius:inherit;padding:1.4px;pointer-events:none;background:radial-gradient(360px circle at var(--mx,-999px) var(--my,-999px),rgba(124,134,255,.85),rgba(124,134,255,.15) 35%,transparent 60%);-webkit-mask:linear-gradient(#000 0 0) content-box,linear-gradient(#000 0 0);-webkit-mask-composite:xor;mask:linear-gradient(#000 0 0) content-box,linear-gradient(#000 0 0);mask-composite:exclude;opacity:0;transition:opacity .4s;z-index:2}
@media (hover:hover) and (pointer:fine){:where(.d-card,.p-sec,.p-fcard,.p-duty-box,.p-dl-card,.pm-step-card,.pm-scen,.pm-link-card,.k-err,.w-sample,.d-doc-prev):hover::after{opacity:1}}
/* «фонарь» на фото первого экрана — как на главной (tools/site/fx.py) */
.fx-lit{position:absolute;inset:0;opacity:0;pointer-events:none;-webkit-mask-image:radial-gradient(circle var(--sr,320px) at var(--sx,72%) var(--sy,46%),#000 0%,rgba(0,0,0,.55) 45%,transparent 72%);mask-image:radial-gradient(circle var(--sr,320px) at var(--sx,72%) var(--sy,46%),#000 0%,rgba(0,0,0,.55) 45%,transparent 72%);transition:opacity 1.8s cubic-bezier(.16,1,.3,1)}
#hero :is(.d-hero-media,.hero-media)>picture>img{transition:filter 1.8s cubic-bezier(.16,1,.3,1)}
#hero.fx-lit-on :is(.d-hero-media,.hero-media)>picture>img{filter:grayscale(.3) brightness(.56)}
#hero.fx-lit-on .fx-lit img{filter:brightness(1.08) contrast(1.06) saturate(1.06)}
#hero.fx-lit-on .fx-lit{opacity:1}
</style>
</head>
<body class="d-page">
<a class="skip" href="#main">Перейти к содержанию</a>

<!-- ============ INTRO ============ -->
<div class="intro" id="intro" aria-hidden="true">
  <div class="intro-in">
    <svg class="intro-mark" viewBox="0 0 24 24" fill="none" stroke-width="1" stroke-linejoin="round"><path class="im-shield" pathLength="100" d="M12 2.5l7.5 3v6c0 5-3.2 8.6-7.5 10-4.3-1.4-7.5-5-7.5-10v-6z" stroke="#fff"/><circle class="im-c" pathLength="100" cx="12" cy="11.5" r="2.6" stroke="#7c86ff"/><path class="im-x" pathLength="100" d="M12 6.2v2.7M12 14.1v2.7M6.8 11.5h2.6M14.6 11.5h2.6" stroke="#7c86ff"/></svg>
    <div class="intro-word"><span>ПЕСТКОНТРОЛЬ</span><b>Центр</b></div>
    <div class="intro-bar"><i></i></div>
  </div>
</div>

<div class="progress" aria-hidden="true"><i id="progress"></i></div>
<div class="cursor" aria-hidden="true"><i class="cursor-dot"></i><i class="cursor-ring"></i></div>
<div class="grain" aria-hidden="true"></div>

<header class="hdr" id="hdr">
  <div class="wrap">
    <a href="../../" class="logo" aria-label="ПЕСТКОНТРОЛЬ Центр — на главную">
      <span class="logo-mark"><svg viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="1.6" stroke-linejoin="round" aria-hidden="true"><path d="M12 2.5l7.5 3v6c0 5-3.2 8.6-7.5 10-4.3-1.4-7.5-5-7.5-10v-6z"/><circle cx="12" cy="11.5" r="2.6" stroke="#7c86ff"/><path d="M12 6.2v2.7M12 14.1v2.7M6.8 11.5h2.6M14.6 11.5h2.6" stroke="#7c86ff"/></svg></span>
      <span class="logo-txt"><span class="logo-name">ПЕСТКОНТРОЛЬ</span> <span class="logo-sub">Центр</span></span>
    </a>
    <nav class="nav" aria-label="Основное меню">
      <div class="nav-dd"><button class="nav-dd-btn" type="button" aria-expanded="false" aria-controls="nav-uslugi">Услуги<svg viewBox="0 0 12 12" aria-hidden="true"><path d="M2.5 4.5 6 8l3.5-3.5" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></button><div class="nav-dd-panel" id="nav-uslugi"><a href="../../dezinfektsiya/">Дезинфекция для организаций<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../../deratizatsiya/">Дератизация для организаций<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../../dezinsektsiya/">Дезинсекция для организаций<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../../sanitarnyy-audit/"><span>Санитарный аудит <span class="nw">(СЭС-аудит)</span></span><svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../../razrabotka-ppk/">Разработка ППК<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../../ochistka-dezinfektsiya-ventilyatsii/">Очистка и дезинфекция вентиляции<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../../dogovor-deratizatsiya-dezinsektsiya/">Договор на обслуживание<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../../#podhod" class="nav-dd-all"><span>Пест-контроль по системе IPM</span><svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../../normativnaya-baza/dokumenty-dlya-rospotrebnadzora/">Документы для Роспотребнадзора</a></div></div><div class="nav-dd"><button class="nav-dd-btn" type="button" aria-expanded="false" aria-controls="nav-otrasli">Отрасли<svg viewBox="0 0 12 12" aria-hidden="true"><path d="M2.5 4.5 6 8l3.5-3.5" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></button><div class="nav-dd-panel" id="nav-otrasli"><a href="../../pishchevoe-proizvodstvo/">Пищевые производства<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../../magaziny-i-torgovye-seti/">Магазины и торговые сети<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../../restorany-i-kafe/">Рестораны и кафе<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../../sklady-i-logistika/">Склады и логистика<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../../farmatsevticheskie-proizvodstva/">Фармацевтические производства<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../../gostinitsy/">Гостиницы и отели<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../../#otrasli" class="nav-dd-all">Все отрасли<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a></div></div><a href="../../dogovor-deratizatsiya-dezinsektsiya/">Договор</a><a href="../../#podhod">Метод IPM</a><a href="../../#usloviya">Цена</a><div class="nav-dd"><button class="nav-dd-btn active" type="button" aria-expanded="false" aria-controls="nav-materialy">Материалы<svg viewBox="0 0 12 12" aria-hidden="true"><path d="M2.5 4.5 6 8l3.5-3.5" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></button><div class="nav-dd-panel" id="nav-materialy"><a href="../../normativnaya-baza/">Нормативная база<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../../materialy/programma-pest-kontrolya/"><span>Программа <span class="nw">пест-контроля</span></span><svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../../materialy/zhurnal-pest-kontrolya/"><span>Журнал <span class="nw">пест-контроля</span></span><svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../../materialy/pest-menedzhment-ili-razovaya-obrabotka/"><span><span class="nw">Пест-менеджмент</span> или разовая обработка</span><svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="./" aria-current="page">Программа производственного контроля по ХАССП<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../../materialy/" class="nav-dd-all">Все материалы<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a></div></div>
    </nav>
    <div class="hdr-right">
      <a class="phone" href="tel:+74951043570" aria-label="Позвонить: +7 (495) 104-35-70"><i><svg viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2" aria-hidden="true"><path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1 1 .4 1.9.7 2.8a2 2 0 0 1-.5 2.1L8 9.9a16 16 0 0 0 6 6l1.3-1.3a2 2 0 0 1 2.1-.4c.9.3 1.8.6 2.8.7a2 2 0 0 1 1.7 2z"/></svg></i><span>+7 (495) 104-35-70</span></a>
      <div class="msg">
        <a href="https://max.ru/u/f9LHodD0cOIlIUXFkt4KMFP88lD8n4TArBiTcV7RI1XML5c4o39QfsDBXUc" class="max" aria-label="Написать в Max" target="_blank" rel="noopener noreferrer"><svg viewBox="0 0 24 24" fill="#fff" aria-hidden="true"><path d="M12 3a9 9 0 0 0-7.7 13.7L3 21l4.4-1.2A9 9 0 1 0 12 3zm-3.6 12.3V8.7h1.6l2 2.8 2-2.8h1.6v6.6h-1.7v-3.9L12 14l-1.9-2.6v3.9z"/></svg></a>
        <a href="https://t.me/Centr_Dezinfection?text=%D0%97%D0%B4%D1%80%D0%B0%D0%B2%D1%81%D1%82%D0%B2%D1%83%D0%B9%D1%82%D0%B5!%20%D0%9F%D0%B8%D1%88%D1%83%20%D1%81%20%D1%81%D0%B0%D0%B9%D1%82%D0%B0%20%D0%BF%D0%B5%D1%81%D1%82%D0%BA%D0%BE%D0%BD%D1%82%D1%80%D0%BE%D0%BB%D1%8C-%D1%86%D0%B5%D0%BD%D1%82%D1%80.%D1%80%D1%84" class="tg" aria-label="Написать в Telegram" target="_blank" rel="noopener noreferrer"><svg viewBox="0 0 24 24" fill="#fff" aria-hidden="true"><path d="M21.4 4.3 2.9 11.4c-1.3.5-1.2 1.2-.2 1.5l4.7 1.5 1.8 5.6c.2.6.4.8.9.8.4 0 .6-.2.9-.4l2.3-2.2 4.7 3.5c.9.5 1.5.2 1.7-.8l3.1-14.6c.3-1.3-.5-1.8-1.4-1.5zM9.6 14.1l8.6-5.4c.4-.3.8-.1.5.2l-7.1 6.4-.3 3.3z"/></svg></a>
      </div>
      <a href="#zayavka" class="btn btn-w btn-sm" data-magnet><span class="btn-t">Бесплатный выезд</span></a>
      <button class="burger" id="burger" aria-label="Открыть меню" aria-expanded="false" aria-controls="mmenu"><span></span></button>
    </div>
  </div>
</header>
<nav class="mmenu" id="mmenu" aria-label="Мобильное меню">
  <div class="mm-group"><button class="mm-toggle" type="button" aria-expanded="false" aria-controls="mm-uslugi">Услуги<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m6 9 6 6 6-6" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/></svg></button><div class="mm-sub" id="mm-uslugi"><div><a href="../../dezinfektsiya/">Дезинфекция для организаций</a><a href="../../deratizatsiya/">Дератизация для организаций</a><a href="../../dezinsektsiya/">Дезинсекция для организаций</a><a href="../../sanitarnyy-audit/"><span>Санитарный аудит <span class="nw">(СЭС-аудит)</span></span></a><a href="../../razrabotka-ppk/">Разработка ППК</a><a href="../../ochistka-dezinfektsiya-ventilyatsii/">Очистка и дезинфекция вентиляции</a><a href="../../dogovor-deratizatsiya-dezinsektsiya/">Договор на обслуживание</a><a href="../../#podhod"><span class="nw">Пест-контроль</span> по системе IPM</a><a href="../../normativnaya-baza/dokumenty-dlya-rospotrebnadzora/">Документы для Роспотребнадзора</a></div></div></div><div class="mm-group"><button class="mm-toggle" type="button" aria-expanded="false" aria-controls="mm-otrasli">Отрасли<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m6 9 6 6 6-6" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/></svg></button><div class="mm-sub" id="mm-otrasli"><div><a href="../../pishchevoe-proizvodstvo/">Пищевые производства</a><a href="../../magaziny-i-torgovye-seti/">Магазины и торговые сети</a><a href="../../restorany-i-kafe/">Рестораны и кафе</a><a href="../../sklady-i-logistika/">Склады и логистика</a><a href="../../farmatsevticheskie-proizvodstva/">Фармацевтические производства</a><a href="../../gostinitsy/">Гостиницы и отели</a><a href="../../#otrasli">Все отрасли</a></div></div></div><a href="../../dogovor-deratizatsiya-dezinsektsiya/">Договор <small>на дератизацию и дезинсекцию</small></a><a href="../../#podhod">Метод IPM</a><a href="../../#usloviya">Цена</a><div class="mm-group open" data-open><button class="mm-toggle" type="button" aria-expanded="true" aria-controls="mm-materialy">Материалы<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m6 9 6 6 6-6" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/></svg></button><div class="mm-sub" id="mm-materialy"><div><a href="../../normativnaya-baza/">Нормативная база</a><a href="../../materialy/programma-pest-kontrolya/"><span>Программа <span class="nw">пест-контроля</span></span></a><a href="../../materialy/zhurnal-pest-kontrolya/"><span>Журнал <span class="nw">пест-контроля</span></span></a><a href="../../materialy/pest-menedzhment-ili-razovaya-obrabotka/"><span><span class="nw">Пест-менеджмент</span> или разовая обработка</span></a><a href="./" aria-current="page">Программа производственного контроля по ХАССП</a><a href="../../materialy/">Все материалы</a></div></div></div>
  <a href="#zayavka" class="btn btn-w btn-lg"><span class="btn-t">Бесплатный выезд</span></a>
</nav>

<main id="main" tabindex="-1">
<section class="d-hero" id="hero">
  <div class="wrap">
    <div class="d-hero-copy">
      <nav class="d-crumbs" aria-label="Навигационная цепочка" data-h><a href="../../">Главная</a><span aria-hidden="true">→</span><a href="../">Материалы</a><span aria-hidden="true">→</span><span aria-current="page">Программа производственного контроля</span></nav>
      <div class="eyebrow">Материалы для бизнеса · ППК и ХАССП</div>
      <h1><span class="ln"><span>Программа</span></span> <span class="ln"><span>производственного</span></span> <span class="ln"><span>контроля по ХАССП:</span></span> <span class="ln"><span><em>раздел <span class="nw">пест-контроля</span></em></span></span></h1>
      <div class="d-hero-media"><picture><source media="(max-width:860px)" srcset="../../img/ppk-hero-mob-760.webp 760w, ../../img/ppk-hero-mob.webp 1024w" sizes="100vw" width="1024" height="576"><img class="d-hero-img" src="../../img/ppk-hero.webp" srcset="../../img/ppk-hero-1440.webp 1440w, ../../img/ppk-hero.webp 1920w" sizes="100vw" width="1920" height="1072" alt="Инженер по качеству пищевого производства и специалист по пест-контролю сверяют раздел программы производственного контроля и схему точек контроля" fetchpriority="high" decoding="async"></picture><div class="fx-lit" aria-hidden="true"><picture><source media="(max-width:860px)" srcset="../../img/ppk-hero-mob-760.webp 760w, ../../img/ppk-hero-mob.webp 1024w" sizes="100vw" width="1024" height="576"><img class="d-hero-img fx-lit-img" src="../../img/ppk-hero.webp" srcset="../../img/ppk-hero-1440.webp 1440w, ../../img/ppk-hero.webp 1920w" sizes="100vw" width="1920" height="1072" alt="" decoding="async"></picture></div></div>
      <p class="p-def" data-h><strong>Программа производственного контроля (ППК)</strong> — документ, по которому предприятие само контролирует соблюдение санитарных правил. На пищевых объектах её строят на принципах ХАССП, а дезинсекция и дератизация — обязательная часть: периодичность, защита от вредителей и документы для проверки.</p>
      <ul class="d-ticks">
        <li data-h>8 пунктов раздела о дезинсекции и дератизации — со ссылками на нормы</li>
        <li data-h>Какие ссылки обновить после 1 сентября 2026 года</li>
        <li data-h>Полный образец ППК для пищевого производства в PDF</li>
      </ul>
      <div class="d-btns" data-h>
        <a href="#zayavka" class="btn btn-w btn-lg" data-magnet><span class="btn-t">Подготовить раздел для ППК</span></a>
        <a href="#obrazets-ppk" class="btn btn-o btn-lg" data-magnet><span class="btn-t">Образец ППК</span></a>
      </div>
      <p class="p-hero-note" data-h>Выезд и обследование — бесплатно · работаем по лицензии Роспотребнадзора № <span class="nw">Л064-00111-77/01942445</span></p>
    </div>
    <div aria-hidden="true"></div>
  </div>
</section>

<div class="strip" role="group" aria-label="Коротко о программе производственного контроля">
  <div class="strip-track" id="stripTrack">
    <div class="strip-set">
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-file-signature" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M14.364 13.634a2 2 0 0 0-.506.854l-.837 2.87a.5.5 0 0 0 .62.62l2.87-.837a2 2 0 0 0 .854-.506l4.013-4.009a1 1 0 0 0-3.004-3.004z" /> <path d="M14.487 7.858A1 1 0 0 1 14 7V2" /> <path d="M20 19.645V20a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.704.706l2.516 2.516" /> <path d="M8 18h1" /> </svg><b>ППК</b> — в произвольной форме, утверждает руководитель</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-shield-check" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z" /> <path d="m9 12 2 2 4-4" /> </svg><b>Дезинсекция и дератизация</b> — процедура ХАССП</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-file-badge" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M13 22h5a2 2 0 0 0 2-2V8a2.4 2.4 0 0 0-.706-1.706l-3.588-3.588A2.4 2.4 0 0 0 14 2H6a2 2 0 0 0-2 2v3.3" /> <path d="M14 2v5a1 1 0 0 0 1 1h5" /> <path d="m7.69 16.479 1.29 4.88a.5.5 0 0 1-.698.591l-1.843-.849a1 1 0 0 0-.879.001l-1.846.85a.5.5 0 0 1-.692-.593l1.29-4.88" /> <circle cx="6" cy="14" r="3" /> </svg><b>ТР ТС 021/2011</b> ст. 10 и 11</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-scan-search" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M3 7V5a2 2 0 0 1 2-2h2" /> <path d="M17 3h2a2 2 0 0 1 2 2v2" /> <path d="M21 17v2a2 2 0 0 1-2 2h-2" /> <path d="M7 21H5a2 2 0 0 1-2-2v-2" /> <circle cx="12" cy="12" r="3" /> <path d="m16 16-1.9-1.9" /> </svg><b>Насекомые</b> — обследования не реже 2 раз в месяц</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-activity" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M22 12h-2.48a2 2 0 0 0-1.93 1.46l-2.35 8.36a.25.25 0 0 1-.48 0L9.24 2.18a.25.25 0 0 0-.48 0l-2.35 8.36A2 2 0 0 1 4.49 12H2" /> </svg><b>Грызуны</b> — ежемесячная оценка</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-clipboard-check" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <rect width="8" height="4" x="8" y="2" rx="1" ry="1" /> <path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2" /> <path d="m9 14 2 2 4-4" /> </svg><b>С 1 сентября 2026</b> — новые санитарные правила</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-notebook-pen" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M13.4 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-7.4" /> <path d="M2 6h4" /> <path d="M2 10h4" /> <path d="M2 14h4" /> <path d="M2 18h4" /> <path d="M21.378 5.626a1 1 0 1 0-3.004-3.004l-5.01 5.012a2 2 0 0 0-.506.854l-.837 2.87a.5.5 0 0 0 .62.62l2.87-.837a2 2 0 0 0 .854-.506z" /> </svg><b>Образец раздела</b> для ППК</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-list-checks" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M13 5h8" /> <path d="M13 12h8" /> <path d="M13 19h8" /> <path d="m3 17 2 2 4-4" /> <path d="m3 7 2 2 4-4" /> </svg><b>Подтверждение</b> — договор и акты</div>
    </div>
    <div class="strip-set" aria-hidden="true">
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-file-signature" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M14.364 13.634a2 2 0 0 0-.506.854l-.837 2.87a.5.5 0 0 0 .62.62l2.87-.837a2 2 0 0 0 .854-.506l4.013-4.009a1 1 0 0 0-3.004-3.004z" /> <path d="M14.487 7.858A1 1 0 0 1 14 7V2" /> <path d="M20 19.645V20a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.704.706l2.516 2.516" /> <path d="M8 18h1" /> </svg><b>ППК</b> — в произвольной форме, утверждает руководитель</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-shield-check" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z" /> <path d="m9 12 2 2 4-4" /> </svg><b>Дезинсекция и дератизация</b> — процедура ХАССП</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-file-badge" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M13 22h5a2 2 0 0 0 2-2V8a2.4 2.4 0 0 0-.706-1.706l-3.588-3.588A2.4 2.4 0 0 0 14 2H6a2 2 0 0 0-2 2v3.3" /> <path d="M14 2v5a1 1 0 0 0 1 1h5" /> <path d="m7.69 16.479 1.29 4.88a.5.5 0 0 1-.698.591l-1.843-.849a1 1 0 0 0-.879.001l-1.846.85a.5.5 0 0 1-.692-.593l1.29-4.88" /> <circle cx="6" cy="14" r="3" /> </svg><b>ТР ТС 021/2011</b> ст. 10 и 11</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-scan-search" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M3 7V5a2 2 0 0 1 2-2h2" /> <path d="M17 3h2a2 2 0 0 1 2 2v2" /> <path d="M21 17v2a2 2 0 0 1-2 2h-2" /> <path d="M7 21H5a2 2 0 0 1-2-2v-2" /> <circle cx="12" cy="12" r="3" /> <path d="m16 16-1.9-1.9" /> </svg><b>Насекомые</b> — обследования не реже 2 раз в месяц</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-activity" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M22 12h-2.48a2 2 0 0 0-1.93 1.46l-2.35 8.36a.25.25 0 0 1-.48 0L9.24 2.18a.25.25 0 0 0-.48 0l-2.35 8.36A2 2 0 0 1 4.49 12H2" /> </svg><b>Грызуны</b> — ежемесячная оценка</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-clipboard-check" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <rect width="8" height="4" x="8" y="2" rx="1" ry="1" /> <path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2" /> <path d="m9 14 2 2 4-4" /> </svg><b>С 1 сентября 2026</b> — новые санитарные правила</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-notebook-pen" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M13.4 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-7.4" /> <path d="M2 6h4" /> <path d="M2 10h4" /> <path d="M2 14h4" /> <path d="M2 18h4" /> <path d="M21.378 5.626a1 1 0 1 0-3.004-3.004l-5.01 5.012a2 2 0 0 0-.506.854l-.837 2.87a.5.5 0 0 0 .62.62l2.87-.837a2 2 0 0 0 .854-.506z" /> </svg><b>Образец раздела</b> для ППК</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-list-checks" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M13 5h8" /> <path d="M13 12h8" /> <path d="M13 19h8" /> <path d="m3 17 2 2 4-4" /> <path d="m3 7 2 2 4-4" /> </svg><b>Подтверждение</b> — договор и акты</div>
    </div>
  </div>
</div>

<section class="s" id="korotko">
  <div class="wrap">
    <div class="head">
      <div class="eyebrow" data-eyebrow>Коротко</div>
      <h2 data-split>ППК и <span class="nw">пест-контроль</span>: <em>5 фактов</em></h2>
      <p class="sub" data-fade>Короткие ответы на главные вопросы — с номерами пунктов, чтобы их можно было проверить в тексте документов.</p>
    </div>
    <ol class="k-facts" data-group="cards">
      <li><span class="k-n">01</span><div><h3>ППК обязательна каждому юрлицу и ИП</h3><p>Её составляют до начала деятельности, в произвольной форме и без ограничения срока действия. Утверждает руководитель или уполномоченное лицо.</p></div><span class="k-ref"><span class="nw">СП 1.1.1058-01</span>, п. 2.6 и раздел 3</span></li>
      <li><span class="k-n">02</span><div><h3>На пищевых объектах — на принципах ХАССП</h3><p>Изготовитель пищевой продукции обязан разработать, внедрить и поддерживать процедуры ХАССП. Общепит ведёт производственный контроль на их основе.</p></div><span class="k-ref"><span class="nw">ТР ТС 021/2011</span>, ст. 10; <span class="nw">СанПиН 2.3/2.4.4282-26</span>, п. 4</span></li>
      <li><span class="k-n">03</span><div><h3>Дезинсекция и дератизация — отдельная процедура</h3><p>Нужно выбрать способы, установить периодичность и проводить обработки, а также определить меры против проникновения грызунов, насекомых и синантропных птиц.</p></div><span class="k-ref"><span class="nw">ТР ТС 021/2011</span>, ст. 10 ч. 3 п. 10; ст. 11 ч. 3 пп. 7–8</span></li>
      <li><span class="k-n">04</span><div><h3>Периодичность задают санитарные правила</h3><p>На объектах особого эпидемиологического значения — в пищевой промышленности, общепите, при хранении и продаже пищевой продукции, в гостиницах и медицинских организациях — обследования на насекомых не реже 2 раз в месяц, дератизация — по результатам ежемесячной оценки.</p></div><span class="k-ref"><span class="nw">СанПиН 3.3686-21</span>, пп. 98, 101, 110</span></li>
      <li><span class="k-n">05</span><div><h3>Выполнение подтверждают документы</h3><p>В проверочном листе Роспотребнадзора для общепита это договоры на проведение работ и акты выполненных работ. Для аудита ХАССП к ним добавляются схема точек, журнал и анализ результатов.</p></div><span class="k-ref">Проверочный лист Роспотребнадзора; <span class="nw">ГОСТ Р 54762-2011</span>, п. 12.5</span></li>
    </ol>
  </div>
</section>

<section class="s" id="obrazets-ppk">
  <div class="wrap">
    <div class="head">
      <div class="eyebrow" data-eyebrow>Образец документа · PDF, 27 страниц</div>
      <h2 data-split>Образец программы производственного контроля <em>для пищевого производства</em></h2>
      <p class="sub" data-fade>Полная программа для хлебопекарного и кондитерского производства с кремовым цехом: все пункты раздела 3 <span class="nw">СП 1.1.1058-01</span>, процедуры ХАССП с критическими контрольными точками и раздел о дезинсекции и дератизации. Реквизиты условные — подставьте данные своего объекта.</p>
    </div>
    <div class="p-obr k-obr" data-fade>
      <div class="p-obr-pages">
        <a class="p-obr-page" href="obrazets-programmy-proizvodstvennogo-kontrolya.pdf" target="_blank" rel="noopener" data-dl="obrazets"><span><img src="../../img/ppk-sample-p1-360.webp" srcset="../../img/ppk-sample-p1-240.webp 240w, ../../img/ppk-sample-p1-360.webp 360w, ../../img/ppk-sample-p1-720.webp 720w" sizes="(max-width:600px) 28vw, 200px" width="360" height="509" loading="lazy" decoding="async" alt="Образец программы производственного контроля, страница 1: титульный лист с грифами «Согласовано» и «Утверждаю» и сведения об объекте"></span><b>Стр. 1</b><small>Титул и сведения об объекте</small></a>
        <a class="p-obr-page" href="obrazets-programmy-proizvodstvennogo-kontrolya.pdf#page=11" target="_blank" rel="noopener" data-dl="obrazets"><span><img src="../../img/ppk-sample-p11-360.webp" srcset="../../img/ppk-sample-p11-240.webp 240w, ../../img/ppk-sample-p11-360.webp 360w, ../../img/ppk-sample-p11-720.webp 720w" sizes="(max-width:600px) 28vw, 200px" width="360" height="509" loading="lazy" decoding="async" alt="Образец программы производственного контроля, страница 11: критические контрольные точки ХАССП с пределами, мониторингом и корректирующими действиями"></span><b>Стр. 11</b><small>4 ККТ плана ХАССП</small></a>
        <a class="p-obr-page" href="obrazets-programmy-proizvodstvennogo-kontrolya.pdf#page=20" target="_blank" rel="noopener" data-dl="obrazets"><span><img src="../../img/ppk-sample-p20-360.webp" srcset="../../img/ppk-sample-p20-240.webp 240w, ../../img/ppk-sample-p20-360.webp 360w, ../../img/ppk-sample-p20-720.webp 720w" sizes="(max-width:600px) 28vw, 200px" width="360" height="509" loading="lazy" decoding="async" alt="Образец программы производственного контроля, страница 20: план-схема производства с точками отбора проб и точками пест-контроля"></span><b>Стр. 20</b><small>План-схема точек</small></a>
      </div>
      <div class="p-obr-info">
        <h3>Что внутри образца ППК</h3>
        <ol class="p-obr-list">
          <li><b>Стр. 1–2</b><span>Титул с грифами «Согласовано» и «Утверждаю», содержание, подсказки по заполнению</span></li>
          <li><b>Стр. 3–6</b><span>Общие положения, сведения об объекте, 28 нормативных документов и методов с правилами 2026 года, ответственные лица</span></li>
          <li><b>Стр. 7–9</b><span>Лабораторный контроль: сырьё, продукция, смывы, воздух, вода, рабочие места — точки, показатели, периодичность</span></li>
          <li><b>Стр. 10–11</b><span>ХАССП: опасные факторы, 4 ККТ с критическими пределами и корректирующими действиями, 12 программ предварительных мероприятий</span></li>
          <li><b>Стр. 12–14</b><span>Визуальный контроль, медосмотры, гигиеническая подготовка и прививки по должностям, оценка соответствия продукции</span></li>
          <li><b>Стр. 15–16</b><span>Уборка и дезинфекция, личная гигиена, раздел «Дезинсекция и дератизация», отходы, прослеживаемость</span></li>
          <li><b>Стр. 17–19</b><span>8 аварийных ситуаций с порядком информирования, 19 форм учёта, план-график на год</span></li>
          <li><b>Стр. 20–27</b><span>Приложения: план-схема точек, блок-схема с ККТ, формы журналов, лист ознакомления и ссылки на тексты документов</span></li>
        </ol>
        <div class="p-obr-btns">
          <a href="obrazets-programmy-proizvodstvennogo-kontrolya.pdf" class="btn btn-w btn-lg" target="_blank" rel="noopener" data-dl="obrazets"><span class="btn-t">Скачать образец, PDF</span></a>
        </div>
        <p class="p-obr-meta">PDF — 27 страниц, 0,7 МБ; значения для замены выделены синим. Для кафе, столовой или магазина замените разделы 2, 5, 6 и ссылки на <span class="nw">СанПиН 2.3/2.4.4282-26</span> или <span class="nw">СП 2.3.6.4281-26</span>. Раздел о дезинсекции и дератизации и схему точек заполним после бесплатного обследования.</p>
        <p class="p-obr-meta">Нужна программа под ваш объект целиком? <a href="../../razrabotka-ppk/">Разработаем ППК по ХАССП</a> — от 19&nbsp;900&nbsp;₽ за 3 рабочих дня; ППК для объекта без производства — от 5&nbsp;900&nbsp;₽ за 1 рабочий день.</p>
      </div>
    </div>
  </div>
</section>

<section class="s" id="normy-2026">
  <div class="wrap">
    <div class="head">
      <div class="eyebrow" data-eyebrow>С 1 сентября 2026 года</div>
      <h2 data-split>Новые санитарные правила: <em>какие ссылки обновить в ППК</em></h2>
      <p class="sub" data-fade>1 сентября 2026 года вступили в силу новые правила для общепита, торговли пищевой продукцией и объектов, где оказывают услуги. Они действуют до 1 сентября 2032 года. Если в программе остались ссылки на документы 2020 года, раздел о <span class="nw">пест-контроле</span> нужно актуализировать.</p>
    </div>
    <div class="d-table k-norms" data-fade>
      <table>
        <thead><tr><th scope="col">Сфера</th><th scope="col">Было</th><th scope="col">Действует с 01.09.2026</th><th scope="col">Что важно для раздела о дезинсекции и дератизации</th></tr></thead>
        <tbody>
          <tr><td data-l="Сфера">Общественное питание</td><td data-l="Было"><s><span class="nw">СанПиН 2.3/2.4.3590-20</span></s></td><td data-l="Действует"><span class="nw">СанПиН 2.3/2.4.4282-26</span></td><td data-l="Важно">п. 4 — производственный контроль на принципах ХАССП; п. 26 — в помещениях не должно быть насекомых и грызунов; п. 45 — во время обработок продукцию не хранят и не готовят, распыляемые и рассыпаемые средства не применяют при посетителях и персонале</td></tr>
          <tr><td data-l="Сфера">Торговля пищевой продукцией и рынки</td><td data-l="Было"><s><span class="nw">СП 2.3.6.3668-20</span></s></td><td data-l="Действует"><span class="nw">СП 2.3.6.4281-26</span></td><td data-l="Важно">п. 3 — производственный контроль; п. 78 — дезинсекция и дератизация вместе с инженерной защитой зданий, порядок и периодичность определяет организация с учётом <span class="nw">СанПиН 3.3686-21</span>; п. 72 — обработки площадки накопления ТКО</td></tr>
          <tr><td data-l="Сфера">Услуги, работы, продажа непищевых товаров</td><td data-l="Было"><s><span class="nw">СП 2.1.3678-20</span></s></td><td data-l="Действует"><span class="nw">СП 2.1.4284-26</span></td><td data-l="Важно">п. 3 — производственный контроль; п. 14 — в помещениях не должно быть насекомых и грызунов, обработки проводят в отсутствие работников и потребителей</td></tr>
          <tr><td data-l="Сфера">Общие требования</td><td data-l="Было">—</td><td data-l="Действует"><span class="nw">СанПиН 3.3686-21</span> · <span class="nw">ТР ТС 021/2011</span> · <span class="nw">СП 1.1.1058-01</span></td><td data-l="Важно">Не изменились: периодичность обследований и дератизации, процедуры ХАССП, структура программы. <span class="nw">СанПиН 3.3686-21</span> действует до 1 сентября 2027 года</td></tr>
        </tbody>
      </table>
    </div>
    <p class="k-callout" data-fade><b>Для торговых объектов Роспотребнадзор прямо указывает:</b> с вступлением в силу <span class="nw">СП 2.3.6.4281-26</span> в программу производственного контроля нужно внести изменения. Для общепита и услуг логика та же — программа должна ссылаться на действующие правила, иначе раздел о <span class="nw">пест-контроле</span> формально опирается на отменённый документ.</p>
    <p class="k-src" data-fade>Официальные тексты: <a href="http://publication.pravo.gov.ru/document/0001202606020084" target="_blank" rel="noopener"><span class="nw">СанПиН 2.3/2.4.4282-26</span></a> · <a href="http://publication.pravo.gov.ru/document/0001202606020079" target="_blank" rel="noopener"><span class="nw">СП 2.3.6.4281-26</span></a> · <a href="http://publication.pravo.gov.ru/document/0001202606020088" target="_blank" rel="noopener"><span class="nw">СП 2.1.4284-26</span></a> · <a href="http://pravo.gov.ru/proxy/ips/?docbody=&amp;nd=602107773" target="_blank" rel="noopener"><span class="nw">СанПиН 3.3686-21</span></a> · <a href="https://cgon.rospotrebnadzor.ru/biznesu/articles/novye-sanitarnye-pravila-dlya-torgovykh-obektov-i-rynkov-realizuyushchikh-pishchevuyu-produktsiyu/" target="_blank" rel="noopener">разъяснение Роспотребнадзора для торговли</a></p>
  </div>
</section>

<section class="s" id="mesto-v-ppk">
  <div class="wrap">
    <div class="head">
      <div class="eyebrow" data-eyebrow>Структура документов</div>
      <h2 data-split>Где <span class="nw">пест-контроль</span> в ППК <em>и плане ХАССП</em></h2>
      <p class="sub" data-fade>ППК — общий документ предприятия: нормы, ответственные, лабораторный контроль, медосмотры, формы учёта. <span class="nw">Пест-контролю</span> в ней отводится отдельный раздел, а подробности выносятся в программу <span class="nw">пест-контроля</span>, на которую раздел ссылается.</p>
    </div>
    <div class="k-map">
      <ol class="k-stack" data-group="cards" aria-label="Уровни документов от ППК до журнала">
        <li><span class="k-lvl">Уровень 1</span><div><b>Программа производственного контроля</b><span class="k-d">Нормы, ответственные, объекты контроля, формы учёта. Утверждает руководитель.</span><span class="k-ref"><span class="nw">СП 1.1.1058-01</span>, раздел 3</span></div></li>
        <li><span class="k-lvl">Уровень 2</span><div><b>Процедуры на принципах ХАССП</b><span class="k-d">Анализ опасностей, критические контрольные точки, программы предварительных мероприятий.</span><span class="k-ref"><span class="nw">ТР ТС 021/2011</span>, ст. 10</span></div></li>
        <li class="on"><span class="k-lvl">Уровень 3</span><div><b>Раздел «Дезинсекция и дератизация»</b><span class="k-d">Способы, периодичность, ответственные, меры против проникновения, документы.</span><span class="k-ref">ст. 10 ч. 3 п. 10; ст. 11 ч. 3 пп. 7–8</span></div></li>
        <li><span class="k-lvl">Уровень 4</span><div><b>Программа <span class="nw">пест-контроля</span></b><span class="k-d">Зоны риска, схема точек, пороги численности, средства, график визитов.</span><span class="k-ref"><span class="nw">ГОСТ Р 54762-2011</span>, раздел 12</span></div></li>
        <li><span class="k-lvl">Уровень 5</span><div><b>Журнал, акты, отчёты</b><span class="k-d">Подтверждение того, что раздел выполняется на объекте.</span><span class="k-ref"><span class="nw">ТР ТС 021/2011</span>, ст. 10 ч. 3 п. 11</span></div></li>
      </ol>
      <div class="k-side" data-group="cards">
        <article class="d-card">
          <h3>ПОПМ, а не ККТ</h3>
          <p>В плане ХАССП борьба с вредителями — программа обязательных предварительных мероприятий: <span class="nw">ГОСТ Р ИСО 22000-2019</span> называет её среди них в п. 8.2.4. ККТ задают для параметров процесса, например температуры термообработки. Вредители — источник биологических и физических опасностей, которые ПОПМ не пускает в цех.</p>
        </article>
        <article class="d-card">
          <h3>Короткий раздел, подробная программа</h3>
          <p>В ППК достаточно 1–2 страниц: обязательства, периодичность, ответственные и ссылки на приложения. Схема точек, пороги и реестр средств живут в программе <span class="nw">пест-контроля</span> — перестановка ловушки не требует переутверждать всю ППК.</p>
          <p class="k-more"><a class="link-arrow" href="../programma-pest-kontrolya/"><span>Образец программы <span class="nw">пест-контроля</span></span> →</a></p>
        </article>
      </div>
    </div>
  </div>
</section>

<section class="s" id="chto-vpisat">
  <div class="wrap">
    <div class="head">
      <div class="eyebrow" data-eyebrow>Содержание раздела</div>
      <h2 data-split>Что вписать в раздел о дезинсекции и дератизации: <em>8 пунктов</em></h2>
      <p class="sub" data-fade>Пункты повторяют требования к программе из раздела 3 <span class="nw">СП 1.1.1058-01</span> и требования ХАССП к борьбе с вредителями. Для каждого указано основание — на него удобно сослаться в тексте ППК.</p>
    </div>
    <div class="p-secs" data-group="cards">
      <article class="p-sec"><div><div class="p-sec-top"><span class="p-sec-num">Пункт 01</span><span class="p-sec-who"><span class="nw">СП 1.1.1058-01</span>, п. 3.1</span></div><h3>Нормативная база</h3><p>Перечень действующих документов: <span class="nw">ТР ТС 021/2011</span>, <span class="nw">СанПиН 3.3686-21</span> и правила для вашего вида деятельности — <span class="nw">СанПиН 2.3/2.4.4282-26</span>, <span class="nw">СП 2.3.6.4281-26</span> или <span class="nw">СП 2.1.4284-26</span>.</p></div></article>
      <article class="p-sec"><div><div class="p-sec-top"><span class="p-sec-num">Пункт 02</span><span class="p-sec-who"><span class="nw">СП 1.1.1058-01</span>, п. 3.2 · <span class="nw">ГОСТ Р 54762-2011</span>, п. 12.2</span></div><h3>Ответственные и исполнитель</h3><p>Ответственный от предприятия назначается приказом. Исполнитель — организация с лицензией Роспотребнадзора, она обязательна с 1 марта 2025 года. В разделе указывают номер договора и лицензии.</p></div></article>
      <article class="p-sec"><div><div class="p-sec-top"><span class="p-sec-num">Пункт 03</span><span class="p-sec-who"><span class="nw">ТР ТС 021/2011</span>, ст. 10 ч. 3 п. 10</span></div><h3>Объекты и зоны контроля</h3><p>Цеха, склады, зона приёмки, бытовые помещения, наружный периметр и площадка ТКО — с делением на зоны риска и ссылкой на схему точек контроля.</p></div></article>
      <article class="p-sec"><div><div class="p-sec-top"><span class="p-sec-num">Пункт 04</span><span class="p-sec-who"><span class="nw">ГОСТ Р 54762-2011</span>, п. 12.2</span></div><h3>Целевые вредители</h3><p>Грызуны, тараканы, мухи, муравьи, вредители запасов, синантропные птицы — только те, что по результатам обследования угрожают продукции на вашем объекте.</p></div></article>
      <article class="p-sec"><div><div class="p-sec-top"><span class="p-sec-num">Пункт 05</span><span class="p-sec-who"><span class="nw">СанПиН 3.3686-21</span>, пп. 101, 110 · <span class="nw">ТР ТС 021/2011</span>, ст. 11 ч. 3 п. 7</span></div><h3>Периодичность</h3><p>Обследования на насекомых — не реже 2 раз в месяц, оценка по грызунам — ежемесячно, внеплановый выезд — при обнаружении вредителей, с конкретным сроком реакции.</p></div></article>
      <article class="p-sec"><div><div class="p-sec-top"><span class="p-sec-num">Пункт 06</span><span class="p-sec-who"><span class="nw">ТР ТС 021/2011</span>, ст. 11 ч. 3 п. 8 · <span class="nw">ГОСТ Р 54762-2011</span>, пп. 12.2–12.3</span></div><h3>Методы и средства</h3><p>Сначала профилактика и инженерная защита — сетки, уплотнители, герметизация вводов, затем мониторинг. Истребительные меры — по превышению порога, средствами с государственной регистрацией, разрешёнными для конкретной зоны.</p></div></article>
      <article class="p-sec"><div><div class="p-sec-top"><span class="p-sec-num">Пункт 07</span><span class="p-sec-who"><span class="nw">СанПиН 2.3/2.4.4282-26</span>, п. 45 · <span class="nw">СП 2.1.4284-26</span>, п. 14</span></div><h3>Безопасность и пороги</h3><p>Обработки распыляемыми и рассыпаемыми средствами — без продукции, посетителей и персонала. Пороговая численность по зонам и действия при превышении: внеплановое обследование, усиление мониторинга, обработка.</p></div></article>
      <article class="p-sec"><div><div class="p-sec-top"><span class="p-sec-num">Пункт 08</span><span class="p-sec-who"><span class="nw">СП 1.1.1058-01</span>, п. 3.7 · <span class="nw">ТР ТС 021/2011</span>, ст. 10 ч. 3 п. 11</span></div><h3>Учёт и документы</h3><p>Договор, акты выполненных работ, журнал учёта, схема точек, перечень средств, ежемесячный отчёт — где хранятся и кто отвечает. Вести их можно на бумаге или в электронном виде.</p></div></article>
    </div>
  </div>
</section>

<section class="s" id="obrazets">
  <div class="wrap">
    <div class="head">
      <div class="eyebrow" data-eyebrow>Образец текста</div>
      <h2 data-split>Образец раздела ППК <em>«Дезинсекция и дератизация»</em></h2>
      <p class="sub" data-fade>Пример формулировок для пищевого производства, кафе или магазина. Поля, выделенные жёлтым, заполняются после обследования: зоны, периодичность и пороги зависят от объекта. Текст можно скопировать в свою программу.</p>
    </div>
    <div class="k-sample">
      <article class="k-doc" id="k-doc" aria-label="Образец раздела программы производственного контроля" data-fade>
        <div class="k-doc-top"><span>Программа производственного контроля</span><span>Образец · раздел 7</span></div>
        <div id="k-doc-text">
          <h3>7. Дезинсекция и дератизация</h3>
          <ol>
            <li><b>7.1.</b><span>Цель — не допустить присутствия грызунов, насекомых и синантропных птиц в производственных, складских и бытовых помещениях и на территории предприятия и исключить загрязнение пищевой продукции средствами дезинсекции и дератизации.</span></li>
            <li><b>7.2.</b><span>Нормативная база: <span class="nw">ТР ТС 021/2011</span> (ст. 10 ч. 3 п. 10; ст. 11 ч. 3 пп. 7–8), <span class="nw">СанПиН 3.3686-21</span>, <mark><span class="nw">СанПиН 2.3/2.4.4282-26</span>, <span class="nw">СП 2.3.6.4281-26</span> или <span class="nw">СП 2.1.4284-26</span> — по виду деятельности</mark>, <span class="nw">ГОСТ Р 54762-2011</span> (раздел 12).</span></li>
            <li><b>7.3.</b><span>Ответственный за организацию работ — <mark>должность, <span class="nw">Ф. И. О.</span></mark>, назначен приказом от <mark>дата</mark> № <mark>номер</mark>. Исполнитель — <mark>наименование организации</mark>, лицензия Роспотребнадзора № <mark>номер</mark>, договор от <mark>дата</mark> № <mark>номер</mark>.</span></li>
            <li><b>7.4.</b><span>Объекты контроля — помещения и территория по схеме точек контроля (приложение <mark>№</mark>): зона приёмки, склады сырья и готовой продукции, производственные и бытовые помещения, наружный периметр здания, площадка накопления ТКО.</span></li>
            <li><b>7.5.</b><span>Целевые вредители: <mark>серая крыса, домовая мышь, рыжий таракан, мухи, вредители запасов, синантропные птицы</mark> — по результатам обследования.</span></li>
            <li><b>7.6.</b><span>Периодичность: обследование на заселённость членистоногими — не реже 2 раз в месяц; оценка численности грызунов и проверка точек контроля — ежемесячно, график визитов — <mark>по договору</mark>; внеплановое обследование — при обнаружении вредителей или следов их жизнедеятельности, не позднее <mark>__ часов</mark> после заявки.</span></li>
            <li><b>7.7.</b><span>Методы: профилактические и инженерно-технические меры (сетки на проёмах, уплотнители дверей, герметизация вводов коммуникаций); мониторинг по пронумерованным точкам контроля; истребительные мероприятия — при превышении пороговой численности (пороги по зонам — приложение <mark>№</mark>) средствами, имеющими государственную регистрацию и разрешёнными для соответствующей зоны (перечень — приложение <mark>№</mark>). В производственных помещениях применяются ловушки без родентицидов.</span></li>
            <li><b>7.8.</b><span>Меры безопасности: обработки распыляемыми и рассыпаемыми средствами проводятся в отсутствие посетителей и персонала; хранение и изготовление продукции в обрабатываемых помещениях на время обработки не допускается.</span></li>
            <li><b>7.9.</b><span>Корректирующие действия: при обнаружении вредителей ответственный уведомляет исполнителя; устанавливаются причина (пути проникновения, санитарное состояние), меры и сроки, их результативность проверяется при следующем обследовании.</span></li>
            <li><b>7.10.</b><span>Учёт и отчётность: результаты осмотров вносятся в журнал учёта (форма — приложение <mark>№</mark>), выполненные работы подтверждаются актами, ежемесячно исполнитель представляет отчёт с динамикой численности и рекомендациями. Документы хранятся у ответственного <mark>срок хранения</mark>.</span></li>
          </ol>
        </div>
        <p class="k-doc-foot">Образец ПЕСТКОНТРОЛЬ Центра · утверждается руководителем в составе программы производственного контроля</p>
      </article>
      <aside class="k-aside" data-fade>
        <div class="d-card">
          <h3>Что подставить после обследования</h3>
          <ul class="k-list">
            <li>Ответственного и реквизиты приказа</li>
            <li>Исполнителя, номер лицензии и договора</li>
            <li>Схему точек и номера приложений</li>
            <li>Целевых вредителей по факту осмотра</li>
            <li>График визитов и срок внепланового выезда</li>
            <li>Пороги численности по зонам</li>
          </ul>
          <div class="k-aside-btns">
            <button type="button" class="btn btn-w btn-lg" data-copy="#k-doc-text"><span class="btn-t">Скопировать текст</span></button>
            <a href="#zayavka" class="btn btn-o btn-lg"><span class="btn-t">Заполнить со специалистом</span></a>
          </div>
          <p class="k-aside-note">Заполненный пример этого раздела для хлебопекарного производства — в <a href="#obrazets-ppk">полном образце ППК</a> (раздел 11.3). Приложения — схема точек, пороги и реестр средств — входят в программу <span class="nw">пест-контроля</span>: <a href="../programma-pest-kontrolya/">образец и шаблон в PDF</a>.</p>
        </div>
      </aside>
    </div>
  </div>
</section>

<section class="s" id="dokumenty">
  <div class="wrap">
    <div class="head">
      <div class="eyebrow" data-eyebrow>Проверка и аудит</div>
      <h2 data-split>Чем подтверждается раздел <em>на проверке и аудите</em></h2>
      <p class="sub" data-fade>Проверяющий смотрит не только текст программы, но и её выполнение. В проверочном листе Роспотребнадзора для общепита подтверждением пункта о дезинсекции и дератизации названы договоры на проведение работ и акты выполненных работ.</p>
    </div>
    <div class="d-table k-docs" data-fade>
      <table>
        <thead><tr><th scope="col">Документ</th><th scope="col">Что подтверждает</th><th scope="col">Кто готовит</th></tr></thead>
        <tbody>
          <tr><td data-l="Документ">ППК с разделом «Дезинсекция и дератизация»</td><td data-l="Подтверждает">Производственный контроль организован, порядок обработок установлен</td><td data-l="Кто готовит">Утверждает предприятие, текст раздела готовим мы</td></tr>
          <tr><td data-l="Документ">Договор на дезинсекцию и дератизацию</td><td data-l="Подтверждает">Работы проводятся регулярно и профессиональным исполнителем</td><td data-l="Кто готовит">ПЕСТКОНТРОЛЬ Центр</td></tr>
          <tr><td data-l="Документ">Лицензия Роспотребнадзора исполнителя</td><td data-l="Подтверждает">Право оказывать услуги — обязательна с 1 марта 2025 года</td><td data-l="Кто готовит">Проверяется в открытом реестре</td></tr>
          <tr><td data-l="Документ">Акты выполненных работ</td><td data-l="Подтверждает">Работы выполняются по графику</td><td data-l="Кто готовит"><span class="nw">Пест-менеджер</span> после каждого визита</td></tr>
          <tr><td data-l="Документ">Журнал учёта и схема точек контроля</td><td data-l="Подтверждает">Мониторинг ведётся, номера ловушек совпадают с планом объекта</td><td data-l="Кто готовит"><span class="nw">Пест-менеджер</span> и ответственный предприятия</td></tr>
          <tr><td data-l="Документ">Перечень средств с документами о регистрации</td><td data-l="Подтверждает">Применяются разрешённые средства в своих зонах</td><td data-l="Кто готовит">ПЕСТКОНТРОЛЬ Центр</td></tr>
          <tr><td data-l="Документ">Ежемесячный отчёт и корректирующие действия</td><td data-l="Подтверждает">Результаты анализируются, на отклонения есть реакция</td><td data-l="Кто готовит">ПЕСТКОНТРОЛЬ Центр</td></tr>
        </tbody>
      </table>
    </div>
    <ul class="d-chips" data-group="ctalist">
      <li><a href="../zhurnal-pest-kontrolya/"><span>Журнал <span class="nw">пест-контроля</span>: образец →</span></a></li>
      <li><a href="../programma-pest-kontrolya/"><span>Программа <span class="nw">пест-контроля</span>: образец →</span></a></li>
      <li><a href="../../dogovor-deratizatsiya-dezinsektsiya/"><span>Условия и образец договора →</span></a></li>
      <li><a href="https://fp.rospotrebnadzor.ru/licen/?oper=search&amp;numb_history=&amp;numb=&amp;firmget_name=&amp;ogrn_inn_nza=7714462211" target="_blank" rel="noopener"><span>Наша лицензия в реестре Роспотребнадзора →</span></a></li>
    </ul>
  </div>
</section>

<section class="s" id="oshibki">
  <div class="wrap">
    <div class="head">
      <div class="eyebrow" data-eyebrow>Типичные ошибки</div>
      <h2 data-split>6 ошибок в разделе <span class="nw">пест-контроля</span> <em>и как их исправить</em></h2>
    </div>
    <div class="k-errs" data-group="cards">
      <article class="k-err"><span class="k-err-tag">Ошибка 01</span><h3>Ссылки на отменённые правила</h3><p>После 1 сентября 2026 года <span class="nw">СанПиН 2.3/2.4.3590-20</span>, <span class="nw">СП 2.3.6.3668-20</span> и <span class="nw">СП 2.1.3678-20</span> не действуют.</p><p class="k-fix">заменить на документы 2026 года — пункт 7.2 образца.</p></article>
      <article class="k-err"><span class="k-err-tag">Ошибка 02</span><h3>«Дератизация раз в квартал»</h3><p>На пищевом объекте это расходится с ежемесячной оценкой по грызунам и обследованиями на насекомых не реже 2 раз в месяц.</p><p class="k-fix">указать периодичность по пп. 101 и 110 <span class="nw">СанПиН 3.3686-21</span>.</p></article>
      <article class="k-err"><span class="k-err-tag">Ошибка 03</span><h3>«По мере необходимости»</h3><p>Нет порогов численности и срока реакции — нельзя показать, когда и почему проводилась обработка.</p><p class="k-fix">прописать пороги по зонам и срок внепланового выезда.</p></article>
      <article class="k-err"><span class="k-err-tag">Ошибка 04</span><h3>Нет ответственного и исполнителя</h3><p>В разделе не указаны приказ, договор и номер лицензии — он не связан с реальными документами предприятия.</p><p class="k-fix">внести реквизиты — пункт 7.3 образца.</p></article>
      <article class="k-err"><span class="k-err-tag">Ошибка 05</span><h3>Журнал без схемы точек</h3><p>Журнал ссылается на номера ловушек, которых нет на плане, — аудитор не может сверить мониторинг с объектом.</p><p class="k-fix">приложить схему точек и сверять её с журналом при каждом визите.</p></article>
      <article class="k-err"><span class="k-err-tag">Ошибка 06</span><h3>Обработка при людях и продукции</h3><p>Распыление при персонале или открытой продукции нарушает п. 45 <span class="nw">СанПиН 2.3/2.4.4282-26</span> и п. 14 <span class="nw">СП 2.1.4284-26</span>.</p><p class="k-fix">закрепить в разделе время обработок и порядок подготовки помещений.</p></article>
    </div>
  </div>
</section>

<section class="s" id="kak-gotovim">
  <div class="wrap">
    <div class="head">
      <div class="eyebrow" data-eyebrow>Порядок работы и стоимость</div>
      <h2 data-split>Как мы готовим раздел <em>для вашей ППК</em></h2>
      <p class="sub" data-fade>Раздел пишем после осмотра объекта — тогда зоны, периодичность и пороги совпадают с тем, что увидит проверяющий.</p>
    </div>
    <ol class="d-steps k-steps" data-group="cards">
      <li><b>Бесплатный выезд</b><span><span class="nw">Пест-менеджер</span> осматривает объект, действующую ППК и папку документов, опрашивает персонал.</span></li>
      <li><b>Оценка <span class="nw">пест-риска</span></b><span>Делим объект на зоны, определяем целевых вредителей и пути их проникновения.</span></li>
      <li><b>Раздел и программа</b><span>Готовим текст раздела для ППК в Word, программу <span class="nw">пест-контроля</span> и схему точек.</span></li>
      <li><b>Договор и запуск</b><span>Проект договора — в течение 1 часа после осмотра, старт работ — от 3 часов.</span></li>
      <li><b>Ведение</b><span>Визиты по графику, журнал и акты после каждого визита, ежемесячный отчёт с динамикой.</span></li>
    </ol>
    <div class="d-table k-price" data-fade>
      <table>
        <thead><tr><th scope="col">Тип объекта</th><th scope="col">Что входит</th><th scope="col">Ориентир стоимости</th></tr></thead>
        <tbody>
          <tr><td data-l="Объект">Кафе, ресторан, пищеблок</td><td data-l="Входит">Раздел для ППК, программа <span class="nw">пест-контроля</span> и схема точек, 1–2 визита в месяц, журнал и акты</td><td data-l="Стоимость">от 3 500 ₽/мес</td></tr>
          <tr><td data-l="Объект">Магазин, супермаркет</td><td data-l="Входит">Раздел для ППК, схема точек по залу, складу и зоне приёмки, 1–2 визита в месяц, полный комплект документов</td><td data-l="Стоимость">от 3 500 ₽/мес</td></tr>
          <tr><td data-l="Объект">Склад до 1 000 м²</td><td data-l="Входит">Раздел для ППК, оценка <span class="nw">пест-риска</span>, схема контуров защиты, плановый мониторинг и отчёты</td><td data-l="Стоимость">от 4 500 ₽/мес</td></tr>
          <tr><td data-l="Объект">Пищевое производство, РЦ, завод</td><td data-l="Входит">Раздел для ППК и плана ХАССП, программа ПОПМ, многоконтурная схема точек, анализ трендов</td><td data-l="Стоимость">после бесплатного выезда</td></tr>
        </tbody>
      </table>
    </div>
    <div class="d-cols2" data-group="cards">
      <article class="d-card"><h3>Сроки</h3><p>Выезд <span class="nw">пест-менеджера</span> и обследование — бесплатно. Проект договора с программой направляем в течение 1 часа после осмотра. Старт работ на объекте — от 3 часов, внеплановый выезд по сигналу — в течение 3 часов.</p></article>
      <article class="d-card"><h3>Если ППК уже есть</h3><p>Проверим действующий раздел и документы прежнего подрядчика, заменим ссылки на правила 2026 года и запустим обслуживание без разрыва. Работаем с НДС и без НДС, по ЭДО и на бумаге.</p></article>
    </div>
  </div>
</section>


<!-- ============ СМОТРИТЕ ТАКЖЕ (перелинковка) ============ -->
<section class="s s-rel" id="smotrite-takzhe">
  <div class="wrap">
    <div class="head">
      <div class="eyebrow" data-eyebrow>Смотрите также</div>
      <h2 data-split>Связанные услуги <em>и материалы</em></h2>
    </div>
    <div class="rel-grid" data-group="cards">
      <a class="card rel-card" href="../../razrabotka-ppk/"><span class="rel-k">Услуга</span><span class="rel-t">Разработка ППК</span><span class="rel-d">ППК под ваш объект — от 5 900 ₽ за 1 рабочий день, ППК по ХАССП для общепита и пищевых производств — от 19 900 ₽ за 3 рабочих дня.</span><span class="rel-a" aria-hidden="true"><svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></span></a>
      <a class="card rel-card" href="../../materialy/programma-pest-kontrolya/"><span class="rel-k">Материал</span><span class="rel-t">Программа <span class="nw">пест-контроля</span></span><span class="rel-d">Образец и шаблон в PDF: 7 разделов, оценка <span class="nw">пест-риска</span> по зонам и план мероприятий.</span><span class="rel-a" aria-hidden="true"><svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></span></a>
      <a class="card rel-card" href="../../pishchevoe-proizvodstvo/"><span class="rel-k">Отрасль</span><span class="rel-t"><span class="nw">Пест-контроль</span> на пищевом производстве</span><span class="rel-d">Точки контроля, визиты по графику смен и документы для Роспотребнадзора, аудиторов и торговых сетей.</span><span class="rel-a" aria-hidden="true"><svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></span></a>
      <a class="card rel-card" href="../../dogovor-deratizatsiya-dezinsektsiya/"><span class="rel-k">Обслуживание</span><span class="rel-t">Договор на дератизацию и дезинсекцию</span><span class="rel-d">Одно или оба направления в одном договоре: график визитов, акт после выезда, цена до подписания.</span><span class="rel-a" aria-hidden="true"><svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></span></a>
    </div>
  </div>
</section>

<section class="s" id="voprosy">
  <div class="wrap">
    <div class="head">
      <div class="eyebrow" data-eyebrow>Частые вопросы</div>
      <h2 data-split>Вопросы <em>о программе производственного контроля</em></h2>
    </div>
    <div class="faq"><div class="faq-col" data-group="faq"><div class="card qa"><button aria-expanded="false" aria-controls="a1" id="q1"><span class="qa-q">Нужна ли программа производственного контроля по ХАССП кафе или магазину?</span><span class="pm"></span></button><div class="ans" id="a1" role="region" aria-labelledby="q1"><div><p>Программа производственного контроля нужна любому юрлицу и ИП: её составляют до начала деятельности (<span class="nw">СП 1.1.1058-01</span>, п. 2.6). Общепит ведёт производственный контроль на принципах ХАССП — это п. 4 <span class="nw">СанПиН 2.3/2.4.4282-26</span>. Для магазина производственный контроль обязателен по п. 3 <span class="nw">СП 2.3.6.4281-26</span>, а процедуры ХАССП <span class="nw">ТР ТС 021/2011</span> требует от изготовителей пищевой продукции: если в магазине есть кулинария или пекарня, это уже производство.</p></div></div></div><div class="card qa"><button aria-expanded="false" aria-controls="a2" id="q2"><span class="qa-q">Где взять образец программы производственного контроля для пищевого производства?</span><span class="pm"></span></button><div class="ans" id="a2" role="region" aria-labelledby="q2"><div><p>На этой странице — бесплатный образец ППК на 27 страниц для хлебопекарного и кондитерского производства: в PDF. В нём все пункты раздела 3 <span class="nw">СП 1.1.1058-01</span>, лабораторный контроль сырья, продукции, смывов и воды, 4 критические контрольные точки ХАССП, медосмотры и гигиеническая подготовка по должностям, раздел о дезинсекции и дератизации, аварийные ситуации и 19 форм учёта. Реквизиты в образце условные: программу адаптируют под свой объект, утверждает её руководитель.</p></div></div></div><div class="card qa"><button aria-expanded="false" aria-controls="a3" id="q3"><span class="qa-q">Нужно ли включать дезинсекцию и дератизацию в программу производственного контроля?</span><span class="pm"></span></button><div class="ans" id="a3" role="region" aria-labelledby="q3"><div><p>Да. <span class="nw">ТР ТС 021/2011</span> требует выбрать способы, установить периодичность и проводить дезинсекцию и дератизацию (ст. 10 ч. 3 п. 10), а также определить меры против проникновения грызунов, насекомых и синантропных птиц (ст. 11 ч. 3 пп. 7–8). Для торговли и объектов услуг обязанность проводить дезинсекцию и дератизацию закреплена в п. 78 <span class="nw">СП 2.3.6.4281-26</span> и п. 14 <span class="nw">СП 2.1.4284-26</span>.</p></div></div></div><div class="card qa"><button aria-expanded="false" aria-controls="a4" id="q4"><span class="qa-q">Как часто проводить дезинсекцию и дератизацию по программе производственного контроля?</span><span class="pm"></span></button><div class="ans" id="a4" role="region" aria-labelledby="q4"><div><p>На объектах особого эпидемиологического значения — в пищевой промышленности, общепите, на складах и в магазинах пищевой продукции — обследования на насекомых проводятся не реже 2 раз в месяц, а дератизация — по результатам ежемесячной оценки (<span class="nw">СанПиН 3.3686-21</span>, пп. 98, 101, 110). Конкретный график визитов и срок внепланового выезда закрепляются в договоре и программе <span class="nw">пест-контроля</span>, а в ППК — ссылкой на них.</p></div></div></div><div class="card qa"><button aria-expanded="false" aria-controls="a5" id="q5"><span class="qa-q">Кто составляет и утверждает программу производственного контроля?</span><span class="pm"></span></button><div class="ans" id="a5" role="region" aria-labelledby="q5"><div><p>Программу составляет само предприятие — в произвольной форме и без ограничения срока действия; утверждает её руководитель или уполномоченное лицо (<span class="nw">СП 1.1.1058-01</span>, п. 2.6). Санитарные правила не требуют согласовывать её с Роспотребнадзором. Раздел о дезинсекции и дератизации удобно поручить исполнителю с лицензией: он отвечает за периодичность, средства и документы по обработкам.</p></div></div></div></div><div class="faq-col" data-group="faq"><div class="card qa"><button aria-expanded="false" aria-controls="a6" id="q6"><span class="qa-q">Чем программа производственного контроля отличается от программы <span class="nw">пест-контроля</span>?</span><span class="pm"></span></button><div class="ans" id="a6" role="region" aria-labelledby="q6"><div><p>ППК — общий документ предприятия по всем санитарным требованиям: нормы, ответственные, лабораторный контроль, медосмотры, формы учёта. Программа <span class="nw">пест-контроля</span> — подробный рабочий документ только по вредителям: зоны риска, схема точек, пороги численности, средства и график. В ППК достаточно раздела с обязательствами и ссылкой на программу <span class="nw">пест-контроля</span> как приложение.</p></div></div></div><div class="card qa"><button aria-expanded="false" aria-controls="a7" id="q7"><span class="qa-q"><span class="nw">Пест-контроль</span> — это ККТ в плане ХАССП?</span><span class="pm"></span></button><div class="ans" id="a7" role="region" aria-labelledby="q7"><div><p>Как правило, нет. Борьба с вредителями относится к программам обязательных предварительных мероприятий (ПОПМ) — <span class="nw">ГОСТ Р ИСО 22000-2019</span> называет её среди них в п. 8.2.4. Критические контрольные точки устанавливают для параметров технологического процесса, например температуры. Если анализ опасностей выявил значимую опасность, связанную с вредителями, меры по её управлению оформляют как ППОПМ с измеримыми или наблюдаемыми критериями действия (п. 8.5.4.2).</p></div></div></div><div class="card qa"><button aria-expanded="false" aria-controls="a8" id="q8"><span class="qa-q">Нужно ли менять ППК после 1 сентября 2026 года?</span><span class="pm"></span></button><div class="ans" id="a8" role="region" aria-labelledby="q8"><div><p>Да, если в ней остались ссылки на <span class="nw">СанПиН 2.3/2.4.3590-20</span>, <span class="nw">СП 2.3.6.3668-20</span> или <span class="nw">СП 2.1.3678-20</span>: с 1 сентября 2026 года вместо них действуют <span class="nw">СанПиН 2.3/2.4.4282-26</span>, <span class="nw">СП 2.3.6.4281-26</span> и <span class="nw">СП 2.1.4284-26</span>. Для торговых объектов Роспотребнадзор прямо указывает на необходимость внести изменения в программу производственного контроля. Новую редакцию утверждает руководитель.</p></div></div></div><div class="card qa"><button aria-expanded="false" aria-controls="a9" id="q9"><span class="qa-q">Какие документы по <span class="nw">пест-контролю</span> хранить вместе с ППК?</span><span class="pm"></span></button><div class="ans" id="a9" role="region" aria-labelledby="q9"><div><p>Договор с исполнителем, сведения о его лицензии, акты выполненных работ, журнал учёта, схему точек контроля, перечень применяемых средств с документами о государственной регистрации и ежемесячные отчёты. <span class="nw">ТР ТС 021/2011</span> разрешает вести и хранить документацию на бумажных и (или) электронных носителях (ст. 10 ч. 3 п. 11).</p></div></div></div><div class="card qa"><button aria-expanded="false" aria-controls="a10" id="q10"><span class="qa-q">Сколько стоит подготовка раздела ППК по <span class="nw">пест-контролю</span>?</span><span class="pm"></span></button><div class="ans" id="a10" role="region" aria-labelledby="q10"><div><p>Текст раздела готовим вместе с программой <span class="nw">пест-контроля</span> при запуске обслуживания по договору. Абонентское обслуживание — от 3 500 ₽ в месяц для кафе и магазинов и от 4 500 ₽ для складов до 1 000 м²; для пищевых производств расчёт делаем после бесплатного выезда.</p></div></div></div></div></div>
  </div>
</section>

<section class="cta" id="zayavka"><div class="cta-bg f-lazy" aria-hidden="true" data-parallax-bg></div><div class="cta-orb" id="orb" aria-hidden="true"></div>
  <div class="wrap">
    <div>
      <div class="eyebrow" data-eyebrow>Заявка</div>
      <h2 data-split>Получите раздел для ППК <em>под ваш объект</em></h2>
      <p class="sub" data-fade>Бесплатно приедем на предприятие в Москве или Московской области, проверим действующую ППК и папку документов, оценим <span class="nw">пест-риск</span> и в течение 1 часа после осмотра пришлём проект договора с программой.</p>
      <ul class="cta-list" data-group="ctalist">
        <li><svg aria-hidden="true" focusable="false" class="lucide lucide-circle-check" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <circle cx="12" cy="12" r="10" /> <path d="m16 9-5.5 5.5L8 12" /> </svg>Выезд по Москве и Московской области</li>
        <li><svg aria-hidden="true" focusable="false" class="lucide lucide-circle-check" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <circle cx="12" cy="12" r="10" /> <path d="m16 9-5.5 5.5L8 12" /> </svg>Осмотр объекта и расчёт — бесплатно</li>
        <li><svg aria-hidden="true" focusable="false" class="lucide lucide-circle-check" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <circle cx="12" cy="12" r="10" /> <path d="m16 9-5.5 5.5L8 12" /> </svg>Текст раздела для ППК — в формате Word</li>
      </ul>
      <div class="cta-contacts" data-fade>
        <a class="ph" href="tel:+74951043570">+7 (495) 104-35-70</a>
        <div class="msg">
          <a href="https://max.ru/u/f9LHodD0cOIlIUXFkt4KMFP88lD8n4TArBiTcV7RI1XML5c4o39QfsDBXUc" class="max" aria-label="Написать в Max" target="_blank" rel="noopener noreferrer"><svg viewBox="0 0 24 24" fill="#fff" aria-hidden="true"><path d="M12 3a9 9 0 0 0-7.7 13.7L3 21l4.4-1.2A9 9 0 1 0 12 3zm-3.6 12.3V8.7h1.6l2 2.8 2-2.8h1.6v6.6h-1.7v-3.9L12 14l-1.9-2.6v3.9z"/></svg></a>
          <a href="https://t.me/Centr_Dezinfection?text=%D0%97%D0%B4%D1%80%D0%B0%D0%B2%D1%81%D1%82%D0%B2%D1%83%D0%B9%D1%82%D0%B5!%20%D0%9F%D0%B8%D1%88%D1%83%20%D1%81%20%D1%81%D0%B0%D0%B9%D1%82%D0%B0%20%D0%BF%D0%B5%D1%81%D1%82%D0%BA%D0%BE%D0%BD%D1%82%D1%80%D0%BE%D0%BB%D1%8C-%D1%86%D0%B5%D0%BD%D1%82%D1%80.%D1%80%D1%84" class="tg" aria-label="Написать в Telegram" target="_blank" rel="noopener noreferrer"><svg viewBox="0 0 24 24" fill="#fff" aria-hidden="true"><path d="M21.4 4.3 2.9 11.4c-1.3.5-1.2 1.2-.2 1.5l4.7 1.5 1.8 5.6c.2.6.4.8.9.8.4 0 .6-.2.9-.4l2.3-2.2 4.7 3.5c.9.5 1.5.2 1.7-.8l3.1-14.6c.3-1.3-.5-1.8-1.4-1.5zM9.6 14.1l8.6-5.4c.4-.3.8-.1.5.2l-7.1 6.4-.3 3.3z"/></svg></a>
        </div>
      </div>
    </div>
    <form class="form" id="form" novalidate data-form>
      <div class="fbody">
        <h3>Заявка на раздел для ППК</h3>
        <p class="fs">Заполнение займёт меньше минуты</p>
        <div class="fg">
          <div class="field"><label class="sr-only" for="f-name">Ваше имя</label><input id="f-name" name="name" placeholder="Ваше имя" required autocomplete="name"><small class="ferr">Укажите имя</small></div>
          <div class="field"><label class="sr-only" for="phone">Телефон</label><input name="phone" id="phone" type="tel" inputmode="tel" placeholder="+7 (___) ___-__-__" required autocomplete="tel"><small class="ferr">Укажите телефон полностью</small></div>
          <div class="field full"><label class="sr-only" for="f-type">Тип объекта</label><select id="f-type" name="type" required><option value="" disabled selected>Тип объекта</option><option>Пищевое производство</option><option>Магазин или торговая сеть</option><option>Ресторан или кафе</option><option>Склад, логистика</option><option>Фармацевтическое производство</option><option>Гостиница</option><option>Другое</option></select><small class="ferr">Выберите тип объекта</small></div>
          <div class="field full"><label class="sr-only" for="f-address">Адрес или район объекта</label><input id="f-address" name="address" placeholder="Адрес или район объекта" autocomplete="address-line1" maxlength="200"></div>
          <div class="field full"><label class="sr-only" for="f-service">Что нужно</label><select id="f-service" name="service"><option value="" selected>Какая задача стоит</option><option>Подготовить раздел для ППК и запустить обслуживание</option><option>Обновить ППК под санитарные правила 2026 года</option><option>Подготовиться к проверке или аудиту ХАССП</option><option>Проверить документы прежнего подрядчика</option></select></div>
          <div class="field" hidden><input type="hidden" name="email" value=""></div>
          <input type="hidden" name="msg" value="">
        </div>
        <button type="submit" class="btn btn-w btn-lg" id="submitBtn"><span class="btn-t">Получить раздел для ППК</span><svg class="btn-ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M5 12h14M13 6l6 6-6 6"/></svg><i class="spin" aria-hidden="true"></i></button>
        <p class="legal">Нажимая кнопку, вы даёте <a href="../../soglasie/" target="_blank" rel="noopener">согласие на обработку персональных данных</a> и подтверждаете, что ознакомились с <a href="../../privacy/" target="_blank" rel="noopener">политикой конфиденциальности</a>.</p>
      </div>
      <div class="ok" role="status" aria-live="polite">
        <svg class="ok-ic" viewBox="0 0 52 52" aria-hidden="true"><circle cx="26" cy="26" r="24" fill="none"/><path fill="none" d="M15 27l7 7 15-16"/></svg>
        <h3>Заявка отправлена</h3><p>Перезвоним в ближайшее рабочее время, чтобы согласовать день выезда.</p>
      </div>
    </form>
  </div>
</section>

</main>

<footer>
  <div class="wrap">
    <div class="ft">
      <div>
        <a href="../../" class="logo" aria-label="ПЕСТКОНТРОЛЬ Центр — на главную"><span class="logo-mark"><svg viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="1.6" stroke-linejoin="round" aria-hidden="true"><path d="M12 2.5l7.5 3v6c0 5-3.2 8.6-7.5 10-4.3-1.4-7.5-5-7.5-10v-6z"/><circle cx="12" cy="11.5" r="2.6" stroke="#7c86ff"/><path d="M12 6.2v2.7M12 14.1v2.7M6.8 11.5h2.6M14.6 11.5h2.6" stroke="#7c86ff"/></svg></span><span class="logo-txt"><span class="logo-name">ПЕСТКОНТРОЛЬ</span> <span class="logo-sub">Центр</span></span></a>
        <p class="d"><span class="nw">Пест-контроль</span> и <span class="nw">пест-менеджмент</span> по системе IPM для бизнеса в Москве и Московской области: бесплатный аудит, оценка <span class="nw">пест-риска</span>, мониторинг вредителей и отчётность.</p>
      </div>
      <div><h4>Услуги</h4><ul><li><a href="../../dezinfektsiya/">Дезинфекция для организаций</a></li><li><a href="../../deratizatsiya/">Дератизация для организаций</a></li><li><a href="../../dezinsektsiya/">Дезинсекция для организаций</a></li><li><a href="../../sanitarnyy-audit/"><span>Санитарный аудит <span class="nw">(СЭС-аудит)</span></span></a></li><li><a href="../../razrabotka-ppk/">Разработка ППК</a></li><li><a href="../../ochistka-dezinfektsiya-ventilyatsii/">Очистка и дезинфекция вентиляции</a></li><li><a href="../../dogovor-deratizatsiya-dezinsektsiya/">Договор на дератизацию и дезинсекцию</a></li><li><a href="../../#podhod"><span><span class="nw">Пест-контроль</span> по системе IPM</span></a></li><li><a href="../../#etapy">Этапы работы</a></li><li><a href="../../#vrediteli">Вредители</a></li><li><a href="../../#usloviya">Цена</a></li><li><a href="../../#voprosy">Вопросы</a></li><li><a href="../../normativnaya-baza/dokumenty-dlya-rospotrebnadzora/">Документы для Роспотребнадзора</a></li></ul></div>
      <div><h4>Отрасли</h4><ul><li><a href="../../pishchevoe-proizvodstvo/">Пищевые производства</a></li><li><a href="../../magaziny-i-torgovye-seti/">Магазины и торговые сети</a></li><li><a href="../../restorany-i-kafe/">Рестораны и кафе</a></li><li><a href="../../sklady-i-logistika/">Склады и логистика</a></li><li><a href="../../farmatsevticheskie-proizvodstva/">Фармацевтические производства</a></li><li><a href="../../gostinitsy/">Гостиницы и отели</a></li></ul></div>
      <div><h4>Материалы</h4><ul><li><a href="../../normativnaya-baza/">Нормативная база</a></li><li><a href="../../normativnaya-baza/proverochnye-listy/">Проверочные листы 2026</a></li><li><a href="../../materialy/programma-pest-kontrolya/"><span>Программа <span class="nw">пест-контроля</span></span></a></li><li><a href="../../materialy/zhurnal-pest-kontrolya/"><span>Журнал <span class="nw">пест-контроля</span></span></a></li><li><a href="../../materialy/pest-menedzhment-ili-razovaya-obrabotka/"><span><span class="nw">Пест-менеджмент</span> или разовая обработка</span></a></li><li><a href="./" aria-current="page">Программа производственного контроля по ХАССП</a></li><li><a href="../../materialy/">Все материалы</a></li><li><a href="../../normativnaya-baza/dokumenty-dlya-rospotrebnadzora/">Документы для Роспотребнадзора</a></li></ul></div>
      <div><h4>Контакты</h4><ul><li><a href="tel:+74951043570">+7 (495) 104-35-70</a></li><li><a href="mailto:b2b@pestcontrol-center.ru">b2b@<wbr><span style="white-space:nowrap">pestcontrol-center.ru</span></a></li><li>Пн–Пт: 8:00–20:00</li><li>Срочные выезды: 24/7</li></ul>
        <div class="msg"><a href="https://max.ru/u/f9LHodD0cOIlIUXFkt4KMFP88lD8n4TArBiTcV7RI1XML5c4o39QfsDBXUc" class="max" aria-label="Написать в Max" target="_blank" rel="noopener noreferrer"><svg viewBox="0 0 24 24" fill="#fff" aria-hidden="true"><path d="M12 3a9 9 0 0 0-7.7 13.7L3 21l4.4-1.2A9 9 0 1 0 12 3zm-3.6 12.3V8.7h1.6l2 2.8 2-2.8h1.6v6.6h-1.7v-3.9L12 14l-1.9-2.6v3.9z"/></svg></a><a href="https://t.me/Centr_Dezinfection?text=%D0%97%D0%B4%D1%80%D0%B0%D0%B2%D1%81%D1%82%D0%B2%D1%83%D0%B9%D1%82%D0%B5!%20%D0%9F%D0%B8%D1%88%D1%83%20%D1%81%20%D1%81%D0%B0%D0%B9%D1%82%D0%B0%20%D0%BF%D0%B5%D1%81%D1%82%D0%BA%D0%BE%D0%BD%D1%82%D1%80%D0%BE%D0%BB%D1%8C-%D1%86%D0%B5%D0%BD%D1%82%D1%80.%D1%80%D1%84" class="tg" aria-label="Написать в Telegram" target="_blank" rel="noopener noreferrer"><svg viewBox="0 0 24 24" fill="#fff" aria-hidden="true"><path d="M21.4 4.3 2.9 11.4c-1.3.5-1.2 1.2-.2 1.5l4.7 1.5 1.8 5.6c.2.6.4.8.9.8.4 0 .6-.2.9-.4l2.3-2.2 4.7 3.5c.9.5 1.5.2 1.7-.8l3.1-14.6c.3-1.3-.5-1.8-1.4-1.5zM9.6 14.1l8.6-5.4c.4-.3.8-.1.5.2l-7.1 6.4-.3 3.3z"/></svg></a></div>
      </div>
    </div>
    <div class="fb"><span>© 2026 ПЕСТКОНТРОЛЬ Центр</span><a href="../../privacy/">Политика конфиденциальности</a><a href="../../soglasie/">Согласие на обработку данных</a><span>Информация на сайте не является публичной офертой</span></div>
  </div>
</footer>

<div class="mbar" id="mbar">
  <a href="tel:+74951043570" class="c1"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1 1 .4 1.9.7 2.8a2 2 0 0 1-.5 2.1L8 9.9a16 16 0 0 0 6 6l1.3-1.3a2 2 0 0 1 2.1-.4c.9.3 1.8.6 2.8.7a2 2 0 0 1 1.7 2z"/></svg>Позвонить</a>
  <a href="#zayavka" class="c2"><span>Обследование</span></a>
</div>
<div class="fab" role="group" aria-label="Написать в мессенджер">
  <a href="https://max.ru/u/f9LHodD0cOIlIUXFkt4KMFP88lD8n4TArBiTcV7RI1XML5c4o39QfsDBXUc" class="max" aria-label="Написать в Max" target="_blank" rel="noopener noreferrer"><svg viewBox="0 0 24 24" fill="#fff" aria-hidden="true"><path d="M12 3a9 9 0 0 0-7.7 13.7L3 21l4.4-1.2A9 9 0 1 0 12 3zm-3.6 12.3V8.7h1.6l2 2.8 2-2.8h1.6v6.6h-1.7v-3.9L12 14l-1.9-2.6v3.9z"/></svg></a>
  <a href="https://t.me/Centr_Dezinfection?text=%D0%97%D0%B4%D1%80%D0%B0%D0%B2%D1%81%D1%82%D0%B2%D1%83%D0%B9%D1%82%D0%B5!%20%D0%9F%D0%B8%D1%88%D1%83%20%D1%81%20%D1%81%D0%B0%D0%B9%D1%82%D0%B0%20%D0%BF%D0%B5%D1%81%D1%82%D0%BA%D0%BE%D0%BD%D1%82%D1%80%D0%BE%D0%BB%D1%8C-%D1%86%D0%B5%D0%BD%D1%82%D1%80.%D1%80%D1%84" class="tg" aria-label="Написать в Telegram" target="_blank" rel="noopener noreferrer"><svg viewBox="0 0 24 24" fill="#fff" aria-hidden="true"><path d="M21.4 4.3 2.9 11.4c-1.3.5-1.2 1.2-.2 1.5l4.7 1.5 1.8 5.6c.2.6.4.8.9.8.4 0 .6-.2.9-.4l2.3-2.2 4.7 3.5c.9.5 1.5.2 1.7-.8l3.1-14.6c.3-1.3-.5-1.8-1.4-1.5zM9.6 14.1l8.6-5.4c.4-.3.8-.1.5.2l-7.1 6.4-.3 3.3z"/></svg></a>
</div>

<script>
(function(){if(/^(www\.)?xn----itbbsflddbfpfdodg9d0f\.xn--p1ai$/i.test(location.hostname))return;var f=window.fetch;window.fetch=function(u){if(typeof u==='string'&&u.indexOf('send.php')>-1)return new Promise(function(r){setTimeout(function(){r(new Response('{"success":true}',{status:200,headers:{'Content-Type':'application/json'}}))},500)});return f.apply(this,arguments)};document.addEventListener('DOMContentLoaded',function(){var p=document.querySelector('.form .fs');if(p)p.textContent='Предпросмотр: заявка никуда не отправляется'})})();
document.addEventListener('click',function(e){var a=e.target.closest('[data-dl]');if(!a)return;try{if(window.ym)ym(113675622,'reachGoal','ppk_'+a.getAttribute('data-dl'))}catch(_){}});
(function(){var f=document.getElementById('form');if(!f)return;f.addEventListener('submit',function(){var e=f.elements,s=e.service.value||'не выбрано',a=e.address.value.trim()||'не указан';e.msg.value='Задача: '+s+'\nАдрес объекта: '+a+'\nСтраница: Программа производственного контроля по ХАССП (/materialy/programma-proizvodstvennogo-kontrolya-haccp/)';});})();
/* «Скопировать текст» образца раздела */
document.addEventListener('click',function(ev){var b=ev.target.closest('[data-copy]');if(!b)return;var el=document.querySelector(b.getAttribute('data-copy'));if(!el)return;var t=[].map.call(el.querySelectorAll('h3,li'),function(n){return n.tagName==='LI'?n.children[0].textContent+' '+n.children[1].textContent:n.textContent}).join('\n\n').replace(/\u00a0/g,' ').trim(),l=b.querySelector('.btn-t'),o=l.textContent;function ok(){l.textContent='Текст скопирован';setTimeout(function(){l.textContent=o},2400)}function alt(){var a=document.createElement('textarea');a.value=t;a.setAttribute('readonly','');a.style.cssText='position:fixed;top:0;left:0;opacity:0';document.body.appendChild(a);a.select();try{document.execCommand('copy');ok()}catch(x){}document.body.removeChild(a)}if(navigator.clipboard&&window.isSecureContext)navigator.clipboard.writeText(t).then(ok,alt);else alt()});
</script>
<script data-fx>
/* Эффекты под курсором, как на главной (tools/site/fx.py) */
(function(){
  var mm=window.matchMedia;if(!mm)return;
  var fine=mm('(hover: hover) and (pointer: fine)').matches;
  /* «фонарь»: следует за мышью, без движения мыши плавно ходит сам; на сенсорных экранах ходит сам (30 кадров в секунду).
     Не считаем, пока первый экран не виден или вкладка скрыта. Старт — вместе со входом первого экрана */
  var hero=document.getElementById('hero'),lit=hero&&hero.querySelector('.fx-lit');
  if(lit&&!mm('(prefers-reduced-motion: reduce)').matches){
    var media=lit.parentNode,small=mm('(max-width:860px)').matches,full=hero.classList.contains('f-hero');
    lit.style.setProperty('--sr',small?'150px':'clamp(240px, 21vw, 400px)');
    var cx=small?.5:(full?.68:.74),ax=small?.24:(full?.16:.13),cy=small?.5:.47,ay=small?.2:.17;
    var sx=cx,sy=cy,tx=cx,ty=cy,last=-1e9,vis=true,on=false,raf=0,lt=0;
    var frame=function(now){
      raf=0;if(!on||!vis||document.hidden)return;
      var dt=now-lt;if(!fine&&dt<30){raf=requestAnimationFrame(frame);return;}
      lt=now;if(now-last>2600){var t=now/1000;tx=cx+ax*Math.sin(t*.33);ty=cy+ay*Math.sin(t*.47+1.3);}
      var k=1-Math.pow(.94,Math.min(dt,100)/16.67);sx+=(tx-sx)*k;sy+=(ty-sy)*k;
      lit.style.setProperty('--sx',(sx*100).toFixed(2)+'%');lit.style.setProperty('--sy',(sy*100).toFixed(2)+'%');
      raf=requestAnimationFrame(frame);
    };
    var kick=function(){if(!raf&&on&&vis&&!document.hidden){lt=performance.now();raf=requestAnimationFrame(frame);}};
    hero.addEventListener('pointermove',function(e){
      if(e.pointerType!=='mouse')return;var r=media.getBoundingClientRect();if(!r.width||!r.height)return;
      tx=(e.clientX-r.left)/r.width;ty=(e.clientY-r.top)/r.height;last=performance.now();kick();
    },{passive:true});
    if('IntersectionObserver' in window)new IntersectionObserver(function(es){vis=es[0].isIntersecting;kick();}).observe(hero);
    document.addEventListener('visibilitychange',kick);
    var start=function(){if(on)return;on=true;hero.classList.add('fx-lit-on');kick();};
    var eb=hero.querySelector('.eyebrow');
    if(eb&&'MutationObserver' in window){
      if(eb.classList.contains('in'))start();
      else{var mo=new MutationObserver(function(){if(eb.classList.contains('in')){mo.disconnect();start();}});mo.observe(eb,{attributes:true,attributeFilter:['class']});}
    }
    setTimeout(start,eb?5000:2500);
  }
  /* подсветка рамки карточек за курсором — как у .card на главной */
  if(fine)document.addEventListener('pointermove',function(e){
    var c=e.target.closest&&e.target.closest('.d-card,.p-sec,.p-fcard,.p-duty-box,.p-dl-card,.pm-step-card,.pm-scen,.pm-link-card,.k-err,.w-sample,.d-doc-prev');if(!c)return;
    var r=c.getBoundingClientRect();c.style.setProperty('--mx',(e.clientX-r.left)+'px');c.style.setProperty('--my',(e.clientY-r.top)+'px');
  },{passive:true});
})();
</script>
<script>
  /* скрипты анимаций подключаются сразу после первой отрисовки: фото и заголовок первого экрана не ждут их загрузки */
  (function (r, l) {
    var go = function () { l.forEach(function (u) { var e = document.createElement('script'); e.src = r + u; e.async = false; document.body.appendChild(e); }); };
    if (document.visibilityState === 'hidden' || !window.requestAnimationFrame) setTimeout(go, 0);
    else requestAnimationFrame(function () { setTimeout(go, 0); });
  })('../../', ['vendor/gsap.min.js', 'vendor/ScrollTrigger.min.js', 'vendor/lenis.min.js', 'app.min.js?v=20261106s2']);
</script>
<!-- Yandex.Metrika counter + UIS + Radist: загружаются после первого действия посетителя (касание, прокрутка, мышь, клавиатура) или через 5 с после загрузки страницы -->
<script type="text/javascript">
    (function (w, d) {
        w.ym = w.ym || function () { (w.ym.a = w.ym.a || []).push(arguments); };
        w.ym.l = 1 * new Date();
        ym(113675622, 'init', {ssr:true, webvisor:true, clickmap:true, ecommerce:"dataLayer", referrer: document.referrer, url: location.href, accurateTrackBounce:true, trackLinks:true});
        var done = false, ready = false, wait = null, ev = ['pointerdown', 'touchstart', 'keydown', 'scroll', 'wheel', 'mousemove'];
        w.__cs = w.__cs || [];
        w.__cs.push(['waitForTrackViewAndRun', function () { ready = true; }]);
        // Radist: код заявки в ссылках Telegram и MAX — сразу, скрипт Radist загрузится вместе со счётчиками
        var rmsg = 'Здравствуйте! Пишу с сайта пестконтроль-центр.рф. Номер заявки: {radist_tracker}';
        w.radist_tracker = w.radist_tracker || function () { (w.radist_tracker.a = w.radist_tracker.a || []).push(arguments); };
        w.radist_tracker.l = 1 * new Date();
        w.radist_tracker({ message: rmsg, whatsapp_enabled: true, tgbot_enabled: true, tg_enabled: true, max_enabled: true, vk_enabled: true });
        (function () {
            var id = null, abc = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789', s = 'ro', i, txt;
            try {
                id = sessionStorage.getItem('radistVisit');
                if (!id || id.length !== 12) {
                    for (i = 0; i < 10; i++) s += abc.charAt(Math.floor(Math.random() * abc.length));
                    sessionStorage.setItem('radistVisit', s);
                    id = sessionStorage.getItem('radistVisit');
                }
            } catch (e) { id = null; }
            if (!id || id.length !== 12) return;
            txt = encodeURIComponent(rmsg.replace(/{radist_tracker}/g, id));
            [].forEach.call(d.querySelectorAll('a[href*="//t.me/"], a[href*="//max.ru/"]'), function (a) {
                try {
                    var u = new URL(a.href), n = u.pathname.split('/')[1] || '';
                    if (u.host === 'max.ru') a.href = 'https://max.ru/' + u.pathname.substring(1) + '?start=' + id;
                    else if (u.host === 't.me' && !/bot$/i.test(n)) a.href = 'https://t.me' + u.pathname + '?text=' + txt;
                } catch (e) {}
            });
        })();
        function add(src) { var k = d.createElement('script'); k.async = true; k.src = src; d.head.appendChild(k); return k; }
        function load() {
            if (done) return; done = true;
            ev.forEach(function (e) { w.removeEventListener(e, load, true); });
            add('https://mc.yandex.ru/metrika/tag.js?id=113675622');
            var p = d.createElement('link'); p.rel = 'preconnect'; p.href = 'https://tracker.comagic.ru'; d.head.appendChild(p);
            add('https://app.uiscom.ru/static/cs.min.js?k=ICWycQx6m3NSBe3WlCeDAdAKMTmNhMHC').onerror = function () { ready = true; };
            add('https://track.radist.me/tracker.min.js');
        }
        ev.forEach(function (e) { w.addEventListener(e, load, { capture: true, passive: true }); });
        function later() { setTimeout(load, 5000); }
        if (d.readyState === 'complete') later(); else w.addEventListener('load', later);
        // Ожидание подмены номера при первом касании: набор откладывается до ответа UIS, максимум 0,8–1 с
        d.addEventListener('click', function (e) {
            if (ready) return;
            var a = e.target && e.target.closest ? e.target.closest('a[href^="tel:"]') : null;
            if (!a || e.button || e.ctrlKey || e.metaKey || e.shiftKey || e.altKey) return;
            e.preventDefault();
            if (wait) return;
            load();
            var href = a.getAttribute('href'), op = a.style.opacity, max = 'GestureEvent' in w ? 800 : 1000, t;
            function go() {
                for (var i = 0; i < wait.length; i++) clearTimeout(wait[i]);
                wait = null; ready = true; a.style.opacity = op;
                w.location.href = a.href;
            }
            function check(last) { return function () { if (wait && (last || ready || a.getAttribute('href') !== href)) go(); }; }
            wait = [];
            a.style.opacity = '.6';
            for (t = 50; t <= max; t += 50) wait.push(setTimeout(check(t === max), t));
        }, true);
    })(window, document);
</script>
<noscript><div><img src="https://mc.yandex.ru/watch/113675622" style="position:absolute; left:-9999px;" alt="" /></div></noscript>
<!-- /Yandex.Metrika counter -->
</body>
</html>
