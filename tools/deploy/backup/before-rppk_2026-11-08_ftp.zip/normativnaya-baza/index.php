<!doctype html>
<html lang="ru">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>СанПиН по дезинсекции и дератизации 2026: требования и периодичность</title>
<meta name="description" content="Какие СанПиН и нормативные документы действуют для дезинсекции и дератизации в 2026 году: периодичность, лицензия, ХАССП, сроки и отменённые документы.">
<link rel="canonical" href="https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/normativnaya-baza/">
<meta name="theme-color" content="#000000">
<meta property="og:type" content="article">
<meta property="og:locale" content="ru_RU">
<meta property="og:site_name" content="ПЕСТКОНТРОЛЬ Центр">
<meta property="og:url" content="https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/normativnaya-baza/">
<meta property="og:title" content="СанПиН и требования к дезинсекции и дератизации в 2026 году">
<meta property="og:description" content="Какие СанПиН и нормативные документы действуют для дезинсекции и дератизации в 2026 году: периодичность, лицензия, ХАССП, сроки и отменённые документы.">
<meta property="og:image" content="https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/img/nb-og.jpg">
<meta property="og:image:type" content="image/jpeg">
<meta property="og:image:width" content="1200">
<meta property="og:image:height" content="630">
<meta property="og:image:alt" content="СанПиН и требования к дезинсекции и дератизации в 2026 году">
<meta name="twitter:card" content="summary_large_image">
<link rel="icon" href="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 32 32'%3E%3Ccircle cx='16' cy='16' r='15' fill='%2309090b' stroke='%237c86ff' stroke-width='2'/%3E%3Cpath d='M16 7l7 3v5c0 5-3 8.5-7 10-4-1.5-7-5-7-10v-5z' fill='none' stroke='%23fff' stroke-width='2'/%3E%3C/svg%3E">
<link rel="preload" href="../fonts/inter-ru-wght-normal.woff2" as="font" type="font/woff2" crossorigin>
<link rel="preload" as="image" media="(min-width:861px)" imagesrcset="../img/nb-hero-1440.webp 1440w, ../img/nb-hero.webp 1920w" imagesizes="100vw" fetchpriority="high">
<link rel="preload" as="image" media="(max-width:860px)" imagesrcset="../img/nb-hero-mob-760.webp 760w, ../img/nb-hero-mob.webp 1024w" imagesizes="100vw" fetchpriority="high">
<script>
  /* начальные состояния анимаций — только при работающем JS; страховка — через 4 с всё показывается.
     Заставка — один раз за посещение: при переходе по ссылке с якорем и между страницами сайта её нет */
  (function (d) {
    d.classList.add('js');
    try { if (location.hash || sessionStorage.getItem('pc-intro')) d.classList.add('no-intro'); else sessionStorage.setItem('pc-intro', '1'); }
    catch (e) { if (location.hash) d.classList.add('no-intro'); }
    setTimeout(function () { if (!d.classList.contains('anim-ready')) d.classList.add('anim-fail'); }, 4000);
  })(document.documentElement);
</script>
<link rel="stylesheet" href="../style.css?v=20261106s2">
<style>.d-page .s{padding:clamp(64px,7vw,128px) 0;border-top:1px solid var(--line)}.d-crumbs{padding-top:calc(clamp(68px,6vw,115px) + 20px);font-size:14px;color:var(--t3);display:flex;flex-wrap:wrap;gap:8px}.d-crumbs a{color:var(--t2)}.d-crumbs a:hover{color:var(--t1)}.d-hero{padding:clamp(28px,3vw,56px) 0 clamp(64px,7vw,128px)}.d-hero .wrap{display:grid;grid-template-columns:minmax(0,1.15fr) minmax(0,.85fr);gap:clamp(28px,4vw,80px);align-items:center}.d-hero h1{font-size:clamp(34px,4.2vw,80px);line-height:1.05;letter-spacing:-.045em;font-weight:300;margin:18px 0 0}.d-ticks{list-style:none;padding:0;margin:28px 0 34px;display:grid;gap:12px}.d-ticks li{position:relative;padding-left:30px;line-height:1.5}.d-ticks li::before{content:"";position:absolute;left:2px;top:.42em;width:13px;height:7px;border-left:2px solid var(--acc);border-bottom:2px solid var(--acc);transform:rotate(-45deg)}.d-btns{display:flex;flex-wrap:wrap;gap:12px}.ph-img{aspect-ratio:4/3;border:1.5px dashed var(--line2);border-radius:var(--r);display:flex;align-items:center;justify-content:center;text-align:center;padding:28px;color:var(--t3);font-size:14px;line-height:1.5;background:rgba(255,255,255,.02)}.ph-doc{aspect-ratio:3/4;max-width:340px}.d-cards{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:16px}.d-card{background:var(--card);border:1px solid var(--line2);border-radius:var(--r);padding:clamp(22px,2vw,34px)}.d-card h3{font-size:clamp(20px,1.5vw,26px);font-weight:400;letter-spacing:-.02em;margin:0 0 12px}.d-card p{color:var(--t2);line-height:1.6;margin:0}.d-note{color:var(--t2);margin:24px 0 0;line-height:1.6}.d-strong{color:var(--t1);font-size:clamp(18px,1.3vw,22px)}.d-split{display:grid;grid-template-columns:minmax(0,1fr) minmax(0,340px);gap:clamp(28px,4vw,80px);align-items:start}.d-two{display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1fr);gap:clamp(28px,4vw,80px);align-items:start}.d-two .head{margin-bottom:0}.d-two .d-ticks{margin:0}.d-terms{list-style:none;counter-reset:t;padding:0;margin:0;border-top:1px solid var(--line2)}.d-terms li{display:grid;grid-template-columns:44px minmax(0,.42fr) minmax(0,1fr);gap:16px;padding:18px 0;border-bottom:1px solid var(--line2);line-height:1.55}.d-terms li::before{counter-increment:t;content:counter(t,decimal-leading-zero);color:var(--t3)}.d-terms b{font-weight:500}.d-terms span{color:var(--t2)}.d-doc{display:grid;gap:16px;justify-items:start}.d-small{font-size:14px;color:var(--t3);margin:0}.d-steps{list-style:none;counter-reset:st;padding:0;margin:0;display:grid;grid-template-columns:repeat(5,minmax(0,1fr));gap:18px}.d-steps li{border-top:2px solid var(--line2);padding-top:18px;line-height:1.55}.d-steps li::before{counter-increment:st;content:"0" counter(st);display:block;color:var(--acc);font-size:14px;margin-bottom:12px}.d-steps b{display:block;font-weight:500;margin-bottom:8px}.d-steps span{color:var(--t2)}.d-table{width:100%;border-collapse:collapse;line-height:1.5}.d-table th,.d-table td{text-align:left;vertical-align:top;padding:16px 20px 16px 0;border-bottom:1px solid var(--line2)}.d-table th{color:var(--t3);font-weight:400;font-size:14px}.d-table td{color:var(--t2)}.d-table td:first-child{color:var(--t1)}.d-vs td:first-child{color:var(--t2)}.d-vs th:last-child,.d-vs td:last-child{color:var(--t1);background:rgba(124,134,255,.07);padding-left:20px}.d-cols2{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:16px;margin-top:28px}.d-chips{list-style:none;padding:0;margin:0;display:flex;flex-wrap:wrap;gap:10px}.d-chips a{display:inline-block;padding:12px 18px;border:1px solid var(--line2);border-radius:999px;color:var(--t1);transition:border-color .2s}.d-chips a:hover{border-color:var(--acc)}.tbd{background:rgba(255,209,102,.14);color:#ffd166;border-radius:4px;padding:0 .2em}.d-page .cta .sub{margin-bottom:30px}@media (max-width:1100px){.d-steps{grid-template-columns:repeat(2,minmax(0,1fr))}}@media (max-width:860px){.d-hero .wrap,.d-split,.d-two,.d-cols2,.d-cards{grid-template-columns:minmax(0,1fr)}.d-terms li{grid-template-columns:36px minmax(0,1fr);gap:6px 12px}.d-terms span{grid-column:2}.ph-doc{display:none}}@media (max-width:600px){.d-steps{grid-template-columns:minmax(0,1fr)}.d-table thead{display:none}.d-table,.d-table tbody,.d-table tr,.d-table td{display:block;width:100%}.d-table tr{border:1px solid var(--line2);border-radius:var(--r);padding:6px 16px;margin-bottom:12px}.d-table td{border:0;padding:10px 0}.d-table td+td{border-top:1px solid var(--line)}.d-table td::before{content:attr(data-l);display:block;font-size:13px;color:var(--t3);margin-bottom:4px}.d-vs td:last-child{background:none;padding-left:0}.d-page .form .btn-lg{padding:0 16px}}.hdr .nav a{white-space:nowrap}.f-lazy:not(.bg-in){background-image:none!important}
.f-hero .hero-media{overflow:hidden}.f-hero .hero-media::after{content:"";position:absolute;inset:0 0 auto;height:200px;background:linear-gradient(180deg,rgba(9,9,11,.72),rgba(9,9,11,0));pointer-events:none}.f-hero .f-hero-img{position:absolute;inset:0;width:100%;height:100%;object-fit:cover;object-position:64% 50%;filter:saturate(.95)}.f-hero::before{background:linear-gradient(90deg,rgba(9,9,11,.92) 0%,rgba(9,9,11,.84) 40%,rgba(9,9,11,.32) 58%,rgba(9,9,11,0) 74%)}.f-hero::after{height:22%}.f-hero p.lead{max-width:600px}.f-crumbs{display:flex;flex-wrap:wrap;gap:8px;font-size:14px;color:var(--t3);margin:0 0 26px}.f-crumbs a{color:var(--t2)}.f-crumbs a:hover{color:var(--t1)}.f-urgent{margin:22px 0 0;color:var(--t2);font-size:15px}.f-urgent::before{content:"";display:inline-block;width:8px;height:8px;border-radius:50%;background:var(--grn);margin-right:10px;vertical-align:middle}
.f-checks{position:relative;padding:clamp(28px,3vw,56px) 0 clamp(56px,6vw,110px)}.f-check.panel{max-width:none}.f-check-in{position:relative;z-index:1;display:grid;grid-template-columns:minmax(0,.9fr) minmax(0,1.1fr);gap:clamp(24px,4vw,80px);padding:clamp(24px,3vw,52px)}.f-check-t{font-size:clamp(28px,2.6vw,48px);line-height:1.08;letter-spacing:-.04em;font-weight:300;margin:0}.f-check-res{margin:22px 0 10px;color:var(--t2);font-size:15px}.f-check-res b{font-size:clamp(40px,3.4vw,64px);font-weight:300;letter-spacing:-.04em;color:var(--acc);margin-right:6px;line-height:1;transition:color .3s}.f-check-res.full b{color:var(--grn)}.f-check-note{color:var(--t2);line-height:1.6;margin:0 0 28px;max-width:440px}.f-check-list{list-style:none;margin:0;padding:0;display:grid;align-content:center;border-top:1px solid var(--line)}.f-check-list li{border-bottom:1px solid var(--line)}.f-check-list label{display:flex;gap:18px;align-items:center;padding:18px 4px;cursor:pointer;font-size:clamp(16px,1.15vw,20px);line-height:1.4;color:var(--t2);transition:color .25s}.f-check-list label:hover{color:var(--t1)}.f-check-list input{appearance:none;-webkit-appearance:none;flex:none;width:26px;height:26px;margin:0;border-radius:8px;border:1.4px solid var(--line2);background:rgba(255,255,255,.03) center/14px no-repeat;cursor:pointer;transition:background-color .25s,border-color .25s}.f-check-list input:checked{background-color:var(--acc2);border-color:var(--acc);background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 14 14'%3E%3Cpath d='M2.5 7.5l3 3 6-7' fill='none' stroke='%23fff' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'/%3E%3C/svg%3E")}.f-check-list input:focus-visible{outline:2px solid var(--acc);outline-offset:3px}.f-check-list input:checked+span{color:var(--t1)}
.d-card .f-num{font-size:clamp(28px,2.4vw,44px);line-height:1.05;letter-spacing:-.035em;font-weight:300;color:var(--acc);margin:0 0 16px}.f-req .d-card{border-top:2px solid rgba(124,134,255,.45)}
.f-zmap{display:grid;grid-template-columns:minmax(0,1.4fr) minmax(0,1fr);gap:clamp(20px,2.4vw,44px);align-items:start}.f-plan{margin:0;padding:clamp(14px,1.4vw,26px)}.f-plan svg{display:block;width:100%;height:auto}.f-plan svg *{pointer-events:none}.f-plan .zf,.f-plan .bdg{pointer-events:all}.f-plan .zf{fill:transparent;transition:fill .3s,stroke .3s}.f-plan .z.on .zf{fill:rgba(124,134,255,.14)}.f-plan .z6.on .zf{fill:rgba(124,134,255,.05);stroke:#7c86ff}.f-plan .bdg circle{fill:#09090b;stroke:#7c86ff;stroke-width:2;transition:fill .3s}.f-plan .bdg text{fill:#7c86ff;font:500 22px Inter,system-ui,sans-serif;text-anchor:middle;dominant-baseline:central;transition:fill .3s}.f-plan .bdg.on circle{fill:#7c86ff}.f-plan .bdg.on text{fill:#fff}.f-plan .lbl text{fill:#84848e;font:400 15px Inter,system-ui,sans-serif}.f-legend{display:flex;flex-wrap:wrap;gap:10px 22px;margin:16px 4px 2px;font-size:13px;color:var(--t3)}.f-legend span{display:inline-flex;align-items:center;gap:9px}.f-legend i{flex:none;display:inline-block}.lg-st{width:11px;height:11px;border-radius:2px;background:var(--yel)}.lg-tr{width:11px;height:11px;border-radius:50%;background:var(--acc)}.lg-uv{width:20px;height:7px;border-radius:4px;background:#c4b5fd;box-shadow:0 0 8px rgba(167,139,250,.9)}.lg-fl{width:24px;border-top:2px dashed var(--acc)}.f-zlist{list-style:none;padding:0;margin:0;display:grid;gap:10px;counter-reset:zl}.f-zlist li{display:grid;grid-template-columns:40px minmax(0,1fr);gap:2px 14px;align-items:start;padding:15px 18px;border:1.4px solid var(--line);border-radius:var(--r);background:var(--card);transition:border-color .3s,background .3s;outline:none;cursor:default}.f-zlist li::before{counter-increment:zl;content:counter(zl);grid-row:1/span 2;width:34px;height:34px;border-radius:50%;border:1.4px solid var(--acc);color:var(--acc);display:flex;align-items:center;justify-content:center;font-size:15px;transition:background .3s,color .3s}.f-zlist b{font-weight:500;font-size:clamp(16px,1.05vw,19px);line-height:1.3}.f-zlist span{color:var(--t2);font-size:clamp(14px,.9vw,16px);line-height:1.5}.f-zlist li.on,.f-zlist li:hover,.f-zlist li:focus-visible{border-color:rgba(124,134,255,.6);background:rgba(124,134,255,.08)}.f-zlist li.on::before{background:var(--acc);color:#fff}
.f-steps4{grid-template-columns:repeat(4,minmax(0,1fr))}.d-steps li.f-alert{border-top-color:var(--yel)}.d-steps li.f-alert::before{color:var(--yel)}
.inds.f-inds{grid-template-columns:repeat(6,minmax(0,1fr))}.inds.f-inds>*{grid-column:span 2}.inds.f-inds>:nth-child(n+4){grid-column:span 3}.inds.f-inds>:nth-child(n+4) .ind-img{aspect-ratio:834/275}
.f-lbl{display:block;font-size:12px;letter-spacing:.08em;text-transform:uppercase;color:var(--acc);margin:4px 0 8px}.f-mb{margin:0 0 4px}.f-pricecard .f-price{margin:22px 0 26px;color:var(--t2);line-height:1.6}.f-pricecard .f-price b{display:block;color:var(--t1);font-weight:400;font-size:clamp(20px,1.6vw,28px);letter-spacing:-.02em;line-height:1.25;margin-bottom:6px}.d-card .btn{max-width:100%;white-space:normal;text-align:center;line-height:1.25}
@media (max-width:1100px){.f-steps4{grid-template-columns:repeat(2,minmax(0,1fr))}.f-zmap,.f-check-in{grid-template-columns:minmax(0,1fr)}.inds.f-inds{grid-template-columns:repeat(2,minmax(0,1fr))}.inds.f-inds>*,.inds.f-inds>:nth-child(n+4){grid-column:auto}.inds.f-inds>:nth-child(n+4) .ind-img{aspect-ratio:556/275}.inds.f-inds>:last-child{grid-column:1/-1}.inds.f-inds>:last-child .ind-img{aspect-ratio:834/275}}
@media (max-width:900px){.hdr{background:rgba(0,0,0,.72);backdrop-filter:blur(18px);-webkit-backdrop-filter:blur(18px);border-color:var(--line)}.f-hero{display:block;min-height:0;padding:68px 0 clamp(44px,8vw,72px)}.f-hero::before,.f-hero::after{display:none}.f-hero .hero-media{position:relative;inset:auto;width:100%;aspect-ratio:16/9}.f-hero .hero-media::after{height:100%;background:linear-gradient(180deg,rgba(0,0,0,0) 62%,#000 100%)}.f-hero .f-hero-img{object-position:70% 50%;filter:none}.f-hero .wrap{margin-top:-24px}.f-hero p.lead{max-width:760px}}@media (max-width:760px){.f-hero .hero-media{aspect-ratio:4/3}.f-hero .f-hero-img{object-position:50% 50%}.f-crumbs{font-size:13px;margin-bottom:18px}.inds.f-inds{grid-template-columns:minmax(0,1fr)}.inds.f-inds>:last-child{grid-column:auto}.inds.f-inds>:last-child .ind-img{aspect-ratio:556/275}}
@media (max-width:600px){.f-steps4{grid-template-columns:minmax(0,1fr)}.d-btns .btn,.d-card .btn,.f-check .btn{width:100%;white-space:normal;text-align:center;line-height:1.25}.d-page .btn-lg{padding:0 16px}.f-plan .lbl{display:none}.f-check-in{padding:24px 20px}.f-check-list label{padding:15px 2px;gap:14px}.f-zlist li{padding:14px}}
@media (max-width:400px){.hdr .wrap{gap:10px}.hdr-right{gap:8px}.logo{gap:8px}.logo-mark{width:34px;height:34px}.logo-name{font-size:15px}.phone i,.burger{width:40px;height:40px}}@media (max-width:340px){.logo-sub{display:none}}
/* Раздел «Нормативная база»: /normativnaya-baza/ и /normativnaya-baza/proverochnye-listy/ (класс nb-page) */
/* первый экран: фото на всю ширину и текст слева на градиенте — как у «Программы пест-контроля» в разделе «Материалы».
   На телефоне (до 860 px) порядок: заголовок → фото → текст → кнопки; надзаголовок не показывается, крошки скрыты правилом m-crumbs */
.d-hero.nb-hero{position:relative;overflow:hidden;display:flex;align-items:flex-end;min-height:clamp(680px,54vw,940px);padding:calc(clamp(68px,6vw,115px) + 28px) 0 clamp(40px,4vw,64px);background:#000}
.nb-hero .wrap{width:100%;display:grid;grid-template-columns:minmax(0,1.28fr) minmax(0,.72fr);gap:0 clamp(28px,4vw,80px);align-items:end}
.nb-hero .d-hero-copy{grid-column:1;min-width:0}
.nb-hero .d-hero-copy>*:not(.d-hero-media),.nb-hero .nb-toc{position:relative;z-index:1}
.nb-hero .d-hero-media{position:absolute;inset:0;z-index:0;pointer-events:none;overflow:hidden;margin:0}
.nb-hero .d-hero-media::before{content:"";position:absolute;inset:0;z-index:1;background:linear-gradient(90deg,rgba(0,0,0,.95) 0%,rgba(0,0,0,.86) 40%,rgba(0,0,0,.3) 58%,rgba(0,0,0,0) 70%),linear-gradient(180deg,#000 0,rgba(0,0,0,.55) 90px,rgba(0,0,0,0) 260px),linear-gradient(0deg,#000 0,rgba(0,0,0,.65) 110px,rgba(0,0,0,0) 300px)}
.nb-hero .d-hero-img{position:absolute;inset:0;width:100%;height:100%;object-fit:cover;object-position:100% 50%}
.nb-hero .f-crumbs{margin:0 0 22px}
.nb-hero .eyebrow{margin:0}
.d-hero.nb-hero h1{font-size:clamp(36px,3.6vw,66px);line-height:1.08;letter-spacing:-.055em;font-weight:300;margin:18px 0 0}
.nb-hero h1 .ln{display:block;padding:0 .08em .08em 0;margin-bottom:-.08em}
.nb-hero h1 .ln>span{display:inline-block}
.nb-hero p.lead{font-size:clamp(15px,1.02vw,18px);line-height:1.62;color:#c4c4cc;max-width:720px;margin:22px 0 0}
.nb-hero .d-btns{margin-top:26px}
.nb-byline{font-size:13px;line-height:1.5;color:var(--t3);margin:16px 0 0;max-width:720px}
.nb-hero .nb-toc{grid-column:1/-1;margin-top:clamp(28px,2.6vw,44px)}
.nb-toc{display:flex;flex-wrap:wrap;gap:8px}
.nb-toc a{display:inline-block;padding:9px 16px;border:1px solid var(--line2);border-radius:999px;font-size:14px;color:var(--t2);background:rgba(0,0,0,.45);transition:border-color .2s,color .2s}
.nb-toc a:hover,.nb-toc a:focus-visible{border-color:var(--acc);color:var(--t1)}
@media (min-width:1600px){.nb-hero p.lead,.nb-byline{max-width:820px}}
/* планшет и телефон (до 1180 px): заголовок → фото → текст → кнопки; при наложении текста на фото на этих ширинах
   люди на снимке уходили бы под текст */
@media (max-width:1180px){
  .d-hero.nb-hero{display:block;min-height:0;padding:calc(clamp(68px,6vw,115px) + 18px) 0 clamp(32px,6vw,48px)}
  .nb-hero .wrap{display:block}
  .nb-hero .d-hero-copy{display:flex;flex-direction:column}
  .nb-hero .eyebrow{display:none}
  .d-hero.nb-hero h1{order:1;margin:0}
  .nb-hero h1 .ln{display:inline}
  .nb-hero .d-hero-media{order:2;position:relative;inset:auto;aspect-ratio:16/9;max-height:min(560px,52vh);margin:22px calc(var(--pad) * -1) 0}
  .nb-hero .d-hero-media::before{background:linear-gradient(0deg,#000 0,rgba(0,0,0,0) 24%)}
  .nb-hero .d-hero-img{object-position:50% 15%}
  .nb-hero p.lead{order:3;margin:18px 0 0;max-width:820px}
  .nb-hero .d-btns{order:4;margin-top:24px}
  .nb-hero .nb-byline{order:5;max-width:820px}
  .nb-hero .f-crumbs{order:6;margin:18px 0 0}
  .nb-hero .nb-toc{margin-top:28px}
}
@media (max-width:860px){
  .d-hero.nb-hero h1{font-size:clamp(28px,7.8vw,36px);line-height:1.08}
  .nb-hero .d-hero-media{aspect-ratio:4/3;max-height:min(560px,70vh);margin-top:18px}
  .nb-hero .d-hero-img{object-position:50% 40%}
  .nb-hero p.lead{margin:14px 0 0;font-size:15px;line-height:1.55;max-width:none}
  .nb-hero .d-btns{margin-top:22px;gap:10px}
  .nb-hero .nb-byline{margin-top:14px}
  .nb-hero .nb-toc{margin-top:26px}
}

/* ссылки в тексте */
.nb-page .nb-tbl td a,.nb-after a,.nb-dl a,.nb-fact a,.nb-errs a,.nb-q-note a,.nb-food a,.nb-base a,.nb-five a,.nb-lic a,.nb-page .cta .sub a{color:var(--t1);border-bottom:1px solid rgba(124,134,255,.45);transition:border-color .25s}
.nb-page .nb-tbl td a:hover,.nb-after a:hover,.nb-dl a:hover,.nb-fact a:hover,.nb-errs a:hover,.nb-q-note a:hover,.nb-food a:hover,.nb-base a:hover,.nb-five a:hover,.nb-lic a:hover,.nb-page .cta .sub a:hover{border-color:var(--t1)}
.nb-lic{margin-top:8px}
.nb-lic a{text-decoration:none}

/* пять главных пунктов */
.nb-five{list-style:none;counter-reset:nb;padding:0;margin:0;display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:16px}
.nb-five li{counter-increment:nb;position:relative;padding:clamp(24px,2.2vw,34px) clamp(22px,2vw,32px) clamp(24px,2.2vw,34px) clamp(60px,4.4vw,82px);color:var(--t2);line-height:1.62}
.nb-five li{padding-left:clamp(80px,5.8vw,104px)}
.nb-five .nb-ic{position:absolute;left:clamp(22px,2vw,32px);top:clamp(24px,2.2vw,34px)}
.nb-five li b{display:block;color:var(--t1);font-weight:500;font-size:clamp(17px,1.2vw,21px);line-height:1.35;margin-bottom:10px}
.nb-five li:last-child:nth-child(odd){grid-column:1/-1}

/* таблицы: до 900 px — карточки */
.nb-h3{font-size:clamp(20px,1.5vw,26px);font-weight:400;letter-spacing:-.02em;line-height:1.3;color:var(--t1);margin:clamp(48px,4vw,72px) 0 6px}
.nb-h3:first-of-type{margin-top:0}
.nb-doc{color:var(--acc);font-weight:500}
.nb-date{color:var(--t1)}
.nb-val{color:var(--t1);font-weight:500}
.nb-old s{text-decoration-color:rgba(255,100,103,.75);text-decoration-thickness:1.5px}
.nb-after{margin:22px 0 0;color:var(--t2);line-height:1.62;max-width:1000px}
@media (min-width:901px){
  .nb-docs td:nth-child(1){width:30%}
  .nb-docs td:nth-child(3){width:15%}
  .nb-docs td:nth-child(4){width:15%}
  .nb-docs.nb-3 td:nth-child(3){width:22%}
  .nb-freq td:nth-child(2){width:24%}
  .nb-freq td:nth-child(3),.nb-freq td:nth-child(3){width:9%;white-space:nowrap}
  .nb-freq2 td:nth-child(2){width:28%}
  .nb-old td:nth-child(1){width:46%}
  .nb-old td:nth-child(3){width:26%}
  .nb-obj td:nth-child(1){width:22%}
  .nb-obj td:nth-child(3){width:30%}
  .nb-forms td:nth-child(1){width:20%}
  .nb-forms td:nth-child(2){width:13%;white-space:nowrap}
  .nb-forms td:nth-child(3){width:16%}
  .nb-answers td:nth-child(1){width:28%}
  .nb-answers td:nth-child(3){width:22%}
}
@media (max-width:900px){
  .nb-tbl thead{display:none}
  .nb-tbl,.nb-tbl tbody,.nb-tbl tr,.nb-tbl td{display:block;width:100%}
  .nb-tbl tr{border:1px solid var(--line2);border-radius:var(--r);padding:6px 16px;margin-bottom:12px}
  .nb-tbl td{border:0;padding:10px 0}
  .nb-tbl td+td{border-top:1px solid var(--line)}
  .nb-tbl td::before{content:attr(data-l);display:block;font-size:13px;color:var(--t3);margin-bottom:4px}
}

/* хроника изменений */
.nb-tl{list-style:none;padding:0;margin:0;position:relative;max-width:1240px}
.nb-tl::before{content:"";position:absolute;left:7px;top:10px;bottom:10px;width:1px;background:var(--line2)}
.nb-tl li{position:relative;display:grid;grid-template-columns:minmax(120px,.2fr) minmax(0,1fr) minmax(0,.78fr);gap:clamp(14px,2vw,40px);padding:0 0 clamp(28px,2.4vw,40px) 42px}
.nb-tl li:last-child{padding-bottom:0}
.nb-tl li::before{content:"";position:absolute;left:0;top:5px;width:15px;height:15px;border-radius:50%;border:2px solid var(--acc);background:#09090b;box-sizing:border-box}
.nb-tl-d{color:var(--acc);font-weight:500;font-size:clamp(16px,1.12vw,20px);line-height:1.3;white-space:nowrap}
.nb-tl-w{color:var(--t1);line-height:1.6}
.nb-tl-a{color:var(--t2);line-height:1.6;font-size:15px}
.nb-tl-k{display:block;font-size:12px;letter-spacing:.1em;text-transform:uppercase;color:var(--t3);margin-bottom:4px}
.nb-tl li.is-past::before{border-color:#52525b;background:#52525b}
.nb-tl li.is-past .nb-tl-d{color:var(--t3)}
.nb-tl li.is-past .nb-tl-w{color:var(--t2)}
.nb-tl a{color:var(--t1);border-bottom:1px solid rgba(124,134,255,.45)}
@media (max-width:760px){.nb-tl li{grid-template-columns:minmax(0,1fr);gap:6px;padding-left:34px}}

/* разборы и образцы */
.nb-links{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:16px}
.nb-link{display:flex;flex-direction:column;gap:12px;padding:0 0 clamp(22px,2vw,30px);min-height:190px;color:var(--t1);overflow:hidden}
.nb-link>:not(.nb-link-img){margin:0 clamp(22px,2vw,32px)}
.nb-link-img{display:block;aspect-ratio:16/9;overflow:hidden;background:#18181b;margin-bottom:8px;border-bottom:1px solid var(--line)}
.nb-link-img img{display:block;width:100%;height:100%;object-fit:cover;transition:transform .7s cubic-bezier(.16,1,.3,1)}
.nb-link-img.is-doc{background:#f4f4f5}
.nb-link-img.is-doc img{object-position:50% 0}
.nb-link:hover .nb-link-img img,.nb-link:focus-visible .nb-link-img img{transform:scale(1.04)}
.nb-link-k{font-size:12px;font-weight:500;letter-spacing:.12em;text-transform:uppercase;color:var(--acc)}
.nb-link b{font-weight:400;font-size:clamp(18px,1.3vw,23px);line-height:1.32;letter-spacing:-.01em}
.nb-link-go{margin-top:auto;color:var(--t2);font-size:15px;transition:color .25s}
.nb-link:hover .nb-link-go,.nb-link:focus-visible .nb-link-go{color:var(--t1)}

/* автор */
.nb-author-wrap{display:grid;grid-template-columns:minmax(0,.75fr) minmax(0,1.25fr);gap:clamp(24px,3vw,56px);align-items:center}
.nb-author{display:flex;gap:20px;align-items:center;padding:clamp(24px,2.4vw,36px)}
.nb-avatar{flex:none;display:block;width:112px;height:112px;border-radius:50%;object-fit:cover;background:#18181b;border:1px solid rgba(124,134,255,.4)}
.nb-author p{margin:0}
.nb-author-name{font-size:clamp(20px,1.5vw,26px);color:var(--t1);letter-spacing:-.02em;margin-bottom:4px!important}
.nb-author-role{color:var(--t2);margin-bottom:4px!important}
.nb-author-date{color:var(--t3);font-size:14px}
.nb-author-note{color:var(--t3);font-size:13px;margin-top:6px!important}
.nb-author-text{color:#c4c4cc;font-size:clamp(16px,1.08vw,19px);line-height:1.65;margin:0;max-width:760px}

/* источники — свёрнутый список */
.nb-page #istochniki{padding:clamp(48px,4.6vw,84px) 0}
.nb-src{border:1.4px solid var(--line);border-radius:var(--r);background:var(--card)}
.nb-src summary{list-style:none;cursor:pointer;display:flex;flex-direction:column;gap:8px;padding:clamp(22px,2vw,32px) calc(clamp(22px,2vw,32px) + 48px) clamp(22px,2vw,32px) clamp(22px,2vw,32px);position:relative;border-radius:var(--r)}
.nb-src summary::-webkit-details-marker{display:none}
.nb-src summary .eyebrow{margin:0}
.nb-src-t{font-size:clamp(20px,1.5vw,26px);font-weight:300;letter-spacing:-.02em;line-height:1.3;color:var(--t1)}
.nb-src summary::after{content:"+";position:absolute;right:clamp(22px,2vw,32px);top:50%;width:32px;height:32px;margin-top:-16px;border:1px solid var(--line2);border-radius:50%;display:flex;align-items:center;justify-content:center;color:var(--t2);font-size:18px;line-height:1;transition:border-color .25s}
.nb-src summary:hover::after{border-color:var(--acc)}
.nb-src[open] summary::after{content:"−"}
.nb-base{list-style:none;padding:0 clamp(22px,2vw,32px) clamp(18px,1.6vw,26px);margin:0}
.nb-base li{position:relative;padding:13px 0 13px 28px;border-top:1px solid var(--line2);color:var(--t2);line-height:1.6;font-size:15px}
.nb-base li::before{content:"§";position:absolute;left:3px;top:13px;color:var(--acc)}

/* проверочные листы: изменения, пять вопросов, пищевые производства, шаги, ошибки */
.nb-grid2{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:16px}
.nb-fact{padding:clamp(22px,2.2vw,34px);color:var(--t2);line-height:1.65}
.nb-fact b{display:block;color:var(--t1);font-weight:500;font-size:clamp(17px,1.2vw,21px);margin-bottom:8px}
.nb-qs{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:16px}
.nb-q{padding:clamp(24px,2.4vw,40px)}
.nb-q-wide{grid-column:1/-1}
.nb-q h3{display:flex;gap:16px;align-items:baseline;font-size:clamp(21px,1.6vw,28px);font-weight:400;letter-spacing:-.02em;line-height:1.25;margin:0 0 20px;color:var(--t1)}
.nb-q-n{font-size:14px;font-weight:500;letter-spacing:0;color:var(--acc);flex-shrink:0}
.nb-quote{margin:0 0 22px;padding:18px 20px;border-left:2px solid var(--acc);background:rgba(124,134,255,.06);border-radius:0 10px 10px 0;color:var(--t1);line-height:1.6;font-size:clamp(15px,1.02vw,17px)}
.nb-quote-k{display:block;font-size:12px;font-weight:500;letter-spacing:.12em;text-transform:uppercase;color:var(--acc);margin-bottom:8px}
.nb-dl{display:grid;grid-template-columns:minmax(120px,.3fr) minmax(0,1fr);margin:0}
.nb-dl dt{color:var(--t3);font-size:14px;line-height:1.5;padding:12px 16px 12px 0;border-top:1px solid var(--line2)}
.nb-dl dd{margin:0;color:var(--t2);line-height:1.6;padding:12px 0;border-top:1px solid var(--line2)}
.nb-q-wide .nb-dl{grid-template-columns:minmax(140px,.16fr) minmax(0,1fr)}
.nb-q .nb-tbl{margin:12px 0 18px}
.nb-q-note{color:var(--t2);line-height:1.62;margin:0 0 8px;max-width:1160px}
.nb-food{margin-top:clamp(28px,2.6vw,44px);padding:clamp(24px,2.4vw,40px)}
.nb-food h3{font-size:clamp(20px,1.5vw,26px);font-weight:400;letter-spacing:-.02em;line-height:1.3;margin:0 0 12px;color:var(--t1)}
.nb-food p{margin:0;color:var(--t2);line-height:1.65;max-width:1200px}
.nb-page .nb-steps{grid-template-columns:repeat(3,minmax(0,1fr));gap:28px 18px}
.nb-errs{list-style:none;padding:0;margin:0;display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:0 clamp(24px,3vw,56px);max-width:1440px}
.nb-errs li{position:relative;padding:16px 0 16px 34px;border-top:1px solid var(--line2);color:var(--t2);line-height:1.6}
.nb-errs li::before,.nb-errs li::after{content:"";position:absolute;left:3px;top:27px;width:14px;height:2px;background:var(--red);transform:rotate(45deg)}
.nb-errs li::after{transform:rotate(-45deg)}
.nb-errs-wrap{display:grid;grid-template-columns:minmax(0,1.3fr) minmax(0,.7fr);gap:clamp(24px,3.4vw,64px);align-items:start}
.nb-errs-wrap .nb-errs{grid-template-columns:minmax(0,1fr)}
.nb-errs-ph{margin:0;position:sticky;top:110px}
.nb-errs-ph img{display:block;width:100%;height:auto;border-radius:var(--r);border:1px solid var(--line2);background:#18181b}
.nb-errs-ph figcaption{margin-top:10px;color:var(--t3);font-size:13px;line-height:1.5}

@media (max-width:1100px){
  .nb-links{grid-template-columns:repeat(2,minmax(0,1fr))}
}
@media (max-width:900px){
  .nb-qs,.nb-author-wrap,.nb-errs-wrap{grid-template-columns:minmax(0,1fr)}
  .nb-errs-ph{position:static;max-width:640px}
  .nb-page .nb-steps{grid-template-columns:repeat(2,minmax(0,1fr))}
}
@media (max-width:760px){
  .nb-five,.nb-grid2,.nb-errs{grid-template-columns:minmax(0,1fr)}
  .nb-toc{gap:6px}
  .nb-toc a{padding:8px 13px;font-size:13px}
}
@media (max-width:600px){
  .nb-links{grid-template-columns:minmax(0,1fr)}
  .nb-link{min-height:0}
  .nb-page .nb-steps{grid-template-columns:minmax(0,1fr)}
  .nb-dl,.nb-q-wide .nb-dl{grid-template-columns:minmax(0,1fr)}
  .nb-dl dt{padding-bottom:2px}
  .nb-dl dd{border-top:0;padding-top:2px}
  .nb-avatar{width:80px;height:80px}
  .nb-author{align-items:flex-start}
  .nb-five li{padding-left:22px;padding-top:82px}
  .nb-five .nb-ic{top:24px;left:22px}
  .nb-q h3{flex-direction:column;gap:6px}
}

/* ---------- инфографика раздела: свёрстана кодом, текст остаётся текстом ---------- */
.nb-fig{margin:0 0 clamp(32px,3vw,52px)}
.nb-fig-head{display:flex;flex-direction:column;gap:6px;margin:0 0 18px}
.nb-fig-t{font-size:clamp(21px,1.6vw,28px);font-weight:300;letter-spacing:-.025em;line-height:1.22;color:var(--t1)}
.nb-fig-t em{font-style:italic;font-weight:500}
.nb-fig-d{color:var(--t2);font-size:15px;line-height:1.55;max-width:860px}
.nb-fig-note{color:var(--t3);font-size:13px;line-height:1.5;margin:14px 0 0}
.nb-ic{display:grid;place-items:center;flex:none;width:42px;height:42px;border-radius:12px;background:rgba(124,134,255,.1);border:1px solid rgba(124,134,255,.28);color:var(--acc)}
.nb-ic svg{width:20px;height:20px}

/* месяц на объекте особого значения */
.nb-cal{display:grid;grid-template-columns:minmax(170px,.9fr) repeat(4,minmax(0,1fr));border:1px solid var(--line2);border-radius:var(--r);overflow:hidden;background:var(--card)}
.nb-cal-row{display:contents}
.nb-cal-r,.nb-cal-c,.nb-cal-h{display:flex;align-items:center;min-height:66px;padding:14px 16px;border-bottom:1px solid var(--line)}
.nb-cal-c,.nb-cal-h{border-left:1px solid var(--line)}
.nb-cal-hd>*{min-height:46px;background:rgba(255,255,255,.03)}
.nb-cal-h{color:var(--t3);font-size:12px;letter-spacing:.08em;text-transform:uppercase}
.nb-cal-r{flex-direction:column;align-items:flex-start;justify-content:center;gap:2px}
.nb-cal-r b{color:var(--t1);font-weight:500;font-size:15px;line-height:1.3}
.nb-cal-r small{color:var(--t3);font-size:12px;line-height:1.35}
.nb-cal-row:last-child>*{border-bottom:0}
.nb-dot{display:inline-flex;align-items:center;gap:8px;font-size:13px;line-height:1.3;color:var(--t2);border:1px solid;border-radius:99px;padding:6px 12px 6px 7px}
.nb-dot>b{flex:none;display:inline-grid;place-items:center;width:22px;height:22px;border-radius:50%;color:#000;font-size:12px;font-weight:700}
.nb-dot-w{display:none}
.nb-dot.is-ins{border-color:rgba(124,134,255,.45)}.nb-dot.is-ins>b{background:var(--acc)}
.nb-dot.is-rod{border-color:rgba(255,137,4,.45)}.nb-dot.is-rod>b{background:var(--org)}
.nb-dot.is-bin{border-color:rgba(5,223,114,.4)}.nb-dot.is-bin>b{background:var(--grn)}
.nb-dot.is-tr{border-style:dashed;border-color:var(--t4);color:var(--t3)}.nb-dot.is-tr>b{background:none;border:1px dashed var(--t3);color:var(--t3)}
/* до 900 px (телефон и планшет) — карточка на каждую строку: что проверяют, норма и отметки «Неделя N · …» */
@media (max-width:900px){
  .nb-cal{display:flex;flex-direction:column;gap:10px;border:0;border-radius:0;background:none;overflow:visible}
  .nb-cal-row{display:flex;flex-wrap:wrap;gap:8px;padding:16px;border:1px solid var(--line2);border-radius:var(--r);background:var(--card)}
  .nb-cal-hd{display:none}
  .nb-cal-r,.nb-cal-c,.nb-cal-row:last-child>*{min-height:0;padding:0;border:0}
  .nb-cal-r{flex:1 1 100%;margin-bottom:4px}
  .nb-cal-c:empty{display:none}
  .nb-dot-w{display:inline}
}

/* дорожная карта норм: на компьютере ось слева направо, на телефоне — сверху вниз */
.nb-road{list-style:none;margin:0;padding:0;position:relative;height:300px}
.nb-road-axis{position:absolute;left:0;right:0;top:150px;height:2px;background:rgba(124,134,255,.55)}
.nb-road-fill{position:absolute;left:0;top:0;bottom:0;background:var(--t4)}
.nb-road-pt{position:absolute;top:0;left:var(--x);width:clamp(132px,12.5vw,200px);transform:translateX(-50%);display:flex;flex-direction:column;align-items:center;text-align:center}
.nb-road-pt::before{content:"";flex:none;width:18px;height:18px;border-radius:50%;border:2px solid var(--acc);background:var(--bg2);box-shadow:0 0 0 6px rgba(124,134,255,.12);box-sizing:border-box}
.nb-road-pt time{font-weight:600;font-size:15px;line-height:1.3;color:var(--acc);margin-bottom:6px}
.nb-road-pt span{color:var(--t2);font-size:13px;line-height:1.4}
.nb-road-pt.is-up{height:159px;justify-content:flex-end}
.nb-road-pt.is-up::before{order:3;margin-top:14px}
.nb-road-pt.is-down{top:141px}
.nb-road-pt.is-down::before{margin-bottom:14px}
.nb-road-pt.is-past time,.nb-road-pt.is-past span{color:var(--t3)}
.nb-road-pt.is-past::before{border-color:var(--t4);background:var(--t4);box-shadow:none}
.nb-road-now{position:absolute;left:var(--x);top:151px;transform:translate(-50%,-50%);z-index:2}
.nb-road-now span{display:block;white-space:nowrap;font-size:11px;font-weight:700;letter-spacing:.06em;text-transform:uppercase;color:#000;background:var(--yel);border-radius:99px;padding:4px 10px;box-shadow:0 0 0 5px rgba(253,199,0,.16)}
@media (max-width:760px){
  .nb-road{height:auto;display:flex;flex-direction:column;gap:20px;padding:2px 0 2px 34px}
  .nb-road-axis{left:8px;right:auto;top:8px;bottom:8px;width:2px;height:auto;background:var(--line2)}
  .nb-road-fill{display:none}
  .nb-road-pt,.nb-road-pt.is-up,.nb-road-pt.is-down{position:relative;left:auto;top:auto;width:auto;height:auto;transform:none;align-items:flex-start;justify-content:flex-start;text-align:left;order:var(--o)}
  .nb-road-pt::before,.nb-road-pt.is-up::before,.nb-road-pt.is-down::before{position:absolute;left:-34px;top:1px;margin:0}
  .nb-road-pt time{margin-bottom:2px}
  .nb-road-pt span{font-size:14px}
  .nb-road-now{position:relative;left:auto;top:auto;transform:none;order:var(--o);margin-left:-34px;align-self:flex-start}
}

/* от закона до журнала */
.nb-tier-list{list-style:none;margin:0;padding:0;display:grid;gap:18px}
.nb-tier{position:relative;display:grid;grid-template-columns:minmax(190px,.26fr) minmax(0,1fr);border:1px solid var(--line2);border-radius:var(--r);background:var(--card)}
.nb-tier+.nb-tier::before{content:"";position:absolute;left:clamp(40px,4vw,64px);top:-15px;width:8px;height:8px;border-right:1.5px solid var(--t4);border-bottom:1.5px solid var(--t4);transform:rotate(45deg)}
.nb-tier-n{display:flex;flex-direction:column;justify-content:center;gap:2px;padding:18px 20px;border-right:1px solid var(--line2)}
.nb-tier-n b{font-size:15px;font-weight:600;color:var(--t1)}
.nb-tier-n small{font-size:12px;line-height:1.35;color:var(--t3)}
.nb-tier-ch{display:flex;flex-wrap:wrap;align-items:center;gap:8px;padding:14px 18px}
.nb-chip{display:inline-block;font-size:13px;line-height:1.3;color:var(--t1);border:1px solid var(--line2);border-radius:99px;padding:6px 12px;background:rgba(255,255,255,.02);transition:border-color .2s,background .2s}
span.nb-chip{color:var(--t2)}
a.nb-chip:hover,a.nb-chip:focus-visible{border-color:var(--acc);background:rgba(124,134,255,.08)}
.nb-chip.is-key{border-color:rgba(124,134,255,.55);background:rgba(124,134,255,.12)}
.nb-tier.is-own{border-color:rgba(124,134,255,.45);background:rgba(124,134,255,.06)}
@media (max-width:760px){
  .nb-tier{grid-template-columns:minmax(0,1fr)}
  .nb-tier-n{border-right:0;border-bottom:1px solid var(--line2);padding:14px 16px}
  .nb-tier-ch{padding:12px 16px 14px}
}

/* выберите вид объекта */
.nb-objs{display:grid;grid-template-columns:repeat(6,minmax(0,1fr));gap:14px}
.nb-obj{display:flex;flex-direction:column;overflow:hidden;color:var(--t1)}
.nb-obj-img{display:block;aspect-ratio:16/10;overflow:hidden;background:#18181b}
.nb-obj-img img{display:block;width:100%;height:100%;object-fit:cover;transition:transform .7s cubic-bezier(.16,1,.3,1)}
.nb-obj:hover .nb-obj-img img,.nb-obj:focus-visible .nb-obj-img img{transform:scale(1.05)}
.nb-obj-t{display:flex;flex-direction:column;gap:3px;padding:12px 14px 14px}
.nb-obj-t b{font-size:14px;font-weight:600;line-height:1.3}
.nb-obj-t small{font-size:12px;line-height:1.35;color:var(--t3)}
@media (max-width:1100px){.nb-objs{grid-template-columns:repeat(3,minmax(0,1fr))}}
@media (max-width:600px){.nb-objs{grid-template-columns:repeat(2,minmax(0,1fr));gap:10px}}

/* было → стало */
.nb-bs{display:grid;grid-template-columns:minmax(0,1fr) 64px minmax(0,1.3fr);align-items:center;gap:10px}
.nb-bs-col{display:grid;gap:12px}
.nb-ord{border:1px solid var(--line2);border-radius:var(--r);padding:18px 20px;background:var(--card)}
.nb-ord b{display:block;font-size:17px;font-weight:600;color:var(--t1);margin-bottom:4px}
.nb-ord>span:not(.nb-ord-n){color:var(--t2);font-size:14px;line-height:1.5}
.nb-ord.is-old{background:none;border-style:dashed}
.nb-ord.is-old b{color:#c4c4cc;text-decoration:line-through;text-decoration-color:var(--red);text-decoration-thickness:2px}
.nb-ord.is-old>span{color:#a1a1aa}
.nb-ord.is-new{border-color:rgba(124,134,255,.5)}
.nb-ord-n{float:right;margin:0 0 6px 14px;font-size:34px;font-weight:300;line-height:1;color:var(--acc)}
.nb-bs-arrow{display:grid;place-items:center;color:var(--acc)}
.nb-bs-arrow svg{width:34px;height:34px}
.nb-bs-tot{margin:2px 0 0;color:var(--t3);font-size:14px}
@media (max-width:760px){
  .nb-bs{grid-template-columns:minmax(0,1fr)}
  .nb-bs-arrow svg{transform:rotate(90deg)}
}

/* фрагмент формы проверочного листа */
.nb-sheet{max-width:1120px;background:#f4f4f5;color:#18181b;border-radius:8px;padding:clamp(16px,2vw,28px);box-shadow:0 30px 60px rgba(0,0,0,.5);transform:rotate(-.5deg)}
.nb-sheet-h{display:flex;flex-wrap:wrap;justify-content:space-between;gap:6px 16px;margin:0 0 14px;font-size:12px;color:#52525c}
.nb-sheet table{width:100%;border-collapse:collapse;font-size:13px;line-height:1.45}
.nb-sheet th{text-align:left;font-weight:600;font-size:12px;color:#18181b;background:#e4e4e7;border:1px solid #a1a1aa;padding:8px}
.nb-sheet td{vertical-align:top;border:1px solid #a1a1aa;padding:8px;background:rgba(124,134,255,.09)}
.nb-sheet-n{width:40px;font-weight:600}
.nb-sheet-norm{width:200px;color:#52525c;font-size:12px}
.nb-sheet-c{width:58px;text-align:center}
.nb-box{display:inline-block;position:relative;vertical-align:middle;width:16px;height:16px;border:1.5px solid #3f3f46;border-radius:2px}
.nb-box.is-on::after{content:"";position:absolute;left:4px;top:0;width:5px;height:10px;border:solid var(--acc2);border-width:0 2.5px 2.5px 0;transform:rotate(45deg)}
@media (max-width:760px){
  .nb-sheet{transform:none;padding:14px}
  .nb-sheet thead{display:none}
  .nb-sheet table,.nb-sheet tbody{display:block}
  .nb-sheet tr{display:flex;flex-wrap:wrap;align-items:center;gap:6px 16px;margin-bottom:10px;padding:12px;border:1px solid #a1a1aa;border-radius:6px;background:rgba(124,134,255,.09)}
  .nb-sheet tr:last-child{margin-bottom:0}
  .nb-sheet td{display:block;border:0;padding:0;background:none}
  .nb-sheet-n{flex:0 0 26px;align-self:flex-start}
  .nb-sheet-q{flex:1 1 calc(100% - 42px)}
  .nb-sheet-norm{flex:1 1 100%;width:auto;padding-left:42px!important}
  .nb-sheet-c{flex:0 0 auto;width:auto;display:inline-flex!important;align-items:center;gap:6px}
  .nb-sheet-c:nth-child(4){margin-left:42px}
  .nb-sheet-c::after{content:attr(data-l);font-size:12px;color:#52525c}
}

/* папка к проверке */
.nb-folder{display:grid;grid-template-columns:repeat(5,minmax(0,1fr));gap:16px}
.nb-fdoc{display:flex;flex-direction:column;gap:6px;padding:12px 12px 18px;color:var(--t1)}
.nb-fdoc-img{display:block;aspect-ratio:3/4;overflow:hidden;border-radius:8px;background:#fff;margin-bottom:8px}
.nb-fdoc-img img{display:block;width:100%;height:100%;object-fit:cover;object-position:50% 0;transition:transform .7s cubic-bezier(.16,1,.3,1)}
.nb-fdoc-img.is-photo img{object-position:50% 50%}
.nb-fdoc:hover .nb-fdoc-img img,.nb-fdoc:focus-visible .nb-fdoc-img img{transform:scale(1.03)}
.nb-fdoc b{font-size:15px;font-weight:600;line-height:1.3;padding:0 4px}
.nb-fdoc small{font-size:13px;line-height:1.4;color:var(--t3);padding:0 4px}
@media (max-width:1100px){.nb-folder{grid-template-columns:repeat(3,minmax(0,1fr))}}
@media (max-width:600px){.nb-folder{grid-template-columns:repeat(2,minmax(0,1fr));gap:10px}}

/* иконки: виды объектов в таблице, шаги подготовки */
.nb-obj-ic{display:inline-flex;align-items:center;gap:12px;color:var(--t1)}
.nb-obj-ic .nb-ic{width:34px;height:34px;border-radius:10px}
.nb-obj-ic .nb-ic svg{width:17px;height:17px}
.nb-page .nb-steps li::before{display:inline-block;vertical-align:middle;margin:0 12px 14px 0}
.nb-steps .nb-ic{display:inline-grid;vertical-align:middle;width:36px;height:36px;border-radius:10px;margin:0 0 14px}
.nb-steps .nb-ic svg{width:18px;height:18px}</style>
<script type="application/ld+json">{"@context": "https://schema.org", "@graph": [{"@type": "Organization", "@id": "https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/#org", "name": "ПЕСТКОНТРОЛЬ Центр", "legalName": "ООО «Центр дезинфекционных услуг»", "url": "https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/", "telephone": "+7 495 104-35-70", "email": "b2b@pestcontrol-center.ru"}, {"@type": "BreadcrumbList", "itemListElement": [{"@type": "ListItem", "position": 1, "name": "Главная", "item": "https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/"}, {"@type": "ListItem", "position": 2, "name": "Нормативная база", "item": "https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/normativnaya-baza/"}]}, {"@type": "WebPage", "@id": "https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/normativnaya-baza/#webpage", "url": "https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/normativnaya-baza/", "name": "СанПиН и требования к дезинсекции и дератизации: что действует в 2026 году", "headline": "СанПиН и требования к дезинсекции и дератизации: что действует в 2026 году", "description": "Какие СанПиН и нормативные документы действуют для дезинсекции и дератизации в 2026 году: периодичность, лицензия, ХАССП, сроки и отменённые документы.", "inLanguage": "ru", "datePublished": "2026-11-06", "dateModified": "2026-11-06", "author": {"@type": "Person", "name": "Марианна Семерина", "jobTitle": "Санитарный врач"}, "publisher": {"@id": "https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/#org"}, "primaryImageOfPage": {"@type": "ImageObject", "url": "https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/img/nb-hero.webp", "width": 1920, "height": 1072, "caption": "Санитарный врач в белом халате и голубых перчатках листает папку с нормативными документами в производственном помещении; на стене — ловушка для летающих насекомых"}, "image": [{"@type": "ImageObject", "url": "https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/img/nb-hero.webp", "width": 1920, "height": 1072, "caption": "Санитарный врач в белом халате и голубых перчатках листает папку с нормативными документами в производственном помещении; на стене — ловушка для летающих насекомых"}, {"@type": "ImageObject", "url": "https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/img/nb-og.jpg", "width": 1200, "height": 630}], "about": ["Дезинсекция", "Дератизация", "СанПиН 3.3686-21", "Проверочные листы Роспотребнадзора"], "mainEntity": {"@type": "ItemList", "name": "Документы о дезинсекции и дератизации", "numberOfItems": 16, "itemListElement": [{"@type": "Legislation", "position": 1, "legislationIdentifier": "Федеральный закон № 52-ФЗ", "name": "О санитарно-эпидемиологическом благополучии населения", "legislationJurisdiction": "RU", "legislationLegalForce": "https://schema.org/InForce", "url": "https://base.garant.ru/483424596/7a69fb6632f5876efd3160114758a106/", "legislationDate": "1999-03-30"}, {"@type": "Legislation", "position": 2, "legislationIdentifier": "СанПиН 3.3686-21", "name": "Санитарно-эпидемиологические требования по профилактике инфекционных болезней", "legislationJurisdiction": "RU", "legislationLegalForce": "https://schema.org/InForce", "url": "http://pravo.gov.ru/proxy/ips/?docbody=&nd=602107773", "legislationDate": "2021-01-28", "expires": "2027-09-01"}, {"@type": "Legislation", "position": 3, "legislationIdentifier": "СанПиН 2.1.3684-21", "name": "Санитарно-эпидемиологические требования к содержанию территорий городских и сельских поселений, к водным объектам, питьевой воде и питьевому водоснабжению, атмосферному воздуху, почвам, жилым помещениям, эксплуатации производственных, общественных помещений, организации и проведению санитарно-противоэпидемических (профилактических) мероприятий", "legislationJurisdiction": "RU", "legislationLegalForce": "https://schema.org/InForce", "url": "http://pravo.gov.ru/proxy/ips/?doc_itself=&backlink=1&nd=602024221&page=1&rdk=3", "legislationDate": "2021-01-28", "expires": "2027-03-01"}, {"@type": "Legislation", "position": 4, "legislationIdentifier": "СанПиН 2.3/2.4.4282-26", "name": "Санитарные правила для общественного питания", "legislationJurisdiction": "RU", "legislationLegalForce": "https://schema.org/InForce", "url": "https://www.garant.ru/products/ipo/prime/doc/414229257/"}, {"@type": "Legislation", "position": 5, "legislationIdentifier": "СП 2.3.6.4281-26", "name": "Санитарные правила для торговли пищевой продукцией и рынков", "legislationJurisdiction": "RU", "legislationLegalForce": "https://schema.org/InForce", "url": "https://cgon.rospotrebnadzor.ru/biznesu/articles/novye-sanitarnye-pravila-dlya-torgovykh-obektov-i-rynkov-realizuyushchikh-pishchevuyu-produktsiyu/"}, {"@type": "Legislation", "position": 6, "legislationIdentifier": "СП 2.1.4284-26", "name": "Санитарные правила для эксплуатации помещений и оказания услуг", "legislationJurisdiction": "RU", "legislationLegalForce": "https://schema.org/InForce", "url": "https://www.consultant.ru/law/hotdocs/94328.html"}, {"@type": "Legislation", "position": 7, "legislationIdentifier": "Приказ Роспотребнадзора № 578", "name": "Об утверждении форм проверочных листов (31 форма)", "legislationJurisdiction": "RU", "legislationLegalForce": "https://schema.org/InForce", "url": "https://base.garant.ru/414956074/", "legislationDate": "2026-07-20"}, {"@type": "Legislation", "position": 8, "legislationIdentifier": "Приказ Роспотребнадзора № 580", "name": "Об утверждении форм проверочных листов (6 форм)", "legislationJurisdiction": "RU", "legislationLegalForce": "https://schema.org/InForce", "url": "http://publication.pravo.gov.ru/document/0001202609240001", "legislationDate": "2026-07-20"}, {"@type": "Legislation", "position": 9, "legislationIdentifier": "Федеральный закон № 99-ФЗ", "name": "О лицензировании отдельных видов деятельности", "legislationJurisdiction": "RU", "legislationLegalForce": "https://schema.org/InForce", "url": "https://cgon.rospotrebnadzor.ru/biznesu/profilaktika-nadzor-uslsugi/nadzornie-meropriatiya/litsenzirovanie-dezinfektsionnoy-deyatelnosti/", "legislationDate": "2011-05-04"}, {"@type": "Legislation", "position": 10, "legislationIdentifier": "Приказ Роспотребнадзора № 415", "name": "Форма программы производственного контроля для организаций, оказывающих услуги по дезинфекции, дезинсекции и дератизации", "legislationJurisdiction": "RU", "legislationLegalForce": "https://schema.org/InForce", "url": "http://www.pravo.gov.ru/proxy/ips/?docbody=&prevDoc=602107773&backlink=1&nd=607119571&rdk=", "legislationDate": "2024-05-30", "expires": "2030-09-01"}, {"@type": "Legislation", "position": 11, "legislationIdentifier": "МР 3.5.3.0374-25", "name": "Дератизация. Организация и проведение дератизационных мероприятий", "legislationJurisdiction": "RU", "legislationLegalForce": "https://schema.org/InForce", "url": "https://legalacts.ru/doc/mr-3530374-25-353-deratizatsija-organizatsija-i-provedenie-deratizatsionnykh-meroprijatii/", "legislationDate": "2025-04-28"}, {"@type": "Legislation", "position": 12, "legislationIdentifier": "ТР ТС 021/2011", "name": "О безопасности пищевой продукции", "legislationJurisdiction": "RU", "legislationLegalForce": "https://schema.org/InForce", "url": "https://docs.cntd.ru/document/902320560", "legislationDate": "2011-12-09"}, {"@type": "Legislation", "position": 13, "legislationIdentifier": "ГОСТ Р 51705.1-2024", "name": "Управление качеством и безопасностью пищевых продуктов на основе принципов ХАССП. Общие требования", "legislationJurisdiction": "RU", "legislationLegalForce": "https://schema.org/InForce", "url": "https://base.garant.ru/409077162/"}, {"@type": "Legislation", "position": 14, "legislationIdentifier": "ГОСТ Р 54762-2011", "name": "Программы предварительных требований по безопасности пищевой продукции. Часть 1", "legislationJurisdiction": "RU", "legislationLegalForce": "https://schema.org/InForce", "url": "https://base.garant.ru/70754062/"}, {"@type": "Legislation", "position": 15, "legislationIdentifier": "СП 3.5.3.3223-14", "name": "Санитарно-эпидемиологические требования к организации и проведению дератизационных мероприятий", "legislationJurisdiction": "RU", "legislationLegalForce": "https://schema.org/NotInForce", "url": "https://docs.cntd.ru/document/420223924", "expires": "2021-09-01"}, {"@type": "Legislation", "position": 16, "legislationIdentifier": "СанПиН 3.5.2.3472-17", "name": "Санитарно-эпидемиологические требования к организации и проведению дезинсекционных мероприятий", "legislationJurisdiction": "RU", "legislationLegalForce": "https://schema.org/NotInForce", "url": "https://www.normacs.ru/Doclist/doc/15NM.html", "expires": "2021-09-01"}]}}, {"@type": "FAQPage", "@id": "https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/normativnaya-baza/#faq", "mainEntity": [{"@type": "Question", "name": "Какой документ главный по дезинсекции и дератизации в 2026 году?", "acceptedAnswer": {"@type": "Answer", "text": "СанПиН 3.3686-21 «Санитарно-эпидемиологические требования по профилактике инфекционных болезней», раздел III. Он действует до 1 сентября 2027 года. Отраслевые требования содержатся в правилах 2026 года для общепита, торговли и помещений, а для пищевых производств — ещё и в ТР ТС 021/2011."}}, {"@type": "Question", "name": "Обязательна ли дератизация для организаций и ИП?", "acceptedAnswer": {"@type": "Answer", "text": "Да. Юридические лица и ИП обеспечивают дезинсекцию и дератизацию на своих объектах — сами или через специализированную организацию (п. 88 СанПиН 3.3686-21). Это не обязательно ежемесячная раскладка родентицидов: дератизация включает обследование, профилактику и истребительные мероприятия по результатам оценки (пп. 108–110)."}}, {"@type": "Question", "name": "Как часто проводить дезинсекцию и дератизацию на предприятии?", "acceptedAnswer": {"@type": "Answer", "text": "Зависит от объекта. На объектах особого эпидемиологического значения — пищевых и торговых, в гостиницах, медицинских и детских организациях — обследования на насекомых проводят не реже 2 раз в месяц, на других объектах — раз в месяц (п. 101 СанПиН 3.3686-21). Заселённость грызунами на объектах особого эпидемиологического значения оценивают ежемесячно, а дератизацию проводят по результатам оценки (п. 110). Обработки назначают по результатам обследований."}}, {"@type": "Question", "name": "Что такое объекты особого эпидемиологического значения?", "acceptedAnswer": {"@type": "Answer", "text": "Это объекты из перечня в п. 98 СанПиН 3.3686-21. Среди них организации пищевой промышленности и общественного питания, организации, которые хранят и продают пищевую продукцию, гостиницы и общежития, медицинские, санаторно-курортные и детские образовательные организации, вокзалы, аэропорты и объекты транспорта. Перечень широкий: в него входят также здания, предназначенные для постоянного или временного пребывания людей, и объекты коммунально-бытового назначения. Их обследуют на насекомых не реже 2 раз в месяц, а дератизацию проводят по результатам ежемесячной оценки."}}, {"@type": "Question", "name": "Нужна ли подрядчику лицензия и можно ли проводить обработки своими силами?", "acceptedAnswer": {"@type": "Answer", "text": "С 1 марта 2025 года услуги по дезинфекции, дезинсекции и дератизации оказывают только по лицензии. Если организация работает для собственных нужд, лицензия ей не нужна. При этом в проверочных листах для гостиниц, аптек, спортивных объектов, бань и магазинов непродовольственных товаров есть вопрос, проводит ли обработки «организация, осуществляющая дезинфекционную деятельность»."}}, {"@type": "Question", "name": "Действует ли СП 3.5.3.3223-14?", "acceptedAnswer": {"@type": "Answer", "text": "Нет. СП 3.5.3.3223-14 о дератизации утратили силу 1 сентября 2021 года, их требования вошли в раздел III СанПиН 3.3686-21. Тогда же утратил силу СанПиН 3.5.2.3472-17 о дезинсекции. Если программа или договор ссылаются на эти документы, ссылки нужно обновить."}}, {"@type": "Question", "name": "Можно ли оставить в программе производственного контроля ссылки на старые СП и СанПиН?", "acceptedAnswer": {"@type": "Answer", "text": "Лучше обновить. Правила 2020–2021 годов для общепита, торговли и помещений заменены с 1 сентября 2026 года, а СП 3.5.3.3223-14 и СанПиН 3.5.2.3472-17 не действуют с 2021 года. Ссылки на отменённые документы показывают инспектору и аудитору, что программу давно не пересматривали."}}, {"@type": "Question", "name": "Что будет после 1 сентября 2027 года?", "acceptedAnswer": {"@type": "Answer", "text": "В этот день заканчивается срок действия СанПиН 3.3686-21. Изменения, подготовленные в марте 2026 года, раздел о дезинсекции и дератизации не затрагивают. Мы отслеживаем проекты и обновим эту страницу и образцы документов, как только новые правила будут опубликованы."}}, {"@type": "Question", "name": "Где найти официальные тексты документов?", "acceptedAnswer": {"@type": "Answer", "text": "На портале официального опубликования publication.pravo.gov.ru и в системе pravo.gov.ru. Ссылки на каждый документ — в таблицах выше и в списке источников."}}]}]}</script>
<style id="m-crumbs">/* крошки на телефоне не показываем: для SEO хватает BreadcrumbList и ссылок в HTML */@media (max-width:900px){.d-crumbs,.f-crumbs{display:none!important}}</style>
<style data-fx>
/* подсветка рамки карточек за курсором — как у .card на главной (tools/site/fx.py) */
:where(.d-card,.p-sec,.p-fcard,.p-duty-box,.p-dl-card,.pm-step-card,.pm-scen,.pm-link-card,.k-err,.w-sample,.d-doc-prev){position:relative}
:where(.d-card,.p-sec,.p-fcard,.p-duty-box,.p-dl-card,.pm-step-card,.pm-scen,.pm-link-card,.k-err,.w-sample,.d-doc-prev)::after{content:"";position:absolute;inset:0;border-radius:inherit;padding:1.4px;pointer-events:none;background:radial-gradient(360px circle at var(--mx,-999px) var(--my,-999px),rgba(124,134,255,.85),rgba(124,134,255,.15) 35%,transparent 60%);-webkit-mask:linear-gradient(#000 0 0) content-box,linear-gradient(#000 0 0);-webkit-mask-composite:xor;mask:linear-gradient(#000 0 0) content-box,linear-gradient(#000 0 0);mask-composite:exclude;opacity:0;transition:opacity .4s;z-index:2}
@media (hover:hover) and (pointer:fine){:where(.d-card,.p-sec,.p-fcard,.p-duty-box,.p-dl-card,.pm-step-card,.pm-scen,.pm-link-card,.k-err,.w-sample,.d-doc-prev):hover::after{opacity:1}}
/* «фонарь» на фото первого экрана — как на главной (tools/site/fx.py) */
.fx-lit{position:absolute;inset:0;opacity:0;pointer-events:none;-webkit-mask-image:radial-gradient(circle var(--sr,320px) at var(--sx,72%) var(--sy,46%),#000 0%,rgba(0,0,0,.55) 45%,transparent 72%);mask-image:radial-gradient(circle var(--sr,320px) at var(--sx,72%) var(--sy,46%),#000 0%,rgba(0,0,0,.55) 45%,transparent 72%);transition:opacity 1.8s cubic-bezier(.16,1,.3,1)}
#hero :is(.d-hero-media,.hero-media)>picture>img{transition:filter 1.8s cubic-bezier(.16,1,.3,1)}
#hero.fx-lit-on :is(.d-hero-media,.hero-media)>picture>img{filter:grayscale(.3) brightness(.56)}
#hero.fx-lit-on .fx-lit img{filter:brightness(1.08) contrast(1.06) saturate(1.06)}
#hero.fx-lit-on .fx-lit{opacity:1}
</style>
</head>
<body class="d-page nb-page">
<a class="skip" href="#main">Перейти к содержанию</a>

<!-- ============ INTRO ============ -->
<div class="intro" id="intro" aria-hidden="true">
  <div class="intro-in">
    <svg class="intro-mark" viewBox="0 0 24 24" fill="none" stroke-width="1" stroke-linejoin="round"><path class="im-shield" pathLength="100" d="M12 2.5l7.5 3v6c0 5-3.2 8.6-7.5 10-4.3-1.4-7.5-5-7.5-10v-6z" stroke="#fff"/><circle class="im-c" pathLength="100" cx="12" cy="11.5" r="2.6" stroke="#7c86ff"/><path class="im-x" pathLength="100" d="M12 6.2v2.7M12 14.1v2.7M6.8 11.5h2.6M14.6 11.5h2.6" stroke="#7c86ff"/></svg>
    <div class="intro-word"><span>ПЕСТКОНТРОЛЬ</span><b>Центр</b></div>
    <div class="intro-bar"><i></i></div>
  </div>
</div>

<div class="progress" aria-hidden="true"><i id="progress"></i></div>
<div class="cursor" aria-hidden="true"><i class="cursor-dot"></i><i class="cursor-ring"></i></div>
<div class="grain" aria-hidden="true"></div>

<header class="hdr" id="hdr">
  <div class="wrap">
    <a href="../" class="logo" aria-label="ПЕСТКОНТРОЛЬ Центр — на главную">
      <span class="logo-mark"><svg viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="1.6" stroke-linejoin="round" aria-hidden="true"><path d="M12 2.5l7.5 3v6c0 5-3.2 8.6-7.5 10-4.3-1.4-7.5-5-7.5-10v-6z"/><circle cx="12" cy="11.5" r="2.6" stroke="#7c86ff"/><path d="M12 6.2v2.7M12 14.1v2.7M6.8 11.5h2.6M14.6 11.5h2.6" stroke="#7c86ff"/></svg></span>
      <span class="logo-txt"><span class="logo-name">ПЕСТКОНТРОЛЬ</span> <span class="logo-sub">Центр</span></span>
    </a>
    <nav class="nav" aria-label="Основное меню">
      <div class="nav-dd"><button class="nav-dd-btn" type="button" aria-expanded="false" aria-controls="nav-uslugi">Услуги<svg viewBox="0 0 12 12" aria-hidden="true"><path d="M2.5 4.5 6 8l3.5-3.5" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></button><div class="nav-dd-panel" id="nav-uslugi"><a href="../dezinfektsiya/">Дезинфекция для организаций<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../deratizatsiya/">Дератизация для организаций<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../dezinsektsiya/">Дезинсекция для организаций<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../sanitarnyy-audit/"><span>Санитарный аудит <span class="nw">(СЭС-аудит)</span></span><svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../ochistka-dezinfektsiya-ventilyatsii/">Очистка и дезинфекция вентиляции<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../dogovor-deratizatsiya-dezinsektsiya/">Договор на обслуживание<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../#podhod" class="nav-dd-all"><span>Пест-контроль по системе IPM</span><svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a></div></div><div class="nav-dd"><button class="nav-dd-btn" type="button" aria-expanded="false" aria-controls="nav-otrasli">Отрасли<svg viewBox="0 0 12 12" aria-hidden="true"><path d="M2.5 4.5 6 8l3.5-3.5" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></button><div class="nav-dd-panel" id="nav-otrasli"><a href="../pishchevoe-proizvodstvo/">Пищевые производства<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../magaziny-i-torgovye-seti/">Магазины и торговые сети<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../restorany-i-kafe/">Рестораны и кафе<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../sklady-i-logistika/">Склады и логистика<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../farmatsevticheskie-proizvodstva/">Фармацевтические производства<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../gostinitsy/">Гостиницы и отели<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../#otrasli" class="nav-dd-all">Все отрасли<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a></div></div><a href="../dogovor-deratizatsiya-dezinsektsiya/">Договор</a><a href="../#podhod">Метод IPM</a><a href="../#usloviya">Цена</a><div class="nav-dd"><button class="nav-dd-btn active" type="button" aria-expanded="false" aria-controls="nav-materialy">Материалы<svg viewBox="0 0 12 12" aria-hidden="true"><path d="M2.5 4.5 6 8l3.5-3.5" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></button><div class="nav-dd-panel" id="nav-materialy"><a href="./" aria-current="page">Нормативная база<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../materialy/programma-pest-kontrolya/"><span>Программа <span class="nw">пест-контроля</span></span><svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../materialy/zhurnal-pest-kontrolya/"><span>Журнал <span class="nw">пест-контроля</span></span><svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../materialy/pest-menedzhment-ili-razovaya-obrabotka/"><span><span class="nw">Пест-менеджмент</span> или разовая обработка</span><svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../materialy/programma-proizvodstvennogo-kontrolya-haccp/">Программа производственного контроля по ХАССП<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../materialy/" class="nav-dd-all">Все материалы<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a></div></div>
    </nav>
    <div class="hdr-right">
      <a class="phone" href="tel:+74951043570" aria-label="Позвонить: +7 (495) 104-35-70"><i><svg viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2" aria-hidden="true"><path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1 1 .4 1.9.7 2.8a2 2 0 0 1-.5 2.1L8 9.9a16 16 0 0 0 6 6l1.3-1.3a2 2 0 0 1 2.1-.4c.9.3 1.8.6 2.8.7a2 2 0 0 1 1.7 2z"/></svg></i><span>+7 (495) 104-35-70</span></a>
      <div class="msg">
        <a href="https://max.ru/u/f9LHodD0cOIlIUXFkt4KMFP88lD8n4TArBiTcV7RI1XML5c4o39QfsDBXUc" class="max" aria-label="Написать в Max" target="_blank" rel="noopener noreferrer"><svg viewBox="0 0 24 24" fill="#fff" aria-hidden="true"><path d="M12 3a9 9 0 0 0-7.7 13.7L3 21l4.4-1.2A9 9 0 1 0 12 3zm-3.6 12.3V8.7h1.6l2 2.8 2-2.8h1.6v6.6h-1.7v-3.9L12 14l-1.9-2.6v3.9z"/></svg></a>
        <a href="https://t.me/Centr_Dezinfection?text=%D0%97%D0%B4%D1%80%D0%B0%D0%B2%D1%81%D1%82%D0%B2%D1%83%D0%B9%D1%82%D0%B5!%20%D0%9F%D0%B8%D1%88%D1%83%20%D1%81%20%D1%81%D0%B0%D0%B9%D1%82%D0%B0%20%D0%BF%D0%B5%D1%81%D1%82%D0%BA%D0%BE%D0%BD%D1%82%D1%80%D0%BE%D0%BB%D1%8C-%D1%86%D0%B5%D0%BD%D1%82%D1%80.%D1%80%D1%84" class="tg" aria-label="Написать в Telegram" target="_blank" rel="noopener noreferrer"><svg viewBox="0 0 24 24" fill="#fff" aria-hidden="true"><path d="M21.4 4.3 2.9 11.4c-1.3.5-1.2 1.2-.2 1.5l4.7 1.5 1.8 5.6c.2.6.4.8.9.8.4 0 .6-.2.9-.4l2.3-2.2 4.7 3.5c.9.5 1.5.2 1.7-.8l3.1-14.6c.3-1.3-.5-1.8-1.4-1.5zM9.6 14.1l8.6-5.4c.4-.3.8-.1.5.2l-7.1 6.4-.3 3.3z"/></svg></a>
      </div>
      <a href="#zayavka" class="btn btn-w btn-sm" data-magnet><span class="btn-t">Бесплатный выезд</span></a>
      <button class="burger" id="burger" aria-label="Открыть меню" aria-expanded="false" aria-controls="mmenu"><span></span></button>
    </div>
  </div>
</header>
<nav class="mmenu" id="mmenu" aria-label="Мобильное меню">
  <div class="mm-group"><button class="mm-toggle" type="button" aria-expanded="false" aria-controls="mm-uslugi">Услуги<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m6 9 6 6 6-6" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/></svg></button><div class="mm-sub" id="mm-uslugi"><div><a href="../dezinfektsiya/">Дезинфекция для организаций</a><a href="../deratizatsiya/">Дератизация для организаций</a><a href="../dezinsektsiya/">Дезинсекция для организаций</a><a href="../sanitarnyy-audit/"><span>Санитарный аудит <span class="nw">(СЭС-аудит)</span></span></a><a href="../ochistka-dezinfektsiya-ventilyatsii/">Очистка и дезинфекция вентиляции</a><a href="../dogovor-deratizatsiya-dezinsektsiya/">Договор на обслуживание</a><a href="../#podhod"><span class="nw">Пест-контроль</span> по системе IPM</a></div></div></div><div class="mm-group"><button class="mm-toggle" type="button" aria-expanded="false" aria-controls="mm-otrasli">Отрасли<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m6 9 6 6 6-6" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/></svg></button><div class="mm-sub" id="mm-otrasli"><div><a href="../pishchevoe-proizvodstvo/">Пищевые производства</a><a href="../magaziny-i-torgovye-seti/">Магазины и торговые сети</a><a href="../restorany-i-kafe/">Рестораны и кафе</a><a href="../sklady-i-logistika/">Склады и логистика</a><a href="../farmatsevticheskie-proizvodstva/">Фармацевтические производства</a><a href="../gostinitsy/">Гостиницы и отели</a><a href="../#otrasli">Все отрасли</a></div></div></div><a href="../dogovor-deratizatsiya-dezinsektsiya/">Договор <small>на дератизацию и дезинсекцию</small></a><a href="../#podhod">Метод IPM</a><a href="../#usloviya">Цена</a><div class="mm-group open" data-open><button class="mm-toggle" type="button" aria-expanded="true" aria-controls="mm-materialy">Материалы<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m6 9 6 6 6-6" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/></svg></button><div class="mm-sub" id="mm-materialy"><div><a href="./" aria-current="page">Нормативная база</a><a href="../materialy/programma-pest-kontrolya/"><span>Программа <span class="nw">пест-контроля</span></span></a><a href="../materialy/zhurnal-pest-kontrolya/"><span>Журнал <span class="nw">пест-контроля</span></span></a><a href="../materialy/pest-menedzhment-ili-razovaya-obrabotka/"><span><span class="nw">Пест-менеджмент</span> или разовая обработка</span></a><a href="../materialy/programma-proizvodstvennogo-kontrolya-haccp/">Программа производственного контроля по ХАССП</a><a href="../materialy/">Все материалы</a></div></div></div>
  <a href="#zayavka" class="btn btn-w btn-lg"><span class="btn-t">Заказать бесплатное обследование</span></a>
</nav>

<main id="main" tabindex="-1">
<section class="d-hero nb-hero" id="hero">
  <div class="wrap">
    <div class="d-hero-copy">
      <nav class="f-crumbs" aria-label="Навигационная цепочка" data-h><a href="../">Главная</a><span aria-hidden="true">→</span><span aria-current="page">Нормативная база</span></nav>
      <div class="eyebrow">Нормативная база · для организаций в Москве и Московской области</div>
      <h1><span class="ln"><span>СанПиН и требования</span></span> <span class="ln"><span>к дезинсекции и дератизации:</span></span> <span class="ln"><span>что действует <em>в 2026 году</em></span></span></h1>
      <div class="d-hero-media"><picture><source media="(max-width:860px)" srcset="../img/nb-hero-mob-760.webp 760w, ../img/nb-hero-mob.webp 1024w" sizes="100vw" width="1024" height="768"><img class="d-hero-img" src="../img/nb-hero.webp" srcset="../img/nb-hero-1440.webp 1440w, ../img/nb-hero.webp 1920w" sizes="100vw" width="1920" height="1072" alt="Санитарный врач в белом халате и голубых перчатках листает папку с нормативными документами в производственном помещении; на стене — ловушка для летающих насекомых" fetchpriority="high" decoding="async"></picture><div class="fx-lit" aria-hidden="true"><picture><source media="(max-width:860px)" srcset="../img/nb-hero-mob-760.webp 760w, ../img/nb-hero-mob.webp 1024w" sizes="100vw" width="1024" height="768"><img class="d-hero-img fx-lit-img" src="../img/nb-hero.webp" srcset="../img/nb-hero-1440.webp 1440w, ../img/nb-hero.webp 1920w" sizes="100vw" width="1920" height="1072" alt="" decoding="async"></picture></div></div>
      <p class="lead" data-h>Главный документ о дезинсекции и дератизации — СанПиН <span class="nw">3.3686-21</span>, раздел III. Он действует до 1 сентября 2027 года. По нему организации и ИП обязаны обследовать объекты, вести учёт вредителей и проводить обработки — своими силами или через специализированную организацию. С 1 сентября 2026 года действуют новые правила для общепита, торговли и помещений, с 4–5 октября инспекторы работают по новым проверочным листам. Оказывать услуги по дезинсекции и дератизации с 1 марта 2025 года можно только по лицензии.</p>
      <div class="d-btns" data-h>
        <a href="../normativnaya-baza/proverochnye-listy/" class="btn btn-w btn-lg" data-magnet><span class="btn-t">Вопросы проверочных листов 2026</span></a>
        <a href="#zayavka" class="btn btn-o btn-lg" data-magnet><span class="btn-t">Проверить документы объекта</span></a>
      </div>
      <p class="nb-byline p-hero-note" data-h>Сверено с официальными текстами 06.11.2026 · обновляем при каждом изменении норм · подготовила Марианна Семерина, санитарный врач</p>
    </div>
    <nav class="p-toc nb-toc" aria-label="Разделы страницы" data-h><a href="#glavnoe">Главное</a><a href="#periodichnost">Периодичность</a><a href="#dokumenty">Действующие документы</a><a href="#izmeneniya">Что меняется</a><a href="#otmenennye">Отменённые</a><a href="#obekty">Ваш объект</a><a href="#obraztsy">Образцы</a><a href="#voprosy">Вопросы</a></nav>
  </div>
</section>

<div class="strip" role="group" aria-label="Коротко о нормативной базе">
  <div class="strip-track" id="stripTrack">
    <div class="strip-set">
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-file-badge" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M13 22h5a2 2 0 0 0 2-2V8a2.4 2.4 0 0 0-.706-1.706l-3.588-3.588A2.4 2.4 0 0 0 14 2H6a2 2 0 0 0-2 2v3.3" /> <path d="M14 2v5a1 1 0 0 0 1 1h5" /> <path d="m7.69 16.479 1.29 4.88a.5.5 0 0 1-.698.591l-1.843-.849a1 1 0 0 0-.879.001l-1.846.85a.5.5 0 0 1-.692-.593l1.29-4.88" /> <circle cx="6" cy="14" r="3" /> </svg><b>СанПиН 3.3686-21</b> — до 1 сентября 2027 года</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-scan-search" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M3 7V5a2 2 0 0 1 2-2h2" /> <path d="M17 3h2a2 2 0 0 1 2 2v2" /> <path d="M21 17v2a2 2 0 0 1-2 2h-2" /> <path d="M7 21H5a2 2 0 0 1-2-2v-2" /> <circle cx="12" cy="12" r="3" /> <path d="m16 16-1.9-1.9" /> </svg><b>Насекомые</b> — обследования не реже 2 раз в месяц</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-activity" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M22 12h-2.48a2 2 0 0 0-1.93 1.46l-2.35 8.36a.25.25 0 0 1-.48 0L9.24 2.18a.25.25 0 0 0-.48 0l-2.35 8.36A2 2 0 0 1 4.49 12H2" /> </svg><b>Грызуны</b> — ежемесячная оценка</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-shield-check" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z" /> <path d="m9 12 2 2 4-4" /> </svg><b>Лицензия</b> — с 1 марта 2025 года</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-clipboard-check" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <rect width="8" height="4" x="8" y="2" rx="1" ry="1" /> <path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2" /> <path d="m9 14 2 2 4-4" /> </svg><b>Проверочные листы</b> — приказы № 578 и № 580</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-list-checks" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M13 5h8" /> <path d="M13 12h8" /> <path d="M13 19h8" /> <path d="m3 17 2 2 4-4" /> <path d="m3 7 2 2 4-4" /> </svg><b>Правила 2026 года</b> — с 1 сентября</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-ban" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="m4.9 4.9 14.2 14.2"/></svg><b>Отменённые документы</b> — СП 3.5.3.3223-14 и другие</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-notebook-pen" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M13.4 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-7.4" /> <path d="M2 6h4" /> <path d="M2 10h4" /> <path d="M2 14h4" /> <path d="M2 18h4" /> <path d="M21.378 5.626a1 1 0 1 0-3.004-3.004l-5.01 5.012a2 2 0 0 0-.506.854l-.837 2.87a.5.5 0 0 0 .62.62l2.87-.837a2 2 0 0 0 .854-.506z" /> </svg><b>Образцы</b> программы, журнала и договора</div>
    </div>
    <div class="strip-set" aria-hidden="true">
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-file-badge" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M13 22h5a2 2 0 0 0 2-2V8a2.4 2.4 0 0 0-.706-1.706l-3.588-3.588A2.4 2.4 0 0 0 14 2H6a2 2 0 0 0-2 2v3.3" /> <path d="M14 2v5a1 1 0 0 0 1 1h5" /> <path d="m7.69 16.479 1.29 4.88a.5.5 0 0 1-.698.591l-1.843-.849a1 1 0 0 0-.879.001l-1.846.85a.5.5 0 0 1-.692-.593l1.29-4.88" /> <circle cx="6" cy="14" r="3" /> </svg><b>СанПиН 3.3686-21</b> — до 1 сентября 2027 года</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-scan-search" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M3 7V5a2 2 0 0 1 2-2h2" /> <path d="M17 3h2a2 2 0 0 1 2 2v2" /> <path d="M21 17v2a2 2 0 0 1-2 2h-2" /> <path d="M7 21H5a2 2 0 0 1-2-2v-2" /> <circle cx="12" cy="12" r="3" /> <path d="m16 16-1.9-1.9" /> </svg><b>Насекомые</b> — обследования не реже 2 раз в месяц</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-activity" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M22 12h-2.48a2 2 0 0 0-1.93 1.46l-2.35 8.36a.25.25 0 0 1-.48 0L9.24 2.18a.25.25 0 0 0-.48 0l-2.35 8.36A2 2 0 0 1 4.49 12H2" /> </svg><b>Грызуны</b> — ежемесячная оценка</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-shield-check" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z" /> <path d="m9 12 2 2 4-4" /> </svg><b>Лицензия</b> — с 1 марта 2025 года</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-clipboard-check" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <rect width="8" height="4" x="8" y="2" rx="1" ry="1" /> <path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2" /> <path d="m9 14 2 2 4-4" /> </svg><b>Проверочные листы</b> — приказы № 578 и № 580</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-list-checks" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M13 5h8" /> <path d="M13 12h8" /> <path d="M13 19h8" /> <path d="m3 17 2 2 4-4" /> <path d="m3 7 2 2 4-4" /> </svg><b>Правила 2026 года</b> — с 1 сентября</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-ban" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="m4.9 4.9 14.2 14.2"/></svg><b>Отменённые документы</b> — СП 3.5.3.3223-14 и другие</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-notebook-pen" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M13.4 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-7.4" /> <path d="M2 6h4" /> <path d="M2 10h4" /> <path d="M2 14h4" /> <path d="M2 18h4" /> <path d="M21.378 5.626a1 1 0 1 0-3.004-3.004l-5.01 5.012a2 2 0 0 0-.506.854l-.837 2.87a.5.5 0 0 0 .62.62l2.87-.837a2 2 0 0 0 .854-.506z" /> </svg><b>Образцы</b> программы, журнала и договора</div>
    </div>
  </div>
</div>

<section class="s" id="glavnoe">
  <div class="wrap">
    <div class="head"><div class="eyebrow" data-eyebrow>Коротко</div><h2 data-split>Что нужно знать о требованиях <em><span class="nw">к пест-контролю</span> в 2026 году</em></h2></div>
    <ol class="nb-five" data-group="cards">
      <li class="card"><span class="nb-ic" aria-hidden="true"><svg aria-hidden="true" focusable="false" class="lucide lucide-factory" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M12 16h.01" /> <path d="M16 16h.01" /> <path d="M3 19a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V8.5a.5.5 0 0 0-.769-.422l-4.462 2.844A.5.5 0 0 1 15 10.5v-2a.5.5 0 0 0-.769-.422L9.77 10.922A.5.5 0 0 1 9 10.5V5a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2z" /> <path d="M8 16h.01" /> </svg></span><b>Дезинсекцию и дератизацию обеспечивает сам бизнес.</b> Юридические лица и ИП организуют на своих объектах профилактику, обследования, истребительные мероприятия и контроль их эффективности. Это можно делать своими силами или с привлечением специализированной организации (п. 88 СанПиН <span class="nw">3.3686-21</span>). <span class="nw">Санитарно-противоэпидемические</span> мероприятия обязательны для всех, кто ведёт деятельность (п. 3 ст. 29 Федерального закона № <span class="nw">52-ФЗ</span>).</li>
      <li class="card"><span class="nb-ic" aria-hidden="true"><svg aria-hidden="true" focusable="false" class="lucide lucide-clock" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg></span><b>Для пищевых объектов, гостиниц, медицинских и детских организаций кратность выше.</b> Пищевые производства, общепит, хранение и торговля продуктами, гостиницы, медицинские и детские организации относятся к объектам особого эпидемиологического значения (п. 98). Их обследуют на насекомых не реже 2 раз в месяц (п. 101), а дератизацию проводят по результатам ежемесячной оценки (п. 110).</li>
      <li class="card"><span class="nb-ic" aria-hidden="true"><svg aria-hidden="true" focusable="false" class="lucide lucide-ban" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="m4.9 4.9 14.2 14.2"/></svg></span><b>На пищевых объектах грызунов и насекомых быть не должно.</b> В торговле продуктами, общепите и пищевой промышленности их наличие не допускается (п. 128 СанПиН <span class="nw">3.3686-21</span>).</li>
      <li class="card"><span class="nb-ic" aria-hidden="true"><svg aria-hidden="true" focusable="false" class="lucide lucide-file-badge" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M13 22h5a2 2 0 0 0 2-2V8a2.4 2.4 0 0 0-.706-1.706l-3.588-3.588A2.4 2.4 0 0 0 14 2H6a2 2 0 0 0-2 2v3.3" /> <path d="M14 2v5a1 1 0 0 0 1 1h5" /> <path d="m7.69 16.479 1.29 4.88a.5.5 0 0 1-.698.591l-1.843-.849a1 1 0 0 0-.879.001l-1.846.85a.5.5 0 0 1-.692-.593l1.29-4.88" /> <circle cx="6" cy="14" r="3" /> </svg></span><b>Исполнитель — только с лицензией.</b> С 1 марта 2025 года услуги по дезинфекции, дезинсекции и дератизации лицензируются. Без лицензии можно работать только для собственных нужд (<span class="nw">99-ФЗ</span>, постановление Правительства РФ № 337). Лицензию подрядчика проверяют в <a href="https://fp.rospotrebnadzor.ru/licen/" target="_blank" rel="noopener">реестре Роспотребнадзора</a>.</li>
      <li class="card"><span class="nb-ic" aria-hidden="true"><svg aria-hidden="true" focusable="false" class="lucide lucide-calendar-clock" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M21 7.5V6a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h3.5" /> <path d="M16 2v4" /> <path d="M8 2v4" /> <path d="M3 10h5" /> <path d="M17.5 17.5 16 16.3V14" /> <circle cx="16" cy="16" r="6" /> </svg></span><b>Два главных СанПиН заканчивают действие в 2027 году:</b> СанПиН <span class="nw">2.1.3684-21</span> — 1 марта, СанПиН <span class="nw">3.3686-21</span> — 1 сентября. После утверждения новых правил программы производственного контроля и договоры нужно будет обновить.</li>
    </ol>
  </div>
</section>

<section class="s" id="periodichnost">
  <div class="wrap">
    <div class="head"><div class="eyebrow" data-eyebrow>Периодичность</div><h2 data-split>Как часто проводить <em>дезинсекцию и дератизацию</em></h2><p class="sub" data-fade>Кратность установлена разделом III СанПиН <span class="nw">3.3686-21</span>. Норма говорит об обследованиях — осмотре, учёте вредителей и проверке точек контроля. Обработки назначают по их результатам.</p></div>
    <figure class="nb-fig nb-month" data-fade>
      <figcaption class="nb-fig-head"><span class="nb-fig-t">Месяц на объекте <em>особого значения</em></span><span class="nb-fig-d">Общепит, пищевые производства, торговля продуктами, гостиницы, медицинские и детские организации (п. 98 СанПиН <span class="nw">3.3686-21</span>). Недели условные: норма задаёт кратность, а не дни.</span></figcaption>
      <div class="nb-cal" aria-hidden="true">
        <div class="nb-cal-row nb-cal-hd"><div class="nb-cal-r"></div><div class="nb-cal-h">Неделя 1</div><div class="nb-cal-h">Неделя 2</div><div class="nb-cal-h">Неделя 3</div><div class="nb-cal-h">Неделя 4</div></div>
        <div class="nb-cal-row"><div class="nb-cal-r"><b>Насекомые</b><small>не реже 2 раз в месяц · п. 101</small></div><div class="nb-cal-c"><span class="nb-dot is-ins"><b>1</b><span class="nb-dot-w">Неделя 1 · </span>обследование</span></div><div class="nb-cal-c"></div><div class="nb-cal-c"><span class="nb-dot is-ins"><b>2</b><span class="nb-dot-w">Неделя 3 · </span>обследование</span></div><div class="nb-cal-c"></div></div>
        <div class="nb-cal-row"><div class="nb-cal-r"><b>Грызуны</b><small>ежемесячно · п. 110</small></div><div class="nb-cal-c"><span class="nb-dot is-rod"><b>1</b><span class="nb-dot-w">Неделя 1 · </span>оценка заселённости</span></div><div class="nb-cal-c"></div><div class="nb-cal-c"></div><div class="nb-cal-c"></div></div>
        <div class="nb-cal-row"><div class="nb-cal-r"><b>Мусорокамеры</b><small>не реже 1 раза в месяц · п. 133</small></div><div class="nb-cal-c"></div><div class="nb-cal-c"></div><div class="nb-cal-c"><span class="nb-dot is-bin"><b>1</b><span class="nb-dot-w">Неделя 3 · </span>обследование</span></div><div class="nb-cal-c"></div></div>
        <div class="nb-cal-row"><div class="nb-cal-r"><b>Обработки</b><small>по результатам обследований</small></div><div class="nb-cal-c"></div><div class="nb-cal-c"><span class="nb-dot is-tr"><b>?</b><span class="nb-dot-w">Неделя 2 · </span>если нашли вредителей</span></div><div class="nb-cal-c"></div><div class="nb-cal-c"><span class="nb-dot is-tr"><b>?</b><span class="nb-dot-w">Неделя 4 · </span>контроль эффекта</span></div></div>
      </div>
      <p class="nb-fig-note">Другие объекты: насекомые — 1 раз в месяц, открытые территории — 1 раз в месяц, очаги — 1 раз в неделю (п. 101).</p>
    </figure>
    <table class="d-table nb-tbl nb-freq" data-fade>
      <thead><tr><th scope="col">Что и где</th><th scope="col">Как часто</th><th scope="col">Норма</th></tr></thead>
      <tbody>
        <tr><td data-l="Что и где">Обследования на насекомых на объектах особого эпидемиологического значения: пищевые производства, общепит, хранение и торговля продуктами, гостиницы, медицинские и детские организации и другие объекты из п. 98</td><td data-l="Как часто"><b class="nb-val">Не реже 2 раз в месяц</b></td><td data-l="Норма">п. 101</td></tr>
        <tr><td data-l="Что и где">Обследования на насекомых на других объектах; в п. 101 в скобках названы места общего пользования многоквартирных домов и общежитий</td><td data-l="Как часто"><b class="nb-val">1 раз в месяц</b></td><td data-l="Норма">п. 101</td></tr>
        <tr><td data-l="Что и где">Открытые территории</td><td data-l="Как часто"><b class="nb-val">1 раз в месяц</b></td><td data-l="Норма">п. 101</td></tr>
        <tr><td data-l="Что и где">Очаги инфекционных и паразитарных заболеваний, анофелогенные водоёмы</td><td data-l="Как часто"><b class="nb-val">1 раз в неделю</b></td><td data-l="Норма">п. 101</td></tr>
        <tr><td data-l="Что и где">Оценка заселённости грызунами на объектах особого эпидемиологического значения; дератизацию проводят по её результатам</td><td data-l="Как часто"><b class="nb-val">Ежемесячно</b></td><td data-l="Норма">п. 110</td></tr>
        <tr><td data-l="Что и где">Системы мусороудаления, включая мусоросборные камеры; при обнаружении вредителей обработку проводят незамедлительно</td><td data-l="Как часто"><b class="nb-val">Не реже 1 раза в месяц</b></td><td data-l="Норма">п. 133</td></tr>
      </tbody>
    </table>
    <p class="nb-after" data-fade>Если дезинсекция не дала результата, проверяют качество препарата и повторяют обработку инсектицидами из другой группы химических веществ (п. 99). Как инспекторы спрашивают о кратности — в <a href="../normativnaya-baza/proverochnye-listy/">разборе проверочных листов</a>.</p>
  </div>
</section>

<section class="s" id="dokumenty">
  <div class="wrap">
    <div class="head"><div class="eyebrow" data-eyebrow>Действующие документы</div><h2 data-split>Действующие документы <em>о дезинсекции и дератизации</em></h2><p class="sub" data-fade>Что в каждом документе важно <span class="nw">для пест-контроля</span>, сроки действия и ссылки на официальные тексты.</p></div>

    <figure class="nb-fig nb-tiers" data-fade>
      <figcaption class="nb-fig-head"><span class="nb-fig-t">От закона <em>до журнала</em></span><span class="nb-fig-d">Нажмите на документ — откроется его группа в таблице ниже или образец на сайте.</span></figcaption>
      <ol class="nb-tier-list">
        <li class="nb-tier"><div class="nb-tier-n"><b>Законы</b><small>обязанность, лицензия, ответственность</small></div><div class="nb-tier-ch"><a class="nb-chip" href="#dok-osnovnye"><span class="nw">52-ФЗ</span></a><a class="nb-chip" href="#dok-licenziya"><span class="nw">99-ФЗ</span> — лицензирование</a><a class="nb-chip" href="#dok-otvetstvennost">КоАП РФ — ответственность</a></div></li>
        <li class="nb-tier"><div class="nb-tier-n"><b>Санитарные правила</b><small>что и как часто делать</small></div><div class="nb-tier-ch"><a class="nb-chip is-key" href="#dok-osnovnye">СанПиН <span class="nw">3.3686-21</span>, раздел III</a><a class="nb-chip" href="#dok-osnovnye">СанПиН <span class="nw">2.1.3684-21</span></a><a class="nb-chip" href="#dok-otraslevye">СанПиН <span class="nw">2.3/2.4.4282-26</span></a><a class="nb-chip" href="#dok-otraslevye">СП <span class="nw">2.3.6.4281-26</span></a><a class="nb-chip" href="#dok-otraslevye">СП <span class="nw">2.1.4284-26</span></a><a class="nb-chip" href="#dok-otraslevye">СП <span class="nw">2.4.2.4283-26</span></a></div></li>
        <li class="nb-tier"><div class="nb-tier-n"><b>Как проверяют</b><small>вопросы инспектора</small></div><div class="nb-tier-ch"><a class="nb-chip is-key" href="#dok-listy">Проверочные листы: приказы № 578 и № 580</a></div></li>
        <li class="nb-tier"><div class="nb-tier-n"><b>Стандарты и методики</b><small>ХАССП, GMP, рекомендации</small></div><div class="nb-tier-ch"><a class="nb-chip" href="#dok-haccp"><span class="nw">ТР ТС 021/2011</span></a><a class="nb-chip" href="#dok-haccp">ГОСТ Р <span class="nw">51705.1-2024</span></a><a class="nb-chip" href="#dok-haccp">ГОСТ Р <span class="nw">54762-2011</span></a><a class="nb-chip" href="#dok-haccp">Правила GMP ЕАЭС</a><a class="nb-chip" href="#dok-metodiki">МР <span class="nw">3.5.3.0374-25</span></a><a class="nb-chip" href="#dok-metodiki">МР <span class="nw">5.1.0098-14</span></a></div></li>
        <li class="nb-tier is-own"><div class="nb-tier-n"><b>Ваши документы</b><small>что покажете на проверке</small></div><div class="nb-tier-ch"><a class="nb-chip" href="../materialy/programma-proizvodstvennogo-kontrolya-haccp/">Программа производственного контроля</a><a class="nb-chip" href="../materialy/programma-pest-kontrolya/">Программа <span class="nw">пест-контроля</span></a><a class="nb-chip" href="../dogovor-deratizatsiya-dezinsektsiya/">Договор с лицензированным исполнителем</a><a class="nb-chip" href="../materialy/programma-pest-kontrolya/">Схема точек контроля</a><a class="nb-chip" href="../materialy/zhurnal-pest-kontrolya/">Журнал <span class="nw">пест-контроля</span></a><span class="nb-chip">Акты обследований</span></div></li>
      </ol>
    </figure>

    <h3 class="nb-h3" id="dok-osnovnye" data-fade>Основные санитарные правила</h3>
    <table class="d-table nb-tbl nb-docs" data-fade>
      <thead><tr><th scope="col">Документ</th><th scope="col">Что в нём <span class="nw">для пест-контроля</span></th><th scope="col">Действует</th><th scope="col">Официальный текст</th></tr></thead>
      <tbody>
        <tr><td data-l="Документ"><b class="nb-doc">Федеральный закон от 30.03.1999 № <span class="nw">52-ФЗ</span></b> «<span class="nw">О санитарно-эпидемиологическом</span> благополучии населения»</td><td data-l="Что в нём для пест-контроля">Ст. 29: <span class="nw">санитарно-противоэпидемические</span> мероприятия обязательны для граждан, ИП и юридических лиц</td><td data-l="Действует">Действует</td><td data-l="Официальный текст"><a href="https://base.garant.ru/483424596/7a69fb6632f5876efd3160114758a106/" target="_blank" rel="noopener">Гарант</a></td></tr>
        <tr><td data-l="Документ"><b class="nb-doc">СанПиН <span class="nw">3.3686-21</span></b> «<span class="nw">Санитарно-эпидемиологические</span> требования по профилактике инфекционных болезней», раздел III</td><td data-l="Что в нём для пест-контроля">П. 88 — обязанности организаций и ИП; п. 98 — перечень объектов особого эпидемиологического значения; п. 99 — контроль эффективности и смена средств; п. 101 — кратность обследований; п. 102 — подготовка помещений и информирование сотрудников; пп. 108–111 — дератизация; пп. 128–130 — пищевые объекты, торговля, места массового пребывания; п. 133 — мусороудаление</td><td data-l="Действует"><span class="nb-date">До 01.09.2027</span></td><td data-l="Официальный текст"><a href="http://pravo.gov.ru/proxy/ips/?docbody=&amp;nd=602107773" target="_blank" rel="noopener">pravo.gov.ru</a></td></tr>
        <tr><td data-l="Документ"><b class="nb-doc">СанПиН <span class="nw">2.1.3684-21</span></b> — содержание территорий, помещений, <span class="nw">санитарно-противоэпидемические</span> мероприятия</td><td data-l="Что в нём для пест-контроля">П. 8 и приложение № 1 — уборка, дезинсекция и дератизация контейнерных площадок</td><td data-l="Действует"><span class="nb-date">До 01.03.2027</span>; редакция от 10.09.2026 действует с 05.10.2026</td><td data-l="Официальный текст"><a href="http://pravo.gov.ru/proxy/ips/?doc_itself=&amp;backlink=1&amp;nd=602024221&amp;page=1&amp;rdk=3" target="_blank" rel="noopener">pravo.gov.ru</a>, <a href="https://cepportal.ru/upload/iblock/861/7puwfvg2ic1tb0gi5brmayq7ve2d3oav.pdf" target="_blank" rel="noopener">текст редакции</a></td></tr>
      </tbody>
    </table>

    <h3 class="nb-h3" id="dok-otraslevye" data-fade>Отраслевые правила 2026 года — действуют с 01.09.2026</h3>
    <table class="d-table nb-tbl nb-docs nb-3" data-fade>
      <thead><tr><th scope="col">Документ</th><th scope="col">Что в нём <span class="nw">для пест-контроля</span></th><th scope="col">Источник</th></tr></thead>
      <tbody>
        <tr><td data-l="Документ"><b class="nb-doc">СанПиН <span class="nw">2.3/2.4.4282-26</span></b> — общественное питание</td><td data-l="Что в нём для пест-контроля">П. 4 — производственный контроль на принципах ХАССП; п. 26 — в помещениях не должно быть насекомых, грызунов, синантропных птиц и животных; п. 45 — нельзя хранить и готовить продукцию во время обработок и применять распыляемые и рассыпаемые средства при посетителях и персонале</td><td data-l="Источник"><a href="https://www.garant.ru/products/ipo/prime/doc/414229257/" target="_blank" rel="noopener">Гарант</a>, <a href="https://base.garant.ru/414962758/f7ee959fd36b5699076b35abf4f52c5c/" target="_blank" rel="noopener">проверочный лист № 580, прил. 2</a></td></tr>
        <tr><td data-l="Документ"><b class="nb-doc">СП <span class="nw">2.3.6.4281-26</span></b> — торговля пищевой продукцией, рынки</td><td data-l="Что в нём для пест-контроля">П. 46 — сыпучие продукты хранят в помещениях, не заражённых амбарными вредителями; п. 72 — дератизация площадки накопления отходов; п. 78 — насекомые и грызуны не допускаются, нужны дезинсекция, дератизация и инженерная защита зданий</td><td data-l="Источник"><a href="https://cgon.rospotrebnadzor.ru/biznesu/articles/novye-sanitarnye-pravila-dlya-torgovykh-obektov-i-rynkov-realizuyushchikh-pishchevuyu-produktsiyu/" target="_blank" rel="noopener">ЦГОН Роспотребнадзора</a>, <a href="https://base.garant.ru/414962758/53f89421bbdaf741eb2d1ecc4ddb4c33/" target="_blank" rel="noopener">проверочный лист № 580, прил. 1</a></td></tr>
        <tr><td data-l="Документ"><b class="nb-doc">СП <span class="nw">2.1.4284-26</span></b> — эксплуатация помещений, гостиницы, услуги, медицинские организации</td><td data-l="Что в нём для пест-контроля">П. 14 — в помещениях не должно быть насекомых, грызунов и следов их жизнедеятельности; при их появлении обработки проводит организация, осуществляющая дезинфекционную деятельность, в отсутствие работников и потребителей. Пп. 14 и 21 — грызунонепроницаемость перекрытий и мест прохода коммуникаций (вопрос из листа для медицинских организаций)</td><td data-l="Источник"><a href="https://www.consultant.ru/law/hotdocs/94328.html" target="_blank" rel="noopener">КонсультантПлюс</a>, <a href="https://base.garant.ru/414956074/b89690251be5277812a78962f6302560/" target="_blank" rel="noopener">проверочный лист № 578, прил. 10</a></td></tr>
        <tr><td data-l="Документ"><b class="nb-doc">СП <span class="nw">2.4.2.4283-26</span></b> — детские и образовательные организации</td><td data-l="Что в нём для пест-контроля">Организация и контроль дезинфекции, дезинсекции и дератизации; в загородных лагерях перед сменой — противоклещевая обработка и борьба с грызунами</td><td data-l="Источник"><a href="https://base.garant.ru/414956074/8599a70d26e5983585d90ff6adf82e89/" target="_blank" rel="noopener">проверочный лист № 578, прил. 14</a></td></tr>
      </tbody>
    </table>

    <h3 class="nb-h3" id="dok-listy" data-fade>Проверочные листы</h3>
    <table class="d-table nb-tbl nb-docs" data-fade>
      <thead><tr><th scope="col">Документ</th><th scope="col">Что в нём</th><th scope="col">Действует</th><th scope="col">Текст</th></tr></thead>
      <tbody>
        <tr><td data-l="Документ"><b class="nb-doc">Приказ Роспотребнадзора от 20.07.2026 № 578</b> — 31 форма: торговля непродовольственными товарами, гостиницы, медицинские организации, аптеки, образование, отходы и другие</td><td data-l="Что в нём">Вопросы о насекомых и грызунах, кратности обследований и исполнителе работ</td><td data-l="Действует"><span class="nb-date">С 04.10.2026</span>; заменил приказ № 18 от 20.01.2022</td><td data-l="Текст"><a href="https://base.garant.ru/414956074/" target="_blank" rel="noopener">Гарант</a></td></tr>
        <tr><td data-l="Документ"><b class="nb-doc">Приказ Роспотребнадзора от 20.07.2026 № 580</b> — 6 форм: торговля пищевой продукцией, общепит, спорт, прачечные, салоны красоты, бани</td><td data-l="Что в нём">Те же вопросы плюс запреты при обработках в общепите и амбарные вредители в торговле</td><td data-l="Действует"><span class="nb-date">С 05.10.2026</span>; заменил приказ № 808 от 24.12.2021</td><td data-l="Текст"><a href="http://publication.pravo.gov.ru/document/0001202609240001" target="_blank" rel="noopener">официальная публикация</a>, <a href="https://base.garant.ru/414962758/" target="_blank" rel="noopener">Гарант</a></td></tr>
      </tbody>
    </table>
    <p class="nb-after" data-fade>Разбор всех вопросов о вредителях по видам объектов — на странице <a href="../normativnaya-baza/proverochnye-listy/">«Проверочные листы 2026»</a>.</p>

    <h3 class="nb-h3" id="dok-licenziya" data-fade>Лицензия и требования к исполнителю</h3>
    <table class="d-table nb-tbl nb-docs" data-fade>
      <thead><tr><th scope="col">Документ</th><th scope="col">Что в нём</th><th scope="col">Действует</th><th scope="col">Текст</th></tr></thead>
      <tbody>
        <tr><td data-l="Документ"><b class="nb-doc"><span class="nw">99-ФЗ</span> «О лицензировании отдельных видов деятельности»</b>, пп. 59 п. 1 ст. 12; Положение о лицензировании — постановление Правительства РФ от 20.03.2024 № 337</td><td data-l="Что в нём">Лицензия на услуги по дезинфекции, дезинсекции и дератизации. Не нужна, если работы выполняют для собственных нужд</td><td data-l="Действует"><span class="nb-date">С 01.03.2025</span></td><td data-l="Текст"><a href="https://cgon.rospotrebnadzor.ru/biznesu/profilaktika-nadzor-uslsugi/nadzornie-meropriatiya/litsenzirovanie-dezinfektsionnoy-deyatelnosti/" target="_blank" rel="noopener">ЦГОН Роспотребнадзора</a>, <a href="https://43.rospotrebnadzor.ru/news/detail.php?ID=12430" target="_blank" rel="noopener">Роспотребнадзор по Кировской области</a></td></tr>
        <tr><td data-l="Документ"><b class="nb-doc">Реестр лицензий Роспотребнадзора</b></td><td data-l="Что в нём">Проверка лицензии подрядчика</td><td data-l="Действует">—</td><td data-l="Текст"><a href="https://fp.rospotrebnadzor.ru/licen/" target="_blank" rel="noopener">fp.rospotrebnadzor.ru</a></td></tr>
        <tr><td data-l="Документ"><b class="nb-doc">Приказ Роспотребнадзора от 30.05.2024 № 415</b></td><td data-l="Что в нём">Форма программы производственного контроля для организаций, которые оказывают эти услуги</td><td data-l="Действует"><span class="nb-date">01.09.2024–01.09.2030</span></td><td data-l="Текст"><a href="http://www.pravo.gov.ru/proxy/ips/?docbody=&amp;prevDoc=602107773&amp;backlink=1&amp;nd=607119571&amp;rdk=" target="_blank" rel="noopener">pravo.gov.ru</a></td></tr>
      </tbody>
    </table>

    <h3 class="nb-h3" id="dok-metodiki" data-fade>Методические документы</h3>
    <table class="d-table nb-tbl nb-docs nb-3" data-fade>
      <thead><tr><th scope="col">Документ</th><th scope="col">Что в нём</th><th scope="col">Текст</th></tr></thead>
      <tbody>
        <tr><td data-l="Документ"><b class="nb-doc">МР <span class="nw">3.5.3.0374-25</span></b> «Дератизация. Организация и проведение дератизационных мероприятий»</td><td data-l="Что в нём">Утверждены 28.04.2025 взамен МУ <span class="nw">3.5.3.2949-11</span>. Виды дератизации, ежемесячные мероприятия на объектах особого эпидемиологического значения, учёт <span class="nw">в контрольно-учётной</span> карте объекта</td><td data-l="Текст"><a href="https://legalacts.ru/doc/mr-3530374-25-353-deratizatsija-organizatsija-i-provedenie-deratizatsionnykh-meroprijatii/" target="_blank" rel="noopener">legalacts.ru</a></td></tr>
        <tr><td data-l="Документ"><b class="nb-doc">МР <span class="nw">5.1.0098-14</span></b> «Методические подходы к организации оценки процессов производства (изготовления) пищевой продукции на основе принципов ХАССП»</td><td data-l="Что в нём">Утверждены 18.12.2014. По процедуре дезинсекции и дератизации инспектор запрашивает инструкции, договоры, акты <span class="nw">сдачи-приёмки</span>, журналы, графики и осматривает объект</td><td data-l="Текст"><a href="http://79.rospotrebnadzor.ru/upload/iblock_content/028bdce347a503c6ca4b9b2ce907161a.pdf" target="_blank" rel="noopener">Роспотребнадзор, PDF</a></td></tr>
      </tbody>
    </table>

    <h3 class="nb-h3" id="dok-haccp" data-fade>Пищевая безопасность, ХАССП и GMP</h3>
    <table class="d-table nb-tbl nb-docs nb-3" data-fade>
      <thead><tr><th scope="col">Документ</th><th scope="col">Что в нём <span class="nw">для пест-контроля</span></th><th scope="col">Текст</th></tr></thead>
      <tbody>
        <tr><td data-l="Документ"><b class="nb-doc"><span class="nw">ТР ТС 021/2011</span></b> «О безопасности пищевой продукции»</td><td data-l="Что в нём для пест-контроля">Ст. 10 ч. 3 п. 10 — процедура на принципах ХАССП: выбрать способы, установить периодичность и проводить дезинсекцию и дератизацию производственных помещений. Ст. 17 — защита продукции от грызунов и насекомых при хранении и перевозке</td><td data-l="Текст"><a href="https://docs.cntd.ru/document/902320560" target="_blank" rel="noopener">Техэксперт</a>, <a href="http://78.rospotrebnadzor.ru/dlya-predprinimateley/svedeniya-ob-isklyuchenii-iz-plana-planovykh-proverok/8075/?print=Y" target="_blank" rel="noopener">Роспотребнадзор <span class="nw">по Санкт-Петербургу</span></a></td></tr>
        <tr><td data-l="Документ"><b class="nb-doc">ГОСТ Р <span class="nw">51705.1-2024</span></b> «Системы менеджмента качества. Управление качеством и безопасностью пищевых продуктов на основе принципов ХАССП. Общие требования»</td><td data-l="Что в нём для пест-контроля">Введён с 01.11.2024 взамен ГОСТ Р <span class="nw">51705.1-2001</span></td><td data-l="Текст"><a href="https://base.garant.ru/409077162/" target="_blank" rel="noopener">Гарант</a></td></tr>
        <tr><td data-l="Документ"><b class="nb-doc">ГОСТ Р <span class="nw">54762-2011</span>/ISO/TS <span class="nw">22002-1</span>:2009</b> «Программы предварительных требований по безопасности пищевой продукции. Часть 1. Производство пищевой продукции»</td><td data-l="Что в нём для пест-контроля">Раздел 12 «Борьба с вредителями»: программы борьбы с вредителями, защита от проникновения</td><td data-l="Текст"><a href="https://base.garant.ru/70754062/" target="_blank" rel="noopener">Гарант</a></td></tr>
        <tr><td data-l="Документ"><b class="nb-doc">Правила надлежащей производственной практики ЕАЭС</b> (решение Совета ЕЭК от 03.11.2016 № 77)</td><td data-l="Что в нём для пест-контроля">П. 3.4: помещения должны максимально защищать от проникновения насекомых и животных</td><td data-l="Текст"><a href="https://base.garant.ru/483423312/" target="_blank" rel="noopener">Гарант</a></td></tr>
      </tbody>
    </table>

    <h3 class="nb-h3" id="dok-otvetstvennost" data-fade>Ответственность</h3>
    <table class="d-table nb-tbl nb-docs nb-3" data-fade>
      <thead><tr><th scope="col">Документ</th><th scope="col">Что в нём</th><th scope="col">Текст</th></tr></thead>
      <tbody>
        <tr><td data-l="Документ"><b class="nb-doc">КоАП РФ, ст. 6.3, 6.4, 6.6, 14.43, 19.5</b></td><td data-l="Что в нём">Штрафы и приостановление деятельности за санитарные нарушения, нарушение технических регламентов и невыполнение предписания. Суммы — в таблице на <a href="../sanitarnyy-audit/">странице санитарного аудита</a></td><td data-l="Текст"><a href="https://www.consultant.ru/document/cons_doc_LAW_34661/c967eb7a901005316559be99424c3a824dc426b0/" target="_blank" rel="noopener">ст. 6.3</a>, <a href="https://www.consultant.ru/document/cons_doc_LAW_34661/0d733d8a9e018c4840564cff41afbe7d0776aa5b/" target="_blank" rel="noopener">ст. 6.4</a>, <a href="https://www.consultant.ru/document/cons_doc_LAW_34661/dceffcf2617aa8cbad91f46398ce0beab3d0ea76/" target="_blank" rel="noopener">ст. 6.6</a></td></tr>
      </tbody>
    </table>
  </div>
</section>

<section class="s" id="izmeneniya">
  <div class="wrap">
    <div class="head"><div class="eyebrow" data-eyebrow>Хроника</div><h2 data-split>Что меняется <em>в 2026–2027 годах</em></h2><p class="sub" data-fade>Прошедшие события отмечены серым, предстоящие — цветом.</p></div>
    <figure class="nb-fig nb-road-fig" data-fade>
      <figcaption class="nb-fig-head"><span class="nb-fig-t">Дорожная карта норм <em>2025–2027</em></span><span class="nb-fig-d">Серым — то, что уже действует, цветом — предстоящие сроки.</span></figcaption>
      <ol class="nb-road" id="nbRoad">
        <li class="nb-road-axis" aria-hidden="true"><i class="nb-road-fill" style="width:55.6%"></i></li>
        <li class="nb-road-pt is-up is-past" data-d="2025-03-01" style="--x:6%;--o:0"><time datetime="2025-03-01">01.03.2025</time><span>Услуги по дезинсекции и дератизации — только по лицензии</span></li>
        <li class="nb-road-pt is-down is-past" data-d="2026-09-01" style="--x:22%;--o:2"><time datetime="2026-09-01">01.09.2026</time><span>Новые правила для общепита, торговли, помещений и условий труда</span></li>
        <li class="nb-road-pt is-up is-past" data-d="2026-10-04" style="--x:38%;--o:4"><time datetime="2026-10-04">04–05.10.2026</time><span>Начали применяться новые проверочные листы</span></li>
        <li class="nb-road-pt is-down is-past" data-d="2026-10-05" style="--x:51%;--o:6"><time datetime="2026-10-05">05.10.2026</time><span>Новая редакция СанПиН <span class="nw">2.1.3684-21</span></span></li>
        <li class="nb-road-pt is-up is-next" data-d="2027-03-01" style="--x:72%;--o:8"><time datetime="2027-03-01">01.03.2027</time><span>Заканчивается срок СанПиН <span class="nw">2.1.3684-21</span></span></li>
        <li class="nb-road-pt is-down is-next" data-d="2027-09-01" style="--x:90%;--o:10"><time datetime="2027-09-01">01.09.2027</time><span>Заканчивается срок СанПиН <span class="nw">3.3686-21</span></span></li>
        <li class="nb-road-now" aria-hidden="true" style="--x:55.6%;--o:7"><span>Сверка норм · 06.11.2026</span></li>
      </ol>
    </figure>
    <ol class="nb-tl" data-fade>
      <li class="is-past"><time class="nb-tl-d" datetime="2026-09-01">01.09.2026</time><p class="nb-tl-w">Вступили в силу правила для общепита, торговли, помещений и условий труда</p><p class="nb-tl-a"><span class="nb-tl-k">Что сделать</span>Обновить ссылки в программе производственного контроля и программе <span class="nw">пест-контроля</span></p></li>
      <li class="is-past"><time class="nb-tl-d" datetime="2026-10-04">04–05.10.2026</time><p class="nb-tl-w">Начали применяться новые проверочные листы</p><p class="nb-tl-a"><span class="nb-tl-k">Что сделать</span>Пройти вопросы своей формы — <a href="../normativnaya-baza/proverochnye-listy/">разбор проверочных листов</a></p></li>
      <li class="is-past"><time class="nb-tl-d" datetime="2026-10-05">05.10.2026</time><p class="nb-tl-w">Вступила в силу редакция СанПиН <span class="nw">2.1.3684-21</span> от 10.09.2026</p><p class="nb-tl-a"></p></li>
      <li class="is-next"><time class="nb-tl-d" datetime="2027-03-01">01.03.2027</time><p class="nb-tl-w">Заканчивается срок СанПиН <span class="nw">2.1.3684-21</span>. В июле 2026 года разработан проект замены (<a href="https://cntd.ru/news/read/rospotrebnadzor-planiruet-aktualizirovat-sanitarnye-pravila-k-vode-vozduxu-pocvam-ziliu-otxodam" target="_blank" rel="noopener">Техэксперт</a>)</p><p class="nb-tl-a"><span class="nb-tl-k">Что сделать</span>После утверждения сверить ссылки в программах и договоре</p></li>
      <li class="is-next"><time class="nb-tl-d" datetime="2027-09-01">01.09.2027</time><p class="nb-tl-w">Заканчивается срок СанПиН <span class="nw">3.3686-21</span>. Изменения, подготовленные в марте 2026 года, раздел о дезинсекции и дератизации не затрагивают (<a href="https://www.garant.ru/products/ipo/prime/doc/56948554/" target="_blank" rel="noopener">Гарант</a>)</p><p class="nb-tl-a"><span class="nb-tl-k">Что сделать</span>Мы отслеживаем проекты и обновим эту страницу и образцы документов после публикации новых правил</p></li>
      <li class="is-next"><time class="nb-tl-d" datetime="2030-09-01">01.09.2030</time><p class="nb-tl-w">Заканчивается срок формы программы производственного контроля для исполнителей (приказ № 415)</p><p class="nb-tl-a"></p></li>
    </ol>
  </div>
</section>

<section class="s" id="otmenennye">
  <div class="wrap">
    <div class="head"><div class="eyebrow" data-eyebrow>Отменённые документы</div><h2 data-split>Документы, которые <em>больше не действуют</em></h2><p class="sub" data-fade>Если программа производственного контроля, программа <span class="nw">пест-контроля</span> или договор ссылаются на эти документы, их пора обновить: инспектор и аудитор торговой сети увидят, что документы давно не пересматривали.</p></div>
    <table class="d-table nb-tbl nb-old" data-fade>
      <thead><tr><th scope="col">Устаревший документ</th><th scope="col">Чем заменён</th><th scope="col">С какой даты</th></tr></thead>
      <tbody>
        <tr><td data-l="Устаревший документ"><s>СП <span class="nw">3.5.3.3223-14</span></s> «<span class="nw">Санитарно-эпидемиологические</span> требования к организации и проведению дератизационных мероприятий»</td><td data-l="Чем заменён">СанПиН <span class="nw">3.3686-21</span>, раздел III</td><td data-l="С какой даты">01.09.2021 (<a href="https://docs.cntd.ru/document/420223924" target="_blank" rel="noopener">Техэксперт</a>)</td></tr>
        <tr><td data-l="Устаревший документ"><s>СанПиН <span class="nw">3.5.2.1376-03</span></s>, затем <s>СанПиН <span class="nw">3.5.2.3472-17</span></s> (дезинсекция)</td><td data-l="Чем заменён">СанПиН <span class="nw">3.3686-21</span>, раздел III</td><td data-l="С какой даты"><span class="nw">3472-17</span> утратил силу 01.09.2021 (<a href="https://www.normacs.ru/Doclist/doc/15NM.html" target="_blank" rel="noopener">NormaCS</a>, <a href="https://www.kontur-extern.ru/info/normativ/document/9/300950-postanovlenie-glavnogo-gosudarstvennogo-sanitarnogo-vracha-rf-ot-07-06-2017-n-83" target="_blank" rel="noopener">Контур</a>)</td></tr>
        <tr><td data-l="Устаревший документ"><s>МУ <span class="nw">3.5.3.2949-11</span></s> «Борьба с грызунами в населённых пунктах, на железнодорожном, водном, воздушном транспорте»</td><td data-l="Чем заменён">МР <span class="nw">3.5.3.0374-25</span></td><td data-l="С какой даты">Утверждены 28.04.2025</td></tr>
        <tr><td data-l="Устаревший документ"><s>СанПиН <span class="nw">2.3/2.4.3590-20</span></s> (общественное питание)</td><td data-l="Чем заменён">СанПиН <span class="nw">2.3/2.4.4282-26</span></td><td data-l="С какой даты">01.09.2026</td></tr>
        <tr><td data-l="Устаревший документ"><s>СП <span class="nw">2.3.6.3668-20</span></s> (торговля пищевой продукцией)</td><td data-l="Чем заменён">СП <span class="nw">2.3.6.4281-26</span></td><td data-l="С какой даты">01.09.2026</td></tr>
        <tr><td data-l="Устаревший документ"><s>СП <span class="nw">2.1.3678-20</span></s> (помещения и услуги)</td><td data-l="Чем заменён">СП <span class="nw">2.1.4284-26</span></td><td data-l="С какой даты">01.09.2026</td></tr>
        <tr><td data-l="Устаревший документ"><s>ГОСТ Р <span class="nw">51705.1-2001</span></s> (ХАССП)</td><td data-l="Чем заменён">ГОСТ Р <span class="nw">51705.1-2024</span></td><td data-l="С какой даты">01.11.2024</td></tr>
        <tr><td data-l="Устаревший документ">Приказы Роспотребнадзора <s>№ 18 от 20.01.2022</s> и <s>№ 808 от 24.12.2021</s> (проверочные листы)</td><td data-l="Чем заменён">Приказы № 578 и № 580 от 20.07.2026</td><td data-l="С какой даты">04–05.10.2026</td></tr>
      </tbody>
    </table>
  </div>
</section>

<section class="s" id="obekty">
  <div class="wrap">
    <div class="head"><div class="eyebrow" data-eyebrow>Ваш объект</div><h2 data-split>Какие требования применяются <em>к вашему объекту</em></h2></div>
    <figure class="nb-fig nb-objs-fig">
      <figcaption class="nb-fig-head"><span class="nb-fig-t">Выберите <em>вид объекта</em></span><span class="nb-fig-d">Подробно о требованиях и проверках — на странице отрасли.</span></figcaption>
      <div class="nb-objs" data-group="cards">
        <a class="card nb-obj" href="../pishchevoe-proizvodstvo/"><span class="nb-obj-img"><img src="../img/ind-bakery-480.webp" width="480" height="289" loading="lazy" decoding="async" alt="Цех хлебозавода с инсектицидной лампой и станцией контроля грызунов"></span><span class="nb-obj-t"><b>Пищевое производство</b><small><span class="nw">ТР ТС 021/2011</span> и ХАССП</small></span></a>
        <a class="card nb-obj" href="../restorany-i-kafe/"><span class="nb-obj-img"><img src="../img/ind-kitchen-480.webp" width="480" height="289" loading="lazy" decoding="async" alt="Специалист осматривает кухню ресторана после закрытия"></span><span class="nb-obj-t"><b>Рестораны и кафе</b><small>СанПиН <span class="nw">2.3/2.4.4282-26</span></small></span></a>
        <a class="card nb-obj" href="../magaziny-i-torgovye-seti/"><span class="nb-obj-img"><img src="../img/ind-retail-480.webp" width="480" height="289" loading="lazy" decoding="async" alt="Торговый зал продуктового магазина с холодильными витринами"></span><span class="nb-obj-t"><b>Магазины и сети</b><small>СП <span class="nw">2.3.6.4281-26</span></small></span></a>
        <a class="card nb-obj" href="../gostinitsy/"><span class="nb-obj-img"><img src="../img/ind-hotel-room-480.webp" width="480" height="289" loading="lazy" decoding="async" alt="Специалист проверяет швы матраса в гостиничном номере"></span><span class="nb-obj-t"><b>Гостиницы</b><small>СП <span class="nw">2.1.4284-26</span></small></span></a>
        <a class="card nb-obj" href="../sklady-i-logistika/"><span class="nb-obj-img"><img src="../img/ind-warehouse-480.webp" width="480" height="289" loading="lazy" decoding="async" alt="Высотные стеллажи с коробками на складе"></span><span class="nb-obj-t"><b>Склады</b><small>СанПиН <span class="nw">3.3686-21</span></small></span></a>
        <a class="card nb-obj" href="../farmatsevticheskie-proizvodstva/"><span class="nb-obj-img"><img src="../img/ind-pharma-480.webp" width="480" height="289" loading="lazy" decoding="async" alt="Коридор фармацевтического производства со станцией мониторинга"></span><span class="nb-obj-t"><b>Фармацевтика</b><small>Правила GMP ЕАЭС</small></span></a>
      </div>
    </figure>
    <table class="d-table nb-tbl nb-obj" data-fade>
      <thead><tr><th scope="col">Объект</th><th scope="col">Основные требования</th><th scope="col">Проверочный лист</th></tr></thead>
      <tbody>
        <tr><td data-l="Объект"><a href="../pishchevoe-proizvodstvo/">Пищевое производство</a></td><td data-l="Основные требования">СанПиН <span class="nw">3.3686-21</span> (пп. 98, 101, 110, 128); <span class="nw">ТР ТС 021/2011</span>, ст. 10; ГОСТ Р <span class="nw">54762-2011</span>, раздел 12</td><td data-l="Проверочный лист">Отдельной формы в приказах № 578 и № 580 нет. Процедуры ХАССП оценивают по МР <span class="nw">5.1.0098-14</span></td></tr>
        <tr><td data-l="Объект"><a href="../restorany-i-kafe/">Ресторан, кафе, столовая</a></td><td data-l="Основные требования">СанПиН <span class="nw">2.3/2.4.4282-26</span> (пп. 4, 26, 45); СанПиН <span class="nw">3.3686-21</span> (пп. 98, 101, 110, 128)</td><td data-l="Проверочный лист">№ 580, приложение 2. Питание детей — № 578, приложение 24</td></tr>
        <tr><td data-l="Объект"><a href="../magaziny-i-torgovye-seti/">Магазин продуктов, рынок</a></td><td data-l="Основные требования">СП <span class="nw">2.3.6.4281-26</span> (пп. 46, 72, 78); <span class="nw">ТР ТС 021/2011</span>, ст. 17; СанПиН <span class="nw">3.3686-21</span> (п. 128)</td><td data-l="Проверочный лист">№ 580, приложение 1</td></tr>
        <tr><td data-l="Объект"><a href="../sklady-i-logistika/">Склад пищевой продукции</a></td><td data-l="Основные требования">СанПиН <span class="nw">3.3686-21</span> (пп. 98, 101, 110, 128); <span class="nw">ТР ТС 021/2011</span>, ст. 17</td><td data-l="Проверочный лист">Отдельной формы нет</td></tr>
        <tr><td data-l="Объект"><a href="../gostinitsy/">Гостиница</a></td><td data-l="Основные требования">СП <span class="nw">2.1.4284-26</span> (п. 14); СанПиН <span class="nw">3.3686-21</span> (пп. 101, 110, 130, 133)</td><td data-l="Проверочный лист">№ 578, приложение 2</td></tr>
        <tr><td data-l="Объект">Медицинская организация</td><td data-l="Основные требования">СП <span class="nw">2.1.4284-26</span> (пп. 14, 21, 24, 44); СанПиН <span class="nw">3.3686-21</span> (п. 110)</td><td data-l="Проверочный лист">№ 578, приложение 10</td></tr>
        <tr><td data-l="Объект">Аптека</td><td data-l="Основные требования">СП <span class="nw">2.1.4284-26</span> (п. 14); СанПиН <span class="nw">3.3686-21</span> (пп. 101, 108, 110)</td><td data-l="Проверочный лист">№ 578, приложение 11</td></tr>
        <tr><td data-l="Объект">Магазин непродовольственных товаров</td><td data-l="Основные требования">СП <span class="nw">2.1.4284-26</span> (п. 14); СанПиН <span class="nw">3.3686-21</span> (пп. 98, 108)</td><td data-l="Проверочный лист">№ 578, приложение 1</td></tr>
        <tr><td data-l="Объект"><a href="../farmatsevticheskie-proizvodstva/">Фармацевтическое производство</a></td><td data-l="Основные требования">Правила GMP ЕАЭС, п. 3.4</td><td data-l="Проверочный лист">—</td></tr>
      </tbody>
    </table>
    <p class="nb-after" data-fade>Это ориентир. На одном объекте может применяться несколько форм — например, в гостинице с рестораном. Номера вопросов о вредителях для каждой формы — в <a href="../normativnaya-baza/proverochnye-listy/#po-obektam">разборе проверочных листов</a>.</p>
  </div>
</section>

<section class="s" id="obraztsy">
  <div class="wrap">
    <div class="head"><div class="eyebrow" data-eyebrow>Разборы и образцы</div><h2 data-split>Разборы и образцы <em>документов</em></h2></div>
    <div class="nb-links" data-group="cards">
      <a class="card nb-link" href="../normativnaya-baza/proverochnye-listy/"><span class="nb-link-img is-photo"><img src="../img/pl-hero-mob-760.webp" srcset="../img/pl-hero-mob-760.webp 760w, ../img/pl-hero-mob.webp 1024w" sizes="(max-width:600px) 100vw, (max-width:1100px) 50vw, 33vw" width="760" height="570" loading="lazy" decoding="async" alt="Менеджер по качеству и специалист по пест-контролю проходят проверочный лист на складе"></span><span class="nb-link-k">Разбор</span><b>Проверочные листы 2026: вопросы о дезинсекции и дератизации</b><span class="nb-link-go">Читать →</span></a>
      <a class="card nb-link" href="../materialy/programma-pest-kontrolya/"><span class="nb-link-img is-doc"><img src="../img/programma-sample-p1-top-480.webp" srcset="../img/programma-sample-p1-top-480.webp 480w, ../img/programma-sample-p1-top-720.webp 720w" sizes="(max-width:600px) 100vw, (max-width:1100px) 50vw, 33vw" width="720" height="405" loading="lazy" decoding="async" alt="Первая страница образца программы пест-контроля"></span><span class="nb-link-k">Образец</span><b>Программа <span class="nw">пест-контроля</span></b><span class="nb-link-go">Смотреть образец →</span></a>
      <a class="card nb-link" href="../materialy/zhurnal-pest-kontrolya/"><span class="nb-link-img is-doc"><img src="../img/zhurnal-obrazets-p1-top-480.webp" srcset="../img/zhurnal-obrazets-p1-top-480.webp 480w, ../img/zhurnal-obrazets-p1-top-720.webp 720w" sizes="(max-width:600px) 100vw, (max-width:1100px) 50vw, 33vw" width="720" height="405" loading="lazy" decoding="async" alt="Первая страница образца журнала пест-контроля"></span><span class="nb-link-k">Образец</span><b>Журнал <span class="nw">пест-контроля</span></b><span class="nb-link-go">Смотреть образец →</span></a>
      <a class="card nb-link" href="../materialy/programma-proizvodstvennogo-kontrolya-haccp/"><span class="nb-link-img is-doc"><img src="../img/ppk-sample-p1-top-480.webp" srcset="../img/ppk-sample-p1-top-480.webp 480w, ../img/ppk-sample-p1-top-720.webp 720w" sizes="(max-width:600px) 100vw, (max-width:1100px) 50vw, 33vw" width="720" height="405" loading="lazy" decoding="async" alt="Титульный лист образца программы производственного контроля"></span><span class="nb-link-k">Образец</span><b>Программа производственного контроля по ХАССП</b><span class="nb-link-go">Смотреть образец →</span></a>
      <a class="card nb-link" href="../dogovor-deratizatsiya-dezinsektsiya/"><span class="nb-link-img is-doc"><img src="../img/dogovor-sample-p1-top-480.webp" srcset="../img/dogovor-sample-p1-top-480.webp 480w, ../img/dogovor-sample-p1-top-680.webp 680w" sizes="(max-width:600px) 100vw, (max-width:1100px) 50vw, 33vw" width="680" height="382" loading="lazy" decoding="async" alt="Первая страница образца договора на дератизацию и дезинсекцию"></span><span class="nb-link-k">Образец</span><b>Договор на дератизацию и дезинсекцию</b><span class="nb-link-go">Смотреть договор →</span></a>
      <a class="card nb-link" href="../sanitarnyy-audit/"><span class="nb-link-img is-photo"><img src="../img/san-hero-mob-760.webp" srcset="../img/san-hero-mob-760.webp 760w, ../img/san-hero-mob.webp 1024w" sizes="(max-width:600px) 100vw, (max-width:1100px) 50vw, 33vw" width="760" height="570" loading="lazy" decoding="async" alt="Санитарный врач с планшетом проверяет холодильник на кухне ресторана"></span><span class="nb-link-k">Услуга</span><b>Санитарный аудит: виды проверок и штрафы</b><span class="nb-link-go">Подробнее →</span></a>
    </div>
  </div>
</section>

<section class="s" id="avtor">
  <div class="wrap">
    <div class="head"><div class="eyebrow" data-eyebrow>Автор и сверка</div><h2 data-split>Кто подготовил <em>материал</em></h2></div>
    <div class="nb-author-wrap" data-fade>
      <div class="card nb-author">
        <img class="nb-avatar" src="../img/san-author-photo-240.webp" srcset="../img/san-author-photo-240.webp 240w, ../img/san-author-photo-480.webp 480w" sizes="(max-width:600px) 80px, 112px" width="240" height="240" loading="lazy" decoding="async" alt="Иллюстративное фото санитарного врача, изображение сгенерировано">
        <div><p class="nb-author-name">Марианна Семерина</p><p class="nb-author-role">Санитарный врач, автор материала</p><p class="nb-author-date">Сверено с официальными текстами — 06.11.2026</p><p class="nb-author-note">Фото иллюстративное</p></div>
      </div>
      <p class="nb-author-text">Материал подготовила Марианна Семерина, санитарный врач. Тексты норм сверены с официальными публикациями 06.11.2026. Если вы заметили неточность или изменение, которое мы пропустили, напишите нам — исправим.</p>
    </div>
  </div>
</section>

<section class="s" id="istochniki">
  <div class="wrap">
    <details class="nb-src">
      <summary><span class="eyebrow" data-eyebrow>Источники</span><span class="nb-src-t">Официальные тексты (проверено 06.11.2026)</span></summary>
      <ul class="nb-base" data-fade>
        <li>СанПиН <span class="nw">3.3686-21</span> — <a href="http://pravo.gov.ru/proxy/ips/?docbody=&amp;nd=602107773" target="_blank" rel="noopener">pravo.gov.ru</a></li>
        <li>СанПиН <span class="nw">2.1.3684-21</span> — <a href="http://pravo.gov.ru/proxy/ips/?doc_itself=&amp;backlink=1&amp;nd=602024221&amp;page=1&amp;rdk=3" target="_blank" rel="noopener">pravo.gov.ru</a>, <a href="https://cepportal.ru/upload/iblock/861/7puwfvg2ic1tb0gi5brmayq7ve2d3oav.pdf" target="_blank" rel="noopener">редакция от 10.09.2026</a></li>
        <li>Правила 2026 года — <a href="https://www.consultant.ru/law/hotdocs/94328.html" target="_blank" rel="noopener">КонсультантПлюс</a>, <a href="https://www.garant.ru/products/ipo/prime/doc/414229257/" target="_blank" rel="noopener">Гарант</a>, <a href="https://cgon.rospotrebnadzor.ru/biznesu/articles/novye-sanitarnye-pravila-dlya-torgovykh-obektov-i-rynkov-realizuyushchikh-pishchevuyu-produktsiyu/" target="_blank" rel="noopener">ЦГОН Роспотребнадзора</a></li>
        <li>Приказы № 578 и № 580 — <a href="https://base.garant.ru/414956074/" target="_blank" rel="noopener">Гарант: № 578</a>, <a href="https://base.garant.ru/414962758/" target="_blank" rel="noopener">Гарант: № 580</a>, <a href="http://publication.pravo.gov.ru/document/0001202609240001" target="_blank" rel="noopener">официальная публикация № 580</a>; даты вступления в силу — <a href="https://ppt.ru/obzory/vstupaet-v-silu/prikaz-rospotrebnadzora-20-07-2026-578" target="_blank" rel="noopener">ppt.ru: № 578</a>, <a href="https://ppt.ru/obzory/vstupaet-v-silu/prikaz-rospotrebnadzora-20-07-2026-580" target="_blank" rel="noopener">ppt.ru: № 580</a></li>
        <li>Лицензирование — <a href="https://cgon.rospotrebnadzor.ru/biznesu/profilaktika-nadzor-uslsugi/nadzornie-meropriatiya/litsenzirovanie-dezinfektsionnoy-deyatelnosti/" target="_blank" rel="noopener">ЦГОН Роспотребнадзора</a>, <a href="https://fp.rospotrebnadzor.ru/licen/" target="_blank" rel="noopener">реестр лицензий</a>, <a href="http://www.pravo.gov.ru/proxy/ips/?docbody=&amp;prevDoc=602107773&amp;backlink=1&amp;nd=607119571&amp;rdk=" target="_blank" rel="noopener">приказ № 415</a></li>
        <li>МР <span class="nw">3.5.3.0374-25</span> — <a href="https://legalacts.ru/doc/mr-3530374-25-353-deratizatsija-organizatsija-i-provedenie-deratizatsionnykh-meroprijatii/" target="_blank" rel="noopener">legalacts.ru</a>; МР <span class="nw">5.1.0098-14</span> — <a href="http://79.rospotrebnadzor.ru/upload/iblock_content/028bdce347a503c6ca4b9b2ce907161a.pdf" target="_blank" rel="noopener">Роспотребнадзор</a></li>
        <li><span class="nw">ТР ТС 021/2011</span> — <a href="https://docs.cntd.ru/document/902320560" target="_blank" rel="noopener">Техэксперт</a>; ГОСТ Р <span class="nw">51705.1-2024</span> — <a href="https://base.garant.ru/409077162/" target="_blank" rel="noopener">Гарант</a>; ГОСТ Р <span class="nw">54762-2011</span> — <a href="https://base.garant.ru/70754062/" target="_blank" rel="noopener">Гарант</a>; GMP ЕАЭС — <a href="https://base.garant.ru/483423312/" target="_blank" rel="noopener">Гарант</a></li>
        <li>Проекты и изменения — <a href="https://cntd.ru/news/read/rospotrebnadzor-planiruet-aktualizirovat-sanitarnye-pravila-k-vode-vozduxu-pocvam-ziliu-otxodam" target="_blank" rel="noopener">Техэксперт: замена СанПиН <span class="nw">2.1.3684-21</span></a>, <a href="https://www.garant.ru/products/ipo/prime/doc/56948554/" target="_blank" rel="noopener">Гарант: изменения СанПиН <span class="nw">3.3686-21</span></a></li>
        <li><span class="nw">52-ФЗ</span>, ст. 29 — <a href="https://base.garant.ru/483424596/7a69fb6632f5876efd3160114758a106/" target="_blank" rel="noopener">Гарант</a>; КоАП — ссылки в таблице «Ответственность»</li>
      </ul>
    </details>
  </div>
</section>

<section class="s" id="voprosy">
  <div class="wrap">
    <div class="head"><div class="eyebrow" data-eyebrow>Вопросы</div><h2 data-split>Вопросы <em>о нормативных требованиях</em></h2></div>
    <div class="faq">
      <div class="faq-col" data-group="faq">
        <div class="card qa"><button aria-expanded="false" aria-controls="a1" id="q1"><span>Какой документ главный по дезинсекции и дератизации в 2026 году?</span><span class="pm"></span></button><div class="ans" id="a1" role="region" aria-labelledby="q1"><div><p>СанПиН <span class="nw">3.3686-21</span> «<span class="nw">Санитарно-эпидемиологические</span> требования по профилактике инфекционных болезней», раздел III. Он действует до 1 сентября 2027 года. Отраслевые требования содержатся в правилах 2026 года для общепита, торговли и помещений, а для пищевых производств — ещё и в <span class="nw">ТР ТС 021/2011</span>.</p></div></div></div>
        <div class="card qa"><button aria-expanded="false" aria-controls="a2" id="q2"><span>Обязательна ли дератизация для организаций и ИП?</span><span class="pm"></span></button><div class="ans" id="a2" role="region" aria-labelledby="q2"><div><p>Да. Юридические лица и ИП обеспечивают дезинсекцию и дератизацию на своих объектах — сами или через специализированную организацию (п. 88 СанПиН <span class="nw">3.3686-21</span>). Это не обязательно ежемесячная раскладка родентицидов: дератизация включает обследование, профилактику и истребительные мероприятия по результатам оценки (пп. 108–110).</p></div></div></div>
        <div class="card qa"><button aria-expanded="false" aria-controls="a3" id="q3"><span>Как часто проводить дезинсекцию и дератизацию на предприятии?</span><span class="pm"></span></button><div class="ans" id="a3" role="region" aria-labelledby="q3"><div><p>Зависит от объекта. На объектах особого эпидемиологического значения — пищевых и торговых, в гостиницах, медицинских и детских организациях — обследования на насекомых проводят не реже 2 раз в месяц, на других объектах — раз в месяц (п. 101 СанПиН <span class="nw">3.3686-21</span>). Заселённость грызунами на объектах особого эпидемиологического значения оценивают ежемесячно, а дератизацию проводят по результатам оценки (п. 110). Обработки назначают по результатам обследований.</p></div></div></div>
        <div class="card qa"><button aria-expanded="false" aria-controls="a4" id="q4"><span>Что такое объекты особого эпидемиологического значения?</span><span class="pm"></span></button><div class="ans" id="a4" role="region" aria-labelledby="q4"><div><p>Это объекты из перечня в п. 98 СанПиН <span class="nw">3.3686-21</span>. Среди них организации пищевой промышленности и общественного питания, организации, которые хранят и продают пищевую продукцию, гостиницы и общежития, медицинские, <span class="nw">санаторно-курортные</span> и детские образовательные организации, вокзалы, аэропорты и объекты транспорта. Перечень широкий: в него входят также здания, предназначенные для постоянного или временного пребывания людей, и объекты <span class="nw">коммунально-бытового</span> назначения. Их обследуют на насекомых не реже 2 раз в месяц, а дератизацию проводят по результатам ежемесячной оценки.</p></div></div></div>
        <div class="card qa"><button aria-expanded="false" aria-controls="a5" id="q5"><span>Нужна ли подрядчику лицензия и можно ли проводить обработки своими силами?</span><span class="pm"></span></button><div class="ans" id="a5" role="region" aria-labelledby="q5"><div><p>С 1 марта 2025 года услуги по дезинфекции, дезинсекции и дератизации оказывают только по лицензии. Если организация работает для собственных нужд, лицензия ей не нужна. При этом в проверочных листах для гостиниц, аптек, спортивных объектов, бань и магазинов непродовольственных товаров есть вопрос, проводит ли обработки «организация, осуществляющая дезинфекционную деятельность».</p></div></div></div>
      </div>
      <div class="faq-col" data-group="faq">
        <div class="card qa"><button aria-expanded="false" aria-controls="a6" id="q6"><span>Действует ли СП <span class="nw">3.5.3.3223-14</span>?</span><span class="pm"></span></button><div class="ans" id="a6" role="region" aria-labelledby="q6"><div><p>Нет. СП <span class="nw">3.5.3.3223-14</span> о дератизации утратили силу 1 сентября 2021 года, их требования вошли в раздел III СанПиН <span class="nw">3.3686-21</span>. Тогда же утратил силу СанПиН <span class="nw">3.5.2.3472-17</span> о дезинсекции. Если программа или договор ссылаются на эти документы, ссылки нужно обновить.</p></div></div></div>
        <div class="card qa"><button aria-expanded="false" aria-controls="a7" id="q7"><span>Можно ли оставить в программе производственного контроля ссылки на старые СП и СанПиН?</span><span class="pm"></span></button><div class="ans" id="a7" role="region" aria-labelledby="q7"><div><p>Лучше обновить. Правила 2020–2021 годов для общепита, торговли и помещений заменены с 1 сентября 2026 года, а СП <span class="nw">3.5.3.3223-14</span> и СанПиН <span class="nw">3.5.2.3472-17</span> не действуют с 2021 года. Ссылки на отменённые документы показывают инспектору и аудитору, что программу давно не пересматривали.</p></div></div></div>
        <div class="card qa"><button aria-expanded="false" aria-controls="a8" id="q8"><span>Что будет после 1 сентября 2027 года?</span><span class="pm"></span></button><div class="ans" id="a8" role="region" aria-labelledby="q8"><div><p>В этот день заканчивается срок действия СанПиН <span class="nw">3.3686-21</span>. Изменения, подготовленные в марте 2026 года, раздел о дезинсекции и дератизации не затрагивают. Мы отслеживаем проекты и обновим эту страницу и образцы документов, как только новые правила будут опубликованы.</p></div></div></div>
        <div class="card qa"><button aria-expanded="false" aria-controls="a9" id="q9"><span>Где найти официальные тексты документов?</span><span class="pm"></span></button><div class="ans" id="a9" role="region" aria-labelledby="q9"><div><p>На портале официального опубликования publication.pravo.gov.ru и в системе pravo.gov.ru. Ссылки на каждый документ — в таблицах выше и в списке источников.</p></div></div></div>
      </div>
    </div>
  </div>
</section>

<section class="cta" id="zayavka"><div class="cta-bg f-lazy" aria-hidden="true" data-parallax-bg></div><div class="cta-orb" id="orb" aria-hidden="true"></div>
  <div class="wrap">
    <div>
      <div class="eyebrow" data-eyebrow>Заявка</div>
      <h2 data-split>Не уверены, что относится <em>к вашему объекту?</em></h2>
      <p class="sub" data-fade>Санитарный врач сопоставит ваш объект с требованиями и проверочным листом. Покажем, каких документов не хватает и какие ссылки в программах устарели.</p>
      <ul class="cta-list" data-group="ctalist">
        <li><svg aria-hidden="true" focusable="false" class="lucide lucide-circle-check" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <circle cx="12" cy="12" r="10" /> <path d="m16 9-5.5 5.5L8 12" /> </svg>Сверка с СанПиН и проверочным листом вашего вида деятельности</li>
        <li><svg aria-hidden="true" focusable="false" class="lucide lucide-circle-check" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <circle cx="12" cy="12" r="10" /> <path d="m16 9-5.5 5.5L8 12" /> </svg>Список документов, которых не хватает</li>
        <li><svg aria-hidden="true" focusable="false" class="lucide lucide-circle-check" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <circle cx="12" cy="12" r="10" /> <path d="m16 9-5.5 5.5L8 12" /> </svg>Устаревшие ссылки в программах и договоре</li>
      </ul>
      <div class="cta-contacts" data-fade>
        <a class="ph" href="tel:+74951043570">+7 (495) 104-35-70</a>
        <div class="msg">
          <a href="https://max.ru/u/f9LHodD0cOIlIUXFkt4KMFP88lD8n4TArBiTcV7RI1XML5c4o39QfsDBXUc" class="max" aria-label="Написать в Max" target="_blank" rel="noopener noreferrer"><svg viewBox="0 0 24 24" fill="#fff" aria-hidden="true"><path d="M12 3a9 9 0 0 0-7.7 13.7L3 21l4.4-1.2A9 9 0 1 0 12 3zm-3.6 12.3V8.7h1.6l2 2.8 2-2.8h1.6v6.6h-1.7v-3.9L12 14l-1.9-2.6v3.9z"/></svg></a>
          <a href="https://t.me/Centr_Dezinfection?text=%D0%97%D0%B4%D1%80%D0%B0%D0%B2%D1%81%D1%82%D0%B2%D1%83%D0%B9%D1%82%D0%B5!%20%D0%9F%D0%B8%D1%88%D1%83%20%D1%81%20%D1%81%D0%B0%D0%B9%D1%82%D0%B0%20%D0%BF%D0%B5%D1%81%D1%82%D0%BA%D0%BE%D0%BD%D1%82%D1%80%D0%BE%D0%BB%D1%8C-%D1%86%D0%B5%D0%BD%D1%82%D1%80.%D1%80%D1%84" class="tg" aria-label="Написать в Telegram" target="_blank" rel="noopener noreferrer"><svg viewBox="0 0 24 24" fill="#fff" aria-hidden="true"><path d="M21.4 4.3 2.9 11.4c-1.3.5-1.2 1.2-.2 1.5l4.7 1.5 1.8 5.6c.2.6.4.8.9.8.4 0 .6-.2.9-.4l2.3-2.2 4.7 3.5c.9.5 1.5.2 1.7-.8l3.1-14.6c.3-1.3-.5-1.8-1.4-1.5zM9.6 14.1l8.6-5.4c.4-.3.8-.1.5.2l-7.1 6.4-.3 3.3z"/></svg></a>
        </div>
      </div>
    </div>
    <form class="form" id="form" novalidate data-form>
      <div class="fbody">
        <h3>Проверка документов объекта</h3>
        <p class="fs">Заполнение займёт меньше минуты</p>
        <div class="fg">
<div class="field"><label class="sr-only" for="f-name">Ваше имя</label><input id="f-name" name="name" placeholder="Ваше имя" required autocomplete="name"><small class="ferr">Укажите имя</small></div>
<div class="field"><label class="sr-only" for="phone">Телефон</label><input name="phone" id="phone" type="tel" inputmode="tel" placeholder="+7 (___) ___-__-__" required autocomplete="tel"><small class="ferr">Укажите телефон полностью</small></div>
<div class="field full"><label class="sr-only" for="f-company">Компания</label><input id="f-company" name="company" placeholder="Компания (необязательно)" autocomplete="organization"></div>
<div class="field full"><label class="sr-only" for="f-type">Вид объекта</label><select id="f-type" name="type" required><option value="" selected>Вид объекта</option><option>Пищевое производство</option><option>Ресторан или кафе</option><option value="Магазин или торговая сеть">Магазин продуктов</option><option value="Склад, логистика">Склад</option><option>Гостиница</option><option value="Другое">Медицинская организация</option><option>Другое</option></select><small class="ferr">Выберите вид объекта</small></div>
<div class="field full"><label class="sr-only" for="f-msg">Комментарий</label><textarea id="f-msg" name="comment" placeholder="Комментарий: вид деятельности, площадь, ближайшая проверка"></textarea></div>
<input type="hidden" name="msg" value="">
<div class="field" hidden><input type="hidden" name="email" value=""></div>
<input type="hidden" name="page" value="Нормативная база">
</div>
        <button type="submit" class="btn btn-w btn-lg" id="submitBtn"><span class="btn-t">Проверить документы</span><svg class="btn-ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M5 12h14M13 6l6 6-6 6"/></svg><i class="spin" aria-hidden="true"></i></button>
        <p class="legal">Нажимая кнопку, вы даёте <a href="../soglasie/" target="_blank" rel="noopener">согласие на обработку персональных данных</a> и подтверждаете, что ознакомились с <a href="../privacy/" target="_blank" rel="noopener">политикой конфиденциальности</a>.</p>
      </div>
      <div class="ok" role="status" aria-live="polite">
        <svg class="ok-ic" viewBox="0 0 52 52" aria-hidden="true"><circle cx="26" cy="26" r="24" fill="none"/><path fill="none" d="M15 27l7 7 15-16"/></svg>
        <h3>Заявка отправлена</h3><p>Перезвоним в ближайшее рабочее время и договоримся о сверке документов.</p>
      </div>
    </form>
  </div>
</section>
</main>


<footer>
  <div class="wrap">
    <div class="ft">
      <div>
        <a href="../" class="logo" aria-label="ПЕСТКОНТРОЛЬ Центр — на главную"><span class="logo-mark"><svg viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="1.6" stroke-linejoin="round" aria-hidden="true"><path d="M12 2.5l7.5 3v6c0 5-3.2 8.6-7.5 10-4.3-1.4-7.5-5-7.5-10v-6z"/><circle cx="12" cy="11.5" r="2.6" stroke="#7c86ff"/><path d="M12 6.2v2.7M12 14.1v2.7M6.8 11.5h2.6M14.6 11.5h2.6" stroke="#7c86ff"/></svg></span><span class="logo-txt"><span class="logo-name">ПЕСТКОНТРОЛЬ</span> <span class="logo-sub">Центр</span></span></a>
        <p class="d"><span class="nw">Пест-контроль</span> и <span class="nw">пест-менеджмент</span> по системе IPM для бизнеса в Москве и Московской области: бесплатный аудит, оценка <span class="nw">пест-риска</span>, мониторинг вредителей и отчётность.</p>
      </div>
      <div><h4>Услуги</h4><ul><li><a href="../dezinfektsiya/">Дезинфекция для организаций</a></li><li><a href="../deratizatsiya/">Дератизация для организаций</a></li><li><a href="../dezinsektsiya/">Дезинсекция для организаций</a></li><li><a href="../sanitarnyy-audit/"><span>Санитарный аудит <span class="nw">(СЭС-аудит)</span></span></a></li><li><a href="../ochistka-dezinfektsiya-ventilyatsii/">Очистка и дезинфекция вентиляции</a></li><li><a href="../dogovor-deratizatsiya-dezinsektsiya/">Договор на дератизацию и дезинсекцию</a></li><li><a href="../#podhod"><span><span class="nw">Пест-контроль</span> по системе IPM</span></a></li><li><a href="../#etapy">Этапы работы</a></li><li><a href="../#vrediteli">Вредители</a></li><li><a href="../#dokumenty">Документы для проверок</a></li><li><a href="../#usloviya">Цена</a></li><li><a href="../#voprosy">Вопросы</a></li></ul></div>
      <div><h4>Отрасли</h4><ul><li><a href="../pishchevoe-proizvodstvo/">Пищевые производства</a></li><li><a href="../magaziny-i-torgovye-seti/">Магазины и торговые сети</a></li><li><a href="../restorany-i-kafe/">Рестораны и кафе</a></li><li><a href="../sklady-i-logistika/">Склады и логистика</a></li><li><a href="../farmatsevticheskie-proizvodstva/">Фармацевтические производства</a></li><li><a href="../gostinitsy/">Гостиницы и отели</a></li></ul></div>
      <div><h4>Материалы</h4><ul><li><a href="./" aria-current="page">Нормативная база</a></li><li><a href="../normativnaya-baza/proverochnye-listy/">Проверочные листы 2026</a></li><li><a href="../materialy/programma-pest-kontrolya/"><span>Программа <span class="nw">пест-контроля</span></span></a></li><li><a href="../materialy/zhurnal-pest-kontrolya/"><span>Журнал <span class="nw">пест-контроля</span></span></a></li><li><a href="../materialy/pest-menedzhment-ili-razovaya-obrabotka/"><span><span class="nw">Пест-менеджмент</span> или разовая обработка</span></a></li><li><a href="../materialy/programma-proizvodstvennogo-kontrolya-haccp/">Программа производственного контроля по ХАССП</a></li><li><a href="../materialy/">Все материалы</a></li></ul></div>
      <div><h4>Контакты</h4><ul><li><a href="tel:+74951043570">+7 (495) 104-35-70</a></li><li><a href="mailto:b2b@pestcontrol-center.ru">b2b@<wbr><span style="white-space:nowrap">pestcontrol-center.ru</span></a></li><li>Пн–Пт: 8:00–20:00</li><li>Срочные выезды: 24/7</li></ul>
        <div class="msg"><a href="https://max.ru/u/f9LHodD0cOIlIUXFkt4KMFP88lD8n4TArBiTcV7RI1XML5c4o39QfsDBXUc" class="max" aria-label="Написать в Max" target="_blank" rel="noopener noreferrer"><svg viewBox="0 0 24 24" fill="#fff" aria-hidden="true"><path d="M12 3a9 9 0 0 0-7.7 13.7L3 21l4.4-1.2A9 9 0 1 0 12 3zm-3.6 12.3V8.7h1.6l2 2.8 2-2.8h1.6v6.6h-1.7v-3.9L12 14l-1.9-2.6v3.9z"/></svg></a><a href="https://t.me/Centr_Dezinfection?text=%D0%97%D0%B4%D1%80%D0%B0%D0%B2%D1%81%D1%82%D0%B2%D1%83%D0%B9%D1%82%D0%B5!%20%D0%9F%D0%B8%D1%88%D1%83%20%D1%81%20%D1%81%D0%B0%D0%B9%D1%82%D0%B0%20%D0%BF%D0%B5%D1%81%D1%82%D0%BA%D0%BE%D0%BD%D1%82%D1%80%D0%BE%D0%BB%D1%8C-%D1%86%D0%B5%D0%BD%D1%82%D1%80.%D1%80%D1%84" class="tg" aria-label="Написать в Telegram" target="_blank" rel="noopener noreferrer"><svg viewBox="0 0 24 24" fill="#fff" aria-hidden="true"><path d="M21.4 4.3 2.9 11.4c-1.3.5-1.2 1.2-.2 1.5l4.7 1.5 1.8 5.6c.2.6.4.8.9.8.4 0 .6-.2.9-.4l2.3-2.2 4.7 3.5c.9.5 1.5.2 1.7-.8l3.1-14.6c.3-1.3-.5-1.8-1.4-1.5zM9.6 14.1l8.6-5.4c.4-.3.8-.1.5.2l-7.1 6.4-.3 3.3z"/></svg></a></div>
      </div>
    </div>
    <div class="fb"><span>© 2026 ПЕСТКОНТРОЛЬ Центр</span><a href="../privacy/">Политика конфиденциальности</a><a href="../soglasie/">Согласие на обработку данных</a><span>Информация на сайте не является публичной офертой</span></div>
  </div>
</footer>

<div class="mbar" id="mbar">
  <a href="tel:+74951043570" class="c1"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1 1 .4 1.9.7 2.8a2 2 0 0 1-.5 2.1L8 9.9a16 16 0 0 0 6 6l1.3-1.3a2 2 0 0 1 2.1-.4c.9.3 1.8.6 2.8.7a2 2 0 0 1 1.7 2z"/></svg>Позвонить</a>
  <a href="#zayavka" class="c2"><span>Обследование</span></a>
</div>
<div class="fab" role="group" aria-label="Написать в мессенджер">
  <a href="https://max.ru/u/f9LHodD0cOIlIUXFkt4KMFP88lD8n4TArBiTcV7RI1XML5c4o39QfsDBXUc" class="max" aria-label="Написать в Max" target="_blank" rel="noopener noreferrer"><svg viewBox="0 0 24 24" fill="#fff" aria-hidden="true"><path d="M12 3a9 9 0 0 0-7.7 13.7L3 21l4.4-1.2A9 9 0 1 0 12 3zm-3.6 12.3V8.7h1.6l2 2.8 2-2.8h1.6v6.6h-1.7v-3.9L12 14l-1.9-2.6v3.9z"/></svg></a>
  <a href="https://t.me/Centr_Dezinfection?text=%D0%97%D0%B4%D1%80%D0%B0%D0%B2%D1%81%D1%82%D0%B2%D1%83%D0%B9%D1%82%D0%B5!%20%D0%9F%D0%B8%D1%88%D1%83%20%D1%81%20%D1%81%D0%B0%D0%B9%D1%82%D0%B0%20%D0%BF%D0%B5%D1%81%D1%82%D0%BA%D0%BE%D0%BD%D1%82%D1%80%D0%BE%D0%BB%D1%8C-%D1%86%D0%B5%D0%BD%D1%82%D1%80.%D1%80%D1%84" class="tg" aria-label="Написать в Telegram" target="_blank" rel="noopener noreferrer"><svg viewBox="0 0 24 24" fill="#fff" aria-hidden="true"><path d="M21.4 4.3 2.9 11.4c-1.3.5-1.2 1.2-.2 1.5l4.7 1.5 1.8 5.6c.2.6.4.8.9.8.4 0 .6-.2.9-.4l2.3-2.2 4.7 3.5c.9.5 1.5.2 1.7-.8l3.1-14.6c.3-1.3-.5-1.8-1.4-1.5zM9.6 14.1l8.6-5.4c.4-.3.8-.1.5.2l-7.1 6.4-.3 3.3z"/></svg></a>
</div>

<script>
/* Предпросмотр: вне рабочего домена заявка не отправляется (на пестконтроль-центр.рф этот блок не срабатывает) */
(function(){if(/^(www\.)?xn----itbbsflddbfpfdodg9d0f\.xn--p1ai$/i.test(location.hostname))return;var f=window.fetch;window.fetch=function(u){if(typeof u==='string'&&u.indexOf('send.php')>-1)return new Promise(function(r){setTimeout(function(){r(new Response('{"success":true}',{status:200,headers:{'Content-Type':'application/json'}}))},500)});return f.apply(this,arguments)};document.addEventListener('DOMContentLoaded',function(){var p=document.querySelector('.form .fs');if(p)p.textContent='Предпросмотр: заявка никуда не отправляется'})})();
</script>
<script data-fx>
/* Эффекты под курсором, как на главной (tools/site/fx.py) */
(function(){
  var mm=window.matchMedia;if(!mm)return;
  var fine=mm('(hover: hover) and (pointer: fine)').matches;
  /* «фонарь»: следует за мышью, без движения мыши плавно ходит сам; на сенсорных экранах ходит сам (30 кадров в секунду).
     Не считаем, пока первый экран не виден или вкладка скрыта. Старт — вместе со входом первого экрана */
  var hero=document.getElementById('hero'),lit=hero&&hero.querySelector('.fx-lit');
  if(lit&&!mm('(prefers-reduced-motion: reduce)').matches){
    var media=lit.parentNode,small=mm('(max-width:860px)').matches,full=hero.classList.contains('f-hero');
    lit.style.setProperty('--sr',small?'150px':'clamp(240px, 21vw, 400px)');
    var cx=small?.5:(full?.68:.74),ax=small?.24:(full?.16:.13),cy=small?.5:.47,ay=small?.2:.17;
    var sx=cx,sy=cy,tx=cx,ty=cy,last=-1e9,vis=true,on=false,raf=0,lt=0;
    var frame=function(now){
      raf=0;if(!on||!vis||document.hidden)return;
      var dt=now-lt;if(!fine&&dt<30){raf=requestAnimationFrame(frame);return;}
      lt=now;if(now-last>2600){var t=now/1000;tx=cx+ax*Math.sin(t*.33);ty=cy+ay*Math.sin(t*.47+1.3);}
      var k=1-Math.pow(.94,Math.min(dt,100)/16.67);sx+=(tx-sx)*k;sy+=(ty-sy)*k;
      lit.style.setProperty('--sx',(sx*100).toFixed(2)+'%');lit.style.setProperty('--sy',(sy*100).toFixed(2)+'%');
      raf=requestAnimationFrame(frame);
    };
    var kick=function(){if(!raf&&on&&vis&&!document.hidden){lt=performance.now();raf=requestAnimationFrame(frame);}};
    hero.addEventListener('pointermove',function(e){
      if(e.pointerType!=='mouse')return;var r=media.getBoundingClientRect();if(!r.width||!r.height)return;
      tx=(e.clientX-r.left)/r.width;ty=(e.clientY-r.top)/r.height;last=performance.now();kick();
    },{passive:true});
    if('IntersectionObserver' in window)new IntersectionObserver(function(es){vis=es[0].isIntersecting;kick();}).observe(hero);
    document.addEventListener('visibilitychange',kick);
    var start=function(){if(on)return;on=true;hero.classList.add('fx-lit-on');kick();};
    var eb=hero.querySelector('.eyebrow');
    if(eb&&'MutationObserver' in window){
      if(eb.classList.contains('in'))start();
      else{var mo=new MutationObserver(function(){if(eb.classList.contains('in')){mo.disconnect();start();}});mo.observe(eb,{attributes:true,attributeFilter:['class']});}
    }
    setTimeout(start,eb?5000:2500);
  }
  /* подсветка рамки карточек за курсором — как у .card на главной */
  if(fine)document.addEventListener('pointermove',function(e){
    var c=e.target.closest&&e.target.closest('.d-card,.p-sec,.p-fcard,.p-duty-box,.p-dl-card,.pm-step-card,.pm-scen,.pm-link-card,.k-err,.w-sample,.d-doc-prev');if(!c)return;
    var r=c.getBoundingClientRect();c.style.setProperty('--mx',(e.clientX-r.left)+'px');c.style.setProperty('--my',(e.clientY-r.top)+'px');
  },{passive:true});
})();
</script>
<script>
  /* скрипты анимаций подключаются сразу после первой отрисовки: фото и заголовок первого экрана не ждут их загрузки */
  (function (r, l) {
    var go = function () { l.forEach(function (u) { var e = document.createElement('script'); e.src = r + u; e.async = false; document.body.appendChild(e); }); };
    if (document.visibilityState === 'hidden' || !window.requestAnimationFrame) setTimeout(go, 0);
    else requestAnimationFrame(function () { setTimeout(go, 0); });
  })('../', ['vendor/gsap.min.js', 'vendor/ScrollTrigger.min.js', 'vendor/lenis.min.js', 'app.min.js?v=20261106s2']);
</script>
<script>/* Форма: вид объекта, комментарий и страница — в поле msg, которое читает send.php */
document.addEventListener('submit',function(ev){var f=ev.target;if(!f||f.id!=='form')return;var e=f.elements,s=e.type,o=s&&s.selectedIndex>0?s.options[s.selectedIndex].text:'не выбран',c=e.comment.value.trim();e.msg.value='Вид объекта: '+o+(c?'\nКомментарий: '+c:'')+'\nСтраница: Нормативная база (/normativnaya-baza/)';},true);</script>
<script>/* Дорожная карта и хроника: прошедшее — серым, метка «Сегодня» — по сегодняшней дате */
(function(){var r=document.getElementById('nbRoad');if(!r)return;var t=new Date(),d=new Date(t.getFullYear(),t.getMonth(),t.getDate()),P=function(s){var a=s.split('-');return new Date(+a[0],a[1]-1,+a[2]);},pts=[].slice.call(r.querySelectorAll('[data-d]')),ds=pts.map(function(p){return P(p.getAttribute('data-d'));}),xs=pts.map(function(p){return parseFloat(p.style.getPropertyValue('--x'));}),i=0,x,o;while(i<ds.length&&ds[i]<=d)i++;if(i===0){x=Math.max(1,xs[0]-4);o=-1;}else if(i===ds.length){x=Math.min(99,xs[i-1]+4);o=2*i;}else{x=xs[i-1]+(xs[i]-xs[i-1])*(d-ds[i-1])/(ds[i]-ds[i-1]);o=2*i-1;}pts.forEach(function(p,k){p.classList.toggle('is-past',ds[k]<=d);p.classList.toggle('is-next',ds[k]>d);});var n=r.querySelector('.nb-road-now'),z=function(v){return(v<10?'0':'')+v;};n.style.setProperty('--x',x.toFixed(1)+'%');n.style.setProperty('--o',o);n.firstChild.textContent='Сегодня · '+z(d.getDate())+'.'+z(d.getMonth()+1)+'.'+d.getFullYear();r.querySelector('.nb-road-fill').style.width=x.toFixed(1)+'%';[].forEach.call(document.querySelectorAll('.nb-tl li'),function(li){var m=li.querySelector('time');if(!m)return;var e=P(m.getAttribute('datetime'));li.classList.toggle('is-past',e<=d);li.classList.toggle('is-next',e>d);});})();</script>
<!-- Yandex.Metrika counter + UIS + Radist: загружаются после первого действия посетителя (касание, прокрутка, мышь, клавиатура) или через 5 с после загрузки страницы -->
<script type="text/javascript">
    (function (w, d) {
        w.ym = w.ym || function () { (w.ym.a = w.ym.a || []).push(arguments); };
        w.ym.l = 1 * new Date();
        ym(113675622, 'init', {ssr:true, webvisor:true, clickmap:true, ecommerce:"dataLayer", referrer: document.referrer, url: location.href, accurateTrackBounce:true, trackLinks:true});
        var done = false, ready = false, wait = null, ev = ['pointerdown', 'touchstart', 'keydown', 'scroll', 'wheel', 'mousemove'];
        w.__cs = w.__cs || [];
        w.__cs.push(['waitForTrackViewAndRun', function () { ready = true; }]);
        // Radist: код заявки в ссылках Telegram и MAX — сразу, скрипт Radist загрузится вместе со счётчиками
        var rmsg = 'Здравствуйте! Пишу с сайта пестконтроль-центр.рф. Номер заявки: {radist_tracker}';
        w.radist_tracker = w.radist_tracker || function () { (w.radist_tracker.a = w.radist_tracker.a || []).push(arguments); };
        w.radist_tracker.l = 1 * new Date();
        w.radist_tracker({ message: rmsg, whatsapp_enabled: true, tgbot_enabled: true, tg_enabled: true, max_enabled: true, vk_enabled: true });
        (function () {
            var id = null, abc = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789', s = 'ro', i, txt;
            try {
                id = sessionStorage.getItem('radistVisit');
                if (!id || id.length !== 12) {
                    for (i = 0; i < 10; i++) s += abc.charAt(Math.floor(Math.random() * abc.length));
                    sessionStorage.setItem('radistVisit', s);
                    id = sessionStorage.getItem('radistVisit');
                }
            } catch (e) { id = null; }
            if (!id || id.length !== 12) return;
            txt = encodeURIComponent(rmsg.replace(/{radist_tracker}/g, id));
            [].forEach.call(d.querySelectorAll('a[href*="//t.me/"], a[href*="//max.ru/"]'), function (a) {
                try {
                    var u = new URL(a.href), n = u.pathname.split('/')[1] || '';
                    if (u.host === 'max.ru') a.href = 'https://max.ru/' + u.pathname.substring(1) + '?start=' + id;
                    else if (u.host === 't.me' && !/bot$/i.test(n)) a.href = 'https://t.me' + u.pathname + '?text=' + txt;
                } catch (e) {}
            });
        })();
        function add(src) { var k = d.createElement('script'); k.async = true; k.src = src; d.head.appendChild(k); return k; }
        function load() {
            if (done) return; done = true;
            ev.forEach(function (e) { w.removeEventListener(e, load, true); });
            add('https://mc.yandex.ru/metrika/tag.js?id=113675622');
            var p = d.createElement('link'); p.rel = 'preconnect'; p.href = 'https://tracker.comagic.ru'; d.head.appendChild(p);
            add('https://app.uiscom.ru/static/cs.min.js?k=ICWycQx6m3NSBe3WlCeDAdAKMTmNhMHC').onerror = function () { ready = true; };
            add('https://track.radist.me/tracker.min.js');
        }
        ev.forEach(function (e) { w.addEventListener(e, load, { capture: true, passive: true }); });
        function later() { setTimeout(load, 5000); }
        if (d.readyState === 'complete') later(); else w.addEventListener('load', later);
        // Ожидание подмены номера при первом касании: набор откладывается до ответа UIS, максимум 0,8–1 с
        d.addEventListener('click', function (e) {
            if (ready) return;
            var a = e.target && e.target.closest ? e.target.closest('a[href^="tel:"]') : null;
            if (!a || e.button || e.ctrlKey || e.metaKey || e.shiftKey || e.altKey) return;
            e.preventDefault();
            if (wait) return;
            load();
            var href = a.getAttribute('href'), op = a.style.opacity, max = 'GestureEvent' in w ? 800 : 1000, t;
            function go() {
                for (var i = 0; i < wait.length; i++) clearTimeout(wait[i]);
                wait = null; ready = true; a.style.opacity = op;
                w.location.href = a.href;
            }
            function check(last) { return function () { if (wait && (last || ready || a.getAttribute('href') !== href)) go(); }; }
            wait = [];
            a.style.opacity = '.6';
            for (t = 50; t <= max; t += 50) wait.push(setTimeout(check(t === max), t));
        }, true);
    })(window, document);
</script>
<noscript><div><img src="https://mc.yandex.ru/watch/113675622" style="position:absolute; left:-9999px;" alt="" /></div></noscript>
<!-- /Yandex.Metrika counter -->
</body>
</html>
