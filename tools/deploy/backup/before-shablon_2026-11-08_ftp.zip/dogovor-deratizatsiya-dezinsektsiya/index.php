<!doctype html>
<html lang="ru">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>Договор на дератизацию и дезинсекцию в Москве — ПЕСТКОНТРОЛЬ Центр</title>
<meta name="description" content="Договор на дератизацию и дезинсекцию для организаций в Москве и области: от 3 500 ₽/мес, график визитов, точки контроля, акт после каждого выезда. Образец в PDF.">
<link rel="canonical" href="https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/dogovor-deratizatsiya-dezinsektsiya/">
<meta name="theme-color" content="#000000">
<meta property="og:type" content="website">
<meta property="og:locale" content="ru_RU">
<meta property="og:site_name" content="ПЕСТКОНТРОЛЬ Центр">
<meta property="og:url" content="https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/dogovor-deratizatsiya-dezinsektsiya/">
<meta property="og:title" content="Договор на дератизацию и дезинсекцию для организаций в Москве и области">
<meta property="og:description" content="Договор на дератизацию и дезинсекцию для организаций в Москве и области: от 3 500 ₽/мес, график визитов, точки контроля, акт после каждого выезда. Образец в PDF.">
<meta property="og:image" content="https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/img/dogovor-og.jpg">
<meta property="og:image:type" content="image/jpeg">
<meta property="og:image:width" content="1200">
<meta property="og:image:height" content="630">
<meta property="og:image:alt" content="Специалист ПЕСТКОНТРОЛЬ Центр передаёт руководителю объекта папку с договором и схемой точек контроля">
<meta name="twitter:card" content="summary_large_image">
<link rel="icon" href="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 32 32'%3E%3Ccircle cx='16' cy='16' r='15' fill='%2309090b' stroke='%237c86ff' stroke-width='2'/%3E%3Cpath d='M16 7l7 3v5c0 5-3 8.5-7 10-4-1.5-7-5-7-10v-5z' fill='none' stroke='%23fff' stroke-width='2'/%3E%3C/svg%3E">
<link rel="preload" href="../fonts/inter-ru-wght-normal.woff2" as="font" type="font/woff2" crossorigin>
<link rel="preload" as="image" media="(min-width:861px)" imagesrcset="../img/dogovor-hero-1440.webp 1440w, ../img/dogovor-hero.webp 1920w" imagesizes="100vw" fetchpriority="high">
<link rel="preload" as="image" media="(max-width:860px)" imagesrcset="../img/dogovor-hero-mob-760.webp 760w, ../img/dogovor-hero-mob.webp 1024w" imagesizes="100vw" fetchpriority="high">
<script>
  /* начальные состояния анимаций — только при работающем JS; страховка — через 4 с всё показывается.
     Заставка — один раз за посещение: при переходе по ссылке с якорем и между страницами сайта её нет */
  (function (d) {
    d.classList.add('js');
    try { if (location.hash || sessionStorage.getItem('pc-intro')) d.classList.add('no-intro'); else sessionStorage.setItem('pc-intro', '1'); }
    catch (e) { if (location.hash) d.classList.add('no-intro'); }
    setTimeout(function () { if (!d.classList.contains('anim-ready')) d.classList.add('anim-fail'); }, 4000);
  })(document.documentElement);
</script>
<link rel="stylesheet" href="../style.css?v=20261106s2">
<style>html{scroll-behavior:auto}.d-page .s{padding:clamp(64px,7vw,128px) 0;border-top:1px solid var(--line)}.d-crumbs{font-size:14px;color:var(--t3);display:flex;flex-wrap:wrap;gap:8px;margin:0 0 clamp(28px,3vw,48px)}.d-crumbs a{color:var(--t2)}.d-crumbs a:hover{color:var(--t1)}.d-hero{position:relative;overflow:hidden;padding:calc(clamp(68px,6vw,115px) + 20px) 0 clamp(64px,7vw,116px);min-height:clamp(680px,56vw,900px);display:flex;align-items:center}.d-hero .wrap{width:100%;display:grid;grid-template-columns:minmax(0,.92fr) minmax(0,1.08fr);gap:clamp(28px,4vw,80px);align-items:center}.d-hero-copy>*:not(.d-hero-media){position:relative;z-index:1}.d-hero-media{position:absolute;inset:0;z-index:0;pointer-events:none;overflow:hidden}.d-hero-media::before{content:"";position:absolute;inset:0;z-index:1;background:linear-gradient(90deg,rgba(0,0,0,.92) 0%,rgba(0,0,0,.82) 36%,rgba(0,0,0,.25) 52%,rgba(0,0,0,0) 62%),linear-gradient(180deg,#000 0,rgba(0,0,0,.55) 90px,rgba(0,0,0,0) 260px),linear-gradient(0deg,#000 0,rgba(0,0,0,0) 20%)}.d-hero-img{position:absolute;inset:0;width:100%;height:100%;object-fit:cover;object-position:100% 50%}.d-hero h1{font-size:clamp(42px,4.4vw,84px);line-height:1.1;letter-spacing:-.055em;font-weight:300;margin:18px 0 0}.d-hero h1 .ln{display:block;padding:0 .08em .08em 0;margin-bottom:-.08em}.d-hero h1 .ln>span{display:inline-block}.d-ticks{list-style:none;padding:0;margin:28px 0 0;display:grid;gap:12px}.d-ticks li{position:relative;padding-left:30px;line-height:1.5}.d-ticks li::before{content:"";position:absolute;left:2px;top:.42em;width:13px;height:7px;border-left:2px solid var(--acc);border-bottom:2px solid var(--acc);transform:rotate(-45deg)}.d-hero .sub{margin:22px 0 0}.d-btns{display:flex;flex-wrap:wrap;gap:12px;margin-top:28px}.d-doc-prev{display:block;width:100%;border-radius:14px;overflow:hidden;border:1px solid var(--line2);background:#fff;box-shadow:0 18px 44px rgba(0,0,0,.45);transition:border-color .2s,transform .2s}.d-doc-prev:hover{border-color:var(--acc);transform:translateY(-2px)}.d-doc-prev img{display:block;width:100%;height:auto}.d-cards{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:16px}.d-card{background:var(--card);border:1px solid var(--line2);border-radius:var(--r);padding:clamp(22px,2vw,34px)}.d-card h3{font-size:clamp(20px,1.5vw,26px);font-weight:400;letter-spacing:-.02em;margin:0 0 12px}.d-card p{color:var(--t2);line-height:1.6;margin:0}.d-kind{padding:0;overflow:hidden;display:flex;flex-direction:column}.d-kind-img{aspect-ratio:16/9;overflow:hidden;background:#0c0c0e;border-bottom:1px solid var(--line2)}.d-kind-img img{display:block;width:100%;height:100%;object-fit:cover}.d-kind-b{padding:clamp(22px,2vw,34px)}.d-note{color:var(--t2);margin:24px 0 0;line-height:1.6}.d-strong{color:var(--t1);font-size:clamp(18px,1.3vw,22px)}.d-split{display:grid;grid-template-columns:minmax(0,1fr) minmax(0,340px);gap:clamp(28px,4vw,80px);align-items:start}.d-swap{display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1fr);grid-template-areas:"head img" "ticks img";grid-template-rows:auto 1fr;column-gap:clamp(28px,4vw,80px);row-gap:clamp(24px,2.4vw,40px);align-items:start}.d-swap .head{grid-area:head;margin-bottom:0}.d-swap .d-ticks{grid-area:ticks;margin:0}.d-swap-img{grid-area:img;align-self:center;margin:0;aspect-ratio:1200/896;border-radius:var(--r);overflow:hidden;border:1px solid var(--line2);background:#0c0c0e}.d-swap-img img{display:block;width:100%;height:100%;object-fit:cover}.d-terms{list-style:none;counter-reset:t;padding:0;margin:0;border-top:1px solid var(--line2)}.d-terms li{display:grid;grid-template-columns:44px minmax(0,.42fr) minmax(0,1fr);gap:16px;padding:18px 0;border-bottom:1px solid var(--line2);line-height:1.55}.d-terms li::before{counter-increment:t;content:counter(t,decimal-leading-zero);color:var(--t3)}.d-terms b{font-weight:500}.d-terms span{color:var(--t2)}.d-doc{display:grid;gap:16px;justify-items:stretch}.d-doc-h{font-size:clamp(19px,1.3vw,23px);font-weight:400;letter-spacing:-.02em;line-height:1.3;margin:0}.d-doc-btn{width:100%}.d-small{font-size:14px;color:var(--t3);margin:0}.d-steps{list-style:none;counter-reset:st;padding:0;margin:0;display:grid;grid-template-columns:repeat(5,minmax(0,1fr));gap:18px}.d-steps li{border-top:2px solid var(--line2);padding-top:18px;line-height:1.55}.d-steps li::before{counter-increment:st;content:"0" counter(st);display:block;color:var(--acc);font-size:14px;margin-bottom:12px}.d-steps b{display:block;font-weight:500;margin-bottom:8px}.d-steps span{color:var(--t2)}.d-table{width:100%;border-collapse:collapse;line-height:1.5}.d-table th,.d-table td{text-align:left;vertical-align:top;padding:16px 20px 16px 0;border-bottom:1px solid var(--line2)}.d-table th{color:var(--t3);font-weight:400;font-size:14px}.d-table td{color:var(--t2)}.d-table td:first-child{color:var(--t1)}.d-table .d-price{white-space:nowrap;text-align:right;padding-right:0}.d-table td.d-price{color:var(--t1);font-weight:500;font-variant-numeric:tabular-nums}.d-vs td:first-child{color:var(--t2)}.d-vs th:last-child,.d-vs td:last-child{color:var(--t1);background:rgba(124,134,255,.07);padding-left:20px}.d-cols2{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:16px;margin-top:28px}.d-objs{list-style:none;padding:0;margin:0;display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:16px}.d-obj{display:flex;flex-direction:column;overflow:hidden;transition:border-color .25s}.d-obj:hover{border-color:var(--acc)}.d-obj-img{aspect-ratio:900/542;overflow:hidden;background:#0c0c0e}.d-obj-img picture{display:block;width:100%;height:100%}.d-obj-img img{display:block;width:100%;height:100%;object-fit:cover;filter:saturate(.85);transition:filter .5s}.d-obj:hover .d-obj-img img{filter:none}.d-obj-b{padding:clamp(18px,1.5vw,26px)}.d-obj h3{font-size:clamp(18px,1.25vw,22px);font-weight:500;letter-spacing:-.01em;line-height:1.3;margin:0 0 8px;overflow-wrap:break-word}.d-obj h3 a{color:var(--t1);text-decoration:none;outline:none}.d-obj h3 a::after{content:"";position:absolute;inset:0;z-index:1;border-radius:inherit}.d-obj:focus-within{outline:2px solid var(--acc);outline-offset:3px}.d-obj:has(a:focus:not(:focus-visible)){outline:none}.d-obj p{color:var(--t2);line-height:1.55;margin:0;font-size:clamp(14px,.92vw,16px)}.qa .ans a{color:var(--t1);text-decoration:underline;text-decoration-color:var(--acc);text-underline-offset:3px}.qa .ans a:hover{color:var(--acc)}.qa .ans>div{visibility:hidden;transition:visibility 0s .55s}.qa.open .ans>div{visibility:visible;transition-delay:0s}.f-lazy:not(.bg-in){background-image:none!important}.d-page .cta .sub{margin-bottom:0}.d-page .cta-list{margin:28px 0 34px}@media (max-width:1180px){.d-hero{min-height:0}.d-hero .wrap{grid-template-columns:minmax(0,.82fr) minmax(0,1.18fr)}.d-hero .btn-lg{height:52px;padding:0 22px;font-size:15px}}@media (max-width:1100px){.d-steps,.d-objs{grid-template-columns:repeat(2,minmax(0,1fr))}}@media (max-width:860px){.hdr{background:rgba(0,0,0,.72);backdrop-filter:blur(18px);-webkit-backdrop-filter:blur(18px);border-color:var(--line)}.d-hero{display:block;min-height:0;padding:calc(clamp(68px,6vw,115px) + 20px) 0 clamp(44px,7vw,64px)}.d-hero .wrap,.d-split,.d-swap,.d-cols2,.d-cards{grid-template-columns:minmax(0,1fr)}.d-swap{grid-template-areas:"head" "img" "ticks";grid-template-rows:auto}.d-hero-copy{display:flex;flex-direction:column}.d-hero .eyebrow{display:none}.d-hero h1{order:1;font-size:clamp(26px,7.6vw,31px);line-height:1.1;letter-spacing:-.055em;margin:0}.d-hero h1 .d-ln1,.d-hero h1 .d-ln2{display:inline}.d-hero-media{order:2;position:relative;inset:auto;aspect-ratio:16/9;margin:18px calc(var(--pad) * -1) 0}.d-hero-media::before{display:none}.d-hero-img{height:100%;min-height:0}.d-btns{order:3;margin-top:22px;gap:10px}.d-btns .btn{height:52px}.d-btns .d-tel-btn{display:none}.d-ticks{order:4;margin:26px 0 0}.d-hero .sub{order:5;margin:20px 0 0;font-size:16px;line-height:1.45}.d-crumbs{order:6;margin:18px 0 0;padding:0;font-size:clamp(10px,2.8vw,11px);line-height:1.2;gap:6px;flex-wrap:nowrap;white-space:nowrap;letter-spacing:0;color:#75757d}.d-crumbs a{color:#82828b}.d-terms li{grid-template-columns:36px minmax(0,1fr);gap:6px 12px}.d-terms span{grid-column:2}.d-doc{grid-template-columns:120px minmax(0,1fr);grid-template-areas:"prev h" "prev meta" "btn btn";grid-template-rows:auto 1fr auto;column-gap:18px;row-gap:10px;align-items:start}.d-doc-h{grid-area:h;font-size:18px}.d-doc-prev{grid-area:prev;border-radius:8px;box-shadow:0 10px 26px rgba(0,0,0,.45)}.d-small{grid-area:meta}.d-doc-btn{grid-area:btn;margin-top:6px}}@media (min-width:601px) and (max-width:860px){.d-kind{flex-direction:row}.d-kind-img{flex:0 0 42%;aspect-ratio:auto;min-height:220px;border-bottom:0;border-right:1px solid var(--line2)}.d-kind-b{align-self:center}}@media (max-width:600px){.d-steps{grid-template-columns:minmax(0,1fr)}.d-table thead{display:none}.d-table,.d-table tbody,.d-table tr,.d-table td{display:block;width:100%}.d-table tr{border:1px solid var(--line2);border-radius:var(--r);padding:6px 16px;margin-bottom:12px}.d-table td{border:0;padding:10px 0}.d-table td+td{border-top:1px solid var(--line)}.d-table td::before{content:attr(data-l);display:block;font-size:13px;color:var(--t3);margin-bottom:4px}.d-vs td:last-child{background:none;padding-left:28px}.d-prices tr{display:grid;grid-template-columns:minmax(0,1fr) auto;column-gap:14px;row-gap:6px;padding:14px 16px}.d-prices td{padding:0}.d-prices td::before{display:none}.d-prices td+td{border-top:0}.d-prices td:nth-child(2){grid-column:1/-1;grid-row:2;font-size:14px}.d-prices td.d-price{grid-column:2;grid-row:1;width:auto;text-align:right}.d-vs td{position:relative;padding:12px 0 12px 28px}.d-vs td::before{position:absolute;width:1px;height:1px;margin:0;overflow:hidden;clip:rect(0 0 0 0);clip-path:inset(50%);white-space:nowrap}.d-vs td::after{content:"";position:absolute;left:1px;top:calc(12px + .25em);width:14px;height:14px}.d-vs td:first-child::after{background:linear-gradient(45deg,transparent 42%,var(--red) 42%,var(--red) 58%,transparent 58%),linear-gradient(-45deg,transparent 42%,var(--red) 42%,var(--red) 58%,transparent 58%)}.d-vs td:last-child::after{left:2px;top:calc(12px + .38em);width:13px;height:7px;border-left:2px solid var(--acc);border-bottom:2px solid var(--acc);transform:rotate(-45deg)}.d-objs{grid-template-columns:minmax(0,1fr);gap:12px}.d-obj{flex-direction:row;align-items:stretch}.d-obj-img{flex:0 0 104px;aspect-ratio:auto;min-height:104px}.d-obj-b{padding:14px 16px;align-self:center}.d-obj h3{font-size:17px;margin-bottom:6px}.d-obj p{font-size:14px;line-height:1.5}.d-page .form .btn-lg{padding:0 16px}}@media (max-width:400px){.d-page .form .btn-lg{font-size:15px;padding:0 14px}.d-doc{grid-template-columns:96px minmax(0,1fr);column-gap:14px}.d-doc-h{font-size:17px}.d-obj-img{flex-basis:88px;min-height:88px}.d-obj-b{padding:12px 14px}.d-obj h3{font-size:16px}}@media (max-width:360px){.d-doc .btn-lg{max-width:100%;padding:0 18px;font-size:15px}.d-page .form .btn-ic{display:none}}@media (max-width:340px){.d-page .ft{grid-template-columns:minmax(0,1fr)}.d-obj-img{flex-basis:76px;min-height:76px}.d-page .form .btn-lg{font-size:14px;padding:0 10px}.d-doc .btn-lg{font-size:14px;padding:0 14px}}</style>
<script type="application/ld+json">{"@context":"https://schema.org","@graph":[{"@type":"BreadcrumbList","itemListElement":[{"@type":"ListItem","position":1,"name":"Главная","item":"https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/"},{"@type":"ListItem","position":2,"name":"Договор на дератизацию и дезинсекцию","item":"https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/dogovor-deratizatsiya-dezinsektsiya/"}]},{"@type":"Service","@id":"https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/dogovor-deratizatsiya-dezinsektsiya/#service","name":"Договор на дератизацию и дезинсекцию","serviceType":"Дератизация и дезинсекция по договору (пест-контроль)","description":"Договорное обслуживание организаций: график визитов, точки контроля, обработки по результатам мониторинга, акт после каждого выезда. Внеплановый выезд — в течение 3 часов.","url":"https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/dogovor-deratizatsiya-dezinsektsiya/","provider":{"@type":"Organization","@id":"https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/#org","name":"ПЕСТКОНТРОЛЬ Центр","url":"https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/","telephone":"+7 495 104-35-70","email":"b2b@pestcontrol-center.ru"},"areaServed":[{"@type":"City","name":"Москва"},{"@type":"AdministrativeArea","name":"Московская область"}],"audience":{"@type":"BusinessAudience","audienceType":"Организации и предприятия"},"offers":{"@type":"AggregateOffer","priceCurrency":"RUB","lowPrice":3500,"offerCount":3},"hasOfferCatalog":{"@type":"OfferCatalog","name":"Обслуживание по договору","itemListElement":[{"@type":"Offer","name":"Кафе, ресторан: грызуны и насекомые, 1–2 визита в месяц","priceCurrency":"RUB","price":3500,"priceSpecification":{"@type":"UnitPriceSpecification","minPrice":3500,"priceCurrency":"RUB","unitText":"в месяц","unitCode":"MON"}},{"@type":"Offer","name":"Магазин: грызуны и насекомые, 1–2 визита в месяц","priceCurrency":"RUB","price":3500,"priceSpecification":{"@type":"UnitPriceSpecification","minPrice":3500,"priceCurrency":"RUB","unitText":"в месяц","unitCode":"MON"}},{"@type":"Offer","name":"Склад до 1 000 м²: грызуны, периметр и зоны хранения","priceCurrency":"RUB","price":4500,"priceSpecification":{"@type":"UnitPriceSpecification","minPrice":4500,"priceCurrency":"RUB","unitText":"в месяц","unitCode":"MON"}}]}},{"@type":"FAQPage","mainEntity":[{"@type":"Question","name":"Можно заключить договор только на дератизацию?","acceptedAnswer":{"@type":"Answer","text":"Да. Можно начать с одного направления и позже добавить второе дополнительным соглашением."}},{"@type":"Question","name":"Как часто будет приезжать специалист?","acceptedAnswer":{"@type":"Answer","text":"Кратность определяем после выезда — по типу объекта, зонам риска и требованиям ваших аудиторов — и закрепляем в графике, приложении к договору. Для кафе, ресторанов и магазинов обычно это 1–2 визита в месяц."}},{"@type":"Question","name":"Что делать, если вредители появились между визитами?","acceptedAnswer":{"@type":"Answer","text":"Позвоните или напишите в мессенджер — согласуем внеплановый выезд, найдём причину и при необходимости обработаем очаг. Специалист приедет в течение 3 часов. Порядок таких выездов закрепляем в договоре."}},{"@type":"Question","name":"Можно один договор на несколько адресов?","acceptedAnswer":{"@type":"Answer","text":"Да: адреса перечисляем в приложении, график общий, отчёт сводный."}},{"@type":"Question","name":"Можно посмотреть договор заранее?","acceptedAnswer":{"@type":"Answer","text":"Да. Образец договора с приложениями можно скачать в PDF. Проект с вашими адресами, графиком и ценой пришлём в течение 1 часа после бесплатного осмотра."}},{"@type":"Question","name":"На какой срок заключается договор?","acceptedAnswer":{"@type":"Answer","text":"На 12 месяцев с автоматической пролонгацией. Расторгнуть договор можно с письменным уведомлением за 30 календарных дней."}},{"@type":"Question","name":"Работаете с НДС и по ЭДО?","acceptedAnswer":{"@type":"Answer","text":"Да, работаем как с НДС, так и без НДС (УСН). Договор, акты и закрывающие документы подписываем через ЭДО или на бумаге."}}]}]}</script>
<style id="m-crumbs">/* крошки на телефоне не показываем: для SEO хватает BreadcrumbList и ссылок в HTML */@media (max-width:900px){.d-crumbs,.f-crumbs{display:none!important}}</style>
<style data-fx>
/* подсветка рамки карточек за курсором — как у .card на главной (tools/site/fx.py) */
:where(.d-card,.p-sec,.p-fcard,.p-duty-box,.p-dl-card,.pm-step-card,.pm-scen,.pm-link-card,.k-err,.w-sample,.d-doc-prev){position:relative}
:where(.d-card,.p-sec,.p-fcard,.p-duty-box,.p-dl-card,.pm-step-card,.pm-scen,.pm-link-card,.k-err,.w-sample,.d-doc-prev)::after{content:"";position:absolute;inset:0;border-radius:inherit;padding:1.4px;pointer-events:none;background:radial-gradient(360px circle at var(--mx,-999px) var(--my,-999px),rgba(124,134,255,.85),rgba(124,134,255,.15) 35%,transparent 60%);-webkit-mask:linear-gradient(#000 0 0) content-box,linear-gradient(#000 0 0);-webkit-mask-composite:xor;mask:linear-gradient(#000 0 0) content-box,linear-gradient(#000 0 0);mask-composite:exclude;opacity:0;transition:opacity .4s;z-index:2}
@media (hover:hover) and (pointer:fine){:where(.d-card,.p-sec,.p-fcard,.p-duty-box,.p-dl-card,.pm-step-card,.pm-scen,.pm-link-card,.k-err,.w-sample,.d-doc-prev):hover::after{opacity:1}}
/* «фонарь» на фото первого экрана — как на главной (tools/site/fx.py) */
.fx-lit{position:absolute;inset:0;opacity:0;pointer-events:none;-webkit-mask-image:radial-gradient(circle var(--sr,320px) at var(--sx,72%) var(--sy,46%),#000 0%,rgba(0,0,0,.55) 45%,transparent 72%);mask-image:radial-gradient(circle var(--sr,320px) at var(--sx,72%) var(--sy,46%),#000 0%,rgba(0,0,0,.55) 45%,transparent 72%);transition:opacity 1.8s cubic-bezier(.16,1,.3,1)}
#hero :is(.d-hero-media,.hero-media)>picture>img{transition:filter 1.8s cubic-bezier(.16,1,.3,1)}
#hero.fx-lit-on :is(.d-hero-media,.hero-media)>picture>img{filter:grayscale(.3) brightness(.56)}
#hero.fx-lit-on .fx-lit img{filter:brightness(1.08) contrast(1.06) saturate(1.06)}
#hero.fx-lit-on .fx-lit{opacity:1}
</style>
</head>
<body class="d-page">
<a class="skip" href="#main">Перейти к содержанию</a>

<!-- ============ INTRO ============ -->
<div class="intro" id="intro" aria-hidden="true">
  <div class="intro-in">
    <svg class="intro-mark" viewBox="0 0 24 24" fill="none" stroke-width="1" stroke-linejoin="round"><path class="im-shield" pathLength="100" d="M12 2.5l7.5 3v6c0 5-3.2 8.6-7.5 10-4.3-1.4-7.5-5-7.5-10v-6z" stroke="#fff"/><circle class="im-c" pathLength="100" cx="12" cy="11.5" r="2.6" stroke="#7c86ff"/><path class="im-x" pathLength="100" d="M12 6.2v2.7M12 14.1v2.7M6.8 11.5h2.6M14.6 11.5h2.6" stroke="#7c86ff"/></svg>
    <div class="intro-word"><span>ПЕСТКОНТРОЛЬ</span><b>Центр</b></div>
    <div class="intro-bar"><i></i></div>
  </div>
</div>

<div class="progress" aria-hidden="true"><i id="progress"></i></div>
<div class="cursor" aria-hidden="true"><i class="cursor-dot"></i><i class="cursor-ring"></i></div>
<div class="grain" aria-hidden="true"></div>

<header class="hdr" id="hdr">
  <div class="wrap">
    <a href="../" class="logo" aria-label="ПЕСТКОНТРОЛЬ Центр — на главную">
      <span class="logo-mark"><svg viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="1.6" stroke-linejoin="round" aria-hidden="true"><path d="M12 2.5l7.5 3v6c0 5-3.2 8.6-7.5 10-4.3-1.4-7.5-5-7.5-10v-6z"/><circle cx="12" cy="11.5" r="2.6" stroke="#7c86ff"/><path d="M12 6.2v2.7M12 14.1v2.7M6.8 11.5h2.6M14.6 11.5h2.6" stroke="#7c86ff"/></svg></span>
      <span class="logo-txt"><span class="logo-name">ПЕСТКОНТРОЛЬ</span> <span class="logo-sub">Центр</span></span>
    </a>
    <nav class="nav" aria-label="Основное меню">
      <div class="nav-dd"><button class="nav-dd-btn" type="button" aria-expanded="false" aria-controls="nav-uslugi">Услуги<svg viewBox="0 0 12 12" aria-hidden="true"><path d="M2.5 4.5 6 8l3.5-3.5" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></button><div class="nav-dd-panel" id="nav-uslugi"><a href="../dezinfektsiya/">Дезинфекция для организаций<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../deratizatsiya/">Дератизация для организаций<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../dezinsektsiya/">Дезинсекция для организаций<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../sanitarnyy-audit/"><span>Санитарный аудит <span class="nw">(СЭС-аудит)</span></span><svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../razrabotka-ppk/">Разработка ППК<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../ochistka-dezinfektsiya-ventilyatsii/">Очистка и дезинфекция вентиляции<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="./" aria-current="page">Договор на обслуживание<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../#podhod" class="nav-dd-all"><span>Пест-контроль по системе IPM</span><svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a></div></div><div class="nav-dd"><button class="nav-dd-btn" type="button" aria-expanded="false" aria-controls="nav-otrasli">Отрасли<svg viewBox="0 0 12 12" aria-hidden="true"><path d="M2.5 4.5 6 8l3.5-3.5" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></button><div class="nav-dd-panel" id="nav-otrasli"><a href="../pishchevoe-proizvodstvo/">Пищевые производства<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../magaziny-i-torgovye-seti/">Магазины и торговые сети<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../restorany-i-kafe/">Рестораны и кафе<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../sklady-i-logistika/">Склады и логистика<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../farmatsevticheskie-proizvodstva/">Фармацевтические производства<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../gostinitsy/">Гостиницы и отели<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../#otrasli" class="nav-dd-all">Все отрасли<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a></div></div><a href="./" class="active" aria-current="page">Договор</a><a href="../#podhod">Метод IPM</a><a href="../#usloviya">Цена</a><div class="nav-dd"><button class="nav-dd-btn" type="button" aria-expanded="false" aria-controls="nav-materialy">Материалы<svg viewBox="0 0 12 12" aria-hidden="true"><path d="M2.5 4.5 6 8l3.5-3.5" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></button><div class="nav-dd-panel" id="nav-materialy"><a href="../normativnaya-baza/">Нормативная база<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../materialy/programma-pest-kontrolya/"><span>Программа <span class="nw">пест-контроля</span></span><svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../materialy/zhurnal-pest-kontrolya/"><span>Журнал <span class="nw">пест-контроля</span></span><svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../materialy/pest-menedzhment-ili-razovaya-obrabotka/"><span><span class="nw">Пест-менеджмент</span> или разовая обработка</span><svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../materialy/programma-proizvodstvennogo-kontrolya-haccp/">Программа производственного контроля по ХАССП<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../materialy/" class="nav-dd-all">Все материалы<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a></div></div>
    </nav>
    <div class="hdr-right">
      <a class="phone" href="tel:+74951043570" aria-label="Позвонить: +7 (495) 104-35-70"><i><svg viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2" aria-hidden="true"><path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1 1 .4 1.9.7 2.8a2 2 0 0 1-.5 2.1L8 9.9a16 16 0 0 0 6 6l1.3-1.3a2 2 0 0 1 2.1-.4c.9.3 1.8.6 2.8.7a2 2 0 0 1 1.7 2z"/></svg></i><span>+7 (495) 104-35-70</span></a>
      <div class="msg">
        <a href="https://max.ru/u/f9LHodD0cOIlIUXFkt4KMFP88lD8n4TArBiTcV7RI1XML5c4o39QfsDBXUc" class="max" aria-label="Написать в Max" target="_blank" rel="noopener noreferrer"><svg viewBox="0 0 24 24" fill="#fff" aria-hidden="true"><path d="M12 3a9 9 0 0 0-7.7 13.7L3 21l4.4-1.2A9 9 0 1 0 12 3zm-3.6 12.3V8.7h1.6l2 2.8 2-2.8h1.6v6.6h-1.7v-3.9L12 14l-1.9-2.6v3.9z"/></svg></a>
        <a href="https://t.me/Centr_Dezinfection?text=%D0%97%D0%B4%D1%80%D0%B0%D0%B2%D1%81%D1%82%D0%B2%D1%83%D0%B9%D1%82%D0%B5!%20%D0%9F%D0%B8%D1%88%D1%83%20%D1%81%20%D1%81%D0%B0%D0%B9%D1%82%D0%B0%20%D0%BF%D0%B5%D1%81%D1%82%D0%BA%D0%BE%D0%BD%D1%82%D1%80%D0%BE%D0%BB%D1%8C-%D1%86%D0%B5%D0%BD%D1%82%D1%80.%D1%80%D1%84" class="tg" aria-label="Написать в Telegram" target="_blank" rel="noopener noreferrer"><svg viewBox="0 0 24 24" fill="#fff" aria-hidden="true"><path d="M21.4 4.3 2.9 11.4c-1.3.5-1.2 1.2-.2 1.5l4.7 1.5 1.8 5.6c.2.6.4.8.9.8.4 0 .6-.2.9-.4l2.3-2.2 4.7 3.5c.9.5 1.5.2 1.7-.8l3.1-14.6c.3-1.3-.5-1.8-1.4-1.5zM9.6 14.1l8.6-5.4c.4-.3.8-.1.5.2l-7.1 6.4-.3 3.3z"/></svg></a>
      </div>
      <a href="#zayavka" class="btn btn-w btn-sm" data-magnet><span class="btn-t">Проект договора</span></a>
      <button class="burger" id="burger" aria-label="Открыть меню" aria-expanded="false" aria-controls="mmenu"><span></span></button>
    </div>
  </div>
</header>
<nav class="mmenu" id="mmenu" aria-label="Мобильное меню">
  <div class="mm-group"><button class="mm-toggle" type="button" aria-expanded="false" aria-controls="mm-uslugi">Услуги<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m6 9 6 6 6-6" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/></svg></button><div class="mm-sub" id="mm-uslugi"><div><a href="../dezinfektsiya/">Дезинфекция для организаций</a><a href="../deratizatsiya/">Дератизация для организаций</a><a href="../dezinsektsiya/">Дезинсекция для организаций</a><a href="../sanitarnyy-audit/"><span>Санитарный аудит <span class="nw">(СЭС-аудит)</span></span></a><a href="../razrabotka-ppk/">Разработка ППК</a><a href="../ochistka-dezinfektsiya-ventilyatsii/">Очистка и дезинфекция вентиляции</a><a href="./" aria-current="page">Договор на обслуживание</a><a href="../#podhod"><span class="nw">Пест-контроль</span> по системе IPM</a></div></div></div><div class="mm-group"><button class="mm-toggle" type="button" aria-expanded="false" aria-controls="mm-otrasli">Отрасли<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m6 9 6 6 6-6" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/></svg></button><div class="mm-sub" id="mm-otrasli"><div><a href="../pishchevoe-proizvodstvo/">Пищевые производства</a><a href="../magaziny-i-torgovye-seti/">Магазины и торговые сети</a><a href="../restorany-i-kafe/">Рестораны и кафе</a><a href="../sklady-i-logistika/">Склады и логистика</a><a href="../farmatsevticheskie-proizvodstva/">Фармацевтические производства</a><a href="../gostinitsy/">Гостиницы и отели</a><a href="../#otrasli">Все отрасли</a></div></div></div><a href="./" aria-current="page">Договор <small>на дератизацию и дезинсекцию</small></a><a href="../#podhod">Метод IPM</a><a href="../#usloviya">Цена</a><div class="mm-group"><button class="mm-toggle" type="button" aria-expanded="false" aria-controls="mm-materialy">Материалы<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m6 9 6 6 6-6" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/></svg></button><div class="mm-sub" id="mm-materialy"><div><a href="../normativnaya-baza/">Нормативная база</a><a href="../materialy/programma-pest-kontrolya/"><span>Программа <span class="nw">пест-контроля</span></span></a><a href="../materialy/zhurnal-pest-kontrolya/"><span>Журнал <span class="nw">пест-контроля</span></span></a><a href="../materialy/pest-menedzhment-ili-razovaya-obrabotka/"><span><span class="nw">Пест-менеджмент</span> или разовая обработка</span></a><a href="../materialy/programma-proizvodstvennogo-kontrolya-haccp/">Программа производственного контроля по ХАССП</a><a href="../materialy/">Все материалы</a></div></div></div>
  <a href="#zayavka" class="btn btn-w btn-lg"><span class="btn-t">Получить проект договора</span></a>
</nav>

<main id="main" tabindex="-1">
<section class="d-hero" id="hero">
  <div class="wrap">
    <div class="d-hero-copy">
      <nav class="d-crumbs" aria-label="Навигационная цепочка" data-h><a href="../">Главная</a><span aria-hidden="true">→</span><span aria-current="page">Договор на дератизацию и дезинсекцию</span></nav>
      <div class="eyebrow">Договорное обслуживание организаций</div>
      <h1><span class="ln d-ln1"><span>Договор</span></span> <span class="ln d-ln2"><span>на&nbsp;дератизацию</span></span> <span class="ln"><span><em>и&nbsp;дезинсекцию</em></span></span></h1>
      <div class="d-hero-media"><picture><source media="(max-width:860px)" srcset="../img/dogovor-hero-mob-760.webp 760w, ../img/dogovor-hero-mob.webp 1024w" sizes="100vw" width="1024" height="576"><img class="d-hero-img" src="../img/dogovor-hero.webp" srcset="../img/dogovor-hero-1440.webp 1440w, ../img/dogovor-hero.webp 1920w" sizes="100vw" width="1920" height="1072" alt="Специалист пест-контроля передаёт руководителю объекта папку с договором и схемой размещения точек контроля" fetchpriority="high" decoding="async"></picture><div class="fx-lit" aria-hidden="true"><picture><source media="(max-width:860px)" srcset="../img/dogovor-hero-mob-760.webp 760w, ../img/dogovor-hero-mob.webp 1024w" sizes="100vw" width="1024" height="576"><img class="d-hero-img fx-lit-img" src="../img/dogovor-hero.webp" srcset="../img/dogovor-hero-1440.webp 1440w, ../img/dogovor-hero.webp 1920w" sizes="100vw" width="1920" height="1072" alt="" decoding="async"></picture></div></div>
      <ul class="d-ticks">
        <li data-h>Дератизация, дезинсекция или оба направления — в&nbsp;одном договоре</li>
        <li data-h>Несколько адресов — один договор и&nbsp;общий график</li>
        <li data-h>Бесплатный выезд и&nbsp;расчёт до&nbsp;заключения</li>
      </ul>
      <p class="sub" data-h>График визитов, точки контроля и&nbsp;акт после каждого выезда. Состав и&nbsp;цену видите до&nbsp;подписания.</p>
      <div class="d-btns" data-h>
        <a href="#zayavka" class="btn btn-w btn-lg" data-magnet><span class="btn-t">Получить проект договора</span></a>
        <a href="tel:+74951043570" class="btn btn-o btn-lg d-tel-btn" data-magnet><span class="btn-t">+7 (495) 104-35-70</span></a>
      </div>
    </div>
    <div aria-hidden="true"></div>
  </div>
</section>

<div class="strip" aria-label="Коротко о договоре">
  <div class="strip-track" id="stripTrack">
    <div class="strip-set">
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-file-signature" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M14.364 13.634a2 2 0 0 0-.506.854l-.837 2.87a.5.5 0 0 0 .62.62l2.87-.837a2 2 0 0 0 .854-.506l4.013-4.009a1 1 0 0 0-3.004-3.004z" /> <path d="M14.487 7.858A1 1 0 0 1 14 7V2" /> <path d="M20 19.645V20a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.704.706l2.516 2.516" /> <path d="M8 18h1" /> </svg><b>Один договор</b> на дератизацию и дезинсекцию</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-map-pinned" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M18 8c0 3.613-3.869 7.429-5.393 8.795a1 1 0 01-1.214 0C9.87 15.429 6 11.613 6 8a6 6 0 0112 0" /> <path d="M4.474 15h-.197a1 1 0 00-.969.753l-1.097 4.35a1.5 1.5 0 001.444 1.898L20.344 22a1.5 1.5 0 001.446-1.897l-1.098-4.35a1 1 0 00-.969-.753h-.197" /> <circle cx="12" cy="8" r="2" /> </svg><b>Несколько адресов</b> — общий график</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-scan-search" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M3 7V5a2 2 0 0 1 2-2h2" /> <path d="M17 3h2a2 2 0 0 1 2 2v2" /> <path d="M21 17v2a2 2 0 0 1-2 2h-2" /> <path d="M7 21H5a2 2 0 0 1-2-2v-2" /> <circle cx="12" cy="12" r="3" /> <path d="m16 16-1.9-1.9" /> </svg><b>Бесплатный выезд</b> и расчёт до заключения</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-activity" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M22 12h-2.48a2 2 0 0 0-1.93 1.46l-2.35 8.36a.25.25 0 0 1-.48 0L9.24 2.18a.25.25 0 0 0-.48 0l-2.35 8.36A2 2 0 0 1 4.49 12H2" /> </svg><b>График визитов</b> по программе</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-notebook-pen" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M13.4 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-7.4" /> <path d="M2 6h4" /> <path d="M2 10h4" /> <path d="M2 14h4" /> <path d="M2 18h4" /> <path d="M21.378 5.626a1 1 0 1 0-3.004-3.004l-5.01 5.012a2 2 0 0 0-.506.854l-.837 2.87a.5.5 0 0 0 .62.62l2.87-.837a2 2 0 0 0 .854-.506z" /> </svg><b>Акт</b> после каждого выезда</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-shield-check" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z" /> <path d="m9 12 2 2 4-4" /> </svg><b>Точки контроля</b> на схеме объекта</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-file-badge" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M13 22h5a2 2 0 0 0 2-2V8a2.4 2.4 0 0 0-.706-1.706l-3.588-3.588A2.4 2.4 0 0 0 14 2H6a2 2 0 0 0-2 2v3.3" /> <path d="M14 2v5a1 1 0 0 0 1 1h5" /> <path d="m7.69 16.479 1.29 4.88a.5.5 0 0 1-.698.591l-1.843-.849a1 1 0 0 0-.879.001l-1.846.85a.5.5 0 0 1-.692-.593l1.29-4.88" /> <circle cx="6" cy="14" r="3" /> </svg><b>Документы</b> для Роспотребнадзора и аудитов</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-crosshair" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <circle cx="12" cy="12" r="10" /> <line x1="22" x2="18" y1="12" y2="12" /> <line x1="6" x2="2" y1="12" y2="12" /> <line x1="12" x2="12" y1="6" y2="2" /> <line x1="12" x2="12" y1="22" y2="18" /> </svg><b>IPM</b> в основе программы</div>
    </div>
    <div class="strip-set" aria-hidden="true">
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-file-signature" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M14.364 13.634a2 2 0 0 0-.506.854l-.837 2.87a.5.5 0 0 0 .62.62l2.87-.837a2 2 0 0 0 .854-.506l4.013-4.009a1 1 0 0 0-3.004-3.004z" /> <path d="M14.487 7.858A1 1 0 0 1 14 7V2" /> <path d="M20 19.645V20a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.704.706l2.516 2.516" /> <path d="M8 18h1" /> </svg><b>Один договор</b> на дератизацию и дезинсекцию</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-map-pinned" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M18 8c0 3.613-3.869 7.429-5.393 8.795a1 1 0 01-1.214 0C9.87 15.429 6 11.613 6 8a6 6 0 0112 0" /> <path d="M4.474 15h-.197a1 1 0 00-.969.753l-1.097 4.35a1.5 1.5 0 001.444 1.898L20.344 22a1.5 1.5 0 001.446-1.897l-1.098-4.35a1 1 0 00-.969-.753h-.197" /> <circle cx="12" cy="8" r="2" /> </svg><b>Несколько адресов</b> — общий график</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-scan-search" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M3 7V5a2 2 0 0 1 2-2h2" /> <path d="M17 3h2a2 2 0 0 1 2 2v2" /> <path d="M21 17v2a2 2 0 0 1-2 2h-2" /> <path d="M7 21H5a2 2 0 0 1-2-2v-2" /> <circle cx="12" cy="12" r="3" /> <path d="m16 16-1.9-1.9" /> </svg><b>Бесплатный выезд</b> и расчёт до заключения</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-activity" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M22 12h-2.48a2 2 0 0 0-1.93 1.46l-2.35 8.36a.25.25 0 0 1-.48 0L9.24 2.18a.25.25 0 0 0-.48 0l-2.35 8.36A2 2 0 0 1 4.49 12H2" /> </svg><b>График визитов</b> по программе</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-notebook-pen" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M13.4 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-7.4" /> <path d="M2 6h4" /> <path d="M2 10h4" /> <path d="M2 14h4" /> <path d="M2 18h4" /> <path d="M21.378 5.626a1 1 0 1 0-3.004-3.004l-5.01 5.012a2 2 0 0 0-.506.854l-.837 2.87a.5.5 0 0 0 .62.62l2.87-.837a2 2 0 0 0 .854-.506z" /> </svg><b>Акт</b> после каждого выезда</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-shield-check" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z" /> <path d="m9 12 2 2 4-4" /> </svg><b>Точки контроля</b> на схеме объекта</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-file-badge" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M13 22h5a2 2 0 0 0 2-2V8a2.4 2.4 0 0 0-.706-1.706l-3.588-3.588A2.4 2.4 0 0 0 14 2H6a2 2 0 0 0-2 2v3.3" /> <path d="M14 2v5a1 1 0 0 0 1 1h5" /> <path d="m7.69 16.479 1.29 4.88a.5.5 0 0 1-.698.591l-1.843-.849a1 1 0 0 0-.879.001l-1.846.85a.5.5 0 0 1-.692-.593l1.29-4.88" /> <circle cx="6" cy="14" r="3" /> </svg><b>Документы</b> для Роспотребнадзора и аудитов</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-crosshair" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <circle cx="12" cy="12" r="10" /> <line x1="22" x2="18" y1="12" y2="12" /> <line x1="6" x2="2" y1="12" y2="12" /> <line x1="12" x2="12" y1="6" y2="2" /> <line x1="12" x2="12" y1="22" y2="18" /> </svg><b>IPM</b> в основе программы</div>
    </div>
  </div>
</div>

<section class="s" id="vidy">
  <div class="wrap">
    <div class="head"><div class="eyebrow" data-eyebrow>Виды договора</div><h2 data-split>Дератизация, дезинсекция <em>или&nbsp;комплекс</em></h2></div>
    <div class="d-cards" data-group="cards">
      <article class="d-card d-kind" data-tilt><div class="d-kind-img"><img src="../img/dogovor-vid-deratizatsiya.webp" srcset="../img/dogovor-vid-deratizatsiya-480.webp 480w, ../img/dogovor-vid-deratizatsiya-720.webp 720w, ../img/dogovor-vid-deratizatsiya.webp 1200w" sizes="(max-width:600px) calc(100vw - 40px), (max-width:860px) 42vw, (max-width:1900px) 30vw, 570px" width="1200" height="670" loading="lazy" decoding="async" alt="Специалист проверяет пронумерованную станцию с приманкой для грызунов у ворот склада"></div><div class="d-kind-b"><h3><a href="../deratizatsiya/" style="color:inherit;border-bottom:1px solid var(--line2)">Дератизация</a></h3><p>Крысы и мыши. Станции с приманкой по периметру и снаружи здания; внутри — ловушки без яда там, где приманки недопустимы: цеха, склады продукции, чистые помещения.</p></div></article>
      <article class="d-card d-kind" data-tilt><div class="d-kind-img"><img src="../img/dogovor-vid-dezinsektsiya.webp" srcset="../img/dogovor-vid-dezinsektsiya-480.webp 480w, ../img/dogovor-vid-dezinsektsiya-720.webp 720w, ../img/dogovor-vid-dezinsektsiya.webp 1200w" sizes="(max-width:600px) calc(100vw - 40px), (max-width:860px) 42vw, (max-width:1900px) 30vw, 570px" width="1200" height="670" loading="lazy" decoding="async" alt="Специалист осматривает клеевую ловушку-монитор на кухне ресторана, на стене — лампа для летающих насекомых"></div><div class="d-kind-b"><h3><a href="../dezinsektsiya/" style="color:inherit;border-bottom:1px solid var(--line2)">Дезинсекция</a></h3><p>Тараканы, муравьи, мухи, моль, складские вредители. Клеевые ловушки-мониторы, лампы для летающих насекомых, обработки только в зонах активности.</p></div></article>
      <article class="d-card d-kind" data-tilt><div class="d-kind-img"><img src="../img/dogovor-vid-kompleks.webp" srcset="../img/dogovor-vid-kompleks-480.webp 480w, ../img/dogovor-vid-kompleks-720.webp 720w, ../img/dogovor-vid-kompleks.webp 1200w" sizes="(max-width:600px) calc(100vw - 40px), (max-width:860px) 42vw, (max-width:1900px) 30vw, 570px" width="1200" height="670" loading="lazy" decoding="async" alt="Специалист показывает руководителю производства данные мониторинга на планшете; рядом станция для грызунов и лампа для насекомых"></div><div class="d-kind-b"><h3>Комплекс</h3><p>Грызуны и насекомые в одном графике: один визит, один акт, один счёт. Удобно, когда риск есть по обоим направлениям — например, на кухне или в цехе.</p></div></article>
    </div>
    <p class="d-note" data-fade>Можно начать с одного направления и добавить второе дополнительным соглашением.</p>
  </div>
</section>

<section class="s" id="sostav">
  <div class="wrap">
    <div class="head"><div class="eyebrow" data-eyebrow>Состав договора</div><h2 data-split>Что прописываем <em>в&nbsp;договоре</em></h2>
      <p class="sub" data-fade>Договор и приложения описывают реальную работу на объекте. Проект присылаем до подписания — его можно отдать юристу и службе качества.</p></div>
    <div class="d-split">
      <ol class="d-terms" data-group="steps">
        <li><b>Объекты и зоны</b><span>Адреса, площади, что обслуживаем: территория, здание, отдельные помещения.</span></li>
        <li><b>Программа и график</b><span>Кратность визитов, что делаем на каждом визите, ответственные с обеих сторон.</span></li>
        <li><b>Схема точек контроля</b><span>План объекта с номерами станций и ловушек.</span></li>
        <li><b>Внеплановые выезды</b><span>Как подать заявку и срок прибытия специалиста — в течение 3 часов.</span></li>
        <li><b>Приёмка работ</b><span>Акт после каждого визита, запись в журнале, отчёт раз в месяц.</span></li>
        <li><b>Средства</b><span>Только с госрегистрацией; свидетельства и инструкции передаём заранее.</span></li>
        <li><b>Срок и условия</b><span>Срок договора — 12 месяцев с пролонгацией, изменение объёма работ, расторжение — с уведомлением за 30 дней.</span></li>
      </ol>
      <div class="d-doc" data-fade>
        <h3 class="d-doc-h">Образец договора на&nbsp;дератизацию и&nbsp;дезинсекцию</h3>
        <a href="obrazets-dogovora-pestkontrol-tsentr.pdf" class="d-doc-prev" target="_blank" rel="noopener" aria-label="Открыть образец договора на дератизацию и дезинсекцию, PDF, в новой вкладке"><img src="../img/dogovor-sample-p1.webp" srcset="../img/dogovor-sample-p1-240.webp 240w, ../img/dogovor-sample-p1-360.webp 360w, ../img/dogovor-sample-p1.webp 680w" sizes="(max-width:400px) 96px, (max-width:860px) 120px, 340px" width="680" height="962" loading="lazy" decoding="async" alt="Первая страница образца договора ПЕСТКОНТРОЛЬ Центр на дератизацию и дезинсекцию"></a>
        <p class="d-small">Договор и&nbsp;2&nbsp;приложения: перечень работ и&nbsp;стоимость, правила безопасности. PDF, 6&nbsp;стр., 90&nbsp;КБ</p>
        <a href="obrazets-dogovora-pestkontrol-tsentr.pdf" class="btn btn-o btn-lg d-doc-btn" download="Образец договора на дератизацию и дезинсекцию — ПЕСТКОНТРОЛЬ Центр.pdf"><span class="btn-t">Скачать образец договора, PDF</span></a>
      </div>
    </div>
  </div>
</section>

<section class="s" id="etapy">
  <div class="wrap">
    <div class="head"><div class="eyebrow" data-eyebrow>Порядок</div><h2 data-split>Как заключить <em>договор</em></h2></div>
    <ol class="d-steps" data-group="steps">
      <li><b>Заявка</b><span>По телефону, в мессенджере или через форму. Уточняем адрес, тип объекта и площадь.</span></li>
      <li><b>Бесплатный выезд</b><span>Специалист осматривает объект и определяет, где и сколько нужно точек контроля.</span></li>
      <li><b>Проект договора</b><span>В течение 1 часа после осмотра присылаем договор с программой, графиком и ценой.</span></li>
      <li><b>Подписание</b><span>На бумаге или через ЭДО — работаем с НДС и без НДС.</span></li>
      <li><b>Первый визит</b><span>Ставим точки контроля, передаём схему и журнал. Если есть активный очаг — обрабатываем сразу.</span></li>
    </ol>
    <p class="d-note" data-fade>От заявки до первого визита — от 3 часов.</p>
  </div>
</section>

<section class="s" id="smena">
  <div class="wrap d-swap">
    <div class="head"><div class="eyebrow" data-eyebrow>Смена подрядчика</div><h2 data-split>Меняете <em>подрядчика</em></h2>
      <p class="sub" data-fade>Переходим без перерыва в контроле — чтобы в журнале не было пустых месяцев.</p></div>
    <figure class="d-swap-img" data-fade><img src="../img/dogovor-smena.webp" srcset="../img/dogovor-smena-720.webp 720w, ../img/dogovor-smena.webp 1200w" sizes="(max-width:860px) calc(100vw - 40px), (max-width:1900px) 44vw, 840px" width="1200" height="896" loading="lazy" decoding="async" alt="Специалист снимает старую станцию прежнего подрядчика, рядом новая станция и открытый журнал учёта"></figure>
    <ul class="d-ticks" data-group="ctalist">
      <li>Смотрим, что осталось от прежнего подрядчика: точки, схему, журнал, акты.</li>
      <li>Ставим свои точки контроля и составляем схему с учётом прежней.</li>
      <li>Первый визит назначаем на дату окончания старого договора.</li>
      <li>Данные прежнего журнала учитываем в первом отчёте, если они есть.</li>
    </ul>
  </div>
</section>

<section class="s" id="stoimost">
  <div class="wrap">
    <div class="head"><div class="eyebrow" data-eyebrow>Стоимость</div><h2 data-split>Сколько стоит <em>обслуживание по&nbsp;договору</em></h2>
      <p class="sub" data-fade>Оплата по договору на дератизацию и дезинсекцию — ежемесячная, сумма закреплена в договоре. Точную цену называем после бесплатного выезда.</p></div>
    <table class="d-table d-prices" data-fade>
      <caption class="sr-only">Ориентировочная стоимость обслуживания по договору в месяц</caption>
      <thead><tr><th scope="col">Объект</th><th scope="col">Что обычно входит</th><th scope="col" class="d-price">Ориентир</th></tr></thead>
      <tbody><tr><td data-l="Объект">Кафе, ресторан</td><td data-l="Что обычно входит">Грызуны и насекомые, 1–2 визита в месяц</td><td data-l="Ориентир" class="d-price">от 3 500 ₽/мес</td></tr><tr><td data-l="Объект">Магазин</td><td data-l="Что обычно входит">Грызуны и насекомые, 1–2 визита в месяц</td><td data-l="Ориентир" class="d-price">от 3 500 ₽/мес</td></tr><tr><td data-l="Объект">Склад до 1 000 м²</td><td data-l="Что обычно входит">Грызуны: периметр и зоны хранения</td><td data-l="Ориентир" class="d-price">от 4 500 ₽/мес</td></tr><tr><td data-l="Объект">Пищевое производство</td><td data-l="Что обычно входит">Комплекс по зонам ХАССП</td><td data-l="Ориентир" class="d-price">после выезда</td></tr></tbody>
    </table>
    <div class="d-cols2" data-group="cards">
      <div class="d-card"><h3>Входит в оплату</h3><p>Визиты по графику, осмотр и обслуживание точек контроля, записи в журнале, акты и ежемесячный отчёт.</p></div>
      <div class="d-card"><h3>Оплачивается отдельно</h3><p>Обработки по результатам мониторинга и выезды вне графика. Порядок их оплаты прописываем в договоре.</p></div>
    </div>
  </div>
</section>

<section class="s" id="sravnenie">
  <div class="wrap">
    <div class="head"><div class="eyebrow" data-eyebrow>Разница</div><h2 data-split>Рабочий договор <em>или «договор для&nbsp;проверки»</em></h2></div>
    <table class="d-table d-vs" data-fade>
      <caption class="sr-only">Чем рабочий договор отличается от договора «для проверки»</caption>
      <thead><tr><th scope="col">«Для проверки»</th><th scope="col">Рабочий договор</th></tr></thead>
      <tbody><tr><td data-l="«Для проверки»">Подписан, но выездов нет или они формальные</td><td data-l="Рабочий договор">Визиты по графику, каждый — с датой в журнале</td></tr><tr><td data-l="«Для проверки»">Схемы точек нет, на объекте нечего показать</td><td data-l="Рабочий договор">Каждая точка с номером — на плане и на месте</td></tr><tr><td data-l="«Для проверки»">Акты одинаковые из месяца в месяц</td><td data-l="Рабочий договор">В акте — находки и меры по каждой зоне</td></tr><tr><td data-l="«Для проверки»">Вредители появились — подрядчик не отвечает</td><td data-l="Рабочий договор">Внеплановый выезд в срок из договора</td></tr></tbody>
    </table>
    <p class="d-note d-strong" data-fade>Договоры без выездов мы не заключаем.</p>
  </div>
</section>

<section class="s" id="obekty">
  <div class="wrap">
    <div class="head"><div class="eyebrow" data-eyebrow>Объекты</div><h2 data-split>С кем работаем <em>по&nbsp;договору</em></h2></div>
    <ul class="d-objs" data-group="cards">
      <li class="card d-obj" data-tilt><div class="d-obj-img"><picture><source media="(max-width:600px)" srcset="../img/ind-bakery-sq.webp" width="280" height="280"><img src="../img/ind-bakery.webp" srcset="../img/ind-bakery-480.webp 480w, ../img/ind-bakery-720.webp 720w, ../img/ind-bakery.webp 900w" sizes="(max-width:1100px) 46vw, (max-width:1900px) 30vw, 570px" width="900" height="542" loading="lazy" decoding="async" alt="Цех хлебозавода с инсектицидной лампой и станцией контроля грызунов"></picture></div><div class="d-obj-b"><h3><a href="../pishchevoe-proizvodstvo/">Пищевые производства</a></h3><p>Точки контроля по зонам ХАССП, закрытые станции в цехах, документы для аудитов сетей и сертификации.</p></div></li>
      <li class="card d-obj" data-tilt><div class="d-obj-img"><picture><source media="(max-width:600px)" srcset="../img/ind-retail-sq.webp" width="280" height="280"><img src="../img/ind-retail.webp" srcset="../img/ind-retail-480.webp 480w, ../img/ind-retail-720.webp 720w, ../img/ind-retail.webp 900w" sizes="(max-width:1100px) 46vw, (max-width:1900px) 30vw, 570px" width="900" height="542" loading="lazy" decoding="async" alt="Торговый зал супермаркета"></picture></div><div class="d-obj-b"><h3><a href="../#otrasli">Торговые сети</a></h3><p>Несколько магазинов — один договор: общий график и сводный отчёт по всем адресам.</p></div></li>
      <li class="card d-obj" data-tilt><div class="d-obj-img"><picture><source media="(max-width:600px)" srcset="../img/ind-kitchen-sq.webp" width="280" height="280"><img src="../img/ind-kitchen.webp" srcset="../img/ind-kitchen-480.webp 480w, ../img/ind-kitchen-720.webp 720w, ../img/ind-kitchen.webp 900w" sizes="(max-width:1100px) 46vw, (max-width:1900px) 30vw, 570px" width="900" height="542" loading="lazy" decoding="async" alt="Специалист осматривает кухню ресторана после закрытия"></picture></div><div class="d-obj-b"><h3><a href="../restorany-i-kafe/">Рестораны и кафе</a></h3><p>Кухня, мойка и склад продуктов. Работаем после закрытия, обычно 1–2 визита в месяц.</p></div></li>
      <li class="card d-obj" data-tilt><div class="d-obj-img"><picture><source media="(max-width:600px)" srcset="../img/ind-warehouse-sq.webp" width="280" height="280"><img src="../img/ind-warehouse.webp" srcset="../img/ind-warehouse-480.webp 480w, ../img/ind-warehouse-720.webp 720w, ../img/ind-warehouse.webp 900w" sizes="(max-width:1100px) 46vw, (max-width:1900px) 30vw, 570px" width="900" height="542" loading="lazy" decoding="async" alt="Стеллажи складского комплекса"></picture></div><div class="d-obj-b"><h3><a href="../sklady-i-logistika/">Склады и логистика</a></h3><p>Рампы, зоны приёмки и хранения. Контроль грызунов снаружи и внутри здания.</p></div></li>
      <li class="card d-obj" data-tilt><div class="d-obj-img"><picture><source media="(max-width:600px)" srcset="../img/ind-pharma-sq.webp" width="280" height="280"><img src="../img/ind-pharma.webp" srcset="../img/ind-pharma-480.webp 480w, ../img/ind-pharma-720.webp 720w, ../img/ind-pharma.webp 900w" sizes="(max-width:1100px) 46vw, (max-width:1900px) 30vw, 570px" width="900" height="542" loading="lazy" decoding="async" alt="Коридор фармацевтического производства"></picture></div><div class="d-obj-b"><h3><a href="../farmatsevticheskie-proizvodstva/">Фармацевтические производства</a></h3><p>В чистых помещениях — только ловушки без яда, приманки — по внешнему периметру. Документы для GMP-инспекций.</p></div></li>
      <li class="card d-obj" data-tilt><div class="d-obj-img"><picture><source media="(max-width:600px)" srcset="../img/ind-hotel-room-sq.webp" width="280" height="280"><img src="../img/ind-hotel-room.webp" srcset="../img/ind-hotel-room-480.webp 480w, ../img/ind-hotel-room-720.webp 720w, ../img/ind-hotel-room.webp 900w" sizes="(max-width:1100px) 46vw, (max-width:1900px) 30vw, 570px" width="900" height="542" loading="lazy" decoding="async" alt="Специалист проверяет швы матраса в гостиничном номере"></picture></div><div class="d-obj-b"><h3><a href="../gostinitsy/">Гостиницы</a></h3><p>Плановые осмотры номерного фонда и срочный выезд по сообщению гостя.</p></div></li>
    </ul>
  </div>
</section>


<!-- ============ СМОТРИТЕ ТАКЖЕ (перелинковка) ============ -->
<section class="s s-rel" id="smotrite-takzhe">
  <div class="wrap">
    <div class="head">
      <div class="eyebrow" data-eyebrow>Смотрите также</div>
      <h2 data-split>Связанные услуги <em>и материалы</em></h2>
    </div>
    <div class="rel-grid" data-group="cards">
      <a class="card rel-card" href="../deratizatsiya/"><span class="rel-k">Услуга</span><span class="rel-t">Дератизация для организаций</span><span class="rel-d">Три контура защиты от крыс и мышей, контейнеры КИК и ловушки без яда в цехах, схема точек и акты.</span><span class="rel-a" aria-hidden="true"><svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></span></a>
      <a class="card rel-card" href="../dezinsektsiya/"><span class="rel-k">Услуга</span><span class="rel-t">Дезинсекция для организаций</span><span class="rel-d">Контроль насекомых по IPM без остановки работы, ротация средств, журнал и акты по СанПиН.</span><span class="rel-a" aria-hidden="true"><svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></span></a>
      <a class="card rel-card" href="../materialy/programma-pest-kontrolya/"><span class="rel-k">Материал</span><span class="rel-t">Программа <span class="nw">пест-контроля</span></span><span class="rel-d">Образец в PDF и шаблон Word: 7 разделов, оценка <span class="nw">пест-риска</span> по зонам и план мероприятий.</span><span class="rel-a" aria-hidden="true"><svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></span></a>
      <a class="card rel-card" href="../materialy/zhurnal-pest-kontrolya/"><span class="rel-k">Материал</span><span class="rel-t">Журнал <span class="nw">пест-контроля</span></span><span class="rel-d">Образец заполнения и шаблон в PDF: 9 разделов на 10 листах — точки контроля, ловушки, предписания.</span><span class="rel-a" aria-hidden="true"><svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></span></a>
    </div>
  </div>
</section>

<section class="s" id="voprosy">
  <div class="wrap">
    <div class="head"><div class="eyebrow" data-eyebrow>Вопросы</div><h2 data-split>Вопросы <em>о&nbsp;договоре</em></h2></div>
    <div class="faq"><div class="faq-col" data-group="faq"><div class="card qa"><button aria-expanded="false" aria-controls="a1" id="q1">Можно заключить договор только на&nbsp;дератизацию?<span class="pm"></span></button><div class="ans" id="a1" role="region" aria-labelledby="q1"><div><p>Да. Можно начать с одного направления и позже добавить второе дополнительным соглашением.</p></div></div></div><div class="card qa"><button aria-expanded="false" aria-controls="a2" id="q2">Как часто будет приезжать специалист?<span class="pm"></span></button><div class="ans" id="a2" role="region" aria-labelledby="q2"><div><p>Кратность определяем после выезда — по типу объекта, зонам риска и требованиям ваших аудиторов — и закрепляем в графике, приложении к договору. Для кафе, ресторанов и магазинов обычно это 1–2 визита в месяц.</p></div></div></div><div class="card qa"><button aria-expanded="false" aria-controls="a3" id="q3">Что делать, если вредители появились между визитами?<span class="pm"></span></button><div class="ans" id="a3" role="region" aria-labelledby="q3"><div><p>Позвоните или напишите в мессенджер — согласуем внеплановый выезд, найдём причину и при необходимости обработаем очаг. Специалист приедет в течение 3 часов. Порядок таких выездов закрепляем в договоре.</p></div></div></div><div class="card qa"><button aria-expanded="false" aria-controls="a4" id="q4">Можно один договор на&nbsp;несколько адресов?<span class="pm"></span></button><div class="ans" id="a4" role="region" aria-labelledby="q4"><div><p>Да: адреса перечисляем в приложении, график общий, отчёт сводный.</p></div></div></div></div><div class="faq-col" data-group="faq"><div class="card qa"><button aria-expanded="false" aria-controls="a5" id="q5">Можно посмотреть договор заранее?<span class="pm"></span></button><div class="ans" id="a5" role="region" aria-labelledby="q5"><div><p>Да. Образец договора с приложениями можно <a href="obrazets-dogovora-pestkontrol-tsentr.pdf" target="_blank" rel="noopener">скачать в PDF</a>. Проект с вашими адресами, графиком и ценой пришлём в течение 1 часа после бесплатного осмотра.</p></div></div></div><div class="card qa"><button aria-expanded="false" aria-controls="a6" id="q6">На какой срок заключается договор?<span class="pm"></span></button><div class="ans" id="a6" role="region" aria-labelledby="q6"><div><p>На 12 месяцев с автоматической пролонгацией. Расторгнуть договор можно с письменным уведомлением за 30 календарных дней.</p></div></div></div><div class="card qa"><button aria-expanded="false" aria-controls="a7" id="q7">Работаете с НДС и по ЭДО?<span class="pm"></span></button><div class="ans" id="a7" role="region" aria-labelledby="q7"><div><p>Да, работаем как с НДС, так и без НДС (УСН). Договор, акты и закрывающие документы подписываем через ЭДО или на бумаге.</p></div></div></div></div></div>
  </div>
</section>

<section class="cta" id="zayavka"><div class="cta-bg f-lazy" aria-hidden="true" data-parallax-bg></div><div class="cta-orb" id="orb" aria-hidden="true"></div>
  <div class="wrap">
    <div>
      <div class="eyebrow" data-eyebrow>Заявка</div>
      <h2 data-split>Получите проект договора <em>для вашего объекта</em></h2>
      <p class="sub" data-fade>Бесплатно приедем, осмотрим объект и пришлём договор с программой, графиком и ценой.</p>
      <ul class="cta-list" data-group="ctalist">
        <li><svg aria-hidden="true" focusable="false" class="lucide lucide-circle-check" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <circle cx="12" cy="12" r="10" /> <path d="m16 9-5.5 5.5L8 12" /> </svg>Выезд по Москве и Московской области</li>
        <li><svg aria-hidden="true" focusable="false" class="lucide lucide-circle-check" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <circle cx="12" cy="12" r="10" /> <path d="m16 9-5.5 5.5L8 12" /> </svg>Осмотр объекта и расчёт — бесплатно</li>
        <li><svg aria-hidden="true" focusable="false" class="lucide lucide-circle-check" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <circle cx="12" cy="12" r="10" /> <path d="m16 9-5.5 5.5L8 12" /> </svg>Проект договора — в течение 1 часа после осмотра</li>
      </ul>
      <div class="cta-contacts" data-fade>
        <a class="ph" href="tel:+74951043570">+7 (495) 104-35-70</a>
        <div class="msg">
          <a href="https://max.ru/u/f9LHodD0cOIlIUXFkt4KMFP88lD8n4TArBiTcV7RI1XML5c4o39QfsDBXUc" class="max" aria-label="Написать в Max" target="_blank" rel="noopener noreferrer"><svg viewBox="0 0 24 24" fill="#fff" aria-hidden="true"><path d="M12 3a9 9 0 0 0-7.7 13.7L3 21l4.4-1.2A9 9 0 1 0 12 3zm-3.6 12.3V8.7h1.6l2 2.8 2-2.8h1.6v6.6h-1.7v-3.9L12 14l-1.9-2.6v3.9z"/></svg></a>
          <a href="https://t.me/Centr_Dezinfection?text=%D0%97%D0%B4%D1%80%D0%B0%D0%B2%D1%81%D1%82%D0%B2%D1%83%D0%B9%D1%82%D0%B5!%20%D0%9F%D0%B8%D1%88%D1%83%20%D1%81%20%D1%81%D0%B0%D0%B9%D1%82%D0%B0%20%D0%BF%D0%B5%D1%81%D1%82%D0%BA%D0%BE%D0%BD%D1%82%D1%80%D0%BE%D0%BB%D1%8C-%D1%86%D0%B5%D0%BD%D1%82%D1%80.%D1%80%D1%84" class="tg" aria-label="Написать в Telegram" target="_blank" rel="noopener noreferrer"><svg viewBox="0 0 24 24" fill="#fff" aria-hidden="true"><path d="M21.4 4.3 2.9 11.4c-1.3.5-1.2 1.2-.2 1.5l4.7 1.5 1.8 5.6c.2.6.4.8.9.8.4 0 .6-.2.9-.4l2.3-2.2 4.7 3.5c.9.5 1.5.2 1.7-.8l3.1-14.6c.3-1.3-.5-1.8-1.4-1.5zM9.6 14.1l8.6-5.4c.4-.3.8-.1.5.2l-7.1 6.4-.3 3.3z"/></svg></a>
        </div>
      </div>
    </div>
    <form class="form" id="form" novalidate data-form>
      <div class="fbody">
        <h3>Заявка на проект договора</h3>
        <p class="fs">Заполнение займёт меньше минуты</p>
        <div class="fg">
          <div class="field"><label class="sr-only" for="f-name">Ваше имя</label><input id="f-name" name="name" placeholder="Ваше имя" required autocomplete="name"><small class="ferr">Укажите имя</small></div>
          <div class="field"><label class="sr-only" for="phone">Телефон</label><input name="phone" id="phone" type="tel" inputmode="tel" placeholder="+7 (___) ___-__-__" required autocomplete="tel"><small class="ferr">Укажите телефон полностью</small></div>
          <div class="field full"><label class="sr-only" for="f-type">Тип объекта</label><select id="f-type" name="type" required><option value="" disabled selected>Тип объекта</option><option>Пищевое производство</option><option>Магазин или торговая сеть</option><option>Ресторан или кафе</option><option>Склад, логистика</option><option>Фармацевтическое производство</option><option>Гостиница</option><option>Другое</option></select><small class="ferr">Выберите тип объекта</small></div>
          <div class="field full"><label class="sr-only" for="f-address">Адрес или район объекта</label><input id="f-address" name="address" placeholder="Адрес или район объекта" autocomplete="street-address" maxlength="200"></div>
          <div class="field full"><label class="sr-only" for="f-service">Что нужно</label><select id="f-service" name="service"><option value="" selected>Что нужно</option><option>Дератизация</option><option>Дезинсекция</option><option>Комплекс: дератизация и дезинсекция</option></select></div>
          <div class="field" hidden><input type="hidden" name="email" value=""></div>
          <input type="hidden" name="msg" value="">
        </div>
        <button type="submit" class="btn btn-w btn-lg" id="submitBtn"><span class="btn-t">Получить проект договора</span><svg class="btn-ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M5 12h14M13 6l6 6-6 6"/></svg><i class="spin" aria-hidden="true"></i></button>
        <p class="legal">Нажимая кнопку, вы даёте <a href="../soglasie/" target="_blank" rel="noopener">согласие на обработку персональных данных</a> и подтверждаете, что ознакомились с <a href="../privacy/" target="_blank" rel="noopener">политикой конфиденциальности</a>.</p>
      </div>
      <div class="ok" role="status" aria-live="polite">
        <svg class="ok-ic" viewBox="0 0 52 52" aria-hidden="true"><circle cx="26" cy="26" r="24" fill="none"/><path fill="none" d="M15 27l7 7 15-16"/></svg>
        <h3>Заявка отправлена</h3><p>Перезвоним в ближайшее рабочее время, чтобы согласовать день выезда.</p>
      </div>
    </form>
  </div>
</section>
</main>

<footer>
  <div class="wrap">
    <div class="ft">
      <div>
        <a href="../" class="logo" aria-label="ПЕСТКОНТРОЛЬ Центр — на главную"><span class="logo-mark"><svg viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="1.6" stroke-linejoin="round" aria-hidden="true"><path d="M12 2.5l7.5 3v6c0 5-3.2 8.6-7.5 10-4.3-1.4-7.5-5-7.5-10v-6z"/><circle cx="12" cy="11.5" r="2.6" stroke="#7c86ff"/><path d="M12 6.2v2.7M12 14.1v2.7M6.8 11.5h2.6M14.6 11.5h2.6" stroke="#7c86ff"/></svg></span><span class="logo-txt"><span class="logo-name">ПЕСТКОНТРОЛЬ</span> <span class="logo-sub">Центр</span></span></a>
        <p class="d"><span class="nw">Пест-контроль</span> и <span class="nw">пест-менеджмент</span> по системе IPM для бизнеса в Москве и Московской области: бесплатный аудит, оценка <span class="nw">пест-риска</span>, мониторинг вредителей и отчётность.</p>
      </div>
      <div><h4>Услуги</h4><ul><li><a href="../dezinfektsiya/">Дезинфекция для организаций</a></li><li><a href="../deratizatsiya/">Дератизация для организаций</a></li><li><a href="../dezinsektsiya/">Дезинсекция для организаций</a></li><li><a href="../sanitarnyy-audit/"><span>Санитарный аудит <span class="nw">(СЭС-аудит)</span></span></a></li><li><a href="../razrabotka-ppk/">Разработка ППК</a></li><li><a href="../ochistka-dezinfektsiya-ventilyatsii/">Очистка и дезинфекция вентиляции</a></li><li><a href="./" aria-current="page">Договор на дератизацию и дезинсекцию</a></li><li><a href="../#podhod"><span><span class="nw">Пест-контроль</span> по системе IPM</span></a></li><li><a href="../#etapy">Этапы работы</a></li><li><a href="../#vrediteli">Вредители</a></li><li><a href="../#dokumenty">Документы для проверок</a></li><li><a href="../#usloviya">Цена</a></li><li><a href="../#voprosy">Вопросы</a></li></ul></div>
      <div><h4>Отрасли</h4><ul><li><a href="../pishchevoe-proizvodstvo/">Пищевые производства</a></li><li><a href="../magaziny-i-torgovye-seti/">Магазины и торговые сети</a></li><li><a href="../restorany-i-kafe/">Рестораны и кафе</a></li><li><a href="../sklady-i-logistika/">Склады и логистика</a></li><li><a href="../farmatsevticheskie-proizvodstva/">Фармацевтические производства</a></li><li><a href="../gostinitsy/">Гостиницы и отели</a></li></ul></div>
      <div><h4>Материалы</h4><ul><li><a href="../normativnaya-baza/">Нормативная база</a></li><li><a href="../normativnaya-baza/proverochnye-listy/">Проверочные листы 2026</a></li><li><a href="../materialy/programma-pest-kontrolya/"><span>Программа <span class="nw">пест-контроля</span></span></a></li><li><a href="../materialy/zhurnal-pest-kontrolya/"><span>Журнал <span class="nw">пест-контроля</span></span></a></li><li><a href="../materialy/pest-menedzhment-ili-razovaya-obrabotka/"><span><span class="nw">Пест-менеджмент</span> или разовая обработка</span></a></li><li><a href="../materialy/programma-proizvodstvennogo-kontrolya-haccp/">Программа производственного контроля по ХАССП</a></li><li><a href="../materialy/">Все материалы</a></li></ul></div>
      <div><h4>Контакты</h4><ul><li><a href="tel:+74951043570">+7 (495) 104-35-70</a></li><li><a href="mailto:b2b@pestcontrol-center.ru">b2b@<wbr><span style="white-space:nowrap">pestcontrol-center.ru</span></a></li><li>Пн–Пт: 8:00–20:00</li><li>Срочные выезды: 24/7</li></ul>
        <div class="msg"><a href="https://max.ru/u/f9LHodD0cOIlIUXFkt4KMFP88lD8n4TArBiTcV7RI1XML5c4o39QfsDBXUc" class="max" aria-label="Написать в Max" target="_blank" rel="noopener noreferrer"><svg viewBox="0 0 24 24" fill="#fff" aria-hidden="true"><path d="M12 3a9 9 0 0 0-7.7 13.7L3 21l4.4-1.2A9 9 0 1 0 12 3zm-3.6 12.3V8.7h1.6l2 2.8 2-2.8h1.6v6.6h-1.7v-3.9L12 14l-1.9-2.6v3.9z"/></svg></a><a href="https://t.me/Centr_Dezinfection?text=%D0%97%D0%B4%D1%80%D0%B0%D0%B2%D1%81%D1%82%D0%B2%D1%83%D0%B9%D1%82%D0%B5!%20%D0%9F%D0%B8%D1%88%D1%83%20%D1%81%20%D1%81%D0%B0%D0%B9%D1%82%D0%B0%20%D0%BF%D0%B5%D1%81%D1%82%D0%BA%D0%BE%D0%BD%D1%82%D1%80%D0%BE%D0%BB%D1%8C-%D1%86%D0%B5%D0%BD%D1%82%D1%80.%D1%80%D1%84" class="tg" aria-label="Написать в Telegram" target="_blank" rel="noopener noreferrer"><svg viewBox="0 0 24 24" fill="#fff" aria-hidden="true"><path d="M21.4 4.3 2.9 11.4c-1.3.5-1.2 1.2-.2 1.5l4.7 1.5 1.8 5.6c.2.6.4.8.9.8.4 0 .6-.2.9-.4l2.3-2.2 4.7 3.5c.9.5 1.5.2 1.7-.8l3.1-14.6c.3-1.3-.5-1.8-1.4-1.5zM9.6 14.1l8.6-5.4c.4-.3.8-.1.5.2l-7.1 6.4-.3 3.3z"/></svg></a></div>
      </div>
    </div>
    <div class="fb"><span>© 2026 ПЕСТКОНТРОЛЬ Центр</span><a href="../privacy/">Политика конфиденциальности</a><a href="../soglasie/">Согласие на обработку данных</a><span>Информация на сайте не является публичной офертой</span></div>
  </div>
</footer>

<div class="mbar" id="mbar">
  <a href="tel:+74951043570" class="c1"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1 1 .4 1.9.7 2.8a2 2 0 0 1-.5 2.1L8 9.9a16 16 0 0 0 6 6l1.3-1.3a2 2 0 0 1 2.1-.4c.9.3 1.8.6 2.8.7a2 2 0 0 1 1.7 2z"/></svg>Позвонить</a>
  <a href="#zayavka" class="c2"><span>Проект договора</span></a>
</div>
<div class="fab" role="group" aria-label="Написать в мессенджер">
  <a href="https://max.ru/u/f9LHodD0cOIlIUXFkt4KMFP88lD8n4TArBiTcV7RI1XML5c4o39QfsDBXUc" class="max" aria-label="Написать в Max" target="_blank" rel="noopener noreferrer"><svg viewBox="0 0 24 24" fill="#fff" aria-hidden="true"><path d="M12 3a9 9 0 0 0-7.7 13.7L3 21l4.4-1.2A9 9 0 1 0 12 3zm-3.6 12.3V8.7h1.6l2 2.8 2-2.8h1.6v6.6h-1.7v-3.9L12 14l-1.9-2.6v3.9z"/></svg></a>
  <a href="https://t.me/Centr_Dezinfection?text=%D0%97%D0%B4%D1%80%D0%B0%D0%B2%D1%81%D1%82%D0%B2%D1%83%D0%B9%D1%82%D0%B5!%20%D0%9F%D0%B8%D1%88%D1%83%20%D1%81%20%D1%81%D0%B0%D0%B9%D1%82%D0%B0%20%D0%BF%D0%B5%D1%81%D1%82%D0%BA%D0%BE%D0%BD%D1%82%D1%80%D0%BE%D0%BB%D1%8C-%D1%86%D0%B5%D0%BD%D1%82%D1%80.%D1%80%D1%84" class="tg" aria-label="Написать в Telegram" target="_blank" rel="noopener noreferrer"><svg viewBox="0 0 24 24" fill="#fff" aria-hidden="true"><path d="M21.4 4.3 2.9 11.4c-1.3.5-1.2 1.2-.2 1.5l4.7 1.5 1.8 5.6c.2.6.4.8.9.8.4 0 .6-.2.9-.4l2.3-2.2 4.7 3.5c.9.5 1.5.2 1.7-.8l3.1-14.6c.3-1.3-.5-1.8-1.4-1.5zM9.6 14.1l8.6-5.4c.4-.3.8-.1.5.2l-7.1 6.4-.3 3.3z"/></svg></a>
</div>

<script>(function(){var f=document.getElementById('form');if(!f)return;f.addEventListener('submit',function(){var e=f.elements,s=e.service.value||'не выбрано',a=e.address.value.trim()||'не указан';e.msg.value='Что нужно: '+s+'\nАдрес объекта: '+a+'\nСтраница: договор на дератизацию и дезинсекцию (/dogovor-deratizatsiya-dezinsektsiya/)';});})();</script>
<script data-fx>
/* Эффекты под курсором, как на главной (tools/site/fx.py) */
(function(){
  var mm=window.matchMedia;if(!mm)return;
  var fine=mm('(hover: hover) and (pointer: fine)').matches;
  /* «фонарь»: следует за мышью, без движения мыши плавно ходит сам; на сенсорных экранах ходит сам (30 кадров в секунду).
     Не считаем, пока первый экран не виден или вкладка скрыта. Старт — вместе со входом первого экрана */
  var hero=document.getElementById('hero'),lit=hero&&hero.querySelector('.fx-lit');
  if(lit&&!mm('(prefers-reduced-motion: reduce)').matches){
    var media=lit.parentNode,small=mm('(max-width:860px)').matches,full=hero.classList.contains('f-hero');
    lit.style.setProperty('--sr',small?'150px':'clamp(240px, 21vw, 400px)');
    var cx=small?.5:(full?.68:.74),ax=small?.24:(full?.16:.13),cy=small?.5:.47,ay=small?.2:.17;
    var sx=cx,sy=cy,tx=cx,ty=cy,last=-1e9,vis=true,on=false,raf=0,lt=0;
    var frame=function(now){
      raf=0;if(!on||!vis||document.hidden)return;
      var dt=now-lt;if(!fine&&dt<30){raf=requestAnimationFrame(frame);return;}
      lt=now;if(now-last>2600){var t=now/1000;tx=cx+ax*Math.sin(t*.33);ty=cy+ay*Math.sin(t*.47+1.3);}
      var k=1-Math.pow(.94,Math.min(dt,100)/16.67);sx+=(tx-sx)*k;sy+=(ty-sy)*k;
      lit.style.setProperty('--sx',(sx*100).toFixed(2)+'%');lit.style.setProperty('--sy',(sy*100).toFixed(2)+'%');
      raf=requestAnimationFrame(frame);
    };
    var kick=function(){if(!raf&&on&&vis&&!document.hidden){lt=performance.now();raf=requestAnimationFrame(frame);}};
    hero.addEventListener('pointermove',function(e){
      if(e.pointerType!=='mouse')return;var r=media.getBoundingClientRect();if(!r.width||!r.height)return;
      tx=(e.clientX-r.left)/r.width;ty=(e.clientY-r.top)/r.height;last=performance.now();kick();
    },{passive:true});
    if('IntersectionObserver' in window)new IntersectionObserver(function(es){vis=es[0].isIntersecting;kick();}).observe(hero);
    document.addEventListener('visibilitychange',kick);
    var start=function(){if(on)return;on=true;hero.classList.add('fx-lit-on');kick();};
    var eb=hero.querySelector('.eyebrow');
    if(eb&&'MutationObserver' in window){
      if(eb.classList.contains('in'))start();
      else{var mo=new MutationObserver(function(){if(eb.classList.contains('in')){mo.disconnect();start();}});mo.observe(eb,{attributes:true,attributeFilter:['class']});}
    }
    setTimeout(start,eb?5000:2500);
  }
  /* подсветка рамки карточек за курсором — как у .card на главной */
  if(fine)document.addEventListener('pointermove',function(e){
    var c=e.target.closest&&e.target.closest('.d-card,.p-sec,.p-fcard,.p-duty-box,.p-dl-card,.pm-step-card,.pm-scen,.pm-link-card,.k-err,.w-sample,.d-doc-prev');if(!c)return;
    var r=c.getBoundingClientRect();c.style.setProperty('--mx',(e.clientX-r.left)+'px');c.style.setProperty('--my',(e.clientY-r.top)+'px');
  },{passive:true});
})();
</script>
<script>
  /* скрипты анимаций подключаются сразу после первой отрисовки: фото и заголовок первого экрана не ждут их загрузки */
  (function (r, l) {
    var go = function () { l.forEach(function (u) { var e = document.createElement('script'); e.src = r + u; e.async = false; document.body.appendChild(e); }); };
    if (document.visibilityState === 'hidden' || !window.requestAnimationFrame) setTimeout(go, 0);
    else requestAnimationFrame(function () { setTimeout(go, 0); });
  })('../', ['vendor/gsap.min.js', 'vendor/ScrollTrigger.min.js', 'vendor/lenis.min.js', 'app.min.js?v=20261106s2']);
</script>
<!-- Yandex.Metrika counter + UIS + Radist: загружаются после первого действия посетителя (касание, прокрутка, мышь, клавиатура) или через 5 с после загрузки страницы -->
<script type="text/javascript">
    (function (w, d) {
        w.ym = w.ym || function () { (w.ym.a = w.ym.a || []).push(arguments); };
        w.ym.l = 1 * new Date();
        ym(113675622, 'init', {ssr:true, webvisor:true, clickmap:true, ecommerce:"dataLayer", referrer: document.referrer, url: location.href, accurateTrackBounce:true, trackLinks:true});
        var done = false, ready = false, wait = null, ev = ['pointerdown', 'touchstart', 'keydown', 'scroll', 'wheel', 'mousemove'];
        w.__cs = w.__cs || [];
        w.__cs.push(['waitForTrackViewAndRun', function () { ready = true; }]);
        // Radist: код заявки в ссылках Telegram и MAX — сразу, скрипт Radist загрузится вместе со счётчиками
        var rmsg = 'Здравствуйте! Пишу с сайта пестконтроль-центр.рф. Номер заявки: {radist_tracker}';
        w.radist_tracker = w.radist_tracker || function () { (w.radist_tracker.a = w.radist_tracker.a || []).push(arguments); };
        w.radist_tracker.l = 1 * new Date();
        w.radist_tracker({ message: rmsg, whatsapp_enabled: true, tgbot_enabled: true, tg_enabled: true, max_enabled: true, vk_enabled: true });
        (function () {
            var id = null, abc = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789', s = 'ro', i, txt;
            try {
                id = sessionStorage.getItem('radistVisit');
                if (!id || id.length !== 12) {
                    for (i = 0; i < 10; i++) s += abc.charAt(Math.floor(Math.random() * abc.length));
                    sessionStorage.setItem('radistVisit', s);
                    id = sessionStorage.getItem('radistVisit');
                }
            } catch (e) { id = null; }
            if (!id || id.length !== 12) return;
            txt = encodeURIComponent(rmsg.replace(/{radist_tracker}/g, id));
            [].forEach.call(d.querySelectorAll('a[href*="//t.me/"], a[href*="//max.ru/"]'), function (a) {
                try {
                    var u = new URL(a.href), n = u.pathname.split('/')[1] || '';
                    if (u.host === 'max.ru') a.href = 'https://max.ru/' + u.pathname.substring(1) + '?start=' + id;
                    else if (u.host === 't.me' && !/bot$/i.test(n)) a.href = 'https://t.me' + u.pathname + '?text=' + txt;
                } catch (e) {}
            });
        })();
        function add(src) { var k = d.createElement('script'); k.async = true; k.src = src; d.head.appendChild(k); return k; }
        function load() {
            if (done) return; done = true;
            ev.forEach(function (e) { w.removeEventListener(e, load, true); });
            add('https://mc.yandex.ru/metrika/tag.js?id=113675622');
            var p = d.createElement('link'); p.rel = 'preconnect'; p.href = 'https://tracker.comagic.ru'; d.head.appendChild(p);
            add('https://app.uiscom.ru/static/cs.min.js?k=ICWycQx6m3NSBe3WlCeDAdAKMTmNhMHC').onerror = function () { ready = true; };
            add('https://track.radist.me/tracker.min.js');
        }
        ev.forEach(function (e) { w.addEventListener(e, load, { capture: true, passive: true }); });
        function later() { setTimeout(load, 5000); }
        if (d.readyState === 'complete') later(); else w.addEventListener('load', later);
        // Ожидание подмены номера при первом касании: набор откладывается до ответа UIS, максимум 0,8–1 с
        d.addEventListener('click', function (e) {
            if (ready) return;
            var a = e.target && e.target.closest ? e.target.closest('a[href^="tel:"]') : null;
            if (!a || e.button || e.ctrlKey || e.metaKey || e.shiftKey || e.altKey) return;
            e.preventDefault();
            if (wait) return;
            load();
            var href = a.getAttribute('href'), op = a.style.opacity, max = 'GestureEvent' in w ? 800 : 1000, t;
            function go() {
                for (var i = 0; i < wait.length; i++) clearTimeout(wait[i]);
                wait = null; ready = true; a.style.opacity = op;
                w.location.href = a.href;
            }
            function check(last) { return function () { if (wait && (last || ready || a.getAttribute('href') !== href)) go(); }; }
            wait = [];
            a.style.opacity = '.6';
            for (t = 50; t <= max; t += 50) wait.push(setTimeout(check(t === max), t));
        }, true);
    })(window, document);
</script>
<noscript><div><img src="https://mc.yandex.ru/watch/113675622" style="position:absolute; left:-9999px;" alt="" /></div></noscript>
<!-- /Yandex.Metrika counter -->
</body>
</html>
