<!doctype html>
<html lang="ru">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>Очистка и дезинфекция вентиляции в Москве и МО — ПЕСТКОНТРОЛЬ Центр</title>
<meta name="description" content="Очистка воздуховодов, кухонных вытяжек и дезинфекция вентиляции для организаций в Москве и МО: видео до и после, акт по п. 43 ППР, журнал по МР 3.5.0396-25. Осмотр и смета — 0 ₽.">
<link rel="canonical" href="https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/ochistka-dezinfektsiya-ventilyatsii/">
<meta name="theme-color" content="#000000">
<meta property="og:type" content="website">
<meta property="og:locale" content="ru_RU">
<meta property="og:site_name" content="ПЕСТКОНТРОЛЬ Центр">
<meta property="og:url" content="https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/ochistka-dezinfektsiya-ventilyatsii/">
<meta property="og:title" content="Очистка и дезинфекция вентиляции для организаций в Москве и области">
<meta property="og:description" content="Очистка воздуховодов, кухонных вытяжек и дезинфекция вентиляции для организаций в Москве и МО: видео до и после, акт по п. 43 ППР, журнал по МР 3.5.0396-25. Осмотр и смета — 0 ₽.">
<meta property="og:image" content="https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/img/vent-og.jpg">
<meta property="og:image:type" content="image/jpeg">
<meta property="og:image:width" content="1200">
<meta property="og:image:height" content="630">
<meta property="og:image:alt" content="Специалист ПЕСТКОНТРОЛЬ Центр очищает прямоугольный воздуховод щёточной машиной через ревизионный люк">
<meta name="twitter:card" content="summary_large_image">
<link rel="icon" href="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 32 32'%3E%3Ccircle cx='16' cy='16' r='15' fill='%2309090b' stroke='%237c86ff' stroke-width='2'/%3E%3Cpath d='M16 7l7 3v5c0 5-3 8.5-7 10-4-1.5-7-5-7-10v-5z' fill='none' stroke='%23fff' stroke-width='2'/%3E%3C/svg%3E">
<link rel="preload" href="../fonts/inter-ru-wght-normal.woff2" as="font" type="font/woff2" crossorigin>
<link rel="preload" as="image" media="(min-width:861px)" imagesrcset="../img/vent-hero-1440.webp 1440w, ../img/vent-hero.webp 1920w" imagesizes="100vw" fetchpriority="high">
<link rel="preload" as="image" media="(max-width:860px)" imagesrcset="../img/vent-hero-mob-760.webp 760w, ../img/vent-hero-mob.webp 1024w" imagesizes="100vw" fetchpriority="high">
<script>
  /* начальные состояния анимаций — только при работающем JS; страховка — через 4 с всё показывается.
     Заставка — один раз за посещение: при переходе по ссылке с якорем и между страницами сайта её нет */
  (function (d) {
    d.classList.add('js');
    try { if (location.hash || sessionStorage.getItem('pc-intro')) d.classList.add('no-intro'); else sessionStorage.setItem('pc-intro', '1'); }
    catch (e) { if (location.hash) d.classList.add('no-intro'); }
    setTimeout(function () { if (!d.classList.contains('anim-ready')) d.classList.add('anim-fail'); }, 4000);
  })(document.documentElement);
</script>
<link rel="stylesheet" href="../style.css?v=20261106s2">
<style>html{scroll-behavior:auto}.d-page .s{padding:clamp(64px,7vw,128px) 0;border-top:1px solid var(--line)}.d-crumbs{font-size:14px;color:var(--t3);display:flex;flex-wrap:wrap;gap:8px;margin:0 0 clamp(24px,2.5vw,40px)}.d-crumbs a{color:var(--t2)}.d-crumbs a:hover{color:var(--t1)}.d-hero{position:relative;overflow:hidden;padding:calc(clamp(68px,6vw,115px) + 20px) 0 clamp(64px,7vw,116px);min-height:clamp(680px,56vw,900px);display:flex;align-items:center}.d-hero .wrap{width:100%;display:grid;grid-template-columns:minmax(0,.94fr) minmax(0,1.06fr);gap:clamp(28px,4vw,80px);align-items:center}.d-hero-copy>*:not(.d-hero-media){position:relative;z-index:1}.d-hero-media{position:absolute;inset:0;z-index:0;pointer-events:none;overflow:hidden}.d-hero-media::before{content:"";position:absolute;inset:0;z-index:1;background:linear-gradient(90deg,rgba(0,0,0,.92) 0%,rgba(0,0,0,.84) 38%,rgba(0,0,0,.28) 54%,rgba(0,0,0,0) 66%),linear-gradient(180deg,#000 0,rgba(0,0,0,.55) 90px,rgba(0,0,0,0) 260px),linear-gradient(0deg,#000 0,rgba(0,0,0,0) 20%)}.d-hero-img{position:absolute;inset:0;width:100%;height:100%;object-fit:cover;object-position:100% 50%}.d-hero h1{font-size:clamp(42px,4.4vw,84px);line-height:1.1;letter-spacing:-.055em;font-weight:300;margin:18px 0 0}.d-hero h1 .ln{display:block;padding:0 .08em .08em 0;margin-bottom:-.08em}.d-hero h1 .ln>span{display:inline-block}.d-ticks{list-style:none;padding:0;margin:28px 0 0;display:grid;gap:12px}.d-ticks li{position:relative;padding-left:30px;line-height:1.5}.d-ticks li::before{content:"";position:absolute;left:2px;top:.42em;width:13px;height:7px;border-left:2px solid var(--acc);border-bottom:2px solid var(--acc);transform:rotate(-45deg)}.d-hero .sub{margin:22px 0 0}.d-btns{display:flex;flex-wrap:wrap;gap:12px;margin-top:28px}.d-btns .btn-lg{padding:0 26px}.f-checks{position:relative;padding:clamp(28px,3vw,56px) 0 clamp(56px,6vw,110px);border-top:1px solid var(--line)}.f-check.panel{max-width:none}.f-check-in{position:relative;z-index:1;display:grid;grid-template-columns:minmax(0,.9fr) minmax(0,1.1fr);gap:clamp(24px,4vw,80px);padding:clamp(24px,3vw,52px)}.f-check-t{font-size:clamp(28px,2.6vw,46px);line-height:1.08;letter-spacing:-.04em;font-weight:300;margin:14px 0 0}.f-check-res{margin:22px 0 10px;color:var(--t2);font-size:15px}.f-check-res b{font-size:clamp(40px,3.4vw,64px);font-weight:300;letter-spacing:-.04em;color:var(--acc);margin-right:6px;line-height:1;transition:color .3s}.f-check-res.warn b{color:var(--yel)}.f-check-note{color:var(--t2);line-height:1.6;margin:0 0 28px;max-width:460px}.f-check-list{list-style:none;margin:0;padding:0;display:grid;align-content:center;border-top:1px solid var(--line)}.f-check-list li{border-bottom:1px solid var(--line)}.f-check-list label{display:flex;gap:18px;align-items:center;padding:18px 4px;cursor:pointer;font-size:clamp(15px,1.05vw,18px);line-height:1.45;color:var(--t2);transition:color .25s}.f-check-list label:hover{color:var(--t1)}.f-check-list input{appearance:none;-webkit-appearance:none;flex:none;width:26px;height:26px;margin:0;border-radius:8px;border:1.4px solid var(--line2);background:rgba(255,255,255,.03) center/14px no-repeat;cursor:pointer;transition:background-color .25s,border-color .25s}.f-check-list input:checked{background-color:var(--acc2);border-color:var(--acc);background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 14 14'%3E%3Cpath d='M2.5 7.5l3 3 6-7' fill='none' stroke='%23fff' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'/%3E%3C/svg%3E")}.f-check-list input:focus-visible{outline:2px solid var(--acc);outline-offset:3px}.f-check-list input:checked+span{color:var(--t1)}.d-doc-prev{display:block;width:100%;border-radius:14px;overflow:hidden;border:1px solid var(--line2);background:#fff;box-shadow:0 18px 44px rgba(0,0,0,.45);transition:border-color .2s,transform .2s}.d-doc-prev:hover{border-color:var(--acc);transform:translateY(-2px)}.d-doc-prev img{display:block;width:100%;height:auto}.d-cards{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:16px}.d-card{background:var(--card);border:1px solid var(--line2);border-radius:var(--r);padding:clamp(22px,2vw,34px)}.d-card h3{font-size:clamp(20px,1.5vw,26px);font-weight:400;letter-spacing:-.02em;margin:0 0 12px}.d-card p{color:var(--t2);line-height:1.6;margin:0}.d-card .f-num{font-size:clamp(26px,2.2vw,42px);line-height:1.05;letter-spacing:-.035em;font-weight:300;color:var(--acc);margin:0 0 14px}.f-req .d-card{border-top:2px solid rgba(124,134,255,.45)}.dz-lbl{display:inline-block;font-size:12px;letter-spacing:.08em;text-transform:uppercase;color:var(--acc);margin:0 0 10px}.d-kind{padding:0;overflow:hidden;display:flex;flex-direction:column}.d-kind-img{aspect-ratio:16/9;overflow:hidden;background:#0c0c0e;border-bottom:1px solid var(--line2)}.d-kind-img img{display:block;width:100%;height:100%;object-fit:cover}.d-kind-b{padding:clamp(22px,2vw,34px);display:flex;flex-direction:column;flex:1}.d-kind-b p{margin-bottom:14px}.d-kind-b .d-ticks{margin:auto 0 0;gap:8px;font-size:14.5px;color:var(--t2)}.d-note{color:var(--t2);margin:24px 0 0;line-height:1.6}.d-note a{color:var(--t1);text-decoration:underline;text-decoration-color:var(--acc);text-underline-offset:3px}.d-note a:hover{color:var(--acc)}.d-strong{color:var(--t1);font-size:clamp(18px,1.3vw,22px)}.d-split{display:grid;grid-template-columns:minmax(0,1fr) minmax(0,340px);gap:clamp(28px,4vw,80px);align-items:start}.d-swap{display:grid;grid-template-columns:minmax(0,1.08fr) minmax(0,.92fr);grid-template-areas:"head img" "ticks img";grid-template-rows:auto 1fr;column-gap:clamp(28px,4vw,72px);row-gap:clamp(20px,2vw,32px);align-items:start}.d-swap .head{grid-area:head;margin-bottom:0}.d-swap .d-ticks{grid-area:ticks;margin:0}.d-swap-img{grid-area:img;align-self:center;margin:0;aspect-ratio:1200/896;border-radius:var(--r);overflow:hidden;border:1px solid var(--line2);background:#0c0c0e}.d-swap-img img{display:block;width:100%;height:100%;object-fit:cover}.d-terms{list-style:none;counter-reset:t;padding:0;margin:0;border-top:1px solid var(--line2)}.d-terms li{display:grid;grid-template-columns:44px minmax(0,.42fr) minmax(0,1fr);gap:16px;padding:18px 0;border-bottom:1px solid var(--line2);line-height:1.55}.d-terms li::before{counter-increment:t;content:counter(t,decimal-leading-zero);color:var(--t3)}.d-terms b{font-weight:500}.d-terms span{color:var(--t2)}.d-terms a{color:var(--t1);text-decoration:underline;text-decoration-color:var(--acc);text-underline-offset:3px}.d-doc{display:grid;gap:16px;justify-items:stretch}.d-doc-h{font-size:clamp(19px,1.3vw,23px);font-weight:400;letter-spacing:-.02em;line-height:1.3;margin:0}.d-doc-btn{width:100%}.d-small{font-size:14px;color:var(--t3);margin:0}.d-steps{list-style:none;counter-reset:st;padding:0;margin:0;display:grid;grid-template-columns:repeat(5,minmax(0,1fr));gap:18px}.d-steps-3{grid-template-columns:repeat(3,minmax(0,1fr));margin-bottom:32px}.d-steps li{border-top:2px solid var(--line2);padding-top:18px;line-height:1.55}.d-steps li::before{counter-increment:st;content:"0" counter(st);display:block;color:var(--acc);font-size:14px;margin-bottom:12px}.d-steps b{display:block;font-weight:500;margin-bottom:8px}.d-steps span{color:var(--t2)}.d-table{width:100%;border-collapse:collapse;line-height:1.5}.d-table th,.d-table td{text-align:left;vertical-align:top;padding:16px 20px 16px 0;border-bottom:1px solid var(--line2)}.d-table th{color:var(--t3);font-weight:400;font-size:14px}.d-table td{color:var(--t2)}.d-table td:first-child{color:var(--t1)}.d-table .d-price{white-space:nowrap;text-align:right;padding-right:0}.d-table td.d-price{color:var(--t1);font-weight:500;font-variant-numeric:tabular-nums}.d-vs td:first-child{color:var(--t2)}.d-vs th:last-child,.d-vs td:last-child{color:var(--t1);background:rgba(124,134,255,.07);padding-left:20px}.dz-tag{display:inline-block;font-size:13px;line-height:1.35;color:var(--grn);background:rgba(34,197,94,.1);border:1px solid rgba(34,197,94,.28);padding:4px 10px;border-radius:8px;font-weight:500}.dz-tag.warn{color:var(--yel);background:rgba(253,199,0,.09);border-color:rgba(253,199,0,.3)}.dz-sublbl{display:block;font-size:11px;letter-spacing:.08em;text-transform:uppercase;color:var(--acc);margin:12px 0 4px}.pest-b .lvl.z{color:var(--acc);border-color:rgba(124,134,255,.32);background:rgba(124,134,255,.08);display:inline-block;margin-top:12px;white-space:normal;line-height:1.35}.d-cols2{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:16px;margin-top:28px}.d-objs{list-style:none;padding:0;margin:0;display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:16px}.d-obj{display:flex;flex-direction:column;overflow:hidden;transition:border-color .25s}.d-obj:hover{border-color:var(--acc)}.d-obj-img{aspect-ratio:900/542;overflow:hidden;background:#0c0c0e}.d-obj-img picture{display:block;width:100%;height:100%}.d-obj-img img{display:block;width:100%;height:100%;object-fit:cover;filter:saturate(.85);transition:filter .5s}.d-obj:hover .d-obj-img img{filter:none}.d-obj-b{padding:clamp(18px,1.5vw,26px)}.d-obj h3{font-size:clamp(18px,1.25vw,22px);font-weight:500;letter-spacing:-.01em;line-height:1.3;margin:0 0 8px;overflow-wrap:break-word}.d-obj h3 a{color:var(--t1);text-decoration:none;outline:none}.d-obj h3 a::after{content:"";position:absolute;inset:0;z-index:1;border-radius:inherit}.d-obj:focus-within{outline:2px solid var(--acc);outline-offset:3px}.d-obj:has(a:focus:not(:focus-visible)){outline:none}.d-obj p{color:var(--t2);line-height:1.55;margin:0;font-size:clamp(14px,.92vw,16px)}.qa .ans a{color:var(--t1);text-decoration:underline;text-decoration-color:var(--acc);text-underline-offset:3px}.qa .ans a:hover{color:var(--acc)}.qa .ans>div{visibility:hidden;transition:visibility 0s .55s}.qa.open .ans>div{visibility:visible;transition-delay:0s}.f-lazy:not(.bg-in){background-image:none!important}.d-page .cta .sub{margin-bottom:0}.d-page .cta-list{margin:28px 0 34px}@media (max-width:1180px){.d-hero{min-height:0}.d-hero .wrap{grid-template-columns:minmax(0,.84fr) minmax(0,1.16fr)}.d-hero .btn-lg{height:52px;padding:0 22px;font-size:15px}}@media (max-width:1100px){.d-steps,.d-objs,.f-check-in{grid-template-columns:repeat(2,minmax(0,1fr))}.f-check-in{grid-template-columns:minmax(0,1fr)}}@media (max-width:860px){.hdr{background:rgba(0,0,0,.72);backdrop-filter:blur(18px);-webkit-backdrop-filter:blur(18px);border-color:var(--line)}.d-hero{display:block;min-height:0;padding:calc(clamp(68px,6vw,115px) + 20px) 0 clamp(44px,7vw,64px)}.d-hero .wrap,.d-split,.d-swap,.d-cols2,.d-cards{grid-template-columns:minmax(0,1fr)}.d-swap{grid-template-areas:"head" "img" "ticks";grid-template-rows:auto}.d-hero-copy{display:flex;flex-direction:column}.d-hero .eyebrow{display:none}.d-hero h1{order:1;font-size:clamp(24px,6.8vw,30px);line-height:1.1;letter-spacing:-.055em;margin:0}.d-hero h1 .d-ln2,.d-hero h1 .ln:nth-child(3){display:inline}.d-hero-media{order:2;position:relative;inset:auto;aspect-ratio:16/9;margin:18px calc(var(--pad) * -1) 0}.d-hero-media::before{display:none}.d-hero-img{height:100%;min-height:0}.d-btns{order:3;margin-top:22px;gap:10px}.d-btns .btn{height:52px}.d-btns .d-tel-btn{display:none}.d-ticks{order:4;margin:26px 0 0}.d-hero .sub{order:5;margin:20px 0 0;font-size:16px;line-height:1.45}.d-crumbs{order:6;margin:18px 0 0;padding:0;font-size:clamp(10px,2.8vw,11px);line-height:1.2;gap:6px;flex-wrap:nowrap;white-space:nowrap;letter-spacing:0;color:#8a8a93}.d-crumbs a{color:#9a9aa3}.d-terms li{grid-template-columns:36px minmax(0,1fr);gap:6px 12px}.d-terms span{grid-column:2}.d-doc{grid-template-columns:120px minmax(0,1fr);grid-template-areas:"prev h" "prev meta" "btn btn";grid-template-rows:auto 1fr auto;column-gap:18px;row-gap:10px;align-items:start}.d-doc-h{grid-area:h;font-size:18px}.d-doc-prev{grid-area:prev;border-radius:8px;box-shadow:0 10px 26px rgba(0,0,0,.45)}.d-small{grid-area:meta}.d-doc-btn{grid-area:btn;margin-top:6px}}@media (min-width:601px) and (max-width:860px){.d-kind{flex-direction:row}.d-kind-img{flex:0 0 42%;aspect-ratio:auto;min-height:220px;border-bottom:0;border-right:1px solid var(--line2)}.d-kind-b{align-self:center}}@media (max-width:600px){.d-steps,.d-steps-3{grid-template-columns:minmax(0,1fr)}.d-table thead{display:none}.d-table,.d-table tbody,.d-table tr,.d-table td{display:block;width:100%}.d-table tr{border:1px solid var(--line2);border-radius:var(--r);padding:6px 16px;margin-bottom:12px}.d-table td{border:0;padding:10px 0}.d-table td+td{border-top:1px solid var(--line)}.d-table td::before{content:attr(data-l);display:block;font-size:13px;color:var(--t3);margin-bottom:4px}.d-vs td:last-child{background:none;padding-left:28px}.d-prices tr{display:grid;grid-template-columns:minmax(0,1fr) auto;column-gap:14px;row-gap:6px;padding:14px 16px}.d-prices td{padding:0}.d-prices td::before{display:none}.d-prices td+td{border-top:0}.d-prices td:nth-child(2){grid-column:1/-1;grid-row:2;font-size:14px}.d-prices td.d-price{grid-column:2;grid-row:1;width:auto;text-align:right}.d-vs td{position:relative;padding:12px 0 12px 28px}.d-vs td::before{position:absolute;width:1px;height:1px;margin:0;overflow:hidden;clip:rect(0 0 0 0);clip-path:inset(50%);white-space:nowrap}.d-vs td::after{content:"";position:absolute;left:1px;top:calc(12px + .25em);width:14px;height:14px}.d-vs td:first-child::after{background:linear-gradient(45deg,transparent 42%,var(--red) 42%,var(--red) 58%,transparent 58%),linear-gradient(-45deg,transparent 42%,var(--red) 42%,var(--red) 58%,transparent 58%)}.d-vs td:last-child::after{left:2px;top:calc(12px + .38em);width:13px;height:7px;border-left:2px solid var(--acc);border-bottom:2px solid var(--acc);transform:rotate(-45deg)}.d-objs{grid-template-columns:minmax(0,1fr);gap:12px}.d-obj{flex-direction:row;align-items:stretch}.d-obj-img{flex:0 0 104px;aspect-ratio:auto;min-height:104px}.d-obj-b{padding:14px 16px;align-self:center}.d-obj h3{font-size:17px;margin-bottom:6px}.d-obj p{font-size:14px;line-height:1.5}.f-check-in{padding:24px 20px}.f-check-list label{padding:15px 2px;gap:14px}.f-check .btn-lg,.d-btns .btn{width:100%;max-width:100%;padding:0 16px;font-size:15px}.d-page .form .btn-lg{padding:0 16px}}@media (max-width:400px){.d-page .form .btn-lg,.f-check .btn-lg,.d-btns .btn{font-size:15px;padding:0 14px}.d-doc{grid-template-columns:96px minmax(0,1fr);column-gap:14px}.d-doc-h{font-size:17px}.d-obj-img{flex-basis:88px;min-height:88px}.d-obj-b{padding:12px 14px}.d-obj h3{font-size:16px}}@media (max-width:360px){.d-doc .btn-lg,.f-check .btn-lg,.d-btns .btn{max-width:100%;padding:0 12px;font-size:14px}.d-page .form .btn-ic{display:none}}@media (max-width:340px){.d-page .ft{grid-template-columns:minmax(0,1fr)}.d-obj-img{flex-basis:76px;min-height:76px}.d-page .form .btn-lg,.f-check .btn-lg,.d-btns .btn{font-size:13.5px;padding:0 10px}.d-doc .btn-lg{font-size:14px;padding:0 14px}}
.v-hero h1{font-size:clamp(40px,3.75vw,74px)}.v-nums{margin-bottom:28px}.v-nums .f-num{display:block}.v-freq td:nth-child(3){white-space:normal;min-width:150px}.v-freq td:nth-child(4){font-size:14.5px;color:var(--t3)}.v-parts .dz-lbl{color:var(--t3);letter-spacing:.12em}.v-swap-r{grid-template-columns:minmax(0,.92fr) minmax(0,1.08fr);grid-template-areas:"img head" "img ticks"}.v-card-acc{border-color:rgba(124,134,255,.35)}.d-cols2 .d-ticks{margin:14px 0 0;gap:10px;color:var(--t2);line-height:1.55}.v-duct{margin:clamp(28px,3vw,44px) 0 0;background:var(--card);border:1px solid var(--line2);border-radius:var(--r);padding:clamp(18px,2vw,30px);display:grid;grid-template-columns:minmax(0,1.25fr) minmax(0,.75fr);grid-template-areas:"top top" "art cap" "art leg";column-gap:clamp(22px,3vw,48px);row-gap:18px;align-items:start}.v-duct-top{grid-area:top;display:flex;flex-wrap:wrap;align-items:center;justify-content:space-between;gap:12px 20px}.v-duct-k{font-size:12px;letter-spacing:.08em;text-transform:uppercase;color:var(--acc)}.v-seg{display:inline-flex;gap:4px;padding:4px;border:1px solid var(--line2);border-radius:999px;background:rgba(255,255,255,.02)}.v-seg button{appearance:none;border:0;background:transparent;color:var(--t2);font:inherit;font-size:14px;line-height:1.2;padding:9px 16px;border-radius:999px;cursor:pointer;transition:background .25s,color .25s}.v-seg button:hover{color:var(--t1)}.v-seg button[aria-pressed="true"]{background:#fff;color:#09090b}.v-seg button:focus-visible{outline:2px solid var(--acc);outline-offset:2px}.v-duct-art{grid-area:art;border-radius:calc(var(--r) - 4px);overflow:hidden;background:#0b0d12;border:1px solid var(--line2);aspect-ratio:720/400}.v-duct-art svg{display:block;width:100%;height:100%}.v-duct figcaption{grid-area:cap;color:var(--t2);line-height:1.6;min-height:7.5em;align-self:end}.v-duct figcaption [data-cap]{display:block}.v-duct figcaption [data-cap][hidden]{display:none}.v-legend{grid-area:leg;list-style:none;margin:0;padding:0;display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px 16px;font-size:14px;color:var(--t3)}.v-legend li{display:flex;align-items:center;gap:10px}.v-legend i{width:12px;height:12px;border-radius:50%;flex:0 0 auto}.v-duct .v-dust,.v-duct .v-grease,.v-duct .v-germs,.v-duct .v-ok,.v-duct .v-shine{transition:opacity .7s ease}.v-duct .v-ok,.v-duct .v-shine{opacity:0}.v-duct[data-state="clean"] .v-dust,.v-duct[data-state="clean"] .v-grease,.v-duct[data-state="dez"] .v-dust,.v-duct[data-state="dez"] .v-grease,.v-duct[data-state="dez"] .v-germs{opacity:0}.v-duct[data-state="clean"] .v-shine{opacity:.6}.v-duct[data-state="dez"] .v-shine,.v-duct[data-state="dez"] .v-ok{opacity:1}.v-jr{margin:0;background:#f5f5f2;color:#1c1d22;border-radius:var(--r);padding:clamp(18px,1.6vw,26px);box-shadow:0 30px 80px -30px rgba(0,0,0,.7);font-size:13.5px;line-height:1.45}.v-jr-h{border-bottom:1px solid #d6d6cf;padding-bottom:12px;margin-bottom:6px}.v-jr-h b{display:block;font-weight:600;font-size:14px;line-height:1.35;color:#111}.v-jr-h span{display:block;margin-top:6px;font-size:12px;color:#5d5f68}.v-jr-rows{margin:0}.v-jr-rows div{display:grid;grid-template-columns:minmax(0,.9fr) minmax(0,1.1fr);gap:10px;padding:8px 0;border-bottom:1px dashed #d6d6cf}.v-jr-rows dt{color:#5d5f68}.v-jr-rows dd{margin:0;color:#111;font-weight:500}.v-jr figcaption{margin-top:10px;font-size:12px;color:#6b6d75}#dokumenty .d-split{grid-template-columns:minmax(0,1fr) minmax(0,440px)}.v-inds{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:16px}.v-ind{padding:clamp(20px,1.8vw,28px);display:flex;flex-direction:column;gap:10px}.v-ind svg{width:26px;height:26px;color:var(--acc)}.v-ind h3{font-size:clamp(17px,1.15vw,20px);font-weight:500;letter-spacing:-.01em;margin:6px 0 0;line-height:1.3}.v-ind p{margin:0;color:var(--t2);line-height:1.55;font-size:15px}.v-ind a{color:var(--t1);text-decoration:underline;text-decoration-color:var(--acc);text-underline-offset:3px}.v-pest{margin-top:16px;border-color:rgba(124,134,255,.35)}.v-pest a{color:var(--t1);text-decoration:underline;text-decoration-color:var(--acc);text-underline-offset:3px}.v-pest a:hover,.v-ind a:hover{color:var(--acc)}.v-steps{grid-template-columns:repeat(3,minmax(0,1fr));row-gap:28px}@media (max-width:1180px){.v-inds{grid-template-columns:repeat(2,minmax(0,1fr))}.v-duct{grid-template-columns:minmax(0,1fr);grid-template-areas:"top" "art" "cap" "leg"}.v-duct figcaption{min-height:0}.v-legend{grid-template-columns:repeat(4,max-content)}#dokumenty .d-split{grid-template-columns:minmax(0,1fr) minmax(0,380px)}}@media (max-width:860px){.v-hero h1{font-size:clamp(28px,8vw,40px)}.v-swap-r{grid-template-areas:"head" "img" "ticks";grid-template-columns:minmax(0,1fr)}.v-steps{grid-template-columns:minmax(0,1fr)}#dokumenty .d-split{grid-template-columns:minmax(0,1fr)}.v-freq td:nth-child(3){min-width:0}.v-legend{grid-template-columns:repeat(2,minmax(0,1fr))}}@media (max-width:600px){.v-inds{grid-template-columns:minmax(0,1fr)}.v-seg{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));width:100%;border-radius:14px}.v-seg button{padding:9px 6px;font-size:13px;border-radius:10px}.v-jr-rows div{grid-template-columns:minmax(0,1fr);gap:2px}}@media (prefers-reduced-motion:reduce){.v-duct .v-dust,.v-duct .v-grease,.v-duct .v-germs,.v-duct .v-ok,.v-duct .v-shine{transition:none}}
</style>
<script type="application/ld+json">{"@context": "https://schema.org", "@graph": [{"@type": "BreadcrumbList", "itemListElement": [{"@type": "ListItem", "position": 1, "name": "Главная", "item": "https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/"}, {"@type": "ListItem", "position": 2, "name": "Очистка и дезинфекция вентиляции", "item": "https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/ochistka-dezinfektsiya-ventilyatsii/"}]}, {"@type": "Service", "@id": "https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/ochistka-dezinfektsiya-ventilyatsii/#service", "name": "Очистка и дезинфекция вентиляции для организаций", "serviceType": "Очистка и дезинфекция систем вентиляции и кондиционирования воздуха", "url": "https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/ochistka-dezinfektsiya-ventilyatsii/", "description": "Очистка воздуховодов, вентиляторов, приточных установок и кухонных вытяжек от пыли, жира и горючих отложений и дезинфекция систем вентиляции и кондиционирования для организаций в Москве и Московской области: видеоинспекция до и после, акт очистки по п. 43 ППР, запись в журнал по МР 3.5.0396-25.", "areaServed": [{"@type": "City", "name": "Москва"}, {"@type": "AdministrativeArea", "name": "Московская область"}], "audience": {"@type": "BusinessAudience", "name": "Юридические лица и ИП"}, "provider": {"@type": "Organization", "@id": "https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/#org", "name": "ПЕСТКОНТРОЛЬ Центр", "legalName": "ООО «Центр дезинфекционных услуг»", "url": "https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/", "telephone": "+7 495 104-35-70", "email": "b2b@pestcontrol-center.ru"}, "offers": {"@type": "AggregateOffer", "priceCurrency": "RUB", "lowPrice": "45", "highPrice": "2400", "offerCount": "7", "description": "Ориентиры: очистка воздуховодов от 100 ₽ за м. п., жировая очистка от 136 ₽ за м. п., дезинфекция от 45 ₽ за м. п.; осмотр и смета — 0 ₽"}}, {"@type": "FAQPage", "mainEntity": [{"@type": "Question", "name": "Как часто нужно чистить и дезинфицировать вентиляцию в организации?", "acceptedAnswer": {"@type": "Answer", "text": "Не реже 1 раза в год. Очистку вентиляционных камер, циклонов, фильтров и воздуховодов от горючих отходов и отложений с составлением акта требует п. 43 Правил противопожарного режима, профилактическую дезинфекцию централизованных систем вентиляции и кондиционирования — п. 132 СанПиН 3.3686-21. В медицинских организациях сплит-системы чистят и дезинфицируют не реже 1 раза в 3 месяца (пп. 22 п. 24 СП 2.1.4284-26). Кухонные вытяжки при ежедневной жарке мы советуем чистить каждые 3–6 месяцев."}}, {"@type": "Question", "name": "Какие документы нужны для пожарной проверки и Роспотребнадзора?", "acceptedAnswer": {"@type": "Answer", "text": "Акт очистки вентиляционных систем от горючих отходов и отложений (п. 43 ППР), акт выполненных работ по дезинфекции, журнал учёта работ по очистке и дезинфекции систем вентиляции и кондиционирования (рекомендуемая форма — приложение 3 к МР 3.5.0396-25), договор с подрядчиком, копии его лицензии и свидетельства о госрегистрации дезсредства. Для централизованных систем кондиционирования и увлажнения нужны ещё протоколы исследований на легионеллы."}}, {"@type": "Question", "name": "Нужна ли лицензия на дезинфекцию вентиляции?", "acceptedAnswer": {"@type": "Answer", "text": "Если работы выполняет подрядчик — да: с 1 марта 2025 года деятельность по оказанию услуг дезинфекции, дезинсекции и дератизации подлежит обязательному лицензированию (Федеральный закон № 194-ФЗ). Профилактическую дезинфекцию может проводить и персонал самой организации (п. 3.2 МР 3.5.0396-25), если сотрудники прошли специальную подготовку, медосмотр и вакцинацию (п. 3.3). У ООО «Центр дезинфекционных услуг» действующая лицензия Роспотребнадзора № Л064-00111-77/01942445 — проверить запись можно в реестре Роспотребнадзора."}}, {"@type": "Question", "name": "Чем очистка вентиляции отличается от дезинфекции?", "acceptedAnswer": {"@type": "Answer", "text": "Очистка механически удаляет пыль, жир и горючие отложения, а дезинфекция уничтожает микроорганизмы на уже очищенных поверхностях. Поэтому порядок всегда один: подготовка, очистка, дезинфекция и оценка эффективности — так алгоритм работ описан в приложении 1 к МР 3.5.0396-25. Дезинфекция без очистки не убирает ни горючие отложения, ни питательную среду для микробов."}}, {"@type": "Question", "name": "Можно ли чистить вентиляцию без остановки ресторана или производства?", "acceptedAnswer": {"@type": "Answer", "text": "Объект может работать, но очищаемая система на время работ выключается, а включает её после полной просушки ответственный специалист объекта (п. 3.15 МР 3.5.0396-25). Поэтому кухни обслуживаем ночью или в санитарный день, а производства, торговые и бизнес-центры — по участкам, в окна между сменами."}}, {"@type": "Question", "name": "Сколько стоит очистка и дезинфекция вентиляции?", "acceptedAnswer": {"@type": "Answer", "text": "Ориентиры: очистка воздуховодов от пыли — от 100 ₽ за погонный метр, жировая очистка кухонной вытяжки — от 136 ₽ за погонный метр, дезинфекция — от 45 ₽ за погонный метр, очистка радиального вентилятора — от 2 400 ₽. Точную смету даём после бесплатного осмотра: она зависит от длины и сечения коробов, вида отложений, доступа и числа вентиляторов и установок."}}, {"@type": "Question", "name": "Как проверить, что вентиляцию действительно очистили?", "acceptedAnswer": {"@type": "Answer", "text": "Сравнить видео до и после на тех же участках, осмотреть решётки, зонты и рабочие колёса вентиляторов, а для медицинских организаций, гостиниц и офисов с центральным кондиционированием — получить протокол лабораторного исследования смывов. Если результат неудовлетворительный, очистку и дезинфекцию повторяют (п. 4.3 МР 3.5.0396-25)."}}, {"@type": "Question", "name": "Можно ли мыть воздуховоды водой или химией?", "acceptedAnswer": {"@type": "Answer", "text": "Внутренние поверхности воздуховодов чистят без воды и концентрированных кислотных и щелочных растворов. Исключение — кухонные вытяжные системы: при полной разборке или после герметизации короба и остановке приготовления пищи допускаются моющие средства, вода и пар (п. 3.11 МР 3.5.0396-25). Выжигать жировые отложения в воздуховодах запрещено (п. 41 «г» ППР)."}}, {"@type": "Question", "name": "Как часто проводится обследование технического состояния вентиляции?", "acceptedAnswer": {"@type": "Answer", "text": "Перед вводом здания или помещения в эксплуатацию или его реконструкцией, затем через 2 года после ввода и далее не реже 1 раза в 10 лет, с инструментальными замерами объёмов вытяжки (п. 8 СП 2.1.4284-26, действует с 1 сентября 2026 года вместо СП 2.1.3678-20). Обследование не заменяет очистку и дезинфекцию: у этих работ своя периодичность."}}, {"@type": "Question", "name": "Работаете ли вы с НДС и через ЭДО?", "acceptedAnswer": {"@type": "Answer", "text": "Да, мы работаем как с НДС, так и без НДС (УСН). Договоры, акты выполненных работ и УПД направляем через системы электронного документооборота (ЭДО) или на бумажном носителе."}}]}]}</script>
</head>
<body class="d-page">
<a class="skip" href="#main">Перейти к содержанию</a>

<!-- ============ INTRO ============ -->
<div class="intro" id="intro" aria-hidden="true">
  <div class="intro-in">
    <svg class="intro-mark" viewBox="0 0 24 24" fill="none" stroke-width="1" stroke-linejoin="round"><path class="im-shield" pathLength="100" d="M12 2.5l7.5 3v6c0 5-3.2 8.6-7.5 10-4.3-1.4-7.5-5-7.5-10v-6z" stroke="#fff"/><circle class="im-c" pathLength="100" cx="12" cy="11.5" r="2.6" stroke="#7c86ff"/><path class="im-x" pathLength="100" d="M12 6.2v2.7M12 14.1v2.7M6.8 11.5h2.6M14.6 11.5h2.6" stroke="#7c86ff"/></svg>
    <div class="intro-word"><span>ПЕСТКОНТРОЛЬ</span><b>Центр</b></div>
    <div class="intro-bar"><i></i></div>
  </div>
</div>

<div class="progress" aria-hidden="true"><i id="progress"></i></div>
<div class="cursor" aria-hidden="true"><i class="cursor-dot"></i><i class="cursor-ring"></i></div>
<div class="grain" aria-hidden="true"></div>

<header class="hdr" id="hdr">
  <div class="wrap">
    <a href="../" class="logo" aria-label="ПЕСТКОНТРОЛЬ Центр — на главную">
      <span class="logo-mark"><svg viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="1.6" stroke-linejoin="round" aria-hidden="true"><path d="M12 2.5l7.5 3v6c0 5-3.2 8.6-7.5 10-4.3-1.4-7.5-5-7.5-10v-6z"/><circle cx="12" cy="11.5" r="2.6" stroke="#7c86ff"/><path d="M12 6.2v2.7M12 14.1v2.7M6.8 11.5h2.6M14.6 11.5h2.6" stroke="#7c86ff"/></svg></span>
      <span class="logo-txt"><span class="logo-name">ПЕСТКОНТРОЛЬ</span> <span class="logo-sub">Центр</span></span>
    </a>
    <nav class="nav" aria-label="Основное меню">
      <div class="nav-dd"><button class="nav-dd-btn active" type="button" aria-expanded="false" aria-controls="nav-uslugi">Услуги<svg viewBox="0 0 12 12" aria-hidden="true"><path d="M2.5 4.5 6 8l3.5-3.5" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></button><div class="nav-dd-panel" id="nav-uslugi"><a href="../dezinfektsiya/">Дезинфекция для организаций<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../deratizatsiya/">Дератизация для организаций<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../dezinsektsiya/">Дезинсекция для организаций<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../sanitarnyy-audit/"><span>Санитарный аудит <span class="nw">(СЭС-аудит)</span></span><svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="./" aria-current="page">Очистка и дезинфекция вентиляции<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../dogovor-deratizatsiya-dezinsektsiya/">Договор на обслуживание<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../#podhod" class="nav-dd-all"><span>Пест-контроль по системе IPM</span><svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a></div></div><div class="nav-dd"><button class="nav-dd-btn" type="button" aria-expanded="false" aria-controls="nav-otrasli">Отрасли<svg viewBox="0 0 12 12" aria-hidden="true"><path d="M2.5 4.5 6 8l3.5-3.5" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></button><div class="nav-dd-panel" id="nav-otrasli"><a href="../pishchevoe-proizvodstvo/">Пищевые производства<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../magaziny-i-torgovye-seti/">Магазины и торговые сети<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../restorany-i-kafe/">Рестораны и кафе<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../sklady-i-logistika/">Склады и логистика<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../farmatsevticheskie-proizvodstva/">Фармацевтические производства<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../gostinitsy/">Гостиницы и отели<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../#otrasli" class="nav-dd-all">Все отрасли<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a></div></div><a href="../dogovor-deratizatsiya-dezinsektsiya/">Договор</a><a href="../#podhod">Метод IPM</a><a href="../#usloviya">Цена</a><div class="nav-dd"><button class="nav-dd-btn" type="button" aria-expanded="false" aria-controls="nav-materialy">Материалы<svg viewBox="0 0 12 12" aria-hidden="true"><path d="M2.5 4.5 6 8l3.5-3.5" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></button><div class="nav-dd-panel" id="nav-materialy"><a href="../materialy/programma-pest-kontrolya/"><span>Программа <span class="nw">пест-контроля</span></span><svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../materialy/zhurnal-pest-kontrolya/"><span>Журнал <span class="nw">пест-контроля</span></span><svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../materialy/pest-menedzhment-ili-razovaya-obrabotka/"><span><span class="nw">Пест-менеджмент</span> или разовая обработка</span><svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../materialy/programma-proizvodstvennogo-kontrolya-haccp/">Программа производственного контроля по ХАССП<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="../materialy/" class="nav-dd-all">Все материалы<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a></div></div>
    </nav>
    <div class="hdr-right">
      <a class="phone" href="tel:+74951043570" aria-label="Позвонить: +7 (495) 104-35-70"><i><svg viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2" aria-hidden="true"><path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1 1 .4 1.9.7 2.8a2 2 0 0 1-.5 2.1L8 9.9a16 16 0 0 0 6 6l1.3-1.3a2 2 0 0 1 2.1-.4c.9.3 1.8.6 2.8.7a2 2 0 0 1 1.7 2z"/></svg></i><span>+7 (495) 104-35-70</span></a>
      <div class="msg">
        <a href="https://max.ru/u/f9LHodD0cOIlIUXFkt4KMFP88lD8n4TArBiTcV7RI1XML5c4o39QfsDBXUc" class="max" aria-label="Написать в Max" target="_blank" rel="noopener noreferrer"><svg viewBox="0 0 24 24" fill="#fff" aria-hidden="true"><path d="M12 3a9 9 0 0 0-7.7 13.7L3 21l4.4-1.2A9 9 0 1 0 12 3zm-3.6 12.3V8.7h1.6l2 2.8 2-2.8h1.6v6.6h-1.7v-3.9L12 14l-1.9-2.6v3.9z"/></svg></a>
        <a href="https://t.me/Centr_Dezinfection?text=%D0%97%D0%B4%D1%80%D0%B0%D0%B2%D1%81%D1%82%D0%B2%D1%83%D0%B9%D1%82%D0%B5!%20%D0%9F%D0%B8%D1%88%D1%83%20%D1%81%20%D1%81%D0%B0%D0%B9%D1%82%D0%B0%20%D0%BF%D0%B5%D1%81%D1%82%D0%BA%D0%BE%D0%BD%D1%82%D1%80%D0%BE%D0%BB%D1%8C-%D1%86%D0%B5%D0%BD%D1%82%D1%80.%D1%80%D1%84" class="tg" aria-label="Написать в Telegram" target="_blank" rel="noopener noreferrer"><svg viewBox="0 0 24 24" fill="#fff" aria-hidden="true"><path d="M21.4 4.3 2.9 11.4c-1.3.5-1.2 1.2-.2 1.5l4.7 1.5 1.8 5.6c.2.6.4.8.9.8.4 0 .6-.2.9-.4l2.3-2.2 4.7 3.5c.9.5 1.5.2 1.7-.8l3.1-14.6c.3-1.3-.5-1.8-1.4-1.5zM9.6 14.1l8.6-5.4c.4-.3.8-.1.5.2l-7.1 6.4-.3 3.3z"/></svg></a>
      </div>
      <a href="#zayavka" class="btn btn-w btn-sm" data-magnet><span class="btn-t">Бесплатный выезд</span></a>
      <button class="burger" id="burger" aria-label="Открыть меню" aria-expanded="false" aria-controls="mmenu"><span></span></button>
    </div>
  </div>
</header>
<nav class="mmenu" id="mmenu" aria-label="Мобильное меню">
  <div class="mm-group open" data-open><button class="mm-toggle" type="button" aria-expanded="true" aria-controls="mm-uslugi">Услуги<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m6 9 6 6 6-6" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/></svg></button><div class="mm-sub" id="mm-uslugi"><div><a href="../dezinfektsiya/">Дезинфекция для организаций</a><a href="../deratizatsiya/">Дератизация для организаций</a><a href="../dezinsektsiya/">Дезинсекция для организаций</a><a href="../sanitarnyy-audit/"><span>Санитарный аудит <span class="nw">(СЭС-аудит)</span></span></a><a href="./" aria-current="page">Очистка и дезинфекция вентиляции</a><a href="../dogovor-deratizatsiya-dezinsektsiya/">Договор на обслуживание</a><a href="../#podhod"><span class="nw">Пест-контроль</span> по системе IPM</a></div></div></div><div class="mm-group"><button class="mm-toggle" type="button" aria-expanded="false" aria-controls="mm-otrasli">Отрасли<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m6 9 6 6 6-6" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/></svg></button><div class="mm-sub" id="mm-otrasli"><div><a href="../pishchevoe-proizvodstvo/">Пищевые производства</a><a href="../magaziny-i-torgovye-seti/">Магазины и торговые сети</a><a href="../restorany-i-kafe/">Рестораны и кафе</a><a href="../sklady-i-logistika/">Склады и логистика</a><a href="../farmatsevticheskie-proizvodstva/">Фармацевтические производства</a><a href="../gostinitsy/">Гостиницы и отели</a><a href="../#otrasli">Все отрасли</a></div></div></div><a href="../dogovor-deratizatsiya-dezinsektsiya/">Договор <small>на дератизацию и дезинсекцию</small></a><a href="../#podhod">Метод IPM</a><a href="../#usloviya">Цена</a><div class="mm-group"><button class="mm-toggle" type="button" aria-expanded="false" aria-controls="mm-materialy">Материалы<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m6 9 6 6 6-6" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/></svg></button><div class="mm-sub" id="mm-materialy"><div><a href="../materialy/programma-pest-kontrolya/"><span>Программа <span class="nw">пест-контроля</span></span></a><a href="../materialy/zhurnal-pest-kontrolya/"><span>Журнал <span class="nw">пест-контроля</span></span></a><a href="../materialy/pest-menedzhment-ili-razovaya-obrabotka/"><span><span class="nw">Пест-менеджмент</span> или разовая обработка</span></a><a href="../materialy/programma-proizvodstvennogo-kontrolya-haccp/">Программа производственного контроля по ХАССП</a><a href="../materialy/">Все материалы</a></div></div></div>
  <a href="#zayavka" class="btn btn-w btn-lg"><span class="btn-t">Заказать бесплатное обследование</span></a>
</nav>

<main id="main" tabindex="-1">
<section class="d-hero v-hero" id="hero">
  <div class="wrap">
    <div class="d-hero-copy">
      <nav class="d-crumbs" aria-label="Навигационная цепочка" data-h><a href="../">Главная</a><span aria-hidden="true">→</span><span aria-current="page">Очистка и дезинфекция вентиляции</span></nav>
      <div class="eyebrow">Воздуховоды и вытяжки · Только для юридических лиц</div>
      <h1><span class="ln d-ln1"><span>Очистка и дезинфекция</span></span> <span class="ln d-ln2"><span>вентиляции</span></span> <span class="ln"><span><em>для организаций</em></span></span></h1>
      <div class="d-hero-media"><picture><source media="(max-width:860px)" srcset="../img/vent-hero-mob-760.webp 760w, ../img/vent-hero-mob.webp 1024w" sizes="100vw" width="1024" height="576"><img class="d-hero-img" src="../img/vent-hero.webp" srcset="../img/vent-hero-1440.webp 1440w, ../img/vent-hero.webp 1920w" sizes="100vw" width="1920" height="1072" alt="Специалист вводит гибкий вал щёточной машины в ревизионный люк прямоугольного воздуховода на техническом этаже, рядом подключён шланг промышленного пылесоса" fetchpriority="high" decoding="async"></picture></div>
      <ul class="d-ticks">
        <li data-h>Видеоинспекция до и после — запись по каждому участку короба</li>
        <li data-h>Акт очистки от горючих отложений для пожарной проверки по п. 43 ППР</li>
        <li data-h>Дезинфекция средствами с СГР и запись в журнал по МР <span class="nw">3.5.0396-25</span></li>
      </ul>
      <p class="sub" data-h>Чистим и дезинфицируем приточно-вытяжную вентиляцию, кухонные вытяжки и системы кондиционирования в Москве и области. Работаем ночью и в санитарные дни, чтобы кухня и производство не останавливались.</p>
      <div class="d-btns" data-h>
        <a href="#zayavka" class="btn btn-w btn-lg" data-magnet><span class="btn-t">Заказать бесплатный осмотр</span></a>
        <a href="tel:+74951043570" class="btn btn-o btn-lg d-tel-btn" data-magnet><span class="btn-t">+7 (495) 104-35-70</span></a>
      </div>
    </div>
    <div aria-hidden="true"></div>
  </div>
</section>

<div class="strip" aria-label="Коротко об очистке и дезинфекции вентиляции">
  <div class="strip-track" id="stripTrack">
    <div class="strip-set">
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-scan-search" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M3 7V5a2 2 0 0 1 2-2h2" /> <path d="M17 3h2a2 2 0 0 1 2 2v2" /> <path d="M21 17v2a2 2 0 0 1-2 2h-2" /> <path d="M7 21H5a2 2 0 0 1-2-2v-2" /> <circle cx="12" cy="12" r="3" /> <path d="m16 16-1.9-1.9" /> </svg><b>Видео до и после</b> по каждому участку</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-file-badge" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M13 22h5a2 2 0 0 0 2-2V8a2.4 2.4 0 0 0-.706-1.706l-3.588-3.588A2.4 2.4 0 0 0 14 2H6a2 2 0 0 0-2 2v3.3" /> <path d="M14 2v5a1 1 0 0 0 1 1h5" /> <path d="m7.69 16.479 1.29 4.88a.5.5 0 0 1-.698.591l-1.843-.849a1 1 0 0 0-.879.001l-1.846.85a.5.5 0 0 1-.692-.593l1.29-4.88" /> <circle cx="6" cy="14" r="3" /> </svg><b>Акт по п. 43 ППР</b> для пожарной проверки</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-notebook-pen" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M13.4 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-7.4" /> <path d="M2 6h4" /> <path d="M2 10h4" /> <path d="M2 14h4" /> <path d="M2 18h4" /> <path d="M21.378 5.626a1 1 0 1 0-3.004-3.004l-5.01 5.012a2 2 0 0 0-.506.854l-.837 2.87a.5.5 0 0 0 .62.62l2.87-.837a2 2 0 0 0 .854-.506z" /> </svg><b>Журнал</b> по МР 3.5.0396-25</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-spray-can" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M3 3h.01" /> <path d="M7 5h.01" /> <path d="M11 7h.01" /> <path d="M3 7h.01" /> <path d="M7 9h.01" /> <path d="M3 11h.01" /> <rect width="4" height="4" x="15" y="5" /> <path d="m19 9 2 2v10c0 .6-.4 1-1 1h-6c-.6 0-1-.4-1-1V11l2-2" /> <path d="m13 14 8-2" /> <path d="m13 19 8-2" /> </svg><b>Дезсредства с СГР</b> и режимом для вентиляции</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-utensils" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M3 2v7c0 1.1.9 2 2 2h4a2 2 0 0 0 2-2V2" /> <path d="M7 2v20" /> <path d="M21 15V2a5 5 0 0 0-5 5v6c0 1.1.9 2 2 2h3Zm0 0v7" /> </svg><b>Кухонные вытяжки</b> зонты, фильтры, короба</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-flask-conical" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M14 2v6a2 2 0 0 0 .245.96l5.51 10.08A2 2 0 0 1 18 22H6a2 2 0 0 1-1.755-2.96l5.51-10.08A2 2 0 0 0 10 8V2" /> <path d="M6.453 15h11.094" /> <path d="M8.5 2h7" /> </svg><b>Смывы</b> на легионеллы и микрофлору</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-clock" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg><b>Ночью и в выходные</b> без остановки смены</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-shield-check" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z" /> <path d="m9 12 2 2 4-4" /> </svg><b>Лицензия</b> Роспотребнадзора</div>
    </div>
    <div class="strip-set" aria-hidden="true">
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-scan-search" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M3 7V5a2 2 0 0 1 2-2h2" /> <path d="M17 3h2a2 2 0 0 1 2 2v2" /> <path d="M21 17v2a2 2 0 0 1-2 2h-2" /> <path d="M7 21H5a2 2 0 0 1-2-2v-2" /> <circle cx="12" cy="12" r="3" /> <path d="m16 16-1.9-1.9" /> </svg><b>Видео до и после</b> по каждому участку</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-file-badge" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M13 22h5a2 2 0 0 0 2-2V8a2.4 2.4 0 0 0-.706-1.706l-3.588-3.588A2.4 2.4 0 0 0 14 2H6a2 2 0 0 0-2 2v3.3" /> <path d="M14 2v5a1 1 0 0 0 1 1h5" /> <path d="m7.69 16.479 1.29 4.88a.5.5 0 0 1-.698.591l-1.843-.849a1 1 0 0 0-.879.001l-1.846.85a.5.5 0 0 1-.692-.593l1.29-4.88" /> <circle cx="6" cy="14" r="3" /> </svg><b>Акт по п. 43 ППР</b> для пожарной проверки</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-notebook-pen" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M13.4 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-7.4" /> <path d="M2 6h4" /> <path d="M2 10h4" /> <path d="M2 14h4" /> <path d="M2 18h4" /> <path d="M21.378 5.626a1 1 0 1 0-3.004-3.004l-5.01 5.012a2 2 0 0 0-.506.854l-.837 2.87a.5.5 0 0 0 .62.62l2.87-.837a2 2 0 0 0 .854-.506z" /> </svg><b>Журнал</b> по МР 3.5.0396-25</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-spray-can" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M3 3h.01" /> <path d="M7 5h.01" /> <path d="M11 7h.01" /> <path d="M3 7h.01" /> <path d="M7 9h.01" /> <path d="M3 11h.01" /> <rect width="4" height="4" x="15" y="5" /> <path d="m19 9 2 2v10c0 .6-.4 1-1 1h-6c-.6 0-1-.4-1-1V11l2-2" /> <path d="m13 14 8-2" /> <path d="m13 19 8-2" /> </svg><b>Дезсредства с СГР</b> и режимом для вентиляции</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-utensils" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M3 2v7c0 1.1.9 2 2 2h4a2 2 0 0 0 2-2V2" /> <path d="M7 2v20" /> <path d="M21 15V2a5 5 0 0 0-5 5v6c0 1.1.9 2 2 2h3Zm0 0v7" /> </svg><b>Кухонные вытяжки</b> зонты, фильтры, короба</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-flask-conical" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M14 2v6a2 2 0 0 0 .245.96l5.51 10.08A2 2 0 0 1 18 22H6a2 2 0 0 1-1.755-2.96l5.51-10.08A2 2 0 0 0 10 8V2" /> <path d="M6.453 15h11.094" /> <path d="M8.5 2h7" /> </svg><b>Смывы</b> на легионеллы и микрофлору</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-clock" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg><b>Ночью и в выходные</b> без остановки смены</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-shield-check" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z" /> <path d="m9 12 2 2 4-4" /> </svg><b>Лицензия</b> Роспотребнадзора</div>
    </div>
  </div>
</div>

<section class="f-checks" id="samoproverka" aria-labelledby="chk-t">
  <div class="wrap">
    <div class="panel f-check" data-fade>
      <div class="panel-scan" aria-hidden="true"></div>
      <div class="f-check-in">
        <div class="f-check-l">
          <div class="badge"><span class="dot"></span>Готовность к проверкам МЧС и Роспотребнадзора</div>
          <h2 id="chk-t" class="f-check-t" data-split>Проверьте вентиляцию <em>на вашем объекте</em></h2>
          <p class="f-check-res" id="chk-res" aria-live="polite"><b>5</b> из 5 на месте</p>
          <p class="f-check-note" id="chk-note">Все пять пунктов закрыты — продлите график, чтобы следующий акт и запись в журнале появились вовремя. Напомним о сроке и приедем в удобное окно.</p>
          <a href="#zayavka" class="btn btn-w btn-lg"><span class="btn-t">Заказать бесплатный осмотр</span></a>
        </div>
        <ul class="f-check-list">
          <li><label><input type="checkbox" checked><span>Акт очистки вентиляционных камер, фильтров и воздуховодов от горючих отложений составлен не раньше чем 12 месяцев назад (п. 43 ППР)</span></label></li>
          <li><label><input type="checkbox" checked><span>Централизованная вентиляция и кондиционирование прошли профилактическую дезинфекцию за последние 12 месяцев (п. 132 СанПиН <span class="nw">3.3686-21</span>)</span></label></li>
          <li><label><input type="checkbox" checked><span>Ведётся журнал учёта очистки и дезинфекции систем вентиляции: даты, системы, площадь коробов, дезсредство (п. 4.2 МР <span class="nw">3.5.0396-25</span>)</span></label></li>
          <li><label><input type="checkbox" checked><span>Над плитами и фритюрами чистят не только жироулавливающие фильтры, но и короб вытяжки за ними, вентилятор и выброс</span></label></li>
          <li><label><input type="checkbox" checked><span>У подрядчика есть лицензия на услуги дезинфекции, а в папке лежат копии СГР и инструкции на дезсредство</span></label></li>
        </ul>
      </div>
    </div>
  </div>
</section>

<section class="s" id="chto-takoe">
  <div class="wrap">
    <div class="d-swap">
      <div class="head">
        <div class="eyebrow" data-eyebrow>Определение · МР <span class="nw">3.5.0396-25</span></div>
        <h2 data-split>Что такое очистка и дезинфекция <em>вентиляции</em></h2>
        <p class="sub" data-fade><b>Очистка и дезинфекция вентиляции</b> — это удаление пыли, жира и горючих отложений из воздуховодов, вентиляторов, фильтров и вытяжных зонтов и последующая обработка внутренних поверхностей зарегистрированным дезинфицирующим средством. Для организаций это обязательная работа не реже 1 раза в год: очистку с актом требует <a href="https://www.consultant.ru/document/cons_doc_LAW_363263/" target="_blank" rel="noopener noreferrer">п. 43 Правил противопожарного режима</a>, профилактическую дезинфекцию централизованных систем — <a href="http://pravo.gov.ru/proxy/ips/?docbody=&amp;nd=602107773&amp;rdk=0" target="_blank" rel="noopener noreferrer">п. 132 СанПиН <span class="nw">3.3686-21</span></a>.</p>
      </div>
      <figure class="d-swap-img" data-fade><img src="../img/vent-brush.webp" srcset="../img/vent-brush-720.webp 720w, ../img/vent-brush.webp 1200w" sizes="(max-width:860px) calc(100vw - 40px), (max-width:1900px) 44vw, 840px" width="1200" height="896" loading="lazy" decoding="async" alt="Специалист вводит вращающуюся щётку на гибком валу в ревизионный люк воздуховода и подсвечивает фонарём слой пыли на дне короба"></figure>
      <ul class="d-ticks" data-group="ctalist">
        <li><b>Сначала очистка, потом дезинфекция.</b> Порядок задаёт рекомендуемый алгоритм МР <span class="nw">3.5.0396-25</span> (приложение 1): подготовка, очистка, дезинфекция и оценка эффективности. Обработка по слою пыли и жира не даёт нужного эффекта.</li>
        <li><b>Система на время работ выключена.</b> У выключателей размещаем предупреждающие надписи, а включает вентиляцию ваш ответственный специалист — после полной просушки (п. 3.15 МР).</li>
        <li><b>В воздуховодах — без воды и концентрированных кислот и щелочей.</b> Моющие средства, вода и пар допустимы только в кухонной вытяжке при разборке или герметизации короба (п. 3.11 МР).</li>
      </ul>
    </div>
    <div class="d-cards" style="margin-top:28px" data-group="cards">
      <article class="d-card d-kind" data-tilt>
        <div class="d-kind-img"><img src="../img/vent-ahu.webp" srcset="../img/vent-ahu-480.webp 480w, ../img/vent-ahu-720.webp 720w, ../img/vent-ahu.webp 1200w" sizes="(max-width:600px) calc(100vw - 40px), (max-width:860px) 42vw, (max-width:1900px) 30vw, 570px" width="1200" height="670" loading="lazy" decoding="async" alt="Специалист достаёт загрязнённый карманный фильтр из секции приточной установки, рядом стопка новых фильтров"></div>
        <div class="d-kind-b"><span class="dz-lbl">Приток и вытяжка</span><h3>Очистка от пыли</h3><p>Приточно-вытяжные системы офисов, торговых центров, складов и производств: короба, вентиляторы, секции приточных установок, решётки и диффузоры. Щёточные машины и промышленный пылесос с фильтром.</p></div>
      </article>
      <article class="d-card d-kind" data-tilt>
        <div class="d-kind-img"><img src="../img/vent-kitchen.webp" srcset="../img/vent-kitchen-480.webp 480w, ../img/vent-kitchen-720.webp 720w, ../img/vent-kitchen.webp 1200w" sizes="(max-width:600px) calc(100vw - 40px), (max-width:860px) 42vw, (max-width:1900px) 30vw, 570px" width="1200" height="670" loading="lazy" decoding="async" alt="Ночью на закрытой кухне ресторана специалист снимает жироулавливающий фильтр с вытяжного зонта, оборудование укрыто плёнкой"></div>
        <div class="d-kind-b"><span class="dz-lbl">Общепит и пищевые цеха</span><h3>Жировая очистка</h3><p>Вытяжные зонты, жироулавливающие фильтры, короба, вентилятор и выброс на кровле. Жир в коробе горит, а выжигать его запрещено (п. 41 «г» ППР) — снимаем механически и щелочными средствами.</p></div>
      </article>
      <article class="d-card d-kind" data-tilt>
        <div class="d-kind-img"><img src="../img/vent-disinfection.webp" srcset="../img/vent-disinfection-480.webp 480w, ../img/vent-disinfection-720.webp 720w, ../img/vent-disinfection.webp 1200w" sizes="(max-width:600px) calc(100vw - 40px), (max-width:860px) 42vw, (max-width:1900px) 30vw, 570px" width="1200" height="670" loading="lazy" decoding="async" alt="Специалист в респираторе подаёт мелкодисперсный аэрозоль генератора холодного тумана в ревизионный люк круглого воздуховода"></div>
        <div class="d-kind-b"><span class="dz-lbl">После очистки</span><h3>Дезинфекция</h3><p>Воздуховоды, приточные установки, фанкойлы и сплит-системы. Средства с СГР, режимом для систем вентиляции и широким спектром действия — орошением или аэрозолем, с расчётом расхода в журнале (пп. 3.12–3.13 МР).</p></div>
      </article>
    </div>
  </div>
</section>

<section class="s" id="normy">
  <div class="wrap">
    <div class="head">
      <div class="eyebrow" data-eyebrow>Нормы на ноябрь 2026 года</div>
      <h2 data-split>Как часто чистить и дезинфицировать <em>вентиляцию</em></h2>
      <p class="sub" data-fade>Сроки задают сразу несколько документов: пожарные правила, санитарные правила и методические рекомендации Роспотребнадзора. С 1 сентября 2026 года СП <span class="nw">2.1.3678-20</span> заменён на <a href="http://publication.pravo.gov.ru/document/0001202606020088" target="_blank" rel="noopener noreferrer">СП <span class="nw">2.1.4284-26</span></a> — в таблице уже новые пункты.</p>
    </div>
    <div class="d-cards v-nums" data-group="cards">
      <article class="d-card"><span class="f-num">1 раз в год</span><h3>Минимум для любой организации</h3><p>Очистка от горючих отложений с актом (п. 43 ППР) и профилактическая дезинфекция централизованных систем (п. 132 СанПиН <span class="nw">3.3686-21</span>).</p></article>
      <article class="d-card"><span class="f-num">2 раза в год</span><h3>Анализ на легионеллы</h3><p>Для централизованных систем кондиционирования и увлажнения воздуха — кроме сплит-систем и кондиционеров малой мощности без увлажнения.</p></article>
      <article class="d-card"><span class="f-num">Раз в 3 месяца</span><h3>Сплит-системы в медицине</h3><p>Очистка и дезинфекция фильтров и камер теплообменника в медицинских организациях (пп. 22 п. 24 СП <span class="nw">2.1.4284-26</span>).</p></article>
    </div>
    <table class="d-table v-freq" data-fade>
      <caption class="sr-only">Периодичность очистки и дезинфекции систем вентиляции по действующим нормам</caption>
      <thead><tr><th scope="col">Объект и система</th><th scope="col">Что делать</th><th scope="col">Как часто</th><th scope="col">Основание</th></tr></thead>
      <tbody>
        <tr><td data-l="Объект и система"><b>Любая организация</b><br><span class="d-small">Вентиляционные камеры, циклоны, фильтры, воздуховоды</span></td><td data-l="Что делать">Очистка от горючих отходов и отложений с составлением акта</td><td data-l="Как часто"><span class="dz-tag">Не реже 1 раза в год</span></td><td data-l="Основание">п. 43 ППР в РФ (постановление Правительства РФ № 1479)</td></tr>
        <tr><td data-l="Объект и система"><b>Медицина, образование, гостиницы, офисы, производство, торговля, транспорт</b><br><span class="d-small">Централизованная вентиляция и кондиционирование</span></td><td data-l="Что делать">Профилактическая дезинфекция средствами широкого спектра, разрушающими биоплёнку</td><td data-l="Как часто"><span class="dz-tag">Не реже 1 раза в год</span></td><td data-l="Основание">п. 132 СанПиН <span class="nw">3.3686-21</span></td></tr>
        <tr><td data-l="Объект и система"><b>Те же объекты</b><br><span class="d-small">Централизованные системы кондиционирования и увлажнения воздуха</span></td><td data-l="Что делать">Микробиологическое исследование на легионеллы</td><td data-l="Как часто"><span class="dz-tag">Не реже 2 раз в год</span></td><td data-l="Основание">п. 132 СанПиН <span class="nw">3.3686-21</span></td></tr>
        <tr><td data-l="Объект и система"><b>Медицинские организации</b><br><span class="d-small">Механическая приточно-вытяжная вентиляция и кондиционирование</span></td><td data-l="Что делать">Проверка эффективности работы, очистка и дезинфекция</td><td data-l="Как часто"><span class="dz-tag">1 раз в год</span></td><td data-l="Основание">пп. 2 и 27 п. 24 СП <span class="nw">2.1.4284-26</span></td></tr>
        <tr><td data-l="Объект и система"><b>Медицинские организации</b><br><span class="d-small">Сплит-системы в кабинетах, палатах, административных помещениях</span></td><td data-l="Что делать">Очистка и дезинфекция фильтров и камер теплообменника</td><td data-l="Как часто"><span class="dz-tag warn">Не реже 1 раза в 3 месяца</span></td><td data-l="Основание">пп. 22 п. 24 СП <span class="nw">2.1.4284-26</span></td></tr>
        <tr><td data-l="Объект и система"><b>Медицинские организации</b><br><span class="d-small">Вентиляционные камеры и воздухозаборные шахты</span></td><td data-l="Что делать">Уборка помещений венткамер и воздухозаборных шахт</td><td data-l="Как часто"><span class="dz-tag warn">Камеры — не реже 1 раза в месяц, шахты — не реже 1 раза в 6 месяцев</span></td><td data-l="Основание">пп. 27 п. 24 СП <span class="nw">2.1.4284-26</span></td></tr>
        <tr><td data-l="Объект и система"><b>Кухни общепита и пищевые цеха</b><br><span class="d-small">Зонты, жироулавливающие фильтры, короба, вентилятор</span></td><td data-l="Что делать">Жировая очистка механически и моющими средствами, без выжигания</td><td data-l="Как часто"><span class="dz-tag">По графику объекта, но не реже 1 раза в год</span></td><td data-l="Основание">пп. 41 «г» и 43 ППР; при ежедневной жарке советуем каждые 3–6 месяцев</td></tr>
        <tr><td data-l="Объект и система"><b>Любой объект</b><br><span class="d-small">Неблагополучная эпидемиологическая обстановка, например выявлены легионеллы</span></td><td data-l="Что делать">Дезинфекция по эпидемическим показаниям, в том числе заключительная — только силами дезинфекционной организации</td><td data-l="Как часто"><span class="dz-tag warn">Без ожидания планового срока</span></td><td data-l="Основание">пп. 2.4 и 3.2 МР <span class="nw">3.5.0396-25</span></td></tr>
      </tbody>
    </table>
    <p class="d-note" data-fade>Правила противопожарного режима, утверждённые постановлением Правительства РФ № 1479, действуют до 31 декабря 2026 года. Новые правила утверждает МЧС России: проект приказа опубликован 6 августа 2026 года и, если его примут, вступит в силу 1 января 2027 года. Акт очистки за 2026 год оформляем по действующей редакции, а после выхода приказа сверим форму и ссылки.</p>
  </div>
</section>

<section class="s" id="sostav">
  <div class="wrap">
    <div class="head">
      <div class="eyebrow" data-eyebrow>Состав работ</div>
      <h2 data-split>Что чистим и дезинфицируем <em>в системе</em></h2>
      <p class="sub" data-fade>Очищаем систему целиком — от воздухозабора до выброса. Если чистить только решётки и фильтры, пыль и жир из коробов снова попадают в помещение.</p>
    </div>
    <div class="d-cards v-parts" data-group="cards">
      <article class="d-card"><span class="dz-lbl">01</span><h3>Воздуховоды</h3><p>Круглые и прямоугольные, горизонтальные и вертикальные участки. Работаем через ревизионные люки; если их нет, на осмотре отмечаем, где нужны герметичные инспекционные двери (п. 3.17 МР).</p></article>
      <article class="d-card"><span class="dz-lbl">02</span><h3>Зонты и жироуловители</h3><p>Снимаем жироулавливающие фильтры, отмачиваем и моем в щелочном растворе, очищаем корпус зонта и короб за ним до вентилятора.</p></article>
      <article class="d-card"><span class="dz-lbl">03</span><h3>Вентиляторы</h3><p>Радиальные «улитки», осевые, канальные и крышные: рабочее колесо, корпус и гибкие вставки. Налёт на колесе снижает расход воздуха и разбалансирует вентилятор.</p></article>
      <article class="d-card"><span class="dz-lbl">04</span><h3>Приточные установки</h3><p>Секции фильтров, нагреватели и охладители, дренажные поддоны, шумоглушители. Фильтры, которые нельзя очистить, меняем на новые (п. 3.25 МР).</p></article>
      <article class="d-card"><span class="dz-lbl">05</span><h3>Решётки, диффузоры, клапаны</h3><p>Решётки и диффузоры снимаем, моем и дезинфицируем отдельно (п. 3.15 МР), а регулирующие клапаны и шиберы очищаем с обеих сторон через инспекционные двери (п. 3.16 МР).</p></article>
      <article class="d-card"><span class="dz-lbl">06</span><h3>Кондиционеры и фанкойлы</h3><p>Сплит-системы, кассетные и канальные блоки, потолочные фанкойлы: фильтры, теплообменник, дренажный поддон и трасса, дезинфекция испарителя.</p></article>
    </div>
  </div>
</section>

<section class="s" id="video">
  <div class="wrap">
    <div class="d-swap v-swap-r">
      <div class="head">
        <div class="eyebrow" data-eyebrow>Видеоинспекция</div>
        <h2 data-split>Показываем, что внутри короба, — <em>до и после</em></h2>
        <p class="sub" data-fade>Камера на гибкой штанге проходит по тем же участкам дважды: на осмотре, чтобы оценить слой отложений и посчитать работы, и после — чтобы вы увидели результат, а не поверили на слово. Фото- и видеоинспекцию для обследования систем прямо называет МР <span class="nw">3.5.0396-25</span> (приложение 1).</p>
      </div>
      <figure class="d-swap-img" data-fade><img src="../img/vent-video.webp" srcset="../img/vent-video-720.webp 720w, ../img/vent-video.webp 1200w" sizes="(max-width:860px) calc(100vw - 40px), (max-width:1900px) 44vw, 840px" width="1200" height="896" loading="lazy" decoding="async" alt="Специалист опускает кабель инспекционной камеры в ревизионный люк воздуховода и смотрит изображение внутренней поверхности короба на защищённом планшете"></figure>
      <ul class="d-ticks" data-group="ctalist">
        <li><b>До работ:</b> снимаем 2–3 характерных участка, определяем вид отложений — пыль, жир, строительный мусор, следы влаги и плесени — и отмечаем места для люков.</li>
        <li><b>После работ:</b> повторяем маршрут камеры на тех же участках и прикладываем запись к акту, со схемой мест съёмки.</li>
        <li><b>Для медицины, гостиниц и офисов</b> с центральным кондиционированием дополнительно берём смывы и передаём протокол аккредитованной лаборатории.</li>
      </ul>
    </div>
    <figure class="v-duct" id="vduct" data-state="do" aria-labelledby="vduct-cap" data-fade>
      <div class="v-duct-top">
        <span class="v-duct-k">Схема · что видит камера в коробе</span>
        <div class="v-seg" role="group" aria-label="Состояние воздуховода">
          <button type="button" data-s="do" aria-pressed="true">До работ</button>
          <button type="button" data-s="clean" aria-pressed="false">После очистки</button>
          <button type="button" data-s="dez" aria-pressed="false">После дезинфекции</button>
        </div>
      </div>
      <div class="v-duct-art">
        <svg viewBox="0 0 720 400" role="img" aria-label="Схема внутренней поверхности прямоугольного воздуховода: отложения пыли, жировая плёнка и микроорганизмы до работ, после очистки и после дезинфекции">
          <defs>
            <linearGradient id="vdF" x1="0" y1="1" x2="0" y2="0"><stop offset="0" stop-color="#3a414f"/><stop offset="1" stop-color="#1c2029"/></linearGradient>
            <linearGradient id="vdC" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#454d5d"/><stop offset="1" stop-color="#222731"/></linearGradient>
            <linearGradient id="vdL" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#3d4452"/><stop offset="1" stop-color="#1f232c"/></linearGradient>
            <linearGradient id="vdR" x1="1" y1="0" x2="0" y2="0"><stop offset="0" stop-color="#363d4a"/><stop offset="1" stop-color="#1d2129"/></linearGradient>
            <radialGradient id="vdB" cx=".5" cy=".5" r=".6"><stop offset="0" stop-color="#05060a"/><stop offset="1" stop-color="#11141b"/></radialGradient>
            <linearGradient id="vdD" x1="0" y1="1" x2="0" y2="0"><stop offset="0" stop-color="#b7b2a6"/><stop offset="1" stop-color="#6f6c66"/></linearGradient>
          </defs>
          <rect width="720" height="400" fill="#0b0d12"/>
          <g transform="matrix(1.2 0 0 1.17647 -72 -35.294)">
          <polygon points="60,30 660,30 420,166 300,166" fill="url(#vdC)"/>
          <polygon points="60,370 660,370 420,234 300,234" fill="url(#vdF)"/>
          <polygon points="60,30 300,166 300,234 60,370" fill="url(#vdL)"/>
          <polygon points="660,30 420,166 420,234 660,370" fill="url(#vdR)"/>
          <rect x="300" y="166" width="120" height="68" fill="url(#vdB)"/>
          <g fill="none" stroke="#5a6375" stroke-opacity=".55" stroke-width="2">
            <rect x="144" y="77.6" width="432" height="244.8"/>
            <rect x="210" y="115" width="300" height="170"/>
            <rect x="261" y="143.9" width="198" height="112.2"/>
          </g>
          <g stroke="#5a6375" stroke-opacity=".35" stroke-width="1.2">
            <line x1="60" y1="30" x2="300" y2="166"/><line x1="660" y1="30" x2="420" y2="166"/>
            <line x1="60" y1="370" x2="300" y2="234"/><line x1="660" y1="370" x2="420" y2="234"/>
          </g>
          <g class="v-shine" stroke="#dfe6f2" stroke-linecap="round" fill="none">
            <path d="M120 54 L262 136" stroke-width="3" stroke-opacity=".22"/>
            <path d="M600 54 L458 136" stroke-width="2" stroke-opacity=".16"/>
            <path d="M150 352 L282 268" stroke-width="2" stroke-opacity=".14"/>
          </g>
          <g class="v-grease">
            <path d="M60 210 L300 202 L300 234 L60 370 Z" fill="#a8792f" fill-opacity=".34"/>
            <path d="M660 214 L420 204 L420 234 L660 370 Z" fill="#a8792f" fill-opacity=".3"/>
            <path d="M96 214 q4 30 -2 52 q8 -10 10 -52 Z M150 210 q5 22 0 40 q8 -8 8 -40 Z M226 205 q3 16 -1 28 q6 -6 6 -28 Z" fill="#c79a44" fill-opacity=".45"/>
            <path d="M622 218 q-4 30 2 50 q-9 -10 -10 -50 Z M560 214 q-5 20 0 36 q-8 -8 -8 -36 Z M492 209 q-3 15 1 26 q-6 -6 -6 -26 Z" fill="#c79a44" fill-opacity=".4"/>
          </g>
          <g class="v-dust">
            <path d="M60 370 L660 370 L420 234 L300 234 Z" fill="url(#vdD)" fill-opacity=".62"/>
            <path d="M60 370 C140 338 220 352 300 330 C380 312 470 346 560 330 C610 322 640 344 660 370 Z" fill="#cfc9bc" fill-opacity=".55"/>
            <path d="M150 318 c18 -10 40 -8 52 2 c-14 4 -36 6 -52 -2 Z M410 300 c14 -8 34 -6 44 2 c-12 4 -30 5 -44 -2 Z M300 262 c10 -5 24 -4 30 1 c-8 3 -20 4 -30 -1 Z M520 336 c16 -9 36 -7 48 2 c-13 4 -33 5 -48 -2 Z" fill="#e6e0d2" fill-opacity=".65"/>
            <g fill="#e8e3d8" fill-opacity=".5"><circle cx="110" cy="74" r="2"/><circle cx="180" cy="60" r="1.6"/><circle cx="250" cy="120" r="1.8"/><circle cx="470" cy="118" r="1.6"/><circle cx="560" cy="66" r="2"/><circle cx="620" cy="100" r="1.4"/><circle cx="96" cy="150" r="1.6"/><circle cx="640" cy="170" r="1.8"/></g>
          </g>
          <g class="v-germs">
            <g fill="#7c86ff"><circle cx="96" cy="120" r="4"/><circle cx="112" cy="132" r="3"/><circle cx="88" cy="140" r="2.5"/><circle cx="210" cy="190" r="3.5"/><circle cx="226" cy="178" r="2.5"/><circle cx="604" cy="126" r="4"/><circle cx="590" cy="142" r="3"/><circle cx="620" cy="146" r="2.5"/><circle cx="512" cy="196" r="3.5"/><circle cx="496" cy="186" r="2.5"/><circle cx="250" cy="300" r="3.5"/><circle cx="268" cy="312" r="2.5"/><circle cx="470" cy="290" r="3.5"/><circle cx="452" cy="300" r="2.5"/><circle cx="360" cy="320" r="3"/><circle cx="330" cy="70" r="3"/><circle cx="392" cy="84" r="2.5"/></g>
            <g fill="#4ade80" fill-opacity=".8"><circle cx="300" cy="170" r="4.5"/><circle cx="292" cy="180" r="3"/><circle cx="306" cy="184" r="2.5"/><circle cx="420" cy="230" r="4"/><circle cx="428" cy="220" r="2.5"/><circle cx="412" cy="222" r="2"/><circle cx="72" cy="356" r="4"/><circle cx="84" cy="346" r="2.5"/><circle cx="646" cy="40" r="3.5"/><circle cx="636" cy="48" r="2.2"/></g>
          </g>
          </g>
          <g class="v-ok" transform="translate(660 56)">
            <circle r="26" fill="#0f2a1b" stroke="#4ade80" stroke-width="2"/>
            <path d="M-11 0 l7 8 l15 -16" fill="none" stroke="#4ade80" stroke-width="3.4" stroke-linecap="round" stroke-linejoin="round"/>
          </g>
        </svg>
      </div>
      <figcaption id="vduct-cap">
        <span data-cap="do">Короб, который давно не обслуживали: на дне слой пыли и пуха, на стенках жировая плёнка, на металле колонии микроорганизмов и плесени. Такой участок снимаем на видео ещё на осмотре.</span>
        <span data-cap="clean" hidden>Щётки и пылесос сняли пыль и жир, но микроорганизмы остались на металле. Поэтому следом идёт дезинфекция — по уже чистой поверхности.</span>
        <span data-cap="dez" hidden>Средство с СГР нанесено по режиму для систем вентиляции, короб просушен. Повторное видео того же участка — к акту, запись о работах — в журнал объекта.</span>
      </figcaption>
      <ul class="v-legend" aria-label="Обозначения на схеме">
        <li><i style="background:#cfc9bc"></i>Пыль и пух</li>
        <li><i style="background:#c79a44"></i>Жировая плёнка</li>
        <li><i style="background:#7c86ff"></i>Микроорганизмы</li>
        <li><i style="background:#4ade80"></i>Плесень</li>
      </ul>
    </figure>
  </div>
</section>

<section class="s" id="kuhni">
  <div class="wrap">
    <div class="head">
      <div class="eyebrow" data-eyebrow>Рестораны, столовые, фуд-корты</div>
      <h2 data-split>Очистка кухонной вытяжки <em>от жира</em></h2>
      <p class="sub" data-fade>Жир оседает не только на фильтрах, но и в коробе за зонтом, на рабочем колесе вентилятора и у выброса на кровле. Фильтры персонал моет сам, а короб без доступа внутрь не отмыть — именно там копится горючий слой.</p>
    </div>
    <div class="d-cols2" data-group="cards">
      <div class="d-card">
        <span class="dz-lbl">Силами кухни</span>
        <h3>Что моет персонал</h3>
        <ul class="d-ticks">
          <li>Жироулавливающие фильтры — по инструкции производителя и графику кухни</li>
          <li>Наружные поверхности зонтов и лотки для стока жира</li>
          <li>Запись в график уборки — для производственного контроля</li>
        </ul>
      </div>
      <div class="d-card v-card-acc">
        <span class="dz-lbl">Наша работа</span>
        <h3>Что чистим мы</h3>
        <ul class="d-ticks">
          <li>Внутреннюю полость зонта и короб до вентилятора — через люки, механически и щелочными средствами при остановленной кухне (п. 3.11 МР)</li>
          <li>Рабочее колесо и корпус вентилятора, участок выброса на кровле</li>
          <li>Укрываем плиты, пароконвектоматы и столы плёнкой, убираем за собой до открытия</li>
          <li>Акт очистки от горючих отложений и видео до и после — для пожарной проверки и управляющей компании</li>
        </ul>
      </div>
    </div>
    <p class="d-note" data-fade>Выжигать скопившиеся в воздуховодах жировые отложения запрещено (п. 41 «г» ППР). При ежедневной жарке и работе фритюров советуем чистить короба каждые 3–6 месяцев, а точный интервал определяем по видео на первом осмотре.</p>
  </div>
</section>

<section class="s" id="etapy">
  <div class="wrap">
    <div class="head">
      <div class="eyebrow" data-eyebrow>Порядок работ · МР <span class="nw">3.5.0396-25</span></div>
      <h2 data-split>Как проходят очистка и дезинфекция <em>на объекте</em></h2>
    </div>
    <ol class="d-steps v-steps" data-group="steps">
      <li><b>Осмотр и видеоинспекция — 0 ₽</b><span>Инженер изучает схему или паспорт вентиляции, снимает 2–3 участка на камеру, оценивает отложения и доступ к коробам.</span></li>
      <li><b>Смета и окно работ</b><span>Считаем по длине и сечению коробов, числу зонтов, вентиляторов и установок. Выбираем окно: ночь, выходные или санитарный день.</span></li>
      <li><b>Подготовка</b><span>Предупреждаем персонал, ваш специалист отключает систему, мы вешаем таблички, укрываем оборудование и снимаем решётки (пп. 3.14–3.15 МР).</span></li>
      <li><b>Очистка</b><span>Сухая механическая или жировая — по типу системы. Отходы собираем промышленным пылесосом, чтобы пыль не уходила в помещение.</span></li>
      <li><b>Дезинфекция</b><span>Средство с СГР по режиму для вентиляции, экспозиция и просушка. Систему включает ваш ответственный специалист.</span></li>
      <li><b>Контроль и документы</b><span>Видео после работ, визуальная оценка и при необходимости смывы. Акт, запись в журнал, отчёт. Неудовлетворительный результат — повторная очистка и дезинфекция (п. 4.3 МР).</span></li>
    </ol>
    <div class="d-card" style="margin-top:28px;border-color:rgba(124,134,255,.35)">
      <span class="dz-lbl">Памятка ответственному за вентиляцию</span>
      <h3 data-fade>Что подготовить к нашему приезду</h3>
      <ul class="d-ticks" style="margin-top:16px" data-group="ctalist">
        <li>Схему или паспорт вентиляции, если они есть, — так смета будет точнее, а маршрут камеры короче.</li>
        <li>Доступ на технический этаж, кровлю и в венткамеры, ключи от щитов и ревизионных люков.</li>
        <li>Специалиста, который отключит и после просушки включит систему, — по МР работы ведутся под его руководством (п. 3.6).</li>
        <li>Окно без людей в зоне работ: для кухни — после закрытия, для производства — между сменами.</li>
      </ul>
    </div>
  </div>
</section>

<section class="s" id="dokumenty">
  <div class="wrap">
    <div class="head">
      <div class="eyebrow" data-eyebrow>Отчётность</div>
      <h2 data-split>Документы после работ — <em>для МЧС, Роспотребнадзора и аудита</em></h2>
      <p class="sub" data-fade>Комплект собираем так, чтобы его можно было сразу положить в папку к проверке или аудиту ХАССП. Если журнала на объекте ещё нет, заведём его по рекомендуемой форме.</p>
    </div>
    <div class="d-split">
      <ol class="d-terms" data-group="steps">
        <li><b>Акт очистки от горючих отложений</b><span>Системы, участки, даты и исполнитель — подтверждает выполнение п. 43 ППР.</span></li>
        <li><b>Акт выполненных работ по дезинфекции</b><span>Дезсредство и номер СГР, концентрация, способ обработки, объём работ.</span></li>
        <li><b>Запись в журнал учёта работ</b><span>Рекомендуемая форма — приложение 3 к МР <span class="nw">3.5.0396-25</span> (п. 4.2).</span></li>
        <li><b>Видео- и фотоотчёт</b><span>До и после на тех же участках, со схемой мест съёмки.</span></li>
        <li><b>Копии лицензии и СГР</b><span>Лицензия Роспотребнадзора на услуги дезинфекции, дезинсекции и дератизации, свидетельство о госрегистрации и инструкция на средство.</span></li>
        <li><b>Протоколы лаборатории</b><span>Если заказаны смывы — на легионеллы и микробную обсеменённость.</span></li>
      </ol>
      <figure class="v-jr" aria-label="Пример заполнения журнала учёта работ по очистке и дезинфекции систем вентиляции" data-fade>
        <div class="v-jr-h"><b>Журнал учёта работ по проведению очистки и дезинфекции систем вентиляции и кондиционирования воздуха на объекте</b><span>Рекомендуемая форма — приложение 3 к МР <span class="nw">3.5.0396-25</span> · пример заполнения</span></div>
        <dl class="v-jr-rows">
          <div><dt>Юридическое лицо и адрес объекта</dt><dd>ООО «Ваша компания» · г. Москва</dd></div>
          <div><dt>Основной вид деятельности</dt><dd>Общественное питание, ресторан</dd></div>
          <div><dt>Дата проведения работ</dt><dd>12.11.2026</dd></div>
          <div><dt>Тип вентиляционной системы</dt><dd>Приточно-вытяжная механическая, местная вытяжка над тепловым оборудованием</dd></div>
          <div><dt>Обработано систем вентиляции</dt><dd>3 шт. — П1, В1, В2</dd></div>
          <div><dt>Площадь обработанных воздуховодов</dt><dd>46 кв. м</dd></div>
          <div><dt>Обработано местных кондиционеров</dt><dd>4 шт. — сплит-системы</dd></div>
          <div><dt>Дезсредство, концентрация, количество</dt><dd>По СГР и инструкции, 0,5 %, 6 л рабочего раствора</dd></div>
          <div><dt>Способ обработки</dt><dd>Орошение</dd></div>
          <div><dt>Организация-исполнитель</dt><dd>ООО «Центр дезинфекционных услуг», лицензия № <span class="nw">Л064-00111-77/01942445</span></dd></div>
        </dl>
        <figcaption>Пример с условными данными: реальные значения вносим по итогам работ на вашем объекте.</figcaption>
      </figure>
    </div>
  </div>
</section>

<section class="s" id="otrasli">
  <div class="wrap">
    <div class="head">
      <div class="eyebrow" data-eyebrow>Для кого</div>
      <h2 data-split>Очистка вентиляции <em>по типам объектов</em></h2>
    </div>
    <div class="v-inds" data-group="cards">
      <article class="card v-ind"><svg aria-hidden="true" focusable="false" class="lucide lucide-utensils" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M3 2v7c0 1.1.9 2 2 2h4a2 2 0 0 0 2-2V2" /> <path d="M7 2v20" /> <path d="M21 15V2a5 5 0 0 0-5 5v6c0 1.1.9 2 2 2h3Zm0 0v7" /> </svg><h3>Рестораны, кафе, фуд-корты</h3><p>Жировая очистка зонтов и коробов ночью, акт для пожарной проверки и управляющей компании.</p></article>
      <article class="card v-ind"><svg aria-hidden="true" focusable="false" class="lucide lucide-factory" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M12 16h.01" /> <path d="M16 16h.01" /> <path d="M3 19a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V8.5a.5.5 0 0 0-.769-.422l-4.462 2.844A.5.5 0 0 1 15 10.5v-2a.5.5 0 0 0-.769-.422L9.77 10.922A.5.5 0 0 1 9 10.5V5a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2z" /> <path d="M8 16h.01" /> </svg><h3>Пищевые производства</h3><p>Вытяжки над варкой, жаркой и мойкой, приток в чистые зоны, документы в папку ХАССП. <a href="../pishchevoe-proizvodstvo/"><span class="nw">Пест-контроль</span> на производстве</a></p></article>
      <article class="card v-ind"><svg aria-hidden="true" focusable="false" class="lucide lucide-pill" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="m10.5 20.5 10-10a4.95 4.95 0 1 0-7-7l-10 10a4.95 4.95 0 1 0 7 7Z" /> <path d="m8.5 8.5 7 7" /> </svg><h3>Медицинские организации</h3><p>Очистка и дезинфекция раз в год, сплит-системы — раз в 3 месяца, пылесосы с фильтрами H14 (п. 3.28 МР).</p></article>
      <article class="card v-ind"><svg aria-hidden="true" focusable="false" class="lucide lucide-building-2" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M6 22V4a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v18Z" /> <path d="M6 12H4a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2h2" /> <path d="M18 9h2a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2h-2" /> <path d="M10 6h4" /> <path d="M10 10h4" /> <path d="M10 14h4" /> <path d="M10 18h4" /> </svg><h3>Офисы и бизнес-центры</h3><p>Центральное кондиционирование: дезинфекция раз в год и анализ на легионеллы 2 раза в год.</p></article>
      <article class="card v-ind"><svg aria-hidden="true" focusable="false" class="lucide lucide-shopping-cart" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="m2.05 2.05 1.099-.028a1 1 0 0 1 1.008.815l2.69 14.347A1 1 0 0 0 7.83 18H18" /> <path d="M4.563 5h16.435a1 1 0 0 1 .981 1.204l-1.026 6.226A2 2 0 0 1 18.962 14H6.25" /> <circle cx="18" cy="20" r="2" /> <circle cx="8" cy="20" r="2" /> </svg><h3>Торговые центры и магазины</h3><p>Приток торговых залов, крышные вентиляторы, вытяжки фуд-кортов — по участкам, в ночные окна.</p></article>
      <article class="card v-ind"><svg aria-hidden="true" focusable="false" class="lucide lucide-bed-double" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M2 20v-8a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v8" /> <path d="M4 10V6a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v4" /> <path d="M12 4v6" /> <path d="M2 18h20" /> </svg><h3>Гостиницы</h3><p>Кондиционирование и увлажнение номеров и общих зон: дезинфекция, смывы, работы по этажам.</p></article>
      <article class="card v-ind"><svg aria-hidden="true" focusable="false" class="lucide lucide-graduation-cap" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M21.42 10.922a1 1 0 0 0-.019-1.838L12.83 5.18a2 2 0 0 0-1.66 0L2.6 9.08a1 1 0 0 0 0 1.832l8.57 3.908a2 2 0 0 0 1.66 0z" /> <path d="M22 10v6" /> <path d="M6 12.5V16a6 3 0 0 0 12 0v-3.5" /> </svg><h3>Школы и детские сады</h3><p>Профилактическая дезинфекция вентиляции и кондиционирования раз в год — в каникулы или выходные.</p></article>
      <article class="card v-ind"><svg aria-hidden="true" focusable="false" class="lucide lucide-warehouse" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M18 21V10a1 1 0 0 0-1-1H7a1 1 0 0 0-1 1v11" /> <path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V8a2 2 0 0 1 1.132-1.803l7.95-3.974a2 2 0 0 1 1.837 0l7.948 3.974A2 2 0 0 1 22 8z" /> <path d="M6 13h12" /> <path d="M6 17h12" /> </svg><h3>Склады и производства</h3><p>Очистка венткамер, циклонов и коробов от горючей пыли с актом по п. 43 ППР.</p></article>
    </div>
    <div class="d-card v-pest" data-fade>
      <span class="dz-lbl">Вентиляция и <span class="nw">пест-контроль</span></span>
      <h3>По коробам ходят не только воздух и пыль</h3>
      <p>Тараканы и муравьи переходят по вентиляции между помещениями и этажами, а через незащищённые продухи чердаков и подвалов в здание попадают грызуны, птицы и насекомые — в медицинских организациях такая защита прямо требуется (пп. 29 п. 24 СП <span class="nw">2.1.4284-26</span>). На очистке проверяем сетки, люки и следы вредителей и при необходимости подключаем <a href="../dezinsektsiya/">дезинсекцию</a> или <a href="../deratizatsiya/">дератизацию</a>.</p>
    </div>
  </div>
</section>

<section class="s" id="stoimost">
  <div class="wrap">
    <div class="head">
      <div class="eyebrow" data-eyebrow>Стоимость и расчёт</div>
      <h2 data-split>Сколько стоит очистка и дезинфекция <em>вентиляции</em></h2>
      <p class="sub" data-fade>Точную стоимость фиксируем в смете и договоре после бесплатного осмотра. Работаем с юридическими лицами и ИП по безналичному расчёту (с НДС и без НДС).</p>
    </div>
    <table class="d-table d-prices v-prices" data-fade>
      <caption class="sr-only">Ориентиры стоимости очистки и дезинфекции вентиляции для организаций</caption>
      <thead><tr><th scope="col">Работа</th><th scope="col">Что входит</th><th scope="col" class="d-price">Ориентир</th></tr></thead>
      <tbody>
        <tr><td data-l="Работа">Осмотр, видеоинспекция и смета</td><td data-l="Что входит">Выезд инженера, съёмка 2–3 участков, расчёт работ и окна</td><td data-l="Ориентир" class="d-price">0 ₽</td></tr>
        <tr><td data-l="Работа">Очистка воздуховодов от пыли</td><td data-l="Что входит">Щёточные машины, промышленный пылесос, видео до и после</td><td data-l="Ориентир" class="d-price">от 100 ₽ за м. п.</td></tr>
        <tr><td data-l="Работа">Жировая очистка кухонной вытяжки</td><td data-l="Что входит">Зонты, жироулавливающие фильтры, короба до вентилятора</td><td data-l="Ориентир" class="d-price">от 136 ₽ за м. п.</td></tr>
        <tr><td data-l="Работа">Дезинфекция воздуховодов</td><td data-l="Что входит">Средство с СГР по режиму для вентиляции, расчёт расхода в журнале</td><td data-l="Ориентир" class="d-price">от 45 ₽ за м. п.</td></tr>
        <tr><td data-l="Работа">Очистка радиального вентилятора</td><td data-l="Что входит">Рабочее колесо, корпус, гибкие вставки</td><td data-l="Ориентир" class="d-price">от 2 400 ₽</td></tr>
        <tr><td data-l="Работа">Очистка и дезинфекция фанкойла</td><td data-l="Что входит">Фильтр, теплообменник, дренажный поддон</td><td data-l="Ориентир" class="d-price">от 2 200 ₽</td></tr>
        <tr><td data-l="Работа">Очистка и дезинфекция сплит-системы</td><td data-l="Что входит">Фильтры, теплообменник, дренаж, дезинфекция испарителя</td><td data-l="Ориентир" class="d-price">от 1 600 ₽</td></tr>
        <tr><td data-l="Работа">Микробиологические смывы</td><td data-l="Что входит">Отбор проб и протокол аккредитованной лаборатории</td><td data-l="Ориентир" class="d-price">от 1 400 ₽</td></tr>
      </tbody>
    </table>
    <div class="d-cols2" data-group="cards">
      <div class="d-card">
        <h3>Что влияет на смету</h3>
        <p>Длина и сечение коробов, вид отложений (пыль, жир, строительный мусор), высота и доступ — фальшпотолки, шахты, число ревизионных люков, — а также количество зонтов, вентиляторов, установок и кондиционеров.</p>
      </div>
      <div class="d-card">
        <h3>Входит в каждую работу</h3>
        <p>Подготовка и укрытие оборудования, уборка после себя, видео до и после, акт и запись в журнал. Сеть объектов или несколько зданий — одна смета и общий график работ.</p>
      </div>
    </div>
  </div>
</section>


<!-- ============ СМОТРИТЕ ТАКЖЕ (перелинковка) ============ -->
<section class="s s-rel" id="smotrite-takzhe">
  <div class="wrap">
    <div class="head">
      <div class="eyebrow" data-eyebrow>Смотрите также</div>
      <h2 data-split>Связанные услуги <em>и материалы</em></h2>
    </div>
    <div class="rel-grid" data-group="cards">
      <a class="card rel-card" href="../dezinsektsiya/"><span class="rel-k">Услуга</span><span class="rel-t">Дезинсекция для организаций</span><span class="rel-d">Контроль насекомых по IPM без остановки работы, ротация средств, журнал и акты по СанПиН.</span><span class="rel-a" aria-hidden="true"><svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></span></a>
      <a class="card rel-card" href="../pishchevoe-proizvodstvo/"><span class="rel-k">Отрасль</span><span class="rel-t"><span class="nw">Пест-контроль</span> на пищевом производстве</span><span class="rel-d">Точки контроля, визиты по графику смен и документы для Роспотребнадзора, аудиторов и торговых сетей.</span><span class="rel-a" aria-hidden="true"><svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></span></a>
      <a class="card rel-card" href="../dogovor-deratizatsiya-dezinsektsiya/"><span class="rel-k">Обслуживание</span><span class="rel-t">Договор на дератизацию и дезинсекцию</span><span class="rel-d">Одно или оба направления в одном договоре: график визитов, акт после выезда, цена до подписания.</span><span class="rel-a" aria-hidden="true"><svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></span></a>
      <a class="card rel-card" href="../deratizatsiya/"><span class="rel-k">Услуга</span><span class="rel-t">Дератизация для организаций</span><span class="rel-d">Три контура защиты от крыс и мышей, контейнеры КИК и ловушки без яда в цехах, схема точек и акты.</span><span class="rel-a" aria-hidden="true"><svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></span></a>
    </div>
  </div>
</section>

<section class="s" id="voprosy">
  <div class="wrap">
    <div class="head">
      <div class="eyebrow" data-eyebrow>Вопросы и ответы</div>
      <h2 data-split>Частые вопросы об очистке <em>и дезинфекции вентиляции</em></h2>
    </div>
    <div class="faq">
      <div class="faq-col" data-group="faq">
        <div class="card qa open"><button aria-expanded="true" aria-controls="a1" id="q1">Как часто нужно чистить и дезинфицировать вентиляцию в организации?<span class="pm"></span></button><div class="ans" id="a1" role="region" aria-labelledby="q1" style="height:auto"><div><p>Не реже 1 раза в год. Очистку вентиляционных камер, циклонов, фильтров и воздуховодов от горючих отходов и отложений с составлением акта требует <a href="https://www.consultant.ru/document/cons_doc_LAW_363263/" target="_blank" rel="noopener noreferrer">п. 43 Правил противопожарного режима</a>, профилактическую дезинфекцию централизованных систем вентиляции и кондиционирования — <a href="http://pravo.gov.ru/proxy/ips/?docbody=&amp;nd=602107773&amp;rdk=0" target="_blank" rel="noopener noreferrer">п. 132 СанПиН <span class="nw">3.3686-21</span></a>. В медицинских организациях сплит-системы чистят и дезинфицируют не реже 1 раза в 3 месяца (<a href="http://publication.pravo.gov.ru/document/0001202606020088" target="_blank" rel="noopener noreferrer">пп. 22 п. 24 СП <span class="nw">2.1.4284-26</span></a>). Кухонные вытяжки при ежедневной жарке мы советуем чистить каждые 3–6 месяцев.</p></div></div></div>
        <div class="card qa"><button aria-expanded="false" aria-controls="a2" id="q2">Какие документы нужны для пожарной проверки и Роспотребнадзора?<span class="pm"></span></button><div class="ans" id="a2" role="region" aria-labelledby="q2"><div><p>Акт очистки вентиляционных систем от горючих отходов и отложений (п. 43 ППР), акт выполненных работ по дезинфекции, журнал учёта работ по очистке и дезинфекции систем вентиляции и кондиционирования (рекомендуемая форма — приложение 3 к <a href="https://www.consultant.ru/document/cons_doc_LAW_541253/" target="_blank" rel="noopener noreferrer">МР <span class="nw">3.5.0396-25</span></a>), договор с подрядчиком, копии его лицензии и свидетельства о госрегистрации дезсредства. Для централизованных систем кондиционирования и увлажнения нужны ещё протоколы исследований на легионеллы.</p></div></div></div>
        <div class="card qa"><button aria-expanded="false" aria-controls="a3" id="q3">Нужна ли лицензия на дезинфекцию вентиляции?<span class="pm"></span></button><div class="ans" id="a3" role="region" aria-labelledby="q3"><div><p>Если работы выполняет подрядчик — да: с 1 марта 2025 года деятельность по оказанию услуг дезинфекции, дезинсекции и дератизации подлежит обязательному лицензированию (Федеральный закон № 194-ФЗ). Профилактическую дезинфекцию может проводить и персонал самой организации (п. 3.2 МР <span class="nw">3.5.0396-25</span>), если сотрудники прошли специальную подготовку, медосмотр и вакцинацию (п. 3.3). У ООО «Центр дезинфекционных услуг» действующая лицензия Роспотребнадзора № <span class="nw">Л064-00111-77/01942445</span> — проверить запись можно в <a href="https://fp.rospotrebnadzor.ru/licen/?oper=search&amp;numb_history=&amp;numb=&amp;firmget_name=&amp;ogrn_inn_nza=7714462211" target="_blank" rel="noopener noreferrer">реестре Роспотребнадзора</a>.</p></div></div></div>
        <div class="card qa"><button aria-expanded="false" aria-controls="a4" id="q4">Чем очистка вентиляции отличается от дезинфекции?<span class="pm"></span></button><div class="ans" id="a4" role="region" aria-labelledby="q4"><div><p>Очистка механически удаляет пыль, жир и горючие отложения, а дезинфекция уничтожает микроорганизмы на уже очищенных поверхностях. Поэтому порядок всегда один: подготовка, очистка, дезинфекция и оценка эффективности — так алгоритм работ описан в приложении 1 к МР <span class="nw">3.5.0396-25</span>. Дезинфекция без очистки не убирает ни горючие отложения, ни питательную среду для микробов.</p></div></div></div>
        <div class="card qa"><button aria-expanded="false" aria-controls="a5" id="q5">Можно ли чистить вентиляцию без остановки ресторана или производства?<span class="pm"></span></button><div class="ans" id="a5" role="region" aria-labelledby="q5"><div><p>Объект может работать, но очищаемая система на время работ выключается, а включает её после полной просушки ответственный специалист объекта (п. 3.15 МР <span class="nw">3.5.0396-25</span>). Поэтому кухни обслуживаем ночью или в санитарный день, а производства, торговые и бизнес-центры — по участкам, в окна между сменами.</p></div></div></div>
      </div>
      <div class="faq-col" data-group="faq">
        <div class="card qa"><button aria-expanded="false" aria-controls="a6" id="q6">Сколько стоит очистка и дезинфекция вентиляции?<span class="pm"></span></button><div class="ans" id="a6" role="region" aria-labelledby="q6"><div><p>Ориентиры: очистка воздуховодов от пыли — от 100 ₽ за погонный метр, жировая очистка кухонной вытяжки — от 136 ₽ за погонный метр, дезинфекция — от 45 ₽ за погонный метр, очистка радиального вентилятора — от 2 400 ₽. Точную смету даём после бесплатного осмотра: она зависит от длины и сечения коробов, вида отложений, доступа и числа вентиляторов и установок.</p></div></div></div>
        <div class="card qa"><button aria-expanded="false" aria-controls="a7" id="q7">Как проверить, что вентиляцию действительно очистили?<span class="pm"></span></button><div class="ans" id="a7" role="region" aria-labelledby="q7"><div><p>Сравнить видео до и после на тех же участках, осмотреть решётки, зонты и рабочие колёса вентиляторов, а для медицинских организаций, гостиниц и офисов с центральным кондиционированием — получить протокол лабораторного исследования смывов. Если результат неудовлетворительный, очистку и дезинфекцию повторяют (п. 4.3 МР <span class="nw">3.5.0396-25</span>).</p></div></div></div>
        <div class="card qa"><button aria-expanded="false" aria-controls="a8" id="q8">Можно ли мыть воздуховоды водой или химией?<span class="pm"></span></button><div class="ans" id="a8" role="region" aria-labelledby="q8"><div><p>Внутренние поверхности воздуховодов чистят без воды и концентрированных кислотных и щелочных растворов. Исключение — кухонные вытяжные системы: при полной разборке или после герметизации короба и остановке приготовления пищи допускаются моющие средства, вода и пар (п. 3.11 МР <span class="nw">3.5.0396-25</span>). Выжигать жировые отложения в воздуховодах запрещено (п. 41 «г» ППР).</p></div></div></div>
        <div class="card qa"><button aria-expanded="false" aria-controls="a9" id="q9">Как часто проводится обследование технического состояния вентиляции?<span class="pm"></span></button><div class="ans" id="a9" role="region" aria-labelledby="q9"><div><p>Перед вводом здания или помещения в эксплуатацию или его реконструкцией, затем через 2 года после ввода и далее не реже 1 раза в 10 лет, с инструментальными замерами объёмов вытяжки (<a href="http://publication.pravo.gov.ru/document/0001202606020088" target="_blank" rel="noopener noreferrer">п. 8 СП <span class="nw">2.1.4284-26</span></a>, действует с 1 сентября 2026 года вместо СП <span class="nw">2.1.3678-20</span>). Обследование не заменяет очистку и дезинфекцию: у этих работ своя периодичность.</p></div></div></div>
        <div class="card qa"><button aria-expanded="false" aria-controls="a10" id="q10">Работаете ли вы с НДС и через ЭДО?<span class="pm"></span></button><div class="ans" id="a10" role="region" aria-labelledby="q10"><div><p>Да, мы работаем как с НДС, так и без НДС (УСН). Договоры, акты выполненных работ и УПД направляем через системы электронного документооборота (ЭДО) или на бумажном носителе.</p></div></div></div>
      </div>
    </div>
  </div>
</section>

<section class="cta" id="zayavka"><div class="cta-bg f-lazy" aria-hidden="true" data-parallax-bg></div><div class="cta-orb" id="orb" aria-hidden="true"></div>
  <div class="wrap">
    <div>
      <div class="eyebrow" data-eyebrow>Бесплатный осмотр</div>
      <h2 data-split>Закажите осмотр вентиляции <em>и смету</em></h2>
      <p class="sub" data-fade>Инженер приедет на объект в Москве или Московской области, снимет участки коробов на камеру, оценит отложения и доступ и подготовит смету с окном работ — ночью, в выходные или в санитарный день.</p>
      <ul class="cta-list" data-group="ctalist">
        <li><svg aria-hidden="true" focusable="false" class="lucide lucide-circle-check" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="m16 9-5.5 5.5L8 12"/></svg>Осмотр, видеоинспекция и смета по Москве и МО — 0 ₽</li>
        <li><svg aria-hidden="true" focusable="false" class="lucide lucide-circle-check" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="m16 9-5.5 5.5L8 12"/></svg>Видео до и после по каждому участку короба</li>
        <li><svg aria-hidden="true" focusable="false" class="lucide lucide-circle-check" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="m16 9-5.5 5.5L8 12"/></svg>Акт по п. 43 ППР, запись в журнал по МР <span class="nw">3.5.0396-25</span></li>
      </ul>
      <div class="cta-contacts" data-fade>
        <a class="ph" href="tel:+74951043570">+7 (495) 104-35-70</a>
        <div class="msg">
          <a href="https://max.ru/u/f9LHodD0cOIlIUXFkt4KMFP88lD8n4TArBiTcV7RI1XML5c4o39QfsDBXUc" class="max" aria-label="Написать в Max" target="_blank" rel="noopener noreferrer"><svg viewBox="0 0 24 24" fill="#fff" aria-hidden="true"><path d="M12 3a9 9 0 0 0-7.7 13.7L3 21l4.4-1.2A9 9 0 1 0 12 3zm-3.6 12.3V8.7h1.6l2 2.8 2-2.8h1.6v6.6h-1.7v-3.9L12 14l-1.9-2.6v3.9z"/></svg></a>
          <a href="https://t.me/Centr_Dezinfection?text=%D0%97%D0%B4%D1%80%D0%B0%D0%B2%D1%81%D1%82%D0%B2%D1%83%D0%B9%D1%82%D0%B5!%20%D0%9F%D0%B8%D1%88%D1%83%20%D1%81%20%D1%81%D0%B0%D0%B9%D1%82%D0%B0%20%D0%BF%D0%B5%D1%81%D1%82%D0%BA%D0%BE%D0%BD%D1%82%D1%80%D0%BE%D0%BB%D1%8C-%D1%86%D0%B5%D0%BD%D1%82%D1%80.%D1%80%D1%84" class="tg" aria-label="Написать в Telegram" target="_blank" rel="noopener noreferrer"><svg viewBox="0 0 24 24" fill="#fff" aria-hidden="true"><path d="M21.4 4.3 2.9 11.4c-1.3.5-1.2 1.2-.2 1.5l4.7 1.5 1.8 5.6c.2.6.4.8.9.8.4 0 .6-.2.9-.4l2.3-2.2 4.7 3.5c.9.5 1.5.2 1.7-.8l3.1-14.6c.3-1.3-.5-1.8-1.4-1.5zM9.6 14.1l8.6-5.4c.4-.3.8-.1.5.2l-7.1 6.4-.3 3.3z"/></svg></a>
        </div>
      </div>
    </div>
    <form class="form" id="form" novalidate>
      <div class="fbody">
        <h3>Заявка на осмотр и смету</h3>
        <p class="fs">Заполнение займёт меньше минуты</p>
        <div class="fg">
          <div class="field"><label class="sr-only" for="f-name">Ваше имя</label><input id="f-name" name="name" placeholder="Ваше имя" required autocomplete="name"><small class="ferr">Укажите имя</small></div>
          <div class="field"><label class="sr-only" for="phone">Телефон</label><input name="phone" id="phone" type="tel" inputmode="tel" placeholder="+7 (___) ___-__-__" required autocomplete="tel"><small class="ferr">Укажите телефон полностью</small></div>
          <div class="field full"><label class="sr-only" for="f-type">Тип объекта</label><select id="f-type" name="type" required><option value="" disabled selected>Тип объекта</option><option value="Ресторан или кафе">Ресторан, кафе, столовая или фуд-корт</option><option value="Пищевое производство">Пищевое производство</option><option value="Другое">Медицинская организация</option><option value="Другое">Офис или бизнес-центр</option><option value="Магазин или торговая сеть">Торговый центр или магазин</option><option value="Гостиница">Гостиница</option><option value="Другое">Школа, детский сад или спортивный объект</option><option value="Склад, логистика">Склад или логистический центр</option><option value="Фармацевтическое производство">Фармацевтическое производство</option><option value="Другое">Другое</option></select><small class="ferr">Выберите тип объекта</small></div>
          <div class="field full"><label class="sr-only" for="fk">Задача</label><select id="fk" name="task"><option value="" selected>Что нужно (необязательно)</option><option>Очистка и дезинфекция приточно-вытяжной вентиляции</option><option>Очистка кухонной вытяжки от жира</option><option>Дезинфекция кондиционеров, фанкойлов, сплит-систем</option><option>Акт и журнал к проверке МЧС или Роспотребнадзора</option><option>Договор на регулярное обслуживание</option></select></div>
          <div class="field full"><label class="sr-only" for="fm">Адрес или комментарий</label><input id="fm" name="comment" placeholder="Адрес, длина коробов или комментарий" autocomplete="street-address" maxlength="200"></div>
          <div class="field" hidden><input type="hidden" name="email" value=""></div>
          <input type="hidden" name="msg" id="fmsg" value="">
        </div>
        <button type="submit" class="btn btn-w btn-lg" id="submitBtn"><span class="btn-t">Заказать осмотр</span><svg class="btn-ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M5 12h14M13 6l6 6-6 6"/></svg><i class="spin" aria-hidden="true"></i></button>
        <p class="legal">Нажимая кнопку, вы даёте <a href="../soglasie/" target="_blank" rel="noopener">согласие на обработку персональных данных</a> и подтверждаете, что ознакомились с <a href="../privacy/" target="_blank" rel="noopener">политикой конфиденциальности</a>.</p>
      </div>
      <div class="ok" role="status" aria-live="polite">
        <svg class="ok-ic" viewBox="0 0 52 52" aria-hidden="true"><circle cx="26" cy="26" r="24" fill="none"/><path fill="none" d="M15 27l7 7 15-16"/></svg>
        <h3>Заявка отправлена</h3><p>Перезвоним в ближайшее рабочее время, чтобы согласовать день бесплатного осмотра.</p>
      </div>
    </form>
  </div>
</section>
</main>

<footer>
  <div class="wrap">
    <div class="ft">
      <div>
        <a href="../" class="logo" aria-label="ПЕСТКОНТРОЛЬ Центр — на главную"><span class="logo-mark"><svg viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="1.6" stroke-linejoin="round" aria-hidden="true"><path d="M12 2.5l7.5 3v6c0 5-3.2 8.6-7.5 10-4.3-1.4-7.5-5-7.5-10v-6z"/><circle cx="12" cy="11.5" r="2.6" stroke="#7c86ff"/><path d="M12 6.2v2.7M12 14.1v2.7M6.8 11.5h2.6M14.6 11.5h2.6" stroke="#7c86ff"/></svg></span><span class="logo-txt"><span class="logo-name">ПЕСТКОНТРОЛЬ</span> <span class="logo-sub">Центр</span></span></a>
        <p class="d"><span class="nw">Пест-контроль</span> и <span class="nw">пест-менеджмент</span> по системе IPM для бизнеса в Москве и Московской области: бесплатный аудит, оценка <span class="nw">пест-риска</span>, мониторинг вредителей и отчётность.</p>
      </div>
      <div><h4>Услуги</h4><ul><li><a href="../dezinfektsiya/">Дезинфекция для организаций</a></li><li><a href="../deratizatsiya/">Дератизация для организаций</a></li><li><a href="../dezinsektsiya/">Дезинсекция для организаций</a></li><li><a href="../sanitarnyy-audit/"><span>Санитарный аудит <span class="nw">(СЭС-аудит)</span></span></a></li><li><a href="./" aria-current="page">Очистка и дезинфекция вентиляции</a></li><li><a href="../dogovor-deratizatsiya-dezinsektsiya/">Договор на дератизацию и дезинсекцию</a></li><li><a href="../#podhod"><span><span class="nw">Пест-контроль</span> по системе IPM</span></a></li><li><a href="../#etapy">Этапы работы</a></li><li><a href="../#vrediteli">Вредители</a></li><li><a href="../#dokumenty">Документы для проверок</a></li><li><a href="../#usloviya">Цена</a></li><li><a href="../#voprosy">Вопросы</a></li></ul></div>
      <div><h4>Отрасли</h4><ul><li><a href="../pishchevoe-proizvodstvo/">Пищевые производства</a></li><li><a href="../magaziny-i-torgovye-seti/">Магазины и торговые сети</a></li><li><a href="../restorany-i-kafe/">Рестораны и кафе</a></li><li><a href="../sklady-i-logistika/">Склады и логистика</a></li><li><a href="../farmatsevticheskie-proizvodstva/">Фармацевтические производства</a></li><li><a href="../gostinitsy/">Гостиницы и отели</a></li></ul></div>
      <div><h4>Материалы</h4><ul><li><a href="../materialy/programma-pest-kontrolya/"><span>Программа <span class="nw">пест-контроля</span></span></a></li><li><a href="../materialy/zhurnal-pest-kontrolya/"><span>Журнал <span class="nw">пест-контроля</span></span></a></li><li><a href="../materialy/pest-menedzhment-ili-razovaya-obrabotka/"><span><span class="nw">Пест-менеджмент</span> или разовая обработка</span></a></li><li><a href="../materialy/programma-proizvodstvennogo-kontrolya-haccp/">Программа производственного контроля по ХАССП</a></li><li><a href="../materialy/">Все материалы</a></li></ul></div>
      <div><h4>Контакты</h4><ul><li><a href="tel:+74951043570">+7 (495) 104-35-70</a></li><li><a href="mailto:b2b@pestcontrol-center.ru">b2b@<wbr><span style="white-space:nowrap">pestcontrol-center.ru</span></a></li><li>Пн–Пт: 8:00–20:00</li><li>Срочные выезды: 24/7</li></ul>
        <div class="msg"><a href="https://max.ru/u/f9LHodD0cOIlIUXFkt4KMFP88lD8n4TArBiTcV7RI1XML5c4o39QfsDBXUc" class="max" aria-label="Написать в Max" target="_blank" rel="noopener noreferrer"><svg viewBox="0 0 24 24" fill="#fff" aria-hidden="true"><path d="M12 3a9 9 0 0 0-7.7 13.7L3 21l4.4-1.2A9 9 0 1 0 12 3zm-3.6 12.3V8.7h1.6l2 2.8 2-2.8h1.6v6.6h-1.7v-3.9L12 14l-1.9-2.6v3.9z"/></svg></a><a href="https://t.me/Centr_Dezinfection?text=%D0%97%D0%B4%D1%80%D0%B0%D0%B2%D1%81%D1%82%D0%B2%D1%83%D0%B9%D1%82%D0%B5!%20%D0%9F%D0%B8%D1%88%D1%83%20%D1%81%20%D1%81%D0%B0%D0%B9%D1%82%D0%B0%20%D0%BF%D0%B5%D1%81%D1%82%D0%BA%D0%BE%D0%BD%D1%82%D1%80%D0%BE%D0%BB%D1%8C-%D1%86%D0%B5%D0%BD%D1%82%D1%80.%D1%80%D1%84" class="tg" aria-label="Написать в Telegram" target="_blank" rel="noopener noreferrer"><svg viewBox="0 0 24 24" fill="#fff" aria-hidden="true"><path d="M21.4 4.3 2.9 11.4c-1.3.5-1.2 1.2-.2 1.5l4.7 1.5 1.8 5.6c.2.6.4.8.9.8.4 0 .6-.2.9-.4l2.3-2.2 4.7 3.5c.9.5 1.5.2 1.7-.8l3.1-14.6c.3-1.3-.5-1.8-1.4-1.5zM9.6 14.1l8.6-5.4c.4-.3.8-.1.5.2l-7.1 6.4-.3 3.3z"/></svg></a></div>
      </div>
    </div>
    <div class="fb"><span>© 2026 ПЕСТКОНТРОЛЬ Центр</span><a href="../privacy/">Политика конфиденциальности</a><a href="../soglasie/">Согласие на обработку данных</a><span>Информация на сайте не является публичной офертой</span></div>
  </div>
</footer>

<div class="mbar" id="mbar">
  <a href="tel:+74951043570" class="c1"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1 1 .4 1.9.7 2.8a2 2 0 0 1-.5 2.1L8 9.9a16 16 0 0 0 6 6l1.3-1.3a2 2 0 0 1 2.1-.4c.9.3 1.8.6 2.8.7a2 2 0 0 1 1.7 2z"/></svg>Позвонить</a>
  <a href="#zayavka" class="c2"><span>Бесплатный выезд</span></a>
</div>
<div class="fab" role="group" aria-label="Написать в мессенджер">
  <a href="https://max.ru/u/f9LHodD0cOIlIUXFkt4KMFP88lD8n4TArBiTcV7RI1XML5c4o39QfsDBXUc" class="max" aria-label="Написать в Max" target="_blank" rel="noopener noreferrer"><svg viewBox="0 0 24 24" fill="#fff" aria-hidden="true"><path d="M12 3a9 9 0 0 0-7.7 13.7L3 21l4.4-1.2A9 9 0 1 0 12 3zm-3.6 12.3V8.7h1.6l2 2.8 2-2.8h1.6v6.6h-1.7v-3.9L12 14l-1.9-2.6v3.9z"/></svg></a>
  <a href="https://t.me/Centr_Dezinfection?text=%D0%97%D0%B4%D1%80%D0%B0%D0%B2%D1%81%D1%82%D0%B2%D1%83%D0%B9%D1%82%D0%B5!%20%D0%9F%D0%B8%D1%88%D1%83%20%D1%81%20%D1%81%D0%B0%D0%B9%D1%82%D0%B0%20%D0%BF%D0%B5%D1%81%D1%82%D0%BA%D0%BE%D0%BD%D1%82%D1%80%D0%BE%D0%BB%D1%8C-%D1%86%D0%B5%D0%BD%D1%82%D1%80.%D1%80%D1%84" class="tg" aria-label="Написать в Telegram" target="_blank" rel="noopener noreferrer"><svg viewBox="0 0 24 24" fill="#fff" aria-hidden="true"><path d="M21.4 4.3 2.9 11.4c-1.3.5-1.2 1.2-.2 1.5l4.7 1.5 1.8 5.6c.2.6.4.8.9.8.4 0 .6-.2.9-.4l2.3-2.2 4.7 3.5c.9.5 1.5.2 1.7-.8l3.1-14.6c.3-1.3-.5-1.8-1.4-1.5zM9.6 14.1l8.6-5.4c.4-.3.8-.1.5.2l-7.1 6.4-.3 3.3z"/></svg></a>
</div>

<script>
/* Предпросмотр: вне рабочего домена заявка не отправляется (на пестконтроль-центр.рф этот блок не срабатывает) */
(function(){
  if(!/^(www\.)?xn----itbbsflddbfpfdodg9d0f\.xn--p1ai$/i.test(location.hostname)){
    var origFetch=window.fetch;
    window.fetch=function(u){
      if(typeof u==='string'&&u.indexOf('send.php')>-1){
        return new Promise(function(r){setTimeout(function(){r(new Response('{"success":true}',{status:200,headers:{'Content-Type':'application/json'}}))},400)});
      }
      return origFetch.apply(this,arguments);
    };
  }
  /* самопроверка: 5 пунктов */
  var box=document.getElementById('samoproverka');
  if(box){
    var cbs=box.querySelectorAll('input[type=checkbox]'),res=document.getElementById('chk-res'),note=document.getElementById('chk-note');
    var upd=function(){
      var n=0;for(var i=0;i<cbs.length;i++)if(cbs[i].checked)n++;
      res.innerHTML='<b>'+n+'</b> из '+cbs.length+' на месте';
      res.classList.toggle('warn',n<cbs.length);
      note.textContent=n===cbs.length
        ?'Все пять пунктов закрыты — продлите график, чтобы следующий акт и запись в журнале появились вовремя. Напомним о сроке и приедем в удобное окно.'
        :'Не хватает '+(cbs.length-n)+' из '+cbs.length+'. За один выезд очистим и продезинфицируем систему, оформим акт по п. 43 ППР и заведём журнал по МР 3.5.0396-25.';
    };
    for(var i=0;i<cbs.length;i++)cbs[i].addEventListener('change',upd);
  }
  /* схема воздуховода: до работ → после очистки → после дезинфекции */
  var vd=document.getElementById('vduct');
  if(vd){
    var bs=vd.querySelectorAll('.v-seg button'),caps=vd.querySelectorAll('[data-cap]'),touched=false,timers=[];
    var set=function(st){
      vd.setAttribute('data-state',st);
      for(var i=0;i<bs.length;i++)bs[i].setAttribute('aria-pressed',bs[i].getAttribute('data-s')===st?'true':'false');
      for(var j=0;j<caps.length;j++)caps[j].hidden=caps[j].getAttribute('data-cap')!==st;
    };
    for(var k=0;k<bs.length;k++)bs[k].addEventListener('click',function(){
      touched=true;timers.forEach(clearTimeout);set(this.getAttribute('data-s'));
    });
    /* один показ всех состояний, когда схема впервые видна (без автопоказа при «уменьшить движение») */
    var calm=window.matchMedia&&window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if(!calm&&'IntersectionObserver' in window){
      var vo=new IntersectionObserver(function(es){
        if(!es[0].isIntersecting)return;vo.disconnect();
        timers.push(setTimeout(function(){if(!touched)set('clean')},1800));
        timers.push(setTimeout(function(){if(!touched)set('dez')},4000));
      },{threshold:.55});
      vo.observe(vd);
    }
  }
  var lz=document.querySelectorAll('.f-lazy');
  if('IntersectionObserver' in window){
    var io=new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting){e.target.classList.add('bg-in');io.unobserve(e.target)}})},{rootMargin:'300px'});
    lz.forEach(function(el){io.observe(el)});
  }else{lz.forEach(function(el){el.classList.add('bg-in')})}
  /* заявка: тип объекта, задача, комментарий и страница — в поле msg, которое читает send.php */
  var f=document.getElementById('form');
  if(f){
    f.addEventListener('submit',function(){
      var tp=document.getElementById('f-type'),tk=document.getElementById('fk'),cm=document.getElementById('fm'),ms=document.getElementById('fmsg');
      if(ms){
        var parts=['Страница: очистка и дезинфекция вентиляции (/ochistka-dezinfektsiya-ventilyatsii/)'];
        if(tp&&tp.selectedIndex>0)parts.push('Объект: '+tp.options[tp.selectedIndex].text);
        if(tk&&tk.value)parts.push('Задача: '+tk.value);
        if(cm&&cm.value.trim())parts.push('Комментарий / адрес: '+cm.value.trim());
        ms.value=parts.join('\n');
      }
    },true);
  }
})();
</script>
<script>
  /* скрипты анимаций подключаются сразу после первой отрисовки: фото и заголовок первого экрана не ждут их загрузки */
  (function (r, l) {
    var go = function () { l.forEach(function (u) { var e = document.createElement('script'); e.src = r + u; e.async = false; document.body.appendChild(e); }); };
    if (document.visibilityState === 'hidden' || !window.requestAnimationFrame) setTimeout(go, 0);
    else requestAnimationFrame(function () { setTimeout(go, 0); });
  })('../', ['vendor/gsap.min.js', 'vendor/ScrollTrigger.min.js', 'vendor/lenis.min.js', 'app.min.js?v=20261106s2']);
</script>
<!-- Yandex.Metrika counter + UIS + Radist: загружаются после первого действия посетителя (касание, прокрутка, мышь, клавиатура) или через 5 с после загрузки страницы -->
<script type="text/javascript">
    (function (w, d) {
        w.ym = w.ym || function () { (w.ym.a = w.ym.a || []).push(arguments); };
        w.ym.l = 1 * new Date();
        ym(113675622, 'init', {ssr:true, webvisor:true, clickmap:true, ecommerce:"dataLayer", referrer: document.referrer, url: location.href, accurateTrackBounce:true, trackLinks:true});
        var done = false, ready = false, wait = null, ev = ['pointerdown', 'touchstart', 'keydown', 'scroll', 'wheel', 'mousemove'];
        w.__cs = w.__cs || [];
        w.__cs.push(['waitForTrackViewAndRun', function () { ready = true; }]);
        // Radist: код заявки в ссылках Telegram и MAX — сразу, скрипт Radist загрузится вместе со счётчиками
        var rmsg = 'Здравствуйте! Пишу с сайта пестконтроль-центр.рф. Номер заявки: {radist_tracker}';
        w.radist_tracker = w.radist_tracker || function () { (w.radist_tracker.a = w.radist_tracker.a || []).push(arguments); };
        w.radist_tracker.l = 1 * new Date();
        w.radist_tracker({ message: rmsg, whatsapp_enabled: true, tgbot_enabled: true, tg_enabled: true, max_enabled: true, vk_enabled: true });
        (function () {
            var id = null, abc = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789', s = 'ro', i, txt;
            try {
                id = sessionStorage.getItem('radistVisit');
                if (!id || id.length !== 12) {
                    for (i = 0; i < 10; i++) s += abc.charAt(Math.floor(Math.random() * abc.length));
                    sessionStorage.setItem('radistVisit', s);
                    id = sessionStorage.getItem('radistVisit');
                }
            } catch (e) { id = null; }
            if (!id || id.length !== 12) return;
            txt = encodeURIComponent(rmsg.replace(/{radist_tracker}/g, id));
            [].forEach.call(d.querySelectorAll('a[href*="//t.me/"], a[href*="//max.ru/"]'), function (a) {
                try {
                    var u = new URL(a.href), n = u.pathname.split('/')[1] || '';
                    if (u.host === 'max.ru') a.href = 'https://max.ru/' + u.pathname.substring(1) + '?start=' + id;
                    else if (u.host === 't.me' && !/bot$/i.test(n)) a.href = 'https://t.me' + u.pathname + '?text=' + txt;
                } catch (e) {}
            });
        })();
        function add(src) { var k = d.createElement('script'); k.async = true; k.src = src; d.head.appendChild(k); return k; }
        function load() {
            if (done) return; done = true;
            ev.forEach(function (e) { w.removeEventListener(e, load, true); });
            add('https://mc.yandex.ru/metrika/tag.js?id=113675622');
            var p = d.createElement('link'); p.rel = 'preconnect'; p.href = 'https://tracker.comagic.ru'; d.head.appendChild(p);
            add('https://app.uiscom.ru/static/cs.min.js?k=ICWycQx6m3NSBe3WlCeDAdAKMTmNhMHC').onerror = function () { ready = true; };
            add('https://track.radist.me/tracker.min.js');
        }
        ev.forEach(function (e) { w.addEventListener(e, load, { capture: true, passive: true }); });
        function later() { setTimeout(load, 5000); }
        if (d.readyState === 'complete') later(); else w.addEventListener('load', later);
        // Ожидание подмены номера при первом касании: набор откладывается до ответа UIS, максимум 0,8–1 с
        d.addEventListener('click', function (e) {
            if (ready) return;
            var a = e.target && e.target.closest ? e.target.closest('a[href^="tel:"]') : null;
            if (!a || e.button || e.ctrlKey || e.metaKey || e.shiftKey || e.altKey) return;
            e.preventDefault();
            if (wait) return;
            load();
            var href = a.getAttribute('href'), op = a.style.opacity, max = 'GestureEvent' in w ? 800 : 1000, t;
            function go() {
                for (var i = 0; i < wait.length; i++) clearTimeout(wait[i]);
                wait = null; ready = true; a.style.opacity = op;
                w.location.href = a.href;
            }
            function check(last) { return function () { if (wait && (last || ready || a.getAttribute('href') !== href)) go(); }; }
            wait = [];
            a.style.opacity = '.6';
            for (t = 50; t <= max; t += 50) wait.push(setTimeout(check(t === max), t));
        }, true);
    })(window, document);
</script>
<noscript><div><img src="https://mc.yandex.ru/watch/113675622" style="position:absolute; left:-9999px;" alt="" /></div></noscript>
<!-- /Yandex.Metrika counter -->
</body>
</html>
